# P0A3H — H-C0 (first immutable checkpoint) · `NO_P0A3H_EXECUTION_YET` · preflight `P0A3H_PREFLIGHT_INCOMPLETE`

This checkpoint is governed by the signed P0A3H protocol: commit `2b77d6f3be9499b5725b4f51fc41aabf7fe37400`, parent `d9d0d6ad…`, blob `bae850a9…`, signer `D4EC014EEFCC90E619D2AA59A91239ABCF512130`. It is unsigned engineering evidence, not a test result and not QC.

| Path | Content |
|---|---|
| `H-C0_INTAKE_AND_SOURCE_LEDGER.json` | Authentication results, predecessor blobs, signed archive identities, 51-file baseline and kernel pins, R2-H01 fixture, intake handoff identity |
| `H-C0_ENVIRONMENT_AND_TRUST_MODEL.md` | Measured host and binary identities; cooperative-host trust model and limits |
| `H-C0_EXPOSURE_REGISTER_AND_NEGATIVE_FINDINGS.md` | Prior exposure (P0A3G, R2, C3) and the retained negative findings |
| `H-C0_STATIC_FEASIBILITY_AND_PREFLIGHT_STATUS.md` | Static per-case record, and the factual blocker for H02–H05 preparation |
| `H-C0_CHRONOLOGY.md` | UTC chronology, including two platform safety interruptions; zero executions |
| `source_verification/` | ZIP checks of the signed archives, the signed preservation manifests, and SOURCE_LOCK and R2 external lock copies |
| `protocol/` | Signed P0A3H protocol (blob-verified copy) and the execution handoff |
| `signer_public_key_from_repo.asc` | Public key used for the signature checks (from the in-repo provenance file) |

`SHA256SUMS` covers every member except itself. `PACKAGE_INVENTORY.json` covers every member except itself and `SHA256SUMS`.

H-C1 has **not** been constructed. P0A4 is not run and not authorized. No commit, push or code freeze has been made.
