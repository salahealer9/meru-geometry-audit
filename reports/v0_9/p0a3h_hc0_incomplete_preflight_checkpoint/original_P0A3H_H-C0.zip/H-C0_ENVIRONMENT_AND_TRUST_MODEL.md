# P0A3H H-C0 — Environment identity and cooperative-host trust model (identification only)

## Measured identities (binary identification only, no candidate or test process; 2026-10-21T19:11Z)
| Item | Observed |
|---|---|
| OS | Ubuntu 24.04.5 LTS, Linux 6.18.44-fc-v139, x86_64, 2 CPUs |
| Interpreter | `/usr/bin/python3.12` (realpath identical), Python 3.12.3, SHA-256 `e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f`, which equals the pin |
| OpenSSL | `/usr/bin/openssl` OpenSSL 3.0.13, SHA-256 `b4f547c0f16272d1cc7f870330a6f2c243710c335e7a99c734ff7a0c6fdb2503`, which equals the pin |
| Python 3.13 (historical probe binary only) | `/usr/bin/python3.13`, SHA-256 `a35753ccb97941cce1467786cce892e608141f09d717188a3235d4f51a754446` |
| procfs | `/proc` mounted (type proc). The entries `exe`, `cmdline`, `environ`, `maps`, `fd` and `status` exist for the inspecting shell itself (`/proc/self`). No challenge process was started, so readability for a launched child is **not yet established**. |
| Candidate resource policy | `schemas/v0_9/p0a3g/resource_policy.json`, SHA-256 `9b7221fc…4e09`, unchanged: 8 s worker wall, 6 s CPU, 256 MiB memory, 2 MiB file and stream, NOFILE 32, concurrency 1, recursion 256, 16 MiB run disk, 64 KiB request |

The host is a cloud container session, the same host family as R2. The preferred runtime pins match, so a same-host qualification is not blocked on binary identity.

## Trust model (signed protocol §2), stated before any work
- **Assumptions:** the Linux kernel and filesystem are cooperative and non-malicious; the observer and controller are not intentionally compromised; SHA-256 is collision resistant; locked hashes are received independently.
- **Placement:** the observer and the candidate would share one host and one OS account. A second process provides separation of role, not adversarial isolation.
- **Limits of the procfs evidence:** procfs is sampled, not continuous. It cannot prove all loaded code and cannot close time-of-check/time-of-use windows. Any in-process module or import report would be self-reported supplementary evidence only.
- **Disclosures that remain in force after any outcome:** `LOADED_CODE_IDENTITY_UNVERIFIED` and `PRODUCTION_CODE_AUTHORITY_ABSENT`. A missing mandatory observation must be classified as INCONCLUSIVE.
- **Excluded claims:** no hostile-host, process-memory, trusted-boot or production-signing claim is in scope.
