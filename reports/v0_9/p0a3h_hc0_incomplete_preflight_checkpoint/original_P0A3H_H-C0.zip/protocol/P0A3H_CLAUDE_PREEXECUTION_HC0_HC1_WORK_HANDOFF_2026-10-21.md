# P0A3H — Claude pre-execution handoff (H-P0 / H-P1 only; HARD STOP at H-C1)

**Date:** 2026-10-21  
**Repository:** `salahealer9/meru-geometry-audit`  
**Branch:** `hebrew-projection-capacity-v0.9`  
**Authority:** human-signed P0A3H protocol; this document is an *execution handoff*, not an amendment to that protocol.  
**This message authorizes preparation and durable independent transfer of H-C0/H-C1 ONLY. It does not authorize H-P2, H-P3, `P0A3H_DEV_01`, any registered case execution, code freeze or P0A4.**

## A. Binding signed authority — authenticate BEFORE all H work

1. Retrieve the **complete original P0A3H protocol directly from GitHub at its immutable commit**, rather than relying on this handoff, excerpts, former agent memory or a local changed copy:

   - Signed preregistration commit: `2b77d6f3be9499b5725b4f51fc41aabf7fe37400`.
   - Required single direct parent: `d9d0d6ad5b7cc310ed14af774355aeaa2652ea89`.
   - Protocol file: `docs/v0_9/p0a3h_prospective_observed_runtime_and_loaded_code_identity_boundary_protocol_2026_10_21.md`.
   - Exact protocol Git blob: `bae850a9d94c0c30e189c5430542773488a4d83b`.
   - Required human signer fingerprint: `D4EC014EEFCC90E619D2AA59A91239ABCF512130`.
   - Expected commit diff: exactly that **one newly added Markdown file**, zero prior changes/deletions.
   - Verify branch HEAD is the new commit, not the parent. GitHub retrieval confirms the tree/diff and the human terminal recorded `VALIDSIG`; the agent should independently perform `git verify-commit` with full signer fingerprint wherever possible, carefully distinguishing cryptographic signature validity from GitHub presentation and ownertrust.

2. Read and authenticate the signed predecessor lineage and historical limitations, particularly:

   - P0A3D exact 2D SO(2) theorem `59eb47f7500d57866e4935822b78a555d3bcb515`;
   - R1 negative independent QC `d95c50ea96744ce266058c51f85fff320d1a27df`;
   - original P0A3G negative QC `0e86df64e30d081065bbeb75b6f53391e287f8f3`;
   - signed R2 protocol `7de01ab2c90afe52dd763652a9eaffd2e9a2cff9`, H04 correction `4b488825ed35c7ac91a19abe62be068e75e9a076`;
   - R2 incomplete QC preservation `e491e1e9f96391cd512db0dd528765d63bc179c1`;
   - C3 protocol `f5e31de09a8b79ddb1b5f0ba738443fc4012a390` and positive *C3-only* closeout `d9d0d6ad5b7cc310ed14af774355aeaa2652ea89`.

   **Retained negatives:** `P0A3F_R1_INDEPENDENT_QC_NOT_QUALIFIED`, `P0A3G_INDEPENDENT_QC_NOT_QUALIFIED`, `R2_QCF01_C2_PRIOR_RECEIPTS_OMITTED`, `P0A3G_R2_INDEPENDENT_QC_NOT_FULLY_QUALIFIED`. C3 administratively certified the later receipt-chain evidence; it did not retroactively repair original C2.

3. Retrieve the **actual immutable source archives from signed preservation**, not an edited local candidate:

   - Signed R2 QC preservation contains `original_P0A3G_R2_C1_REV1.zip` (197,250 bytes, SHA-256 `b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1`).
   - It embeds 51-file candidate source lock `abff7aa8df19f73e070d9f06ebd23334f8d98b45c1736d38399b845c69835902` and R2 external seven-file lock `2c8301fdfb8a313163713cacd3050a77a5a6a3d0b2f1b4f7d391791af967377b`.
   - Independently compare 51 source files against preserved original P0A3G G-CFINAL (1,271,972 bytes, SHA-256 `8b0ec808ddea05d31422ad30308d3a5bbe8aaadb860cd613adf51bdcc9f33a6a`).
   - Original R2-H01 generic request `r2_external/fixtures/R2_H01.request.json`: **735 bytes**, SHA-256 `0807f2245f10dd3ebf819f2c9be1206587a4aa55cd0f4226163bf79f5cf898fa`. Do not execute it at this stage.
   - Frozen kernels: `algebra.py` `442065847937252db00d3f63b02184c15d57989f958f764c5c731cb385de6d2d`; `core.py` `37701d034d98725673240a881420892893906c70387f68432b5993f8557dd420`; `arithmetic.py` `72b3c37f02be65b2df7616a94e84601d66cf4af5b7a50e878724de647e5bf0ba`.

**On any missing source, signature ambiguity, unexpected parent, archive mismatch, changed mathematical kernel or unauthorized workspace state, STOP with preserved negative/preflight evidence. Do not resolve an identity failure by silently replacing a source.**

## B. Absolute work boundary / no hidden test exposure

Execute in a **new isolated workspace outside the Git checkout** called `P0A3H/`, with the Git checkout and all historical signed evidence untouched. **NO COMMIT, PUSH, REBASE, RESET, tracked file changes, signing keys, or production trust-root credentials.** The earlier agent may be reused; its prior R1/G/R2 implementation and test exposure MUST be disclosed in H-C0.

Before external independent witness of H-C1, allowed operations are only source/archive retrieval, cryptographic and Git verification, source text inspection, source-file hashing, static AST/syntax parsing **without importing/launching scripts**, environment/binary identification, observer/test-source authoring **without execution**, checkpoint ZIP creation and fresh readback validation.

**Explicitly forbidden before H-C1 witness and a later separate SHA-specific human release:**

- Candidate import or invocation; running R2-H01 or any old G/H method; Python parser/controller requests; executing geometry/reference functions.
- Launching/trying the new observer, launcher, reconciler, dispatcher or individual H01–H07 checks, even as a 'smoke', 'dry', 'mock', 'preflight', 'signature check', 'import probe', 'partial suite', or demonstration. Do not start child processes intended to exercise any P0A3H test.
- Generating test-only signing keys or verifying them through the candidate as a preview; enabling `DEPLOYMENT`, changing its fail-closed policy or accessing a human production key.
- Manipulating original candidate, its three kernels, source fixtures, historical archives, or presenting newly generated receipts as original signed artifacts.

**An unregistered pre-witness invocation is a protocol breach, even if the agent calls it a dry run.** Record it faithfully and STOP. Do not cleanse chronology or use the protocol's prospective outcome label.

## C. H-P0: independent-source intake and H-C0 checkpoint

Before authoring H-C1:

1. Authenticate authority/lineage and archive bytes, internal safe paths, CRC, per-member manifest/inventory and 51-file source pins.
2. Read static candidate invocation, import, `TEST_AUTHORITY`, existing `DEPLOYMENT` rejection and external reference/evidence interfaces. Decide *from static analysis alone* whether all seven challenges can be defined without patching candidate source. Disclose any impossible interface and STOP, rather than rewrite the science or substitute a case.
3. Measure identity only (no candidate execution): operating system/kernel architecture, `/proc` availability **without running challenge processes**, pinned absolute executable locations, SHA-256, interpreter version, OpenSSL, host/process observation limitations, resource policy and proposed external observer limits.
4. Define the cooperative-host trust model. Same-host `/proc` samples cannot prove all loaded code or prevent TOCTOU: `LOADED_CODE_IDENTITY_UNVERIFIED` must remain stated even after a positive test.
5. Establish a UTC chronology and historical exposure register, including all failed/successful P0A3G prior test runs, rejected R2-C1, positive bounded R2 20/20, R2-C2 receipt omission and positive C3-only administrative closure. Avoid counting them as H trials.
6. Produce H-C0, including **`NO_P0A3H_EXECUTION_YET`**, authoritative source registers, host and scope limitations, chosen durable archive channel, manifest/inventory, actual ZIP size/SHA-256. Preserve H-C0 durably and retrieve it into a fresh, empty directory for byte-for-byte readback **before preparing H-C1**.

If H-C0 fails verification or cannot be delivered, STOP with `P0A3H_PREFLIGHT_INCOMPLETE`; no tests.

## D. H-P1: build and lock seven exact cases without execution

Implement `h_external/` source code outside the candidate tree: a launch observer, read-only test dispatcher, independent file/stream/process evidence verifier, schemas, resource/timeout specification and deterministic evidence/checkpoint packaging. Include the **actual complete source** (not pseudocode) and all required run commands, locked environment values, scripts and fixture bytes in H-C1. No dynamically downloaded/unpinned dependencies at run time; no hidden workspace-only adapter.

**The seven signed protocol cases are mandatory**. Lock in H-C1 all exact inputs, byte selections, planned negative injections, subprocess commands, capture paths, unique run IDs and typed decision rules:

| Case | Locked test contract — prepare only, DO NOT EXECUTE |
|---|---|
| **H01** clean observed launch | Real R2-H01 generic TEST_AUTHORITY request; observer measures pinned tree/interpreter/launch/environment/`/proc` relationship and stream evidence. `LOADED_CODE_IDENTITY_UNVERIFIED` persists. |
| **H02** source substitution | Lock a concrete *non-kernel* candidate Python path and predetermined byte offset/old-new value on a disposable copy. Detect before child launch. |
| **H03** executable substitution | Lock the concrete wrong path/executable and disallowed pin. Prelaunch mismatch; child must not launch. Alias/path semantics explicit. |
| **H04** import-path shadowing | Lock exact existing dependency name, shadow-module file, path, source digest, child launch configuration, observable evidence and fail-closed result. If actual loaded import cannot be demonstrated under permitted interfaces, mark `INVALID_NEGATIVE_CONTROL` or `INCONCLUSIVE` as signed—not PASS. |
| **H05** process/record replay | Lock precisely which event record will be copied between two distinct run/PID identities, how files are retained and how the independent verifier rejects it. |
| **H06** test-only vs deployment | Lock positive TEST_AUTHORITY envelope, revoked/scope-modified negative, expected rejection and unchanged `DEPLOYMENT` result `REAL_HUMAN_SIGNED_AUTHORITY_ABSENT`. Test keys only after release; no production keys. |
| **H07** aborted/missing observation | Lock a deterministic premature termination or specified missing mandatory snapshot, how raw partial/empty streams survive, and required `OBSERVATION_INCOMPLETE`/`NO_BOUND_CLAIM`. |

No 'PASS' is available for a fault that never reaches the specified boundary. A missing mandatory observation is **inconclusive**, not a source-identity match. Describe specifically which Linux `/proc/<pid>/exe`, `cmdline`, `environ`, `maps`, fd/provenance and PID/PPID/process-tree observations will be attempted, their capture timings, gaps and expected handling when unavailable. Any import report supplied from inside Python is supplementary/self-reported, not independent attestation.

Prospectively lock two distinct boundaries: the existing **candidate worker policy** (8-second wall, 6-second CPU, 256 MiB, 2 MiB streams, NOFILE 32, concurrency 1, recursion 256, 16 MiB attempt disk and 64 KiB request), and the **observer's own** separately declared limits. Preferred binary: `/usr/bin/python3.12 -I -S -B`, SHA-256 `e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f`; OpenSSL `b4f547c0f16272d1cc7f870330a6f2c243710c335e7a99c734ff7a0c6fdb2503`. A mismatch cannot be called same-host qualification.

**H-C1 must contain at least**:

- Exact signed P0A3H protocol and authenticated predecessor identification;
- Original immutable 51-file candidate + source-lock and byte-identical kernels;
- All `h_external/` scripts, auxiliary source, fixture bytes and complete per-file SHA-256 external lock;
- Predeclared complete H01→H07 test catalogue, expectations, negative controls, observation boundary and failure taxonomy;
- Actual shell/Python commands and launch arguments planned for after release (never executed before witness), test keys/public trust policy, interpreter/runtime pins and both resource envelopes;
- An independent external verifier and immutable evidence schemas, without candidate imports;
- Original exact H-C0 receipt and H-C0 SHA-256; pre-run chronology identifying **zero H invocations**; previous failure/exposure register;
- An explicit predeclared **H-C2 receipt inclusion checklist**: physical copies of original H-C0 receipt, H-C1 receipt, and later human/reviewer SHA-specific release **inside H-C2**, with post-run receipt-presence validation before saving C2; also plan CFINAL's nesting of the original C0/C1/C2 bytes, not a reconstructed copy.

Include `SHA256SUMS`, `PACKAGE_INVENTORY.json`, unique safe ZIP paths, consistent self-hash exception, complete external-source/fixture locks, a separate human-readable H-C1 lock receipt, and precise C1 size/digest. Do not represent agent-authored receipts as cryptographic human attestations.

**Before submission** retrieve H-C1 from user-accessible durable storage into a new empty location, verify original byte equality, SHA-256, ZIP CRC, all manifest/inventory identities and unchanged signed-source pins. Preserve any earlier rejected C1 attempts and their reason; a corrected pre-run lock receives a **new name, hash and independent witness**.

## E. STOP AND TRANSFER — no H-P2 until explicit review

**After H-C1 is prepared, absolutely STOP.** Provide to the human:

- H-C0 actual ZIP (or faithfully decoded ZIP from pinned base64), exact byte length and SHA-256, durable locator and fresh-readback receipt;
- H-C1 actual ZIP, byte length/SHA-256, source-lock/external-lock hashes, member counts and fresh-readback receipt;
- Complete seven-case catalogue and source identity notes; pre-execution chronology and recorded historical exposures;
- A concise statement of uncertainties/preflight limitations, and explicit declaration that **no candidate or observer has run** in H since preregistration.

These must be **user-downloadable originals**. If only base64 can be persisted, provide the unmodified full base64 and deterministic decoding instructions and hash/size checks, not just agent-owned private artifact URLs. The separate independent research chat will examine the actual delivered H-C1 bytes, source lock, feasible interfaces, case implementations, observer threat-model and H-C2 receipt plan.

**Do NOT provide a populated release string.** The release is a *future independent human action* and may only be issued after successful external witness of the exact H-C1 original ZIP:

`P0A3H-C1 LOCK WITNESSED; SHA-256 <reviewer-verified 64-character digest>; AUTHORIZE ONE P0A3H_DEV_01`

A message such as 'continue', the existence of the protocol signature or agent self-approval is **not** release. Do not proceed to H-P2 or H-P3, generate test keys, run challenge tests, assemble H-C2 or H-CFINAL, or claim PASS while awaiting external reviewer disposition. If a mandatory precondition fails, preserve the actual negative H-C0/H-C1 evidence and STOP without testing.

## F. Boundaries after the future release (for planning only, NOT authorized now)

Only a later specific release authorizes **one** H01→H07 attempt `P0A3H_DEV_01`, in immutable order, with no invisible retries/repairs, immediate fail-closed quarantine for material authority/integrity bypasses, and real raw process, file, stdout/stderr evidence. Original H-C0/H-C1 receipts and exact release must **physically be present in H-C2**, not just CFINAL. A separate H-CFINAL retains the original frozen checkpoints and a **blank** independent QC checklist. Separate research-chat QC determines any bounded process-measurement disposition; same-host observations never prove a complete loaded-code identity, production deployment or P0A4.

**Authorized agent output for this handoff only:** `P0A3H_C1_PREEXECUTION_LOCK_SUBMITTED_FOR_EXTERNAL_WITNESS` (if all preparatory checks succeed). This is not a QC disposition and not permission to start the attempt.

---

**Final instruction: authenticated intake → H-C0 (durable readback) → complete H-C1 (durable readback) → return archives and STOP. No test execution. No Git writes. No retrospective upgrading.**
