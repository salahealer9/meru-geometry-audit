# P0A3H H-C0 — Prior exposure register and retained findings (none of these are P0A3H trials)

The same executing agent implemented the P0A3E/F/G candidate code, the R2 external wrapper, driver and reconciler, and the C3 tooling. It ran all the historical tests listed below and authored all the R2 and C3 receipts. Its familiarity with the candidate source is therefore complete, and it is not independent of that source.

| Historical item | Disposition (signed) |
|---|---|
| P0A3D exact 2D SO(2) theorem `59eb47f7…` | unchanged |
| P0A3F-R1 (raw stdout evidence loss) | `P0A3F_R1_INDEPENDENT_QC_NOT_QUALIFIED` |
| P0A3G: smoke1 and smoke2 scripts, four pre-lock full-suite dry runs (one failing, three passing), then post-lock `P0A3G_DEV_01` | `P0A3G_PROSPECTIVE_DEV_LOCK_SEQUENCE_NOT_QUALIFIED`, `P0A3G_INDEPENDENT_QC_NOT_QUALIFIED` |
| R2: first R2-C1 `740da699…` rejected (R2_C1_W01), never executed; R2-C1-REV1 `b34a3cd2…` witnessed; single `P0A3G_R2_DEV_01` with 20/20 methods passed and no unexplained streams | `R2_QCF01_C2_PRIOR_RECEIPTS_OMITTED`, `P0A3G_R2_INDEPENDENT_QC_NOT_FULLY_QUALIFIED`, `P0A3G_R2_C2_PRIOR_RECEIPT_COMPLETENESS_NOT_QUALIFIED`; bounded 20/20 evidence supported |
| R2-C3 administrative receipt chain `5c57483d…` (75/75 checks) | `P0A3G_R2_C3_ADMINISTRATIVE_RECEIPT_CHAIN_QC_PASS_WITH_HISTORICAL_C2_OMISSION_PRESERVED` (C3 lane only; no retroactive repair of C2) |

The R2-H01 request fixture (`0807f224…`) was executed once in R2 (`P0A3G_R2_DEV_01`, method R2-H01). It is previously exposed and is not a holdout.

Stale earlier workspaces (`/home/claude/p0a3g`, `/home/claude/P0A3G_R2`, `/home/claude/P0A3G_R2_C3`) exist on this host. They are not used as P0A3H sources; every P0A3H source was taken from fresh signed Git objects.
