#!/usr/bin/env python3
"""Static, read-only independent H-C0 verification. NEVER imports or executes candidate code."""
from pathlib import Path
import base64,hashlib,io,json,posixpath,re,stat,zipfile

ROOT=Path('/mnt/data')
HC0=ROOT/'P0A3H_H-C0.zip'; B64=ROOT/'P0A3H_H-C0.zip.b64.txt'; RECEIPT=ROOT/'P0A3H_H-C0_RECEIPT.json'
R2=ROOT/'P0A3G_R2-C1-REV1.zip'; G=ROOT/'P0A3G_G-CFINAL.zip'
C2=ROOT/'P0A3G_R2-C2.zip'; FINAL=ROOT/'P0A3G_R2-CFINAL.zip'
PIN={
'P0A3H_H-C0.zip':('6a81791baba88a21d325d759e55664ccde9a4d87388b25ff9ff6f8c2d962f233',40590),
'P0A3H_H-C0.zip.b64.txt':('4638289bade5dd0b8e746479bbde37e3b9445503f4f379692170c2ca4a3f47a4',54833),
'P0A3G_R2-C1-REV1.zip':('b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1',197250),
'P0A3G_G-CFINAL.zip':('8b0ec808ddea05d31422ad30308d3a5bbe8aaadb860cd613adf51bdcc9f33a6a',1271972),
'P0A3G_R2-C2.zip':('860d93dce952a73b65b097e3f7b4da420c0a327ee0ca8b6d4c213865db2d1cbb',1388186),
'P0A3G_R2-CFINAL.zip':('7c9770d15a3a578f61def2571813d84baadda34bfe3d31cfc1b5cdd722a51eb4',1224562)}
P0A3H_PROTOCOL_SHA='adee859bcaa573a1f21e16cda48a733f65f79d519f99f3c6a053089abc978322'
P0A3H_PROTOCOL_BLOB='bae850a9d94c0c30e189c5430542773488a4d83b'
R2_SOURCE_SHA='abff7aa8df19f73e070d9f06ebd23334f8d98b45c1736d38399b845c69835902'
R2_EXTERNAL_SHA='2c8301fdfb8a313163713cacd3050a77a5a6a3d0b2f1b4f7d391791af967377b'
R2_H01_SHA='0807f2245f10dd3ebf819f2c9be1206587a4aa55cd0f4226163bf79f5cf898fa'
results=[]
def check(label, condition, details=None):
    results.append({'check':label,'pass':bool(condition),'detail':details})
    if not condition: print('FAIL:',label,details)
def sha(data):return hashlib.sha256(data).hexdigest()
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
for name,(digest,size) in PIN.items():
    f=ROOT/name
    check('outer_sha_size:'+name, f.exists() and f.stat().st_size==size and sha(f.read_bytes())==digest,
          {'expected_bytes':size,'expected_sha256':digest})

base64_file=B64.read_bytes(); decoded=base64.b64decode(base64_file)
check('b64_decodes_byte_identical_to_H-C0',decoded==HC0.read_bytes())
receipt=json.loads(RECEIPT.read_text())
check('receipt_pin',receipt.get('archive',{}).get('bytes')==40590 and receipt.get('archive',{}).get('sha256')==PIN['P0A3H_H-C0.zip'][0]);
check('receipt_status',receipt.get('preflight_status')=='P0A3H_PREFLIGHT_INCOMPLETE' and receipt.get('execution_status')=='NO_P0A3H_EXECUTION_YET' and receipt.get('h_c1')=='NOT CONSTRUCTED')

with zipfile.ZipFile(HC0) as h,zipfile.ZipFile(R2) as r,zipfile.ZipFile(G) as g:
    names=h.namelist();members={name:h.read(name) for name in names}
    check('member_count_20',len(names)==20)
    check('member_unique',len(names)==len(set(names)))
    check('zip_crc',h.testzip() is None)
    for entry in h.infolist():
        name=entry.filename
        safe=(name==posixpath.normpath(name) and not name.startswith(('/', '\\')) and not re.match(r'^[A-Za-z]:',name)
              and '..' not in name.split('/') and '\\' not in name)
        mode=(entry.external_attr>>16)
        check('safe_regular:'+name,safe and not entry.is_dir() and not stat.S_ISLNK(mode) and not stat.S_ISDIR(mode))
    sums={}
    for line in members['SHA256SUMS'].decode().splitlines():
        mat=re.fullmatch(r'([a-f0-9]{64})  (.+)',line)
        check('sha256sums_syntax:'+str(len(sums)),mat is not None)
        if mat: sums[mat.group(2)]=mat.group(1)
    check('sha256sums_19_cover_n_minus_1',len(sums)==19 and set(sums)==set(names)-{'SHA256SUMS'})
    for path,digest in sums.items():check('sha256sum_member:'+path,sha(members[path])==digest)
    inv=json.loads(members['PACKAGE_INVENTORY.json'])
    invfiles={x['path']:(x['bytes'],x['sha256']) for x in inv['payload_files']}
    check('inventory_18_cover_n_minus_2',len(invfiles)==18 and set(invfiles)==set(names)-{'PACKAGE_INVENTORY.json','SHA256SUMS'})
    for path,(size,digest) in invfiles.items():check('inventory_member:'+path,len(members[path])==size and sha(members[path])==digest)

    proto=members['protocol/p0a3h_protocol.md']
    check('signed_protocol_copy_SHA256',sha(proto)==P0A3H_PROTOCOL_SHA)
    check('signed_protocol_copy_git_blob',blob(proto)==P0A3H_PROTOCOL_BLOB)
    sourcemem=members['source_verification/SOURCE_LOCK_from_signed_R2-C1-REV1.json']
    externalmem=members['source_verification/R2_EXTERNAL_LOCK_from_signed_R2-C1-REV1.json']
    check('source_lock_PIN',sha(sourcemem)==R2_SOURCE_SHA)
    check('source_lock_matches_separate_witness',sourcemem==r.read('lock/SOURCE_LOCK.json'))
    check('external_lock_PIN',sha(externalmem)==R2_EXTERNAL_SHA)
    check('external_lock_matches_separate_witness',externalmem==r.read('lock/R2_EXTERNAL_LOCK.json'))
    check('r2_h01_fixture_identity',sha(r.read('r2_external/fixtures/R2_H01.request.json'))==R2_H01_SHA)
    lock=json.loads(sourcemem)['files']
    check('source_lock_51_count',len(lock)==51)
    for path,attrs in lock.items():
        a=r.read('candidate/'+path); b=g.read('candidate/'+path)
        check('locked_candidate_and_original_g:'+path,a==b and len(a)==attrs['bytes'] and sha(a)==attrs['sha256'])

    k=json.loads(members['H-C0_INTAKE_AND_SOURCE_LEDGER.json'])
    check('ledger_protocol_identity',k['p0a3h_protocol']['commit']=='2b77d6f3be9499b5725b4f51fc41aabf7fe37400' and k['p0a3h_protocol']['git_blob']==P0A3H_PROTOCOL_BLOB)
    check('ledger_original_archives_identity',all(k['signed_archives'].get(orig,{}).get('sha256')==digest for orig,digest in {
      'original_P0A3G_R2_C1_REV1.zip':PIN['P0A3G_R2-C1-REV1.zip'][0],
      'original_P0A3G_G-CFINAL.zip':PIN['P0A3G_G-CFINAL.zip'][0],
      'original_P0A3G_R2_C2.zip':PIN['P0A3G_R2-C2.zip'][0],
      'original_P0A3G_R2_CFINAL.zip':PIN['P0A3G_R2-CFINAL.zip'][0]}.items()))
    check('key_copy_corresponds_to_ledger',sha(members['signer_public_key_from_repo.asc'])==k['gpg']['method'].split('key file sha256 ')[1].split(')')[0])
    s=members['H-C0_STATIC_FEASIBILITY_AND_PREFLIGHT_STATUS.md'].decode()
    chron=members['H-C0_CHRONOLOGY.md'].decode()
    readme=members['README.md'].decode()
    check('blocker_retained',all(x in s for x in ['P0A3H_PREFLIGHT_INCOMPLETE','H02','H03','H04','H05','platform','Not assessed to completion']))
    check('chronology_two_interruptions', 'Safety interruption 1' in chron and 'Safety interruption 2' in chron)
    check('no_hc1_and_no_p0a3h_execution_attested', all(x in readme+chron for x in ['NO_P0A3H_EXECUTION_YET','H-C1']))
    check('underlying_negative_preserved',all(x in members['H-C0_EXPOSURE_REGISTER_AND_NEGATIVE_FINDINGS.md'].decode() for x in ['P0A3F_R1_INDEPENDENT_QC_NOT_QUALIFIED','P0A3G_INDEPENDENT_QC_NOT_QUALIFIED','P0A3G_R2_INDEPENDENT_QC_NOT_FULLY_QUALIFIED']))

out={'review':'P0A3H_HC0_INDEPENDENT_PREFLIGHT_REVIEW_2026_10_21','checks':len(results),'passed':sum(x['pass'] for x in results),'failed':[x for x in results if not x['pass']], 'qc': 'H-C0_ARCHIVE_INTEGRITY_SUPPORTED_PREFLIGHT_INCOMPLETE' if all(x['pass'] for x in results) else 'H-C0_INTEGRITY_INCOMPLETE', 'scope_limits':['Original private-workspace chronology, safety-platform events, no-execution and fresh durable readback are agent attestations, not independently observed.','Environment executable identity is reported from the agent host but not independently re-measured by this reviewer.','No H-C1, H01-H07 execution, loaded-code attestation, P0A4 or code freeze is qualified.'],'pinned_original_hc0_sha256':PIN['P0A3H_H-C0.zip'][0]}
output=ROOT/'P0A3H_HC0_INDEPENDENT_VERIFICATION_2026-10-21.json'; output.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='failed'},indent=2))
if out['failed']:raise SystemExit(2)
