# P0A3H-L1 — Independent Runtime-Pin Preflight Blocker Review

**Date:** 2026-10-21  
**Scope:** passive imported archive/JSON source-integrity review; **no candidate, observer, H01–H07 or cryptographic challenge execution**.  
**Signed prospective L1 protocol:** `39364f5a4345c8b60a879f6411b8d80cc6c299c6` (one-file addition; human GPG proof reported separately).  
**Inherited original P0A3H incomplete H-C0:** unchanged; source/safety interruptions are historical and not L1 tests.

## Evidence and exact identities

- Original verified **L1-C0** 105,474 bytes, SHA-256 `774e58c72921bdf97cf14cd9628278c4bab1c327086e9297879c8a46b4117e3a`; prior separate QC conclusion `P0A3H_L1_C0_INDEPENDENT_BYTE_AND_SOURCE_QC_PASS` is **retained**.
- Original uploaded **passive runtime audit JSON** 3,646 bytes, SHA-256 `3b7dcc3bc0f0f17e90cf28fb1d9d9c8cb1bc0bc37bae963a06da2d3f2a602ca8`; reported collection time `2026-10-21T20:14:16Z`.
- Independently compared to original signed-preserved R2-C1-REV1 ZIP `b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1` and to original G-CFINAL ZIP `8b0ec808ddea05d31422ad30308d3a5bbe8aaadb860cd613adf51bdcc9f33a6a` (retained separately in earlier human-signed repository evidence, not duplicated in this checkpoint).
- Independent static reconciling assertions in accompanying machine-readable ledger: **34/34 PASS**. These are deterministic file assertions, not scientific challenges or proof of a trusted host.

## Direct observed findings within supplied evidence

1. Original immutable `candidate/schemas/v0_9/p0a3g/resource_policy.json` pins **`/usr/bin/python3.12`** to SHA-256 `e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f`. Passive local audit records that path missing.
2. Same original policy pins **`/usr/bin/openssl`** to `b4f547c0f16272d1cc7f870330a6f2c243710c335e7a99c734ff7a0c6fdb2503`. Local audit finds the binary exists but hashes to **`66521161cfad981e189bbc746560e0cc71a141b3765b3fe3658704d877c6ad7d`**, therefore not the pinned original.
3. Original candidate `identity.py` uses `/usr/lib/python3.12` as its standard-library identity base. All **11/11** standard-library paths sampled in the audit were absent. The audit contains no expected individual file hashes for these paths, so nonexistence is proven *within the submitted local observations*, while restoring exact expected identities requires further source-based verification.
4. Original `supervisor.py` hashes the absolute interpreter binary and returns `ENVIRONMENT_UNQUALIFIED / INTERPRETER_IDENTITY` on mismatch **before child launch**. These are mandatory candidate-internal checks, not merely optional external test-harness preferences.
5. The passive collector uses CPython **3.11.2**. The signed L1 protocol allows an explicitly declared cross-host comparison, but does **not** authorize patching candidate-internal fixed policy, identity.py, supervisor.py, OpenSSL hash, symlink aliases or the 51 original source files.

## Independent disposition

**`P0A3H_L1_PREFLIGHT_INCOMPLETE`** — reason **`ABSOLUTE_RUNTIME_PINS_UNSATISFIED`**. No full L1-C1 lock has been built or independently witnessed; `P0A3H_L1_DEV_01` remains **NOT AUTHORIZED**. No H01–H07 execution took place as part of this independent review. The operator's own no-execution declaration and local file-existence observations remain **self-reported host evidence**, not remotely verified hardware/process telemetry.

The positive C0 byte/source QC **is not revoked**. This blocked runtime is an implementation/host-feasibility failure **before** an experiment, not evidence that the mathematical QO theorem or registered adversarial challenges are false. The unresolved H04 import-path observation boundary is a separate pre-lock blocker.

## Allowed future decisions, neither granted here

**A. Exact original-environment recovery:** locate provenances and exact original CPython, OpenSSL and standard-library bytes, and provision them in an appropriately isolated, specifically pinned host/container where required *internal absolute paths* are satisfied. Verify their **actual** digests and observation/resource bounds *before any L1-C1 witness or registered execution*. Installing any Python 3.12 build by name, adding symlinks or replacing binaries on the user's everyday OS is not equivalent to signed-pinned recovery; do not tamper with the normal `/usr/bin` environment. If original bytes cannot be recovered or safely provisioned, stop.

**B. New prospective portability research:** preregister a **separately named and human-signed portability experiment** acknowledging that any changed runtime binding or changed 51-file candidate has a **new software identity**. Do not call it an execution of the unchanged registered L1 candidate or upgrade R2/P0A3H outcomes. Source differences must be explicitly declared and locked before any test.

Historical negative QC remains intact; `LOADED_CODE_IDENTITY_UNVERIFIED`, `PRODUCTION_CODE_AUTHORITY_ABSENT`, and `P0A4 NOT RUN / NOT AUTHORIZED` remain mandatory. This note authorizes **no test**, code freeze, production signing, Git modification by any agent, or protocol amendment. Human-only evidence preservation may be considered separately.
