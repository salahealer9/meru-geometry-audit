# L1-C0 unresolved engineering gates

- Local host is **cross-host** relative to original R2 (CPython 3.11.2 versus 3.12.3, OpenSSL binary differs). This is acceptable only as prospective cross-host L1 evidence.
- Existing host soft RLIMIT_CPU, RLIMIT_AS and RLIMIT_FSIZE are unlimited; registered candidate limits must be explicitly enforced by a locked controller, not inherited by assumption.
- `/proc/self` visibility is not a qualification of snapshots for actual launched child; mandatory `/proc/<pid>` observation feasibility remains untested before L1-C1 source witness.
- Compatibility of frozen candidate source and specific 3.11.2 interpreter is not established by static file equality. No import or trial is allowed before source-lock release.
- The seven exact H01–H07 case adapters, especially observable H04 import-shadow activation, are NOT IMPLEMENTED or qualified by L1-C0.
- Authorship is not independent: GPT-6 wrote the passive intake and C0 builder. A genuinely separate source-design reviewer is needed to claim developer-independent source review of future tests.
- No production key, deployment authority, hostile-host attestation, loaded-code identity proof, P0A4 or Hebrew target study is authorized.
