#!/usr/bin/env python3
"""P0A3H-L1: archive-only L1-C0 builder. No candidate imports or tests.

Authorship: GPT-6 (ChatGPT), 2026-10-21. Independent code review: NOT established.
The user's explicit CLI assertion about no prior L1 tests is not external telemetry.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import zipfile

HEAD = '39364f5a4345c8b60a879f6411b8d80cc6c299c6'
PARENT = '1120360074462c09863b45b85b64dc2b3f733626'
BRANCH = 'hebrew-projection-capacity-v0.9'
KEY = 'D4EC014EEFCC90E619D2AA59A91239ABCF512130'
BLOB = '6a574b7a6b442ed909d9c294341b3865c8be6020'
PROTOCOL = 'docs/v0_9/p0a3h_l1_prospective_local_operator_runtime_identity_qualification_protocol_2026_10_21.md'
ORIGINAL_H_PROTOCOL = 'docs/v0_9/p0a3h_prospective_observed_runtime_and_loaded_code_identity_boundary_protocol_2026_10_21.md'
H_CLOSEOUT = 'docs/v0_9/p0a3h_hc0_incomplete_preflight_independent_qc_preservation_2026_10_21.md'
ORIGINALS = {
    'R2-C1-REV1': ('reports/v0_9/p0a3g_r2_independent_qc_incomplete_checkpoint/original_P0A3G_R2_C1_REV1.zip', 197250, 'b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1'),
    'G-CFINAL': ('reports/v0_9/p0a3g_independent_qc_incomplete_checkpoint/original_P0A3G_G-CFINAL.zip', 1271972, '8b0ec808ddea05d31422ad30308d3a5bbe8aaadb860cd613adf51bdcc9f33a6a'),
    'historical-H-C0': ('reports/v0_9/p0a3h_hc0_incomplete_preflight_checkpoint/original_P0A3H_H-C0.zip', 40590, '6a81791baba88a21d325d759e55664ccde9a4d87388b25ff9ff6f8c2d962f233'),
}
H_RECEIPT = 'reports/v0_9/p0a3h_hc0_incomplete_preflight_checkpoint/original_P0A3H_H-C0_RECEIPT.json'
PINNED_INTAKE_SHA = '731cf300572617f7e95c0ce0613be922e21a08d89e4cb399770dad55d5d39202'
KERNELS = {
    'src/meru_geometry/v0_9/qo2d_exact/algebra.py': '442065847937252db00d3f63b02184c15d57989f958f764c5c731cb385de6d2d',
    'src/meru_geometry/v0_9/qo2d_exact/core.py': '37701d034d98725673240a881420892893906c70387f68432b5993f8557dd420',
    'reference/v0_9/qo2d_exact/arithmetic.py': '72b3c37f02be65b2df7616a94e84601d66cf4af5b7a50e878724de647e5bf0ba',
}

def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def canonical(v) -> bytes:
    return (json.dumps(v, sort_keys=True, indent=2, ensure_ascii=False) + '\n').encode('utf-8')

def required(condition, msg):
    if not condition:
        raise RuntimeError('FAIL_CLOSED: ' + msg)

def cmd(argv, cwd: Path):
    p = subprocess.run(argv, cwd=cwd, capture_output=True, text=True, timeout=45, check=False)
    required(p.returncode == 0, f'command failed: {argv!r}: {p.stderr[:300]}')
    return p.stdout.strip(), p.stderr

def regular_safe_zip(z):
    names=z.namelist()
    required(len(names)==len(set(names)), 'duplicate ZIP names')
    for info in z.infolist():
        name=info.filename
        parts=PurePosixPath(name).parts
        required(name and not name.startswith('/') and '\\' not in name and '..' not in parts and not info.is_dir(),f'unsafe ZIP name: {name!r}')
        mode=info.external_attr >> 16
        required(stat.S_IFMT(mode) in (0,stat.S_IFREG), f'non-regular ZIP member: {name!r}')
    required(z.testzip() is None, 'ZIP CRC mismatch')
    return names

def validate_archive(path:Path, size:int|None=None, digest:str|None=None):
    raw=path.read_bytes()
    if size is not None: required(len(raw)==size, f'archive size mismatch: {path.name}')
    if digest is not None: required(sha(raw)==digest, f'archive SHA-256 mismatch: {path.name}')
    with zipfile.ZipFile(path) as z:
        ns=regular_safe_zip(z)
        required('SHA256SUMS' in ns and 'PACKAGE_INVENTORY.json' in ns, 'archive manifest missing')
        lines=z.read('SHA256SUMS').decode('utf-8').splitlines()
        sums={}
        for line in lines:
            m=re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
            required(m is not None, 'malformed SHA256SUMS entry')
            digest_line,name=m.group(1),m.group(2)
            required(name not in sums, 'duplicate SHA256SUMS row')
            sums[name]=digest_line
        required(set(sums)==set(ns)-{'SHA256SUMS'}, 'SHA256SUMS incomplete or excess')
        for n in sums:
            required(sha(z.read(n))==sums[n], f'archive checksum mismatch: {n}')
        inv=json.loads(z.read('PACKAGE_INVENTORY.json'))
        # historical archive format: inventory items may be named payload_files or files
        rows=inv.get('payload_files', inv.get('files'))
        required(isinstance(rows,list), 'inventory payload list missing')
        require_names=[row.get('path') for row in rows]
        required(len(require_names)==len(set(require_names)), 'inventory duplicate row')
        required(set(require_names)==set(ns)-{'SHA256SUMS','PACKAGE_INVENTORY.json'}, 'inventory coverage mismatch')
        for row in rows:
            b=z.read(row['path'])
            required(len(b)==row['bytes'] and sha(b)==row['sha256'], f'inventory mismatch: {row["path"]}')
        return {'bytes':len(raw),'sha256':sha(raw),'members':len(ns), 'checksum_rows':len(sums), 'inventory_rows':len(rows)}

def validate_intake(intake:Path,receipt:Path):
    v=validate_archive(intake,16906,PINNED_INTAKE_SHA)
    r=json.loads(receipt.read_text('utf-8'))
    required(r['sha256']==PINNED_INTAKE_SHA and r['bytes']==16906 and r['L1_C0']=='NOT BUILT' and r['registered_tests']=='NOT RUN','intake receipt mismatch')
    with zipfile.ZipFile(intake) as z:
        report=json.loads(z.read('P0_INTAKE_RESULTS.json'))
        required(all(c=='PASS' for c in report['checks'].values()) and len(report['checks'])==26 and not report['blocking_errors'],'intake recorded checks not clean')
        required(report['signed_protocol_commit']==HEAD and report['L1_C0']=='NOT BUILT' and report['L1_C1']=='NOT BUILT','intake chronology or authority mismatch')
        required(sha(z.read('P0_COLLECTOR_SOURCE.py'))==report['intake_script_sha256'],'intake collector not preserved')
    return v,report

def blob(repo:Path, path:str, expected:str):
    value,_=cmd(['git','rev-parse',f'HEAD:{path}'],repo)
    required(value==expected, 'Git blob wrong: '+path)

def zip_create(path:Path, payloads:dict[str,bytes]):
    names=set(payloads)
    required(all(n and not n.startswith('/') and '..' not in PurePosixPath(n).parts and '\\' not in n for n in names),'unsafe output member')
    inv={'excludes':['PACKAGE_INVENTORY.json','SHA256SUMS'], 'payload_count':len(names), 'payload_files':[
        {'path':n,'bytes':len(payloads[n]),'sha256':sha(payloads[n])} for n in sorted(names)]}
    all_members=dict(payloads)
    all_members['PACKAGE_INVENTORY.json']=canonical(inv)
    all_members['SHA256SUMS']=''.join(sha(all_members[n])+'  '+n+'\n' for n in sorted(all_members)).encode()
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=False) as z:
        for n in sorted(all_members):
            data=all_members[n]
            info=zipfile.ZipInfo(n,date_time=(2026,10,21,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=(stat.S_IFREG|0o644)<<16
            z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    return validate_archive(path)

def main():
    ap=argparse.ArgumentParser(description='P0A3H-L1 archive-only C0 generator; does not run candidate/tests')
    ap.add_argument('--repo',type=Path,required=True)
    ap.add_argument('--intake-zip',type=Path,required=True)
    ap.add_argument('--intake-receipt',type=Path,required=True)
    ap.add_argument('--output-root',type=Path,required=True)
    ap.add_argument('--affirm-no-l1-tests',action='store_true',help='Human operator declaration, not independent proof')
    args=ap.parse_args()
    required(args.affirm_no_l1_tests,'human operator must explicitly affirm no registered L1 test executions')
    repo=args.repo.resolve(strict=True)
    required((repo/'.git').exists(),'repository root missing .git')
    required(args.intake_zip.is_file() and args.intake_receipt.is_file(),'intake originals missing')
    intake_verification,intake=validate_intake(args.intake_zip,args.intake_receipt)
    branch,_=cmd(['git','symbolic-ref','--short','HEAD'],repo)
    head,_=cmd(['git','rev-parse','HEAD'],repo)
    parent,_=cmd(['git','show','-s','--format=%P','HEAD'],repo)
    remote,_=cmd(['git','ls-remote','origin','refs/heads/'+BRANCH],repo)
    status,_=cmd(['git','status','--porcelain'],repo)
    verified_sig,details=cmd(['git','verify-commit','--raw','HEAD'],repo)
    signer,_=cmd(['git','log','-1','--format=%G?%n%GF','HEAD'],repo)
    required(branch==BRANCH and head==HEAD and parent==PARENT,'signed L1 commit mismatch')
    required(remote.split()[0]==HEAD and status=='','remote diverged or Git checkout dirty')
    required(signer=='G\n'+KEY and ('VALIDSIG '+KEY) in details,'local GPG signature not verified with expected fingerprint')
    blob(repo,PROTOCOL,BLOB)
    pbytes=(repo/PROTOCOL).read_bytes()
    required(sha(pbytes)=='a42feb39335e501f27ce5de64bce0bcf6a2995d6847819fcc4acea7f607c8f18','L1 protocol content SHA mismatch')
    blob(repo,ORIGINAL_H_PROTOCOL,'bae850a9d94c0c30e189c5430542773488a4d83b')
    blob(repo,H_CLOSEOUT,'1335e1a192f3cfcc510f5c6640d1cf5fd0668b65')
    original_bytes={}
    original_meta={}
    for label,(p,size,digest) in ORIGINALS.items():
        f=repo/p
        original_meta[label]={'path':p,**validate_archive(f,size,digest)}
        original_bytes[label]=f.read_bytes()
    hrec_bytes=(repo/H_RECEIPT).read_bytes()
    hrec=json.loads(hrec_bytes)
    required(hrec.get('archive',{}).get('sha256','6a81791baba88a21d325d759e55664ccde9a4d87388b25ff9ff6f8c2d962f233')=='6a81791baba88a21d325d759e55664ccde9a4d87388b25ff9ff6f8c2d962f233','historical receipt mismatch')
    with zipfile.ZipFile(repo/ORIGINALS['R2-C1-REV1'][0]) as r2, zipfile.ZipFile(repo/ORIGINALS['G-CFINAL'][0]) as g:
        source_bytes=r2.read('lock/SOURCE_LOCK.json')
        ext_bytes=r2.read('lock/R2_EXTERNAL_LOCK.json')
        policy_bytes=r2.read('candidate/schemas/v0_9/p0a3g/resource_policy.json')
        fixture_bytes=r2.read('r2_external/fixtures/R2_H01.request.json')
        required(sha(source_bytes)=='abff7aa8df19f73e070d9f06ebd23334f8d98b45c1736d38399b845c69835902','source lock identity')
        required(sha(ext_bytes)=='2c8301fdfb8a313163713cacd3050a77a5a6a3d0b2f1b4f7d391791af967377b','external lock identity')
        required(sha(policy_bytes)=='9b7221fcfb54dc313874c9873423001ae7856b3a1889f12b92f9638abd904e09','R2 policy identity')
        required(len(fixture_bytes)==735 and sha(fixture_bytes)=='0807f2245f10dd3ebf819f2c9be1206587a4aa55cd0f4226163bf79f5cf898fa','fixture identity')
        source=json.loads(source_bytes)
        original_files=source['files']
        required(len(original_files)==51,'expected 51 candidate source files')
        rows=[]
        for name,entry in sorted(original_files.items()):
            b=r2.read('candidate/'+name)
            required(len(b)==entry['bytes'] and sha(b)==entry['sha256'],'R2 candidate mismatch: '+name)
            required(g.read('candidate/'+name)==b,'R2 vs G-CFINAL candidate mismatch: '+name)
            if name in KERNELS: required(sha(b)==KERNELS[name],'kernel SHA mismatch: '+name)
            rows.append({'path':name,'bytes':len(b),'sha256':sha(b),'original_R2_vs_G_CFINAL':'BYTE_IDENTICAL'})
    # Only static host observations; do not spawn any candidate/observer/worker process.
    now=dt.datetime.now(dt.timezone.utc).isoformat()
    current_python=Path(sys.executable).resolve()
    current_python_sha=sha(current_python.read_bytes())
    host=intake['host']
    required(current_python_sha==host['python_binary_sha256'], 'current Python differs from intake (new baseline needed)')
    current_openssl=Path(host['openssl_executable']).resolve()
    required(sha(current_openssl.read_bytes())==host['openssl_binary_sha256'],'OpenSSL differs from intake (new baseline needed)')
    required(os.uname().machine==host['architecture'] and os.uname().release==host['kernel'],'OS machine/kernel changed since intake')
    output_root=args.output_root.expanduser().resolve()
    required(not (output_root==repo or repo in output_root.parents),'output root must be outside signed checkout')
    output_root.mkdir(parents=True,exist_ok=True)
    t=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    out=output_root/('L1_C0_'+t)
    required(not out.exists(),'checkpoint output already exists; do not overwrite')
    out.mkdir(mode=0o700)
    self_bytes=Path(__file__).resolve().read_bytes()
    input_facts={
        'L1_protocol_commit':HEAD,'L1_protocol_blob':BLOB,
        'local_checkout_branch':branch,'signed_commit_parent':PARENT,'local_signature_report':'git verify-commit valid with expected fingerprint; ownertrust not independently established',
        'originals':original_meta,'intake':intake_verification,
        'source_files':51,'frozen_kernels':KERNELS,
    }
    operator={
        'asserted_by':'HUMAN_LOCAL_OPERATOR_USING_EXPLICIT_CLI_FLAG',
        'assertion_time_utc':now,
        'statement':'NO_L1_TEST_EXECUTION_YET; no H01-H07, candidate, observer or worker launched for L1, no smoke/dry/cryptographic trial',
        'independence':'SELF_REPORTED_OPERATOR_ASSERTION_NOT_TELEMETRY',
        'project_roles':{
            'operator':'HUMAN_REPOSITORY_OWNER_LOCAL_LINUX',
            'intake_script_author':'ChatGPT GPT-6',
            'C0_builder_author':'ChatGPT GPT-6',
            'observer_source_author':'NOT PREPARED',
            'independent_design_reviewer':'NOT YET APPOINTED',
            'L1_C1_witness':'NOT AUTHORIZED',
            'L1_dev_release':'NOT AUTHORIZED'
        },
    }
    chronology=f'''# L1-C0 prospective local chronological record\n\n- Signed L1 protocol commit: `{HEAD}`; direct parent `{PARENT}`.\n- Original P0A3H H-C0: **historical**, `P0A3H_PREFLIGHT_INCOMPLETE`; two reported platform safety interruptions; no H-C1 was formed.\n- Original local passive intake collected at `{intake['start_utc']}` through `{intake['end_utc']}`. The operator uploaded its original archive and independent review found no integrity discrepancy.\n- Official L1-C0 assembly: `{now}`, after the original intake.\n- Human operator's explicit no-L1-tests declaration at assembly: **self-report only, not proof about hidden activity**.\n- L1-C1: **NOT BUILT**. L1_DEV_01: **NOT AUTHORIZED / NOT RUN by this archival tool**.\n- The C0 builder reads authenticated files, hashes and archives data; it never imports/launches candidate, observer, dispatcher, worker, geometry code or test-authority fixture.\n- C0 readback is a local duplicated copy; off-machine durable preservation is not independently verified until upload/retrieval.\n- P0A4, Hebrew targets, code-only freeze and deployment: **NOT AUTHORIZED**.\n'''
    preflight='''# L1-C0 unresolved engineering gates\n\n- Local host is **cross-host** relative to original R2 (CPython 3.11.2 versus 3.12.3, OpenSSL binary differs). This is acceptable only as prospective cross-host L1 evidence.\n- Existing host soft RLIMIT_CPU, RLIMIT_AS and RLIMIT_FSIZE are unlimited; registered candidate limits must be explicitly enforced by a locked controller, not inherited by assumption.\n- `/proc/self` visibility is not a qualification of snapshots for actual launched child; mandatory `/proc/<pid>` observation feasibility remains untested before L1-C1 source witness.\n- Compatibility of frozen candidate source and specific 3.11.2 interpreter is not established by static file equality. No import or trial is allowed before source-lock release.\n- The seven exact H01–H07 case adapters, especially observable H04 import-shadow activation, are NOT IMPLEMENTED or qualified by L1-C0.\n- Authorship is not independent: GPT-6 wrote the passive intake and C0 builder. A genuinely separate source-design reviewer is needed to claim developer-independent source review of future tests.\n- No production key, deployment authority, hostile-host attestation, loaded-code identity proof, P0A4 or Hebrew target study is authorized.\n'''
    limitations={'evaluation':'INTERIM L1-C0 BASELINE ONLY; no L1 registered test result',
        'R2_cross_host':{'original_python_3_12_3_sha256':host['R2_comparator']['python_binary_sha256'],'actual_python':host['python_version'],'actual_python_sha256':current_python_sha,'original_openssl_sha256':host['R2_comparator']['openssl_binary_sha256'],'actual_openssl_sha256':host['openssl_binary_sha256'],'same_host':False},
        'host':host,'actual_current_python_binary':str(current_python), 'collection_utc':now,
        'resource_policy_enforceability':'NOT QUALIFIED; prior ambient RLIMITs not enforced bounds',
        'child_proc_visibility':'NOT ESTABLISHED', 'no_test_status':'OPERATOR_ATTESTED_NOT_INDEPENDENTLY_PROVEN'}
    members={
       'authority/SIGNED_L1_PROTOCOL.md':pbytes,
       'authority/ORIGINAL_SIGNED_P0A3H_PROTOCOL.md':(repo/ORIGINAL_H_PROTOCOL).read_bytes(),
       'authority/HISTORICAL_HC0_NEGATIVE_CLOSEOUT.md':(repo/H_CLOSEOUT).read_bytes(),
       'historical/ORIGINAL_P0A3H_H-C0.zip':original_bytes['historical-H-C0'],
       'historical/ORIGINAL_P0A3H_H-C0_RECEIPT.json':hrec_bytes,
       'intake/ORIGINAL_P0_READONLY_INTAKE_EVIDENCE.zip':args.intake_zip.read_bytes(),
       'intake/ORIGINAL_P0_INTAKE_RECEIPT.json':args.intake_receipt.read_bytes(),
       'source/ORIGINAL_SOURCE_LOCK.json':source_bytes,
       'source/ORIGINAL_R2_EXTERNAL_LOCK.json':ext_bytes,
       'source/ORIGINAL_R2_RESOURCE_POLICY.json':policy_bytes,
       'source/ORIGINAL_R2_H01_BENIGN_REQUEST.json':fixture_bytes,
       'source/SOURCE_51_FILE_BYTE_IDENTITY_LEDGER.json':canonical(rows),
       'source/ORIGINAL_ARCHIVE_AND_SIGNED_COMMIT_PINS.json':canonical(input_facts),
       'operator/LOCAL_HOST_REGISTER_AND_OBSERVATION_LIMITS.json':canonical(limitations),
       'operator/DECLARATION_AND_AUTHORSHIP.json':canonical(operator),
       'operator/EXPOSURE_CHRONOLOGY.md':chronology.encode(),
       'operator/UNRESOLVED_PREFLIGHT_GATES.md':preflight.encode(),
       'builder/C0_BUILDER_SOURCE.py':self_bytes,
       'README.md':b'P0A3H-L1 L1-C0 archival baseline ONLY. Not L1-C1, not an H-method test or execution release.\n'
    }
    archived=out/'P0A3H_L1-C0.zip'
    meta=zip_create(archived,members)
    # Durable-readback proof not claimed: copied/read back in a separate *local* directory.
    rb=out/'readback_separate_directory'; rb.mkdir(mode=0o700)
    copied=rb/archived.name
    with archived.open('rb') as fi, copied.open('xb') as fo:
        shutil.copyfileobj(fi,fo)
        fo.flush();os.fsync(fo.fileno())
    rb_meta=validate_archive(copied,meta['bytes'],meta['sha256'])
    required(copied.read_bytes()==archived.read_bytes(),'local readback differs')
    receipt={
      'status':'L1_C0_SUBMITTED_FOR_INDEPENDENT_BYTE_AND_SOURCE_QC',
      'created_utc':now,'archive':archived.name,**meta,
      'local_readback':{'status':'BYTE_IDENTICAL; SAME_HOST_LOCAL_COPY_ONLY','copy_path':str(copied),**rb_meta},
      'local_operator_no_l1_tests':'SELF_REPORTED_EXPLICIT_CLI_FLAG',
      'history':'P0A3H_PREFLIGHT_INCOMPLETE; no previous H-C1',
      'L1_C1':'NOT BUILT','L1_DEV_01':'NOT AUTHORIZED',
      'executed_by_builder':'ARCHIVE/GIT/HASH/OS_METADATA_ONLY; NO_CANDIDATE_EXECUTION',
      'host_source':'Recorded passive P0 intake; fresh current Python, OpenSSL and kernel compared',
      'assistant_authored_C0_builder_sha256':sha(self_bytes),
      'durable_external_upload':'PENDING_HUMAN_UPLOAD_AND_INDEPENDENT_READBACK'
    }
    (out/'P0A3H_L1-C0_RECEIPT.json').write_bytes(canonical(receipt))
    (out/'P0A3H_L1-C0_LOCAL_READBACK.json').write_bytes(canonical(rb_meta))
    print('L1-C0 ARCHIVE COMPLETE (not L1-C1; not a test release)')
    print('output directory:',out)
    print('ZIP:',archived.name,'BYTES:',meta['bytes'],'SHA256:',meta['sha256'])
    print('Original archive, receipt and readback JSON are in the output directory.')
    print('Upload those THREE files for independent review. DO NOT execute H01-H07.')

if __name__=='__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError, zipfile.BadZipFile) as e:
        print('L1-C0 BUILDER STOP / NO VALID CHECKPOINT:',str(e),file=sys.stderr)
        raise SystemExit(2)
