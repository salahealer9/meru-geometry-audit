P0A3H-L1 L1-C0 archival baseline ONLY. Not L1-C1, not an H-method test or execution release.
