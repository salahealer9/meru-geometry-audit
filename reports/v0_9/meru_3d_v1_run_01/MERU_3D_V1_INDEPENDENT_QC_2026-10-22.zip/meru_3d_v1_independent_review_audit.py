#!/usr/bin/env python3
"""Independent, read-only review of 3D-V1 JSON. Never imports/runs original calculator."""
from itertools import product, combinations
from fractions import Fraction
from pathlib import Path
from collections import Counter
import json, hashlib, math, re, sys

SOURCE=Path('/mnt/data/results(1).json')
EXIT=Path('/mnt/data/exit_code(1).txt')
results=json.loads(SOURCE.read_text())
checks=[]
def ok(label, condition):
    checks.append({'check':label,'pass': bool(condition)})
    if not condition:
        print('FAIL',label)

def vecs():
    a0={(s,0,0) for s in [-1,1]}|{(0,s,0) for s in [-1,1]}|{(0,0,s) for s in [-1,1]}
    c=set(product((-1,1),repeat=3))
    e=set()
    t=set()
    for zero in range(3):
        axes=[i for i in range(3) if i!=zero]
        for sx,sy in product((-1,1),repeat=2):
            w=[0,0,0];w[axes[0]]=sx;w[axes[1]]=sy;e.add(tuple(w))
            for a,b in [(1,2),(2,1)]:
                w=[0,0,0];w[axes[0]]=sx*a;w[axes[1]]=sy*b;t.add(tuple(w))
    return {'A0':a0,'C':c,'E':e,'T':t}
strata=vecs()
for k,n in [('A0',6),('C',8),('E',12),('T',24)]:ok('independent stratum size '+k,len(strata[k])==n)
for x,y in combinations(strata,2):ok(f'independent strata {x},{y} disjoint',strata[x].isdisjoint(strata[y]))

def sqnorm(x):return sum(i*i for i in x)
def dot(x,y):return sum(a*b for a,b in zip(x,y))
def canonical_axis(v):
    for val in v:
        if val: return v if val>0 else tuple(-x for x in v)
    raise ValueError('zero vector')
# Independent exact cosine representation as sign plus square of cosine (fraction): if numerator 0 use zero
# This bypasses radicals and the candidate's alleged internal comparator.
def cosine_key(v,w,absval=False):
    d=dot(v,w)
    if absval: d=abs(d)
    sign = 0 if d==0 else (1 if d>0 else -1)
    frac=Fraction(d*d,sqnorm(v)*sqnorm(w))
    return (sign,frac)

def cosine_gt(a,b):
    if a[0]!=b[0]:return a[0]>b[0]
    if a[0]==0:return False
    if a[0]>0:return a[1]>b[1]
    return a[1]<b[1]

def cosine_eq(a,b):return a==b

def summary_cosine(z):
    display='0' if z[0]==0 else ('sqrt(' if z[0]>0 else '-sqrt(')+f'{z[1].numerator}/{z[1].denominator})'
    return {'sign':z[0], 'squared_numerator':z[1].numerator, 'squared_denominator':z[1].denominator, 'display':display}

def summarize_pair_table(seq,keys,absolute=False):
    best=None;tied=[];records=[];part={}
    for i in range(len(seq)):
        for j in range(i+1,len(seq)):
            v,w=seq[i],seq[j]
            d=dot(v,w);n=sqnorm(v)*sqnorm(w)
            key=cosine_key(v,w,absolute)
            records.append([i,j,d,n])
            if best is None or cosine_gt(key,best):best=key;tied=[(i,j)]
            elif cosine_eq(key,best):tied.append((i,j))
            sk=' x '.join(sorted((keys[i],keys[j]),key=lambda z: ['A0','C','E','T'].index(z)))
            part.setdefault(sk,[]).append((i,j,key))
    ps={}
    for label,items in part.items():
        z=None;wins=[]
        for i,j,key in items:
            if z is None or cosine_gt(key,z):z=key;wins=[(i,j)]
            elif cosine_eq(key,z):wins.append((i,j))
        ps[label]={'pair_count':len(items),'maximizing_pair_indices':[list(p) for p in wins], 'maximum_cosine':summary_cosine(z),'number_of_maximizing_pairs':len(wins)}
    return {'complete_pair_table':records,'complete_pair_table_columns':['direction_index_i','direction_index_j','integer_dot','norm_sq_product'], 'maximizing_pair_indices':[list(p) for p in tied], 'maximizing_pair_triples':[[list(seq[i]),list(seq[j])] for i,j in tied],'pair_count':len(records),'number_of_maximizing_pairs':len(tied),'maximum_cosine':summary_cosine(best),'stratum_pair_summary':ps}, best

expected={('A','G0'):(6,3,Fraction(0,1)),('A','G1'):(14,7,Fraction(1,3)),('A','G2'):(26,13,Fraction(2,3)),('B','G0'):(6,3,Fraction(0,1)),('B','G1'):(18,9,Fraction(1,2)),('B','G2'):(42,21,Fraction(9,10))}
stratum_order={('A','G0'):['A0'],('A','G1'):['A0','C'],('A','G2'):['A0','C','E'],('B','G0'):['A0'],('B','G1'):['A0','E'],('B','G2'):['A0','E','T']}
ok('raw JSON top-level study',results.get('study')=='MERU_3D_V1')
ok('original run exit code',EXIT.read_text().strip()=='0')
ok('preregistration commit metadata',results.get('preregistration_commit')=='0e5c1ea4837cf2d2a169fb03c97179e929c3a8ed')
ok('protocol blob metadata',results.get('preregistration_blob')=='217c2b3a3ab06846acaf767636f1efb95ef0e348')
ok('raw measurement state preserved',results.get('record_kind')=='RAW_REGISTERED_MEASUREMENT_AWAITING_INDEPENDENT_REVIEW')
ok('six family-level records',len(results['family_level_results'])==6)
ok('all registered combos unique',Counter((r['family'],r['level']) for r in results['family_level_results'])==Counter(expected.keys()))
observed=[]
for rec in results['family_level_results']:
    f,l=rec['family'],rec['level'];tag=f'{f}-{l}';order=stratum_order[(f,l)]
    seq=[p for label in order for p in sorted(strata[label])]
    lookups={p:label for label in order for p in strata[label]}
    axes=sorted({canonical_axis(v) for v in seq},key=lambda v:(order.index(lookups[v]),v))
    # Note: canonical axes are sorted per stratum lex. Signed directions similarly.
    expected_signed=[{'triple':list(v),'stratum':lookups[v],'norm_sq':sqnorm(v)} for v in seq]
    expected_axes=[{'triple':list(v),'stratum':lookups[v],'norm_sq':sqnorm(v)} for v in axes]
    ok(tag+' exact signed directions list',rec['signed_directions']==expected_signed)
    ok(tag+' exact axis representatives list',rec['axis_representatives']==expected_axes)
    ok(tag+' advertised strata',rec['strata']==order)
    ok(tag+' count vectors',rec['signed_direction_count']==len(seq) and rec['axis_count']==len(axes))
    ok(tag+' nonzero vectors',all(sqnorm(v)>0 for v in seq))
    ok(tag+' antipodal closure',all(tuple(-x for x in v) in seq for v in seq))
    ok(tag+' no duplicate vectors',len(seq)==len(set(seq)))
    ok(tag+' no duplicate axes',len(axes)==len(set(axes)))
    ok(tag+' axes match exact antipodal quotient',len(seq)==2*len(axes))
    key_signed=[lookups[v] for v in seq];key_axes=[lookups[v] for v in axes]
    calc_signed,z1=summarize_pair_table(seq,key_signed,False)
    calc_axis,z2=summarize_pair_table(axes,key_axes,True)
    # stratum pair summaries might be ordered differently as internal index order is sorted groups; compare dictionaries
    for k in calc_signed:
        if k=='maximizing_pair_triples': pass
        ok(tag+' signed '+k,rec['signed_pair_census'].get(k)==calc_signed[k])
    for k in calc_axis:
        ok(tag+' axis '+k,rec['axis_pair_census'].get(k)==calc_axis[k])
    ok(tag+' signed axis maxima identical',z1==z2 and rec['signed_and_axis_maxima_equal_exactly'] is True)
    n,a,frac=expected[(f,l)]
    ok(tag+' preregistered counts and maximum',n==len(seq) and a==len(axes) and z1==(0 if frac==0 else 1,frac))
    ok(tag+' preregistered pair census',len(calc_signed['complete_pair_table'])==n*(n-1)//2 and len(calc_axis['complete_pair_table'])==a*(a-1)//2)
    for kind,z in [('signed',z1),('axis',z2)]:
        d=math.degrees(math.acos((0 if z[0]==0 else z[0]*math.sqrt(float(z[1])))))
        stated=rec[kind+'_pair_census']['minimum_separation_degrees_approx']
        ok(tag+' '+kind+' approximate-angle representation',abs(stated-d)<1e-11)
    observed.append({'family':f,'level':l,'signed_count':n,'axis_count':a,'signed_pair_count':n*(n-1)//2,'axis_pair_count':a*(a-1)//2,'exact_max_cosine':summary_cosine(z1),'angle_degrees':rec['signed_pair_census']['minimum_separation_degrees_approx'],'maximizing_signed_pairs':len(calc_signed['maximizing_pair_indices']),'maximizing_axis_pairs':len(calc_axis['maximizing_pair_indices'])})
# Important: check interlevel nesting, shared initial tier as sets, independent of submitted pair metadata.
for f in ('A','B'):
    s=[set(x for group in stratum_order[(f,l)] for x in strata[group]) for l in ('G0','G1','G2')]
    ok(f+' strictly nested exact direction sets',s[0]<s[1]<s[2])
ok('families share identical G0',observed[0]['exact_max_cosine']==observed[3]['exact_max_cosine'] and results['family_level_results'][0]['signed_directions']==results['family_level_results'][3]['signed_directions'])
stat={'study':'MERU_3D_V1','review_type':'independent algebraic enumeration; original registered calculator not imported or run','source_json':{'name':SOURCE.name,'bytes':SOURCE.stat().st_size,'sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest()},'source_exit':{'name':EXIT.name,'bytes':EXIT.stat().st_size,'sha256':hashlib.sha256(EXIT.read_bytes()).hexdigest()},'preregistration_commit_reported':results['preregistration_commit'],'total_checks':len(checks),'passes':sum(x['pass'] for x in checks),'fails':sum(not x['pass'] for x in checks),'checks':checks,'observed':observed,'result':'PASS' if all(x['pass'] for x in checks) else 'MISMATCH'}
out=Path('/mnt/data/MERU_3D_V1_INDEPENDENT_EXACT_AUDIT_2026-10-22.json');out.write_text(json.dumps(stat,indent=2,sort_keys=True)+'\n')
print(f"{stat['passes']}/{stat['total_checks']} assertions PASS, result={stat['result']}")
for z in observed:print(z['family'],z['level'],z['signed_count'],z['axis_count'],z['signed_pair_count'],z['axis_pair_count'],z['exact_max_cosine']['display'],z['angle_degrees'])
sys.exit(0 if stat['fails']==0 else 1)
