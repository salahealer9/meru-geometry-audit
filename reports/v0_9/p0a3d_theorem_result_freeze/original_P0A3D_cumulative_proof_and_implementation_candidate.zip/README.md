# P0A3D proof-and-implementation candidate — independent QC submission

This is an unsigned review package, **not a freeze or approval**.

| Track | Current disposition |
| --- | --- |
| Theorem | `P0A3D_EXACT_2D_QO_THEOREM_PROPOSED` — constructive proof submitted for independent mathematical QC |
| Software | `P0A3D_IMPLEMENTATION_INCOMPLETE` — exact core and separate checker supplied, with documented hardening and qualification blockers |
| DEV | Final attempt 04 passed 20/20 methods; all four attempts, including failures, preserved |
| Registered certification | Not run; no eligibility or P0A4 approval activated |

## Review order

1. Read `reports/v0_9/p0a3d_exact_qo_core/provenance/WORK_HANDOFF.txt` and the
   complete frozen P0A3D protocol in that directory. Its exact commit is
   `92de104cab58339df370acf96b8d849ecc2d888b`, Git blob
   `39944862b7ec7565188584c97695fdf925538f8a`, parent
   `923bab7855deaee6be49dd299bbdb0d6251844c1`; expected signer fingerprint is
   `D4EC014EEFCC90E619D2AA59A91239ABCF512130`.
2. Inspect `provenance/D0_verified.json`, public signatures/payloads, rehashed
   commit/tree metadata and frozen P0A2/P0A3C texts. Twelve adjacent signed
   commits and the v0.8 tag were verified locally. Earlier ancestry uses a
   GitHub merge-base record, not a full local signature walk. Ownertrust and
   public-key import warning are preserved, not hidden.
3. Review `THEOREM_PROOF.md`, `PROOF_OBLIGATIONS_AND_DECISIONS.csv` and the three
   `docs/v0_9/p0a3d_*` documents. Exact arithmetic includes irrational lengths,
   dependent positive radicals, exact zeros and the zero-conjugate inverse case.
4. Inspect new production `src/meru_geometry/v0_9/qo2d_exact/` and separately
   authored `reference/v0_9/qo2d_exact/`, their trust/independence matrix, source
   additions diff and complete per-attempt snapshots/diffs. No old numerical
   modules were reused. These two routes share CPython/Fraction and some
   mathematics, and are not claimed independently qualified.
5. Read the prospective DEV catalogue, chronology and final evidence; then the
   D8 dispositions and unfilled independent QC checklist. A successful checker
   result remains `EXACT_THEOREM_CERTIFICATE_CANDIDATE_UNVALIDATED`.

## Content and preservation

[FROZEN RESULT] Original P0A3C/P0A3 packages, QC layers and historical DEV 01–08
remain external frozen identities in `provenance/EXTERNAL_PRESERVATION_IDENTITIES.json`.
Their bytes were retrieved, hashed and CRC/internal-manifest checked where
available; no historical test was rerun. The protocol explicitly permits this
nonduplicating cumulative representation. New P0A3D attempts 01–04 are included
in full. Original archives remain unchanged in the signed preservation tree.

[IMPLEMENTED_UNVERIFIED] The isolated DEV runtime was stdlib-only CPython 3.12.14,
created with `venv --without-pip`. Exact historical commands and limits are in
the attempt result records; no dependency install or existing-repository edit
was performed. The numerical API is structured Python objects, not a hardened
network service or raw-JSON CLI. Read the documented parser/resource blockers.

[DEV_CHECKED_ONLY] Tests use six prospectively specified generic certificate
comparisons per attempt plus bounded arithmetic/rejection checks. Attempt 03
retains a failure and error; attempt 04 fixes endpoint Boolean acceptance and
noncanonical failure hashing. These are engineering observations, not a theorem
approval, scientific experiment, benchmark or registered certification.

## Integrity conventions

`PACKAGE_INVENTORY.json` records every payload file's relative path, byte length
and SHA-256, excluding itself and `SHA256SUMS` to avoid self-reference.
`SHA256SUMS` covers all ZIP members except itself, including the inventory.
The exact ZIP hash is delivered separately. ZIP entries are sorted regular
files with fixed metadata; no directory entries, symlinks, absolute paths,
traversals, duplicate names, private keys, image/font payloads or old P0A0
scientific case/result files are included. Git tree metadata lists historical
paths/hashes only; it is not an export of their file contents.

## Restrictions and next gate

[DEFERRED] No commit, push, existing-repository modification, P0A0 replay,
P0A4 run, 3D/camera/QH extension, Hebrew/font-proxy analysis, candidate/null
experiment or optimizer benchmark occurred. No primary Hebrew score or final
G1/G2 hierarchy was selected. All inherited missing-crop, historical optics,
target-order/rights, control-fairness and inferential limitations remain.
Independent mathematical and engineering QC, then separate human-signed
freezes and future registered authority, are required before any promotion.
