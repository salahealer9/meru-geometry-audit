# Ordinary parser/failure-envelope repair before P0A3D_DEV_04

[DEV_CHECKED_ONLY] Attempt 03 retained 20 methods, with 1 failure and 1 error in
two malformed-input subcases of test 02. Boolean endpoint indices were accepted
by Python value equality, and JSON hashing of an already rejected NaN input
raised rather than returning INVALID_INPUT. All exact numerical comparisons and
attained residual checks passed. No theorem or genuine certificate contradiction.

[IMPLEMENTED_UNVERIFIED] Require endpoint index lists with exactly two genuine
int objects in both independently implemented input validators. In the production
failure envelope, a noncanonical/nonfinite object receives request_sha256=null,
explicitly meaning that no canonical JSON identity exists. It remains unscored;
no nonfinite value is serialized. Valid request/certificate hashing is unchanged.
No arithmetic, objective, fixture, precision, resource cap or theorem changed.
Attempt 04 reruns the same declared suite. Preserve attempt 03 stacks and diffs.
