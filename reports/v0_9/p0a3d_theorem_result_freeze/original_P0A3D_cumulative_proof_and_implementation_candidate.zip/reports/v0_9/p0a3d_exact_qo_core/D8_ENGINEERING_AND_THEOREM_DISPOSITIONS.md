# P0A3D proposed dispositions — no self-approval

## Separate decisions

| Domain | Submitted disposition | Evidence and limits |
| --- | --- | --- |
| Mathematical theorem | `P0A3D_EXACT_2D_QO_THEOREM_PROPOSED` | [PROVED_HERE_AWAITING_INDEPENDENT_QC] Constructive proof over all finite valid rational-coordinate ordered open 2D paths, including irrational lengths and dependent radicals. No known logical gap identified by this author; independent review is mandatory. |
| Software | `P0A3D_IMPLEMENTATION_INCOMPLETE` | [IMPLEMENTED_UNVERIFIED] Exact core and separately coded verifier supplied; bounded DEV succeeds, but input/process hardening and independent qualification remain incomplete. No candidate-for-registered-validation status activated. |
| Exact predicates | `P0A3D_EXACT_PREDICATE_UNQUALIFIED` | [UNRESOLVED] Source and constructive derivation supplied; common arithmetic foundations and code correctness await independent QC. |
| Reference independence | `P0A3D_REFERENCE_INDEPENDENCE_UNQUALIFIED` | [UNRESOLVED] Separate code, integration and sign route; common mathematics, CPython and Fraction remain. |
| Resource completion | `P0A3D_RESOURCE_NONCOMPLETION` | [DEV_CHECKED_ONLY] Deliberate budget-negative checks return/raise incomplete, never a score. General completion within practical budgets is not claimed. |
| Registered numerical validation | `P0A3D_REGISTERED_NUMERICAL_VALIDATION_NOT_RUN` | [FROZEN RESULT] No P0A4 authority or execution. |
| 3D and QH | `P0A3D_3D_CAMERA_EXTENSION_DEFERRED`; `P0A3D_QH_DEFERRED` | [DEFERRED] No extension implemented or executed. |
| Historical observation and controls | `P0A3D_HISTORICAL_OBSERVATION_UNRESOLVED`; `P0A3D_CONTROL_FAIRNESS_UNVERIFIED` | [UNRESOLVED] B07/B08 and inherited limitations are not discharged. |

## Bounded DEV chronology

[DEV_CHECKED_ONLY] Four P0A3D attempts are retained independently of historical
DEV 01–08. Attempts 01 and 02 each passed 20 methods. Attempt 03 ran 20 methods
and retained one failure and one error in malformed-input subcases: Boolean
endpoint indices passed Python equality, and an already rejected NaN object
could not be canonically hashed for a failure envelope. Attempt 04 passed 20/20
after genuine-integer endpoint checks in both parsers and a null digest for an
unhashable malformed request. Numerical arithmetic, objective, six generic
certificate cases and declared resource ceilings were unchanged by that repair.
Every command, stdout/stderr, source snapshot, change patch and evidence object
is retained. This is not 80 independent scientific cases or numerical certification.

[DEV_CHECKED_ONLY] Six prospectively declared generic certificate cases per
attempt cover irrational lengths, an exact rational control, zero edges and
subdivision, whole-roll tie, tiny-positive correlation and a fixed different
traversal. All six final certificates were recomputed by the separate checker.
Other methods exercise algebraic identities, rejection and budget limits.
No new registered experiment, optimizer benchmark or source-derived target
fixture was used. No claim of general software correctness follows.

## Remaining engineering blockers

[UNRESOLVED] Strict raw-JSON decoding and uniform malformed-certificate rejection
are not complete. Some nested malformed structures raise ordinary exceptions;
edge-provenance integer metadata uses Python equality and needs type hardening.
No claim is made that the schema is automatically enforced by the checker.
Very large integer parsing, recursion, temporary memory growth and external
process termination are not uniformly mapped to typed status envelopes. DEV
subprocess caps do not make the bare API a resource-isolated service. External
review must bind trusted source/runtime hashes rather than accepting self-hashed
live code as authority. These limitations are preserved, not silently waived.

## Inherited frozen limitations, unchanged

[FROZEN RESULT] The v0.8 conclusion remains
`NO_REPRODUCIBLE_PUBLISHED_FIRST_HAND_CONSTRUCTION_RECOVERED`. Historical three
function sets, the deformation/carrier construction and optical-shadow law have
not been recovered. Abstract QO paths are not historically authenticated Meru
observations. P0A3C remains `P0A3C_IMPLEMENTATION_INCOMPLETE` and
`P0A3C_INDEPENDENT_CHECKER_UNQUALIFIED`; this new narrow proof does not repair
or retroactively certify that system.

[FROZEN RESULT] Inherited source limitations include missing crop
`aog_p07_spherical_projection.png`; the historical 1,281 items / two exclusions;
35 dot entries rather than 59; and the lost 60,950-byte P0A1 package versus its
54,360-byte recovered replacement, which is not byte-identical. A09 establishes
metadata only, not recovered JPEG bytes. These are inherited records, not new
source/image inspections. Historical archives and both QC layers remain pinned
externally to signed preservation bytes; no old DEV or P0A0 suite was rerun.

[UNRESOLVED] Rights, independent target order, observability, matched controls,
fairness and inferential design remain unresolved. The 22 letters cannot simply
be treated as IID trials. No final Hebrew score or final G1/G2 hierarchy was
selected. This session's information-barrier statement is scoped to observed
actions; it is not an exhaustive off-host audit or proof of anyone else's behavior.

## Gate

[UNRESOLVED] Return this candidate for independent mathematical and engineering
QC. Any approved theorem requires a separate human GPG-signed result freeze;
software eligibility requires independent source/reference QC and a separate
human code-only freeze. A new signed target-free protocol is required before
any registered numerical validation. No commit, push, repository modification,
freeze or final approval is performed here.
