# Prospective review correction before P0A3D_DEV_02

[DEV_CHECKED_ONLY] P0A3D_DEV_01 passed all 20 tests. No numeric production or
reference defect was observed. Static review found that test 14 used a malformed
matrix, exercising schema rejection without demonstrating rejection of a valid
proper but nonoptimal witness. Replace that defective copy with identity for the
fixed straight pair whose unique optimal witness is J. This remains the original
predeclared forged-witness category and uses no new numerical fixture.

[IMPLEMENTED_UNVERIFIED] Strengthen test 15 by removing the interior union knot
from the existing fixed-traversal certificate, rather than an endpoint from the
straight pair. Test 20 additionally exercises the already declared coefficient-
bit cap and a reference operation cap. Limits, source inputs, algorithms and
case count remain fixed; no tuning from numerical outcomes. Preserve attempt 01
and all exact source diffs; rerun the same bounded 20-method catalogue as 02.
