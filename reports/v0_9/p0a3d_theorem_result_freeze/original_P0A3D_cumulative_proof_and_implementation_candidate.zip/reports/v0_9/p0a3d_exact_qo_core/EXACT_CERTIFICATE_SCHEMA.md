# D2 exact certificate contract, version qo2d-exact-1

[IMPLEMENTED_UNVERIFIED] The wire object is deterministic sorted-key JSON.
Rationals are two canonical decimal strings [numerator,denominator], gcd=1,
denominator>0, no plus sign, leading zero, negative zero, float, decimal or bool.
Original input objects carry id, ordered=true, parameter_domain=OPEN_INTERVAL,
endpoints=[0,n-1], provenance=INDEPENDENT_GENERIC, and ordered vertices.
An endpoint coordinate may repeat; no closed-curve search is introduced.

[PROVED_HERE_AWAITING_INDEPENDENT_QC] The exact scalar encoding is a sorted list
of [mask,rational] terms. Mask bit i denotes the product factor theta_i. A separate
ordered roots table encodes each radicand in earlier generators only and requires
its exact positive sign. Empty terms mean zero. Coefficients contain no zeros or
duplicate masks. This is canonical syntax for an evaluated radical construction,
not a canonical minimal polynomial of its value. Dependent-radical equalities
must be checked semantically by exact sign; nonzero formal vectors may be zero.

[IMPLEMENTED_UNVERIFIED] A successful certificate contains schema, lane,
machine_state=EXACT_THEOREM_CERTIFICATE_CANDIDATE_UNVALIDATED, original request,
request/input SHA-256, backend versions, roots, two path records (zero-edge
events, surviving original edge indices, positive lengths, total length, knots,
centroid, variance and positive RMS), exact union partition, alpha,beta,s,q²,q,
Q matrix, roll_state, and labeled exact sign/equality decisions. The checker
reconstructs from original input using its own arithmetic/integration, compares
every recorded scalar semantically, and separately computes the direct attained
residual, determinant and all entries of Q^T Q. Root witnesses are positive
radical definitions, not approximate isolation intervals.

[IMPLEMENTED_UNVERIFIED] The external verification argument binds canonical
request and live production/reference source bundle SHA-256 independently of
the certificate. A hash utility merely computes these identities; only external
QC/human authority establishes trusted expected values. DEV pins are temporary
harness observations, not a signed implementation freeze. Root positivity,
input order/IDs, backend/config version and all key sets are checked.

[IMPLEMENTED_UNVERIFIED] Failures are separate envelopes with schema, state,
reason and request digest; no score/witness fields. INVALID_INPUT is a malformed
contract, NOT_EVALUABLE is an exact constant path. RESOURCE_INCOMPLETE records
a caller resource ceiling; UNRESOLVED_EXACT_PREDICATE is an inability to complete
a required predicate and cannot be a tie. Exact predicates return -1/0/+1 or
raise; there is no approximate-equality fallback. The formal JSON schema is a
wire guide; numerical semantic verification is mandatory and separate.

[IMPLEMENTED_UNVERIFIED] A malformed request that cannot be represented as
canonical finite JSON has `request_sha256: null` in its failure envelope, not a
hash of a lossy replacement. The final complete certificate artifact is the
certificate plus its detached expected request/production/reference hash record.
DEV evidence stores these as `certificate` and `external_DEV_pins` alongside
the original request. The JSON schema defines the certificate, request, pins,
bundle and failure shapes; it cannot encode semantic gcd reduction, positive
root embeddings, backward root references, exact equality or trusted hash origin.
The checker must perform semantic recomputation; an external reviewer must supply
trusted pins. No source signature or implementation approval is manufactured.
