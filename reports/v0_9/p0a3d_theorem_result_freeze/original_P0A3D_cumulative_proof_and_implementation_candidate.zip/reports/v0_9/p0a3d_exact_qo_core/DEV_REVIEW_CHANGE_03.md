# Prospective parser probes before P0A3D_DEV_03

[IMPLEMENTED_UNVERIFIED] Static review identified two concrete input-handling
risks: Python considers Boolean endpoint indices equal to 0/1, and failure
hashing of a rejected NaN-containing request can raise before returning the
typed INVALID_INPUT envelope. Add two subcases within the existing malformed-
contract test 02. The Boolean case invokes validation only, never a seventh
QO evaluation. The NaN value is a deliberately invalid parser token, not a
coordinate admitted to numerical arithmetic or a serialized score. All six
generic comparisons, test count, limits and the original plan remain unchanged.
Record the failing attempt before repair, then preserve source diffs and rerun.
