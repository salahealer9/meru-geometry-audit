# P0A3D DEV catalogue v1 — declared before first execution

[IMPLEMENTED_UNVERIFIED] Twenty deterministic unittest methods, at most six
full production QO certificates per attempt, and one independent exact check per
genuine certificate. Additional defective copies exercise checker rejection.
These are fresh abstract arithmetic examples, not source/glyph/font objects,
P0A0 cases, candidate/null data or registered certification fixtures.

Common limits fixed prospectively: at most 6 vertices/path, 64 input bits,
16,384 coefficient bits, 1,024 nonzero terms, formal tower degree at most 256,
2,000,000 arithmetic operations per backend instance; reference rational sign
isolation starts at 8 bits and doubles to a ceiling of 256 bits. This is a
deterministic proof-predicate refinement rule, not score-dependent parameter
selection. Production uses no floating precision. One DEV subprocess has a
60-second timeout and 1-GiB address-space limit. No limit increase from outputs.

Canonical coordinate pairs are reduced integer numerator/positive-denominator
strings. Six fixed path comparisons:

1. Irrational proper rotation: a=(1,3),(2,4),(4,5), b=(4,-1),(3,0),(2,2).
   b=J a+(7,-2), so q=0 and the unique witness is J. Lengths sqrt(2),sqrt(5).
2. Straight segment: a=(-3,0),(3,0), b=(1,-5),(1,1). Means (0,0),(1,-2),
   both variances 3; q=0, witness J. Analytic arclength moments, not vertex weights.
3. Honest subdivision/zero edge: a=(1,3),(1,3),(3/2,7/2),(2,4),(4,5),
   b=(1,3),(2,4),(4,5). Same traversal, q=0; one zero event, preserved indices.
4. Whole-roll tie: a=(-3,0),(3,0); b=(2,0),(-2,0),(2,0). Odd/even symmetry
   proves alpha=beta=0, q²=2 and canonical identity. Return trip is retained.
5. Tiny nonzero: same a; b=(2,0),(-2,0),(2+2^-20,0). Theorem 5.5 gives
   C=e*(h²+4hk+k²)/(2(h+k)²)>0, h=4,k=4+e. No whole-roll tie.
6. Fixed different traversal: a=(1,3),(2,4),(4,5); b=(4,5),(2,4),(1,3).
   Unequal arclength turn positions give a four-point union partition and q>0.
   This is one fixed input pair, **no reversal nuisance/search** is performed.

| Test | Engineering assertion / independent analytic oracle |
|---|---|
| 01 | Strict canonical rational parser; malformed syntax, bool/float/unreduced values rejected |
| 02 | Missing order, closed domain, dimensions and nuisance changes rejected |
| 03 | Irrational-length rotation certificate q=0; independent exact checker |
| 04 | Straight-path exact means/variance and direct residual |
| 05 | Subdivision and exact-zero event certificate q=0 |
| 06 | Retraced symmetric whole-roll tie, q²=2 and identity witness |
| 07 | Tiny nonzero correlation remains exact positive |
| 08 | Unequal knot merge; reversed fixed traversal not silently matched |
| 09 | sqrt(3+2sqrt(2))=1+sqrt(2) in production exact predicates |
| 10 | Independent dense arithmetic verifies same nested identity |
| 11 | Nonzero element with zero conjugate can be inverted exactly |
| 12 | sqrt(2+2^-20)-sqrt(2)>0 in both arithmetic routes |
| 13 | Deliberately forged score rejected |
| 14 | Deliberately forged proper-rotation witness rejected |
| 15 | Omitted union knot rejected |
| 16 | Changed external input/config pin, backend or order rejected |
| 17 | Negative radicand or forward generator reference rejected |
| 18 | False sign-decision record rejected |
| 19 | Canonical deterministic JSON; exact constant path unevaluable |
| 20 | Operation/degree/input-bit caps return RESOURCE_INCOMPLETE without score |

[IMPLEMENTED_UNVERIFIED] Each attempt is named P0A3D_DEV_01 onward, preserving
historical P0A3 attempts 01–08 externally without reexecution. Before running,
snapshot every new .py source and this plan; retain request/certificate bytes
as each is produced, all checker results, stdout/stderr, failed stacks, diffs,
elapsed time and exit codes. An ordinary software defect may be corrected with
an auditable rerun of the same bounded catalogue. A genuine theorem/witness
contradiction stops the corresponding certification claim and is reported.
No numerical kernel has been executed before this catalogue is written.

Command: isolated venv Python -B tests/dev_v0_9/p0a3d/test_core.py,
PYTHONPATH=src:., PYTHONHASHSEED=0, PYTHONDONTWRITEBYTECODE=1, LC_ALL=C.UTF-8.
Exact absolute paths and resource controls are recorded by the DEV logger.
