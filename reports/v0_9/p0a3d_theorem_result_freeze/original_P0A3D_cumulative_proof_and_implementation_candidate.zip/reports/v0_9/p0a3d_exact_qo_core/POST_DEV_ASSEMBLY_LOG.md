# Post-DEV integrity-only assembly

[IMPLEMENTED_UNVERIFIED] After P0A3D_DEV_04, production/reference/test sources
were not changed. Added documents, schema, matrices and provenance records do
not rerun numerical evaluation. `assemble_records.py` verifies all six entries
of the frozen P0A3C preservation manifest, snapshots the isolated runtime,
parses new source for an import graph, compares final source to attempt 04 and
rehashes all four attempts' outputs/evidence. Command:

`python3 -B p0a3d_work/assemble_records.py > p0a3d_work/assembly_stdout.log 2> p0a3d_work/assembly_stderr.log`

[IMPLEMENTED_UNVERIFIED] Assembly completed with exit 0; its stdout/stderr and
driver source are included in provenance. `package_candidate.py` subsequently
performs strict JSON parsing, source/pin comparisons, path/content guards,
inventory/hash generation and ZIP CRC/hash verification. These are artifact
integrity operations, not new numerical microchecks or certification execution.
The final delivery identity is external to the ZIP to avoid circular hashes.

[UNRESOLVED] Preliminary dependency-probe raw output was not separately saved;
its unavailable-package/exit-1 observation is disclosed in the environment
record. Every actual numerical DEV command and stdout/stderr was saved. No
missing source log is reconstructed as if it were an original captured output.

[IMPLEMENTED_UNVERIFIED] Packaging attempt 01 exited 1 before ZIP creation:
the private-key-armor detector matched its own quoted detector strings in the
included packaging source. This was a detector false positive, not a private
key exposure. Its complete source and stdout/stderr are preserved under
`provenance/packaging_attempt01_*`. The correction recognizes armor line headers
rather than quoted substrings. No numerical source or DEV was changed or rerun.
Attempt 02 uses `python3 -B p0a3d_work/package_candidate.py`, with outputs saved
as `p0a3d_work/packaging_attempt02_stdout.log` and `_stderr.log`; delivery identity
is reported separately after ZIP verification.
