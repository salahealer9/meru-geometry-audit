"""Deterministic package assembly/integrity only; never imports QO kernels."""
from pathlib import Path,PurePosixPath
import hashlib,json,shutil,stat,zipfile
W=Path(__file__).resolve().parent;P=W/'package';R=P/'reports/v0_9/p0a3d_exact_qo_core';V=R/'provenance'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n')
def strict(b):
    def pairs(p):
        d={}
        for k,v in p:
            if k in d:raise ValueError('duplicate JSON key '+k)
            d[k]=v
        return d
    def reject(x):raise ValueError('nonfinite JSON '+x)
    return json.loads(b,object_pairs_hook=pairs,parse_constant=reject)
for n in ('assembly_stdout.log','assembly_stderr.log'):shutil.copyfile(W/n,V/n)
shutil.copyfile(Path(__file__),V/'package_candidate.py')
pins=strict((R/'FINAL_SOURCE_PINS.json').read_bytes());e=strict((R/'dev_history/P0A3D_DEV_04_evidence.json').read_bytes())
assert len(e['cases'])==6 and len(e['checks'])==6
for case in e['cases'].values():
    for k in ('production_sha256','reference_sha256'):assert case['external_DEV_pins'][k]==pins[k]
    assert case['certificate']['request']==case['request']
    assert sha(json.dumps(case['request'],sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode())==case['external_DEV_pins']['request_sha256']
for f in pins['files']:
    b=(P/f['path']).read_bytes();assert sha(b)==f['sha256'] and len(b)==f['bytes']
files=[];json_count=0
for p in sorted(P.rglob('*')):
    assert not p.is_symlink()
    if not p.is_file():continue
    n=p.relative_to(P).as_posix()
    if n in ('PACKAGE_INVENTORY.json','SHA256SUMS'):continue
    rel=PurePosixPath(n);assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in n
    assert p.suffix.lower() in {'.py','.md','.json','.csv','.txt','.log','.patch','.asc','.payload','.gpg','.sha256'},n
    assert '__pycache__' not in n and not n.endswith(('.zip','.jsonl')),n
    b=p.read_bytes();assert b'-----BEGIN PGP PRIVATE KEY BLOCK-----' not in b and b'-----BEGIN PRIVATE KEY-----' not in b
    if p.suffix=='.json':strict(b);json_count+=1
    files.append({'path':n,'bytes':len(b),'sha256':sha(b)})
assert len({f['path'] for f in files})==len(files)
audit={'classification':'ARTIFACT_INTEGRITY_ONLY_NOT_MATHEMATICAL_OR_ENGINEERING_APPROVAL','strict_json_files_checked_before_this_report':json_count,'final_DEV_source_and_detached_pins':'MATCH','new_numerical_runs':0,'historical_replays':0,'guards':['regular files only','no ZIP traversal/absolute/duplicate paths','allowlisted text/public-signature payload extensions','no nested archive/P0A0 JSONL','no private-key armor','strict finite JSON/no duplicate object keys'],'checksum_convention':'Inventory excludes itself and SHA256SUMS; SHA256SUMS excludes itself; external ZIP SHA256 binds everything.'}
audit_path=R/'PACKAGE_PREZIP_INTEGRITY.json';put(audit_path,audit)
# Add the just-generated audit to the payload list (replace if rebuilding).
files=[f for f in files if f['path']!=audit_path.relative_to(P).as_posix()]
files.append({'path':audit_path.relative_to(P).as_posix(),'bytes':audit_path.stat().st_size,'sha256':sha(audit_path.read_bytes())});files.sort(key=lambda f:f['path'])
put(P/'PACKAGE_INVENTORY.json',{'phase':'P0A3D','status':'UNSIGNED_CANDIDATE_FOR_INDEPENDENT_QC','payload_files':files,'payload_count':len(files),'excludes':['PACKAGE_INVENTORY.json','SHA256SUMS']})
covered=files+[{'path':'PACKAGE_INVENTORY.json','sha256':sha((P/'PACKAGE_INVENTORY.json').read_bytes())}];covered.sort(key=lambda f:f['path'])
(P/'SHA256SUMS').write_text(''.join(f['sha256']+'  '+f['path']+'\n' for f in covered))
names=sorted([f['path'] for f in files]+['PACKAGE_INVENTORY.json','SHA256SUMS'])
out=W/'P0A3D_cumulative_proof_and_implementation_candidate.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n in names:
        zi=zipfile.ZipInfo(n,(2000,1,1,0,0,0));zi.create_system=3;zi.external_attr=(stat.S_IFREG|0o644)<<16;zi.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(zi,(P/n).read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None and z.namelist()==names and len(names)==len(set(names))
    inv=strict(z.read('PACKAGE_INVENTORY.json'));lines=z.read('SHA256SUMS').decode().splitlines()
    assert set(names)-{'SHA256SUMS','PACKAGE_INVENTORY.json'}=={r['path'] for r in inv['payload_files']}
    assert set(names)-{'SHA256SUMS'}=={line.split('  ',1)[1] for line in lines}
    for line in lines:
        h,n=line.split('  ',1);assert sha(z.read(n))==h
    for row in inv['payload_files']:
        b=z.read(row['path']);assert len(b)==row['bytes'] and sha(b)==row['sha256']
result={'file':str(out),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'entries':len(names),'manifest_records':len(covered),'inventory_payload_files':len(files),'CRC':'PASS','all_internal_hashes':'PASS','strict_JSON':'PASS','final_tested_source_identity':'MATCH','numerical_execution_during_packaging':False}
put(W/'DELIVERY_IDENTITY.json',result)
print(json.dumps(result,indent=2))
