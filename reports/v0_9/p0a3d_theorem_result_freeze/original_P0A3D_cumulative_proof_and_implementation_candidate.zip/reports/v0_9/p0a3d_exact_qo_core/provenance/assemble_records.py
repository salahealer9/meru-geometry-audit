"""Mechanical report/schema/provenance assembly. Does not run numerical code."""
from pathlib import Path
import ast,csv,difflib,hashlib,json,platform,shutil,subprocess,sys
W=Path(__file__).resolve().parent;P=W/'package';R=P/'reports/v0_9/p0a3d_exact_qo_core';I=W/'intake';V=R/'provenance';V.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n')
def table(name,fields,rows):
    with (R/name).open('w',newline='') as f:
        w=csv.writer(f);w.writerow(fields);w.writerows(rows)
d0=json.loads((W/'D0_verified.json').read_text())
# Crosscheck frozen preservation manifest without rewriting any preserved byte.
manifest=[]
for line in (I/'FREEZE_MANIFEST.sha256').read_text().splitlines():
    h,n=line.split('  ',1);p=I/Path(n).name;assert sha(p)==h
    manifest.append({'path':n,'sha256':h,'bytes':p.stat().st_size,'result':'MATCH'})
put(V/'P0A3C_MANIFEST_CROSSCHECK.json',manifest)
for n in ('D0_verified.json','D0_stdout.log','D0_stderr.log','base_environment.json','d0_verify.py','run_dev.py'):
    shutil.copyfile(W/n,V/n)
shutil.copyfile(W.parent/'upload/P0A3D_SIGNED_PROTOCOL_EXACT_2D_QO_PROOF_IMPLEMENTATION_WORK_HANDOFF_2026-10-19(1).txt',V/'WORK_HANDOFF.txt')
# Include exact authority text and public signature/commit/tree records; no old ZIPs,
# old implementation, scientific JSONL/cases, image/target blobs or private keyring.
selected=[]
for p in sorted(I.iterdir()):
    if p.suffix in ('.asc','.payload') or p.name.startswith(('commit_','tree_')) or p.name in {'tag.json','public.gpg','FREEZE_MANIFEST.sha256'} or any(p.name==Path(s['path']).name and p.suffix!='.zip' for s in d0['source_files']):
        shutil.copyfile(p,V/p.name);selected.append(p.name)
anc=json.loads((I/'ancestry.json').read_text())
put(V/'ANCESTRY_METADATA_ONLY.json',{'original_response_sha256':sha(I/'ancestry.json'),'status':anc['status'],'merge_base_commit':anc['merge_base_commit']['sha'],'base_commit':anc['base_commit']['sha'],'total_commits':anc['total_commits'],'commit_ids':[c['sha'] for c in anc['commits']],'method':'GitHub compare; not a local signed walk of pre-P0A0 history','patches_and_file_content_excluded':True})
put(V/'EXTERNAL_PRESERVATION_IDENTITIES.json',{'classification':'FROZEN RESULT','repository':'salahealer9/meru-geometry-audit','commit':'923bab7855deaee6be49dd299bbdb0d6251844c1','source_files':[s for s in d0['source_files'] if s['path'].endswith('.zip')],'verified_archives':d0['archives'],'historical_DEV':d0['historical_DEV'],'note':'Original bytes remain in signed tree and unchanged local intake. Deliberately not duplicated in this ZIP. No historical DEV reexecution.'})
envcode="import json,sys,platform,importlib.metadata;print(json.dumps({'python':sys.version,'executable':sys.executable,'prefix':sys.prefix,'base_prefix':sys.base_prefix,'platform':platform.platform(),'packages':sorted((d.metadata['Name'],d.version) for d in importlib.metadata.distributions())}))"
envcmd=[str(W/'venv/bin/python'),'-B','-c',envcode];envrun=subprocess.run(envcmd,capture_output=True,text=True,check=True);env=json.loads(envrun.stdout)
assert env['prefix']!=env['base_prefix'] and env['packages']==[]
put(R/'ENVIRONMENT_AND_DEPENDENCIES.json',{'classification':'IMPLEMENTED_UNVERIFIED','capture_command':envcmd,'capture_stdout':envrun.stdout,'capture_stderr':envrun.stderr,'isolated_runtime':env,'creation_command':'python3 -m venv --without-pip p0a3d_work/venv','third_party_numeric_dependencies':[],'common_trust':['CPython integers','fractions.Fraction','json','hashlib','OS','hardware'],'base_environment':'provenance/base_environment.json','existing_environment_modified':False,'DEV_environment_and_caps':'dev_history/*_result.json','dependency_probe_note':'SymPy/python-flint unavailable in preliminary pip show (exit 1); no packages installed. The exact implementations use stdlib only. No raw probe output was persisted separately.'})
put(R/'PROVENANCE_AND_INFORMATION_BARRIER.json',{'classification':'INDEPENDENT_DIAGNOSTIC','authority':{'commit':d0['commit'],'protocol_blob':'39944862b7ec7565188584c97695fdf925538f8a','parent':d0['commits'][0]['parent'],'fingerprint':'D4EC014EEFCC90E619D2AA59A91239ABCF512130'},'direct_GitHub_read':'Complete 212-line protocol retrieved and read before implementation; frozen normalization/failure contracts, P0A3C closeout, roadmap and QC read in full.','signed_commits_verified':len(d0['commits']),'signed_tag_verified':True,'commit_tree_blob_rehash':'See D0_verified.json and d0_verify.py','gpg_caveat':'Public key import exit 2 included gpg-agent warning; all detached signature verifications exited 0 with exact VALIDSIG. Ownertrust undefined; signer is pinned by user fingerprint.','ancestry_limit':d0['ancestry'],'branch_at_retrieval':d0['branch_tip'],'local_repository_claim':d0['workspace'],'new_writes':'Only isolated p0a3d_work; no commit/push/checkout/repository edits','no_execution':['P0A0 S00-S12','P0A4','old DEV','3D/cameras/A/B','QH','candidate-null','optimizer/scientific benchmark'],'no_target_access':['Hebrew image/glyph/font proxy','extraction','tracing','scoring'],'allowed_activity':'Constructive mathematics and four bounded generic DEV attempts under unchanged prospectively declared ceilings.','source_categories':{'frozen_documents':'SOURCE_ATTESTED','new_generic_math_and_DEV':'INDEPENDENT_DIAGNOSTIC','historical_observation':'UNRESOLVED','target_evidence':'NONE ACCESSED'},'archive_preservation':'External frozen identities; all historical 01-08 logs and source snapshots hashed without execution.','no_offhost_audit_claim':True,'inherited_limitations':'D8_ENGINEERING_AND_THEOREM_DISPOSITIONS.md','source_reuse':'SOURCE_REUSE_AND_IMPORT_GRAPH.json'})
# Exact schema, structural only. Semantic predicates remain a separate review.
def obj(props):return {'type':'object','properties':props,'required':list(props),'additionalProperties':False}
def ref(s):return {'$ref':'#/$defs/'+s}
def arr(item,n=None,minimum=None):
    x={'type':'array','items':item}
    if n is not None:x.update(minItems=n,maxItems=n)
    if minimum is not None:x['minItems']=minimum
    return x
def const(x):return {'const':x}
integer={'type':'integer','minimum':0};positive={'type':'integer','minimum':1};string={'type':'string'};hashschema={'type':'string','pattern':'^[0-9a-f]{64}$'}
defs={}
defs['rational']={'type':'array','prefixItems':[{'type':'string','pattern':'^(0|-?[1-9][0-9]*)$'},{'type':'string','pattern':'^[1-9][0-9]*$'}],'items':False,'minItems':2,'maxItems':2}
defs['term']={'type':'array','prefixItems':[integer,ref('rational')],'items':False,'minItems':2,'maxItems':2}
defs['scalar']=arr(ref('term'))
defs['limits']=obj({k:positive for k in ('max_vertices','max_input_bits','max_operations','max_coefficient_bits','max_terms','max_formal_degree','reference_max_bits')})
defs['input_path']=obj({'id':{'type':'string','minLength':1},'ordered':const(True),'parameter_domain':const('OPEN_INTERVAL'),'endpoints':arr(integer,2),'provenance':const('INDEPENDENT_GENERIC'),'vertices':arr(arr(ref('rational'),2),minimum=2)})
defs['request']=obj({'schema':const('qo2d-request-1'),'lane':const('P0A3D_QO_2D_OPEN_RATIONAL_VERTEX_SO2_EXACT'),'authority':const(d0['commit']),'nuisance':const('SO2_ONLY'),'paths':arr(ref('input_path'),2),'limits':ref('limits')})
defs['zero_event']=obj({'edge_index':integer,'reason':const('EXACT_ZERO_CONSECUTIVE_EDGE')})
defs['path_record']=obj({'zero_edges':arr(ref('zero_event')),'surviving_edge_indices':arr(integer,minimum=1),'lengths':arr(ref('scalar'),minimum=1),'total_length':ref('scalar'),'knots':arr(ref('scalar'),minimum=2),'centroid':arr(ref('scalar'),2),'variance':ref('scalar'),'rms':ref('scalar')})
defs['decision']=obj({'label':{'type':'string','minLength':1},'expression':ref('scalar'),'sign':{'type':'integer','enum':[-1,0,1]},'method':const('DESCENDING_SIGN_GUARDED_SQUARING')})
defs['pins']=obj({k:hashschema for k in ('request_sha256','production_sha256','reference_sha256')})
defs['certificate']=obj({'schema':const('qo2d-exact-1'),'lane':const('P0A3D_QO_2D_OPEN_RATIONAL_VERTEX_SO2_EXACT'),'machine_state':const('EXACT_THEOREM_CERTIFICATE_CANDIDATE_UNVALIDATED'),'request':ref('request'),'request_sha256':hashschema,'input_sha256':arr(hashschema,2),'backend':const('positive-radical-mask-v1'),'roots':arr(ref('scalar')),'paths':arr(ref('path_record'),2),'union':arr(ref('scalar'),minimum=2),'alpha':ref('scalar'),'beta':ref('scalar'),'s':ref('scalar'),'q_squared':ref('scalar'),'q':ref('scalar'),'rotation':arr(arr(ref('scalar'),2),2),'direct_residual':ref('scalar'),'roll_state':{'enum':['EXACT_WHOLE_ROLL_TIE','EXACT_UNIQUE_PROPER_ROTATION']},'decisions':arr(ref('decision'),minimum=1)})
defs['failure']=obj({'schema':const('qo2d-failure-1'),'state':{'enum':['INVALID_INPUT','NOT_EVALUABLE','RESOURCE_INCOMPLETE']},'reason':string,'request_sha256':{'oneOf':[hashschema,{'type':'null'}]}})
defs['bundle']=obj({'certificate':ref('certificate'),'external_DEV_pins':ref('pins'),'request':ref('request')})
put(R/'EXACT_CERTIFICATE_SCHEMA.json',{'$schema':'https://json-schema.org/draft/2020-12/schema','title':'P0A3D qo2d-exact-1 unvalidated candidate wire structures','$comment':'IMPLEMENTED_UNVERIFIED. Structure alone is not numerical verification or approval. Canonical rationals/root embeddings/semantic equality/trusted detached pins require separate checks.','oneOf':[ref('certificate'),ref('failure'),ref('bundle')],'$defs':defs})
# Retain the initial requirement matrix as chronology, not a final status.
initial=R/'REQUIREMENT_TRACEABILITY_D0_INITIAL.csv'
if not initial.exists():shutil.copyfile(R/'REQUIREMENT_TRACEABILITY.csv',initial)
rows=[
('D0','signed lineage and preserved chain','provenance/D0_verified.json','VERIFIED_INTEGRITY_ONLY','No repository changes or science replay'),
('D1','constructive exact theorem','THEOREM_PROOF.md','PROOF_PROPOSED','Independent mathematical QC pending'),
('D2','schema and detached pins','EXACT_CERTIFICATE_SCHEMA.json; schema.md','IMPLEMENTED_UNVERIFIED','Semantic/source trust must be checked'),
('D3','new isolated core and reference','src/; reference/','IMPLEMENTATION_INCOMPLETE','Input/process hardening blockers retained'),
('D4','prospective bounded DEV','DEV_CASES_PREDECLARED.md; dev_history/','DEV_CHECKED_ONLY','Four attempts; final 20/20; not numerical certification'),
('D5','adversarial proof review material','THEOREM_PROOF section 5; proof ledger; QC checklist','AWAITING_INDEPENDENT_QC','Author review is not independent approval'),
('D6','no extensions and preserved limitations','docs/; D8 report','DEFERRED','No QH/cameras/targets/controls executed'),
('D7','immutable inspectable candidate delivery','PACKAGE_INVENTORY.json; SHA256SUMS','CANDIDATE_PACKAGED','Integrity is not scientific qualification'),
('D8','separate gates','D8_ENGINEERING_AND_THEOREM_DISPOSITIONS.md','PROPOSED_THEOREM_INCOMPLETE_SOFTWARE','No human freeze or eligibility activated'),
('O1','ordered open 2D rational domain','THEOREM_PROOF sections 2-3; parser','PROOF_PROPOSED','Metadata is not historical order authentication'),
('O2','exact arclength and independent normalization','THEOREM_PROOF sections 1-3; both integrators','PROOF_PROPOSED','No rational-length shortcut'),
('O3','SO2 optimum and attained witness','THEOREM_PROOF section 4; direct checker','PROOF_PROPOSED','No reversal/reflection nuisance'),
('O4','honest traversal subdivision only','THEOREM_PROOF 2.3 and 5.4','PARTIAL_SCOPE_ONLY','No arbitrary sampling/smooth-curve bound'),
('O5','camera/degeneracy extension','THEOREM_PROOF 5.6','DEFERRED','No 3D/camera certificate'),
('B01','exact predicates and dependent radicals','THEOREM_PROOF 1.4-1.6; arithmetic source','EXACT_PREDICATE_UNQUALIFIED','New narrow candidate; historical blocker not retroactively closed'),
('B05','independent certificate semantics','independence matrix; checker.py','REFERENCE_INDEPENDENCE_UNQUALIFIED','Common Fraction/runtime and mathematics remain'),
('B02_B03_B04_B06','other P0A3C QH/camera/system obligations','frozen QC and roadmap','DEFERRED','No claim of inherited system completion'),
('QH_CAP','QH and all viewing capacity','docs contract and future design','DEFERRED','Out of signed P0A3D execution scope'),
('B07_B08','historical observation and fairness','D8 inherited limitations','UNRESOLVED','No target/candidate-null work')]
table('REQUIREMENT_TRACEABILITY.csv',['id','scope','evidence','disposition','limitation'],rows)
proofs=[('H1','1.1','finite rational ordered nonconstant 2D paths','strict canonical input and traversal contract'),('A1','1.2-1.3','positive backward-only root embedding','constructible algebraic closure and arithmetic'),('A2','1.4','earlier tower predicates terminate','descending exact sign including dependent zero'),('A3','1.5','evaluated denominator is nonzero','zero-conjugate inversion branch'),('A4','1.6-1.7','positive radicands and finite towers','root construction and wire reconstruction'),('P1','2.1-2.2','nonconstant path with zero edges logged','positive length and true arclength'),('P2','2.3','inserted point lies on original traversal in order','honest subdivision not arbitrary resampling'),('I1','3.1-3.2','exact comparisons and positive cell widths','union partition and two integration formulas'),('N1','3.3-3.4','continuous nonconstant path','strict positive variance and independent unit RMS'),('R1','4.1-4.3','only SO2 nuisance and unit norms','whole-domain optimum and s<=1'),('R2','4.4','exact s trichotomy','whole-roll tie versus unique optimum'),('W1','4.5','original input and canonical proper witness','direct attained residual equality'),('T1','4.6','finite input and unbounded exact model','constructive termination without practical complexity bound'),('X1','5.1-5.7','no generalization beyond hypotheses','irrational/support/reversal/resampling/tiny/3D/resource counterexamples'),('REF1','trust model reference derivation','norm zero at lower levels; nonzero before isolation','exact reference zero and outward enclosure sign')]
table('PROOF_OBLIGATIONS_AND_DECISIONS.csv',['id','proof_location','hypotheses','obligation','theorem_disposition','software_disposition','independent_verification','reviewer_decision'],[(a,b,c,d,'PROVED_HERE_AWAITING_INDEPENDENT_QC','IMPLEMENTED_UNVERIFIED_WITH_DOCUMENTED_LIMITS','Separate source and bounded DEV evidence; common trust disclosed','PENDING') for a,b,c,d in proofs]+[('SW1','contract limitations','untrusted malformed structured or raw JSON input','uniform rejection and no coercion','NOT_A_THEOREM_CLAIM','INCOMPLETE','Not established by DEV','PENDING'),('SW2','contract limitations','finite operating system resources','uniform process/resource status envelope','NOT_A_THEOREM_CLAIM','INCOMPLETE','Not established by DEV','PENDING'),('HIST','D8 report','source rights/order/optics/control fairness','no historical or scientific promotion','UNRESOLVED','DEFERRED','No target access','PENDING')])
table('PRODUCTION_REFERENCE_INDEPENDENCE.csv',['component','production','reference','distinct_route','shared_trust','qualification'],[
('rational parser','core.rational regex and Fraction canonical roundtrip','checker.fraction character scan and gcd','independent syntax implementation','CPython integers Fraction; same normative wire','UNQUALIFIED_PENDING_QC'),
('scalar storage','algebra.E sparse monomial masks','arithmetic.Algebra dense recursive coefficients','different representation/multiplication traversal','same positive quadratic tower identities','UNQUALIFIED_PENDING_QC'),
('zero/sign','Tower.sign descending sign-guarded squares','Algebra.zero norm test; sign rational interval separation','nonzero sign independently bounded','same quadratic zero theory; Fraction','UNQUALIFIED_PENDING_QC'),
('roots','Tower.root isqrt rational shortcut','Algebra.root integer bisection endpoints','different square-root integer procedure','positive root embedding and rational semantics','UNQUALIFIED_PENDING_QC'),
('mean/variance','core.build endpoint mean and centered midpoint formula','checker.path global-u primitive and raw second moment','distinct algebraic integration route','same frozen arclength estimand','UNQUALIFIED_PENDING_QC'),
('partition','core.calculate exact sort then deduplicate and walking indices','checker.reconstruct insertion merge and midpoint membership','separate control flow and exact comparisons','same breakpoint semantics','UNQUALIFIED_PENDING_QC'),
('correlations','core.quad local endpoint product quadrature','checker.integrate_product cubic antiderivative','independent expansion','same alpha beta orientation','UNQUALIFIED_PENDING_QC'),
('witness','core.calculate closed form and local residual','checker.check matrix Gram determinant and global polynomial residual','recompute from original inputs plus matrix checks','same SO2 theorem; exact arithmetic','UNQUALIFIED_PENDING_QC'),
('pins/serialization','core.canonical and digest','checker.wire and hash_object; external expected pins','no shared production function imports','stdlib json/hashlib; external trust must be supplied','UNQUALIFIED_PENDING_QC')])
imports={};files=[]
for base in ('src','reference','tests'):
    for p in sorted((P/base).rglob('*.py')):
        name=p.relative_to(P).as_posix();tree=ast.parse(p.read_text());im=[]
        for n in ast.walk(tree):
            if isinstance(n,ast.Import):im.extend(a.name for a in n.names)
            elif isinstance(n,ast.ImportFrom):im.append('.'*n.level+(n.module or ''))
        imports[name]=im;files.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p),'origin':'NEW_P0A3D_SOURCE_NO_OLD_NUMERICAL_REUSE'})
assert all('meru_geometry' not in s for n,v in imports.items() if n.startswith('reference/') for s in v)
put(R/'SOURCE_REUSE_AND_IMPORT_GRAPH.json',{'classification':'IMPLEMENTED_UNVERIFIED','numeric_source_reuse':'None: no P0A0/P0A3/P0A3C numerical module copied, imported or patched. New standalone namespaces.','read_only_provenance_driver':'D0 verifier adapted a prior read-only verification approach; included full source and exact hash, not a numerical backend. No old runner executed.','files':files,'import_graph':imports,'shared_trust':'CPython/Fraction/JSON/hashlib and positive-quadratic mathematics; no production-to-reference calls','origin_diff':'SOURCE_ADDITIONS_FROM_EMPTY.patch','per_attempt_diffs':'dev_history/*_source_diff.patch'})
patch=''.join(''.join(difflib.unified_diff([], (P/f['path']).read_text().splitlines(True),fromfile='/dev/null',tofile=f['path'])) for f in files)
(R/'SOURCE_ADDITIONS_FROM_EMPTY.patch').write_text(patch)
put(R/'FINAL_SOURCE_PINS.json',{'classification':'UNSIGNED_CANDIDATE_IDENTITIES_NOT_EXTERNAL_APPROVAL','production_sha256':hashlib.sha256(json.dumps([(f['path'],f['sha256']) for f in files if f['path'].startswith('src/')],sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()).hexdigest(),'reference_sha256':hashlib.sha256(json.dumps([(f['path'],f['sha256']) for f in files if f['path'].startswith('reference/')],sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()).hexdigest(),'files':files})
# Source identity and historical log integrity only. NO numerical reevaluation.
last=json.loads((R/'dev_history/P0A3D_DEV_04_sources.json').read_text())
assert all((P/n).read_text()==text for n,text in last.items())
checks=[]
for n in range(1,5):
    stem=f'P0A3D_DEV_{n:02}';record=json.loads((R/f'dev_history/{stem}_result.json').read_text())
    for part in ('sources','stdout','stderr','evidence'):
        ext='.log' if part in ('stdout','stderr') else '.json'
        assert sha(R/f'dev_history/{stem}_{part}{ext}')==record[part+'_sha256']
    assert sha(R/'DEV_CASES_PREDECLARED.md')==record['plan_sha256'];checks.append({'attempt':stem,'returncode':record['returncode'],'source_and_output_hashes':'MATCH'})
put(R/'FINAL_STATIC_INTEGRITY_REVIEW.json',{'classification':'INTEGRITY_CHECK_ONLY_NOT_NUMERICAL_EXECUTION','attempts':checks,'final_source_matches_attempt04':True,'reference_imports_production':False,'P0A3C_manifest_matches':len(manifest),'environment_capture_exit':envrun.returncode,'schema_semantic_limit':'Formal JSON schema generated; no external jsonschema validator invoked. All package JSON will be parsed strictly by packaging integrity check.'})
shutil.copyfile(Path(__file__),V/'assemble_records.py')
print(json.dumps({'assembly':'OK','frozen_manifest_matches':len(manifest),'new_python_sources':len(files),'historical_DEV_attempts_retained_external':len(d0['historical_DEV']),'new_DEV_attempts_integrity_checked':len(checks),'no_new_numerical_execution':True}))
