"""Read-only GitHub provenance; never imports scientific implementation code."""
from pathlib import Path,PurePosixPath
import concurrent.futures,datetime,hashlib,io,json,os,platform,stat,subprocess,sys,zipfile
W=Path(__file__).resolve().parent;I=W/'intake';G=W/'gpg';G.mkdir(mode=0o700,exist_ok=True)
C='92de104cab58339df370acf96b8d849ecc2d888b';F='D4EC014EEFCC90E619D2AA59A91239ABCF512130'
IDS=[C,'923bab7855deaee6be49dd299bbdb0d6251844c1','01270ec3bff3c9a6352c5dadc90d5d9f12da0c0d','8adbc226b1ef7234a9bedab02ca515a6c11e5c4f','2425db592e80d5f688adc0facdea9e1042c05cdb','07b64003940072e00fb2ce969ebc3866a9a3dc4d','e917fa2974997703d6ccb60b0b25d0c668d12bd5','090a1db6c95976bbb5f0d69a3cc4a4603d165505','5b0317f193c481d799e88b494ce370679fec43bc','5148712c07ac48742d3435dc14e01667280f94c3','24c00fc44e4d9d57adacd1e636e9e2d20d86a954','d15865167b4e3c454e398bd498d9d681103096f7']
PRE='8bf0babfd91bdefb0792e93707fd0b0da1c09767';TAG='12afd9f9d1cb4a9d000c0fd9555419f0383978e9';TGT='85748bff0bfae383afcc0d885f4aec505a2885dd'
PROTO='docs/v0_9/p0a3d_exact_2d_qo_core_proof_and_implementation_protocol.md';BASE='reports/v0_9/p0a3c_incomplete_checkpoint/'
PINS={PROTO:'39944862b7ec7565188584c97695fdf925538f8a',BASE+'P0A3C_NEXT_RESTRICTED_CERTIFICATION_PATH.md':'8744dd7af280a09a9e63c22aeacdb72ff4fec299',BASE+'P0A3C_INCOMPLETE_ENGINEERING_PRESERVATION_CLOSEOUT.md':'9eca1f10c6b22f2737108f1f372e36be40f715b7',BASE+'P0A3C_independent_QC_report_2026-10-19.md':'cd44729c5d019351cf5b9b8dfa5ec8400e54b7aa','reports/v0_9/p0a2_target_blind_design/score_normalization_candidates.md':'c848a6bf28471184efb9bf61ae1bd5a0e35933aa','reports/v0_9/p0a2_target_blind_design/numerical_error_failure_ledger.md':'21c4a6dfec35b90a35c36e35ceac508561f552a9'}
API='https://api.github.com/repos/salahealer9/meru-geometry-audit/'
def sha(b):return hashlib.sha256(b).hexdigest()
def obj(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def fetch(task):
    url,name=task;cmd=['curl','--fail','--silent','--show-error','--location','--max-time','90',url,'-o',str(I/name)]
    r=subprocess.run(cmd,capture_output=True,text=True)
    if r.returncode:raise RuntimeError((url,r.returncode,r.stderr))
    return name
def batch(tasks):
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
        for n in ex.map(fetch,tasks):print('RETRIEVED',n,flush=True)
batch([(API+'git/commits/'+c,'commit_'+c+'.json') for c in IDS]+[(API+'git/tags/'+TAG,'tag.json'),(API+'compare/'+TGT+'...'+PRE,'ancestry.json'),(API+'branches/hebrew-projection-capacity-v0.9','branch.json'),('https://github.com/salahealer9.gpg','public.gpg')])
commits=[json.loads((I/('commit_'+c+'.json')).read_text()) for c in IDS]
batch([(API+'git/trees/'+a['tree']['sha']+'?recursive=1','tree_'+a['tree']['sha']+'.json') for a in commits])
trees={};changes=[]
for c,a in zip(IDS,commits):
    t=json.loads((I/('tree_'+a['tree']['sha']+'.json')).read_text());assert not t['truncated'];es={e['path']:e for e in t['tree']}
    for folder,expected in {'':t['sha'],**{e['path']:e['sha'] for e in t['tree'] if e['type']=='tree'}}.items():
        ch=[(q.split('/')[-1],e) for q,e in es.items() if q.rpartition('/')[0]==folder];ch.sort(key=lambda x:(x[0]+('/' if x[1]['type']=='tree' else '')).encode())
        b=b''.join((e['mode'].lstrip('0')+' '+n).encode()+b'\0'+bytes.fromhex(e['sha']) for n,e in ch);assert obj('tree',b)==expected
    trees[c]=es
for new,old in zip(IDS,IDS[1:]):
    a,b=trees[new],trees[old];changed=[q for q,e in a.items() if e['type']=='blob' and q in b and e['sha']!=b[q]['sha']];removed=[q for q,e in b.items() if e['type']=='blob' and q not in a];added=[q for q,e in a.items() if e['type']=='blob' and q not in b]
    assert not changed and not removed;changes.append({'commit':new,'parent':old,'added':added,'changed':changed,'removed':removed})
assert changes[0]['added']==[PROTO] and len(changes[1]['added'])==7 and all(p.startswith(BASE) for p in changes[1]['added'])
paths=sorted(set(PINS)|set(changes[1]['added']))
batch([('https://raw.githubusercontent.com/salahealer9/meru-geometry-audit/'+(C if p==PROTO else IDS[1])+'/'+p,Path(p).name) for p in paths])
imp=subprocess.run(['gpg','--homedir',str(G),'--batch','--import',str(I/'public.gpg')],capture_output=True,text=True)
def signature(v,name):
    assert v['verified'] and v['reason']=='valid'
    (I/(name+'.payload')).write_text(v['payload']);(I/(name+'.asc')).write_text(v['signature'])
    cmd=['gpg','--homedir',str(G),'--batch','--no-auto-key-retrieve','--status-fd','1','--verify',str(I/(name+'.asc')),str(I/(name+'.payload'))];r=subprocess.run(cmd,capture_output=True,text=True)
    vs=[x for x in r.stdout.splitlines() if x.startswith('[GNUPG:] VALIDSIG ')];assert r.returncode==0 and len(vs)==1 and vs[0].split()[2]==F and vs[0].split()[-1]==F
    return {'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
records=[]
for i,(c,a) in enumerate(zip(IDS,commits)):
    parent=(IDS+[PRE])[i+1];assert a['sha']==c and [x['sha'] for x in a['parents']]==[parent]
    v=a['verification'];h,msg=v['payload'].split('\n\n',1)
    assert any(obj('commit',(h+'\ngpgsig '+s.replace('\n','\n ')+'\n\n'+msg).encode())==c for s in (v['signature'],v['signature']+'\n'))
    records.append({'commit':c,'parent':parent,'tree':a['tree']['sha'],'signature':signature(v,c),'object_identity':'VERIFIED'})
source=[]
for p in paths:
    b=(I/Path(p).name).read_bytes();e=trees[C][p];assert obj('blob',b)==e['sha']
    if p in PINS:assert e['sha']==PINS[p]
    source.append({'path':p,'commit':C if p==PROTO else IDS[1],'blob':e['sha'],'bytes':len(b),'sha256':sha(b)})
assert len((I/Path(PROTO).name).read_bytes().splitlines())==212
assert (I/'protocol.md').read_bytes()==(I/Path(PROTO).name).read_bytes()
oldpins={'docs/p0a0_hebrew_projection_source_identity_and_synthetic_pilot_protocol_v0.9.md':'0f8b663bfe2432685c9320a00c80fd6bcf436e38','docs/v0_9/p0a3_target_blind_numerical_implementation_and_certification_architecture_protocol.md':'38106180f7b2855992b70c925d64169dee0213ca','docs/v0_9/p0a3c_finite_camera_algebraic_interval_implementation_completion_protocol.md':'1a54a5c0626d329e1c7389ca389a907139b8413f'}
for c in IDS:
    for p,h in oldpins.items():
        if p in trees[c]:assert trees[c][p]['sha']==h
tag=json.loads((I/'tag.json').read_text());assert tag['sha']==TAG and tag['object']['sha']==TGT;assert obj('tag',(tag['verification']['payload']+tag['verification']['signature']).encode())==TAG
tag_record={'sha':TAG,'target':TGT,'signature':signature(tag['verification'],'tag')}
anc=json.loads((I/'ancestry.json').read_text());assert anc['status']=='ahead' and anc['merge_base_commit']['sha']==TGT
def safe(z):
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
    for f in z.infolist():
        p=PurePosixPath(f.filename);assert not p.is_absolute() and '..' not in p.parts and not stat.S_ISLNK(f.external_attr>>16)
def audit(z):
    safe(z);rows=json.loads(z.read('PACKAGE_INVENTORY.json'))['payload_files'];lines=z.read('SHA256SUMS').decode().splitlines()
    assert {r['path'] for r in rows}==set(z.namelist())-{'SHA256SUMS','PACKAGE_INVENTORY.json'}
    assert {l.split('  ',1)[1] for l in lines}==set(z.namelist())-{'SHA256SUMS'}
    for l in lines:
        h,n=l.split('  ',1);assert sha(z.read(n))==h
    for r in rows:assert len(z.read(r['path']))==r['bytes'] and sha(z.read(r['path']))==r['sha256']
    return {'entries':len(z.namelist()),'hashes':len(lines),'inventory':len(rows),'CRC':'PASS'}
archives=[];history=[]
base=I/'original_P0A3C_cumulative_implementation_candidate.zip';assert base.stat().st_size==4072330 and sha(base.read_bytes())=='4d327ac4cf057598d3377b93c9a22ed19bd69d3ef2dd1d59242d9001c3db3bbe'
with zipfile.ZipFile(base) as z:
    archives.append({'path':base.name,'sha256':sha(base.read_bytes()),'bytes':base.stat().st_size,**audit(z)})
    for n in z.namelist():
        if n.startswith('lineage/') and n.endswith('.zip'):
            b=z.read(n)
            with zipfile.ZipFile(io.BytesIO(b)) as inner:
                safe(inner);v=audit(inner) if 'PACKAGE_INVENTORY.json' in inner.namelist() else {'entries':len(inner.namelist()),'CRC':'PASS'}
                archives.append({'path':n,'sha256':sha(b),'bytes':len(b),**v})
    for i in range(1,9):
        folder='p0a3_implementation' if i<=6 else 'p0a3c_completion';stem=f'reports/v0_9/{folder}/dev_history/attempt_{i:02}'
        r=json.loads(z.read(stem+'_result.json'))
        for part in ('stdout','stderr'):assert sha(z.read(stem+'_'+part+'.log'))==r[part+'_sha256']
        assert sha(z.read(stem+'_prerun_sources.json'))==r['prerun_sources_sha256']
        history.append({'attempt':i,'result':r,'result_sha256':sha(z.read(stem+'_result.json')),'externally_preserved_members':[{'path':n,'bytes':len(z.read(n)),'sha256':sha(z.read(n))} for n in z.namelist() if n.startswith(stem)]})
qc=I/'original_P0A3C_independent_QC_review_2026-10-19.zip';assert sha(qc.read_bytes())=='d4e1fc5e71a00af432e87a2f35d072bdcd5d017e91566ea9b58e2b8214a89fc5'
with zipfile.ZipFile(qc) as z:safe(z);archives.append({'path':qc.name,'sha256':sha(qc.read_bytes()),'bytes':qc.stat().st_size,'entries':len(z.namelist()),'CRC':'PASS'})
branch=json.loads((I/'branch.json').read_text())
out={'phase':'P0A3D','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':C,'commits':records,'tag':tag_record,'ancestry':{'method':'GitHub compare for v0.8 to pre-P0A0; exact adjacent signed parents thereafter','merge_base':anc['merge_base_commit']['sha'],'pre_p0a0':PRE},'source_files':source,'additive_changes':changes,'archives':archives,'historical_DEV':history,'old_protocol_pins':oldpins,'key_import':{'returncode':imp.returncode,'stdout':imp.stdout,'stderr':imp.stderr},'branch_tip':branch['commit']['sha'],'workspace':'Bounded directory listing: no meru-geometry-audit checkout; no local HEAD/status claim. All new writes p0a3d_work only. No Git operations.','barrier':'No P0A0 evaluator or cases imported/executed; archives inspected as bytes only; no target pixels/geometry accessed.'}
(W/'D0_verified.json').write_text(json.dumps(out,indent=2)+'\n')
pip=subprocess.run([sys.executable,'-m','pip','freeze','--all'],capture_output=True,text=True)
(W/'base_environment.json').write_text(json.dumps({'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'os_release':Path('/etc/os-release').read_text(),'pip_freeze':pip.stdout,'pip_stderr':pip.stderr,'pip_exit':pip.returncode,'development_environment':'Not created yet; no existing environment modified'},indent=2)+'\n')
print(json.dumps({'D0':'VERIFIED','signed_commits':len(records),'signed_tag':1,'sources':len(source),'archives':archives,'history_attempts':len(history),'GPG_import_exit':imp.returncode,'branch_tip':branch['commit']['sha']},indent=2))
