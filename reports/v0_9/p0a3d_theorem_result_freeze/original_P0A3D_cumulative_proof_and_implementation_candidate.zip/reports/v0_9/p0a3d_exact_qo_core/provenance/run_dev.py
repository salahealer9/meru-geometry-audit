"""Bounded append-only P0A3D DEV logging. No frozen scientific evaluator import."""
from pathlib import Path
import datetime,difflib,hashlib,json,os,resource,subprocess,sys
W=Path(__file__).resolve().parent;P=W/'package';R=P/'reports/v0_9/p0a3d_exact_qo_core';H=R/'dev_history';H.mkdir(exist_ok=True)
i=1+len(list(H.glob('P0A3D_DEV_*_result.json')));stem=f'P0A3D_DEV_{i:02}'
snapshot={p.relative_to(P).as_posix():p.read_text() for base in ('src','reference','tests') for p in sorted((P/base).rglob('*.py'))}
(H/(stem+'_sources.json')).write_text(json.dumps(snapshot,sort_keys=True,indent=2)+'\n')
old={} if i==1 else json.loads((H/f'P0A3D_DEV_{i-1:02}_sources.json').read_text())
patch=''.join(''.join(difflib.unified_diff(old.get(n,'').splitlines(True),snapshot.get(n,'').splitlines(True),fromfile='previous/'+n,tofile='candidate/'+n)) for n in sorted(set(old)|set(snapshot)))
(H/(stem+'_source_diff.patch')).write_text(patch)
env=os.environ.copy();overrides={'PYTHONPATH':'src:.','PYTHONDONTWRITEBYTECODE':'1','PYTHONHASHSEED':'0','LC_ALL':'C.UTF-8','P0A3D_DEV_EVIDENCE':str(H/(stem+'_evidence.json'))};env.update(overrides)
cmd=[str(W/'venv/bin/python'),'-B','tests/dev_v0_9/p0a3d/test_core.py'];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
def cap():resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
try:
    r=subprocess.run(cmd,cwd=P,env=env,capture_output=True,text=True,timeout=60,preexec_fn=cap);rc,out,err=r.returncode,r.stdout,r.stderr
except subprocess.TimeoutExpired as e:
    rc=124;out=e.stdout or '';err=e.stderr or ''
    if isinstance(out,bytes):out=out.decode()
    if isinstance(err,bytes):err=err.decode()
    err+='\nRESOURCE_INCOMPLETE: DEV 60-second subprocess cap reached. No certification.\n'
(H/(stem+'_stdout.log')).write_text(out);(H/(stem+'_stderr.log')).write_text(err)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result={'attempt':stem,'start_utc':start,'command':cmd,'cwd':str(P),'environment':overrides,'returncode':rc,'timeout_seconds':60,'RLIMIT_AS':1073741824,'plan_sha256':sha(R/'DEV_CASES_PREDECLARED.md'),'sources_sha256':sha(H/(stem+'_sources.json')),'stdout_sha256':sha(H/(stem+'_stdout.log')),'stderr_sha256':sha(H/(stem+'_stderr.log'))}
if (H/(stem+'_evidence.json')).exists():result['evidence_sha256']=sha(H/(stem+'_evidence.json'))
(H/(stem+'_result.json')).write_text(json.dumps(result,indent=2)+'\n')
with (R/'DEV_EXECUTION_LOG.txt').open('a') as f:f.write('\n'+json.dumps(result,indent=2)+'\nSTDOUT\n'+out+'\nSTDERR\n'+err+'\n')
print(json.dumps(result,indent=2));print(out);print(err);sys.exit(rc)
