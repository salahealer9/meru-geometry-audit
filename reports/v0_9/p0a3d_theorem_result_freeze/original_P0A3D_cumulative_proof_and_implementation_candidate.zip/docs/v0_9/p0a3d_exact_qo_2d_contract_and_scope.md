# P0A3D contract and scope

[FROZEN RESULT] Authority is commit `92de104cab58339df370acf96b8d849ecc2d888b`,
protocol Git blob `39944862b7ec7565188584c97695fdf925538f8a`, direct parent
`923bab7855deaee6be49dd299bbdb0d6251844c1`, fingerprint
`D4EC014EEFCC90E619D2AA59A91239ABCF512130`. The complete immutable protocol
and the two P0A2 mathematical contracts are included under report provenance.
Their historical draft banners are unchanged; authority comes from the signed
commit, not an edited banner. This document does not amend that protocol.

## Mathematical contract

[PROVED_HERE_AWAITING_INDEPENDENT_QC] Two finite nonconstant ordered lists in
Q² determine continuous open-interval polygonal traversals. At least two
vertices are supplied. Distinguished initial/final indices remain fixed, even
when their positions coincide. Consecutive equal vertices have zero edge length
and are bypassed with an index ledger linked to the original input. Retracing
and nonconsecutive returns retain their multiplicity. No unordered-support,
nearest-neighbour or sampled-point correspondence substitutes for traversal.

[FROZEN RESULT] For each path independently, normalized Euclidean arclength u
defines its mean c=integral a(u)du and radius r=sqrt(integral ||a-c||²du).
Normalize A=(a-c)/r, B=(b-c_b)/r_b. The sole objective is
q=min_{Q in SO(2)} sqrt(integral ||QA(u)-B(u)||²du), on 0<=u<=1.
Translation and positive scale removal are deterministic normalizers, not
additional fitted nuisance parameters. Reflection, reversal, cyclic phase,
time warp, correspondence permutation, free deformation, trimming, masks,
stroke assignment, rasterization, cameras and physical optics are forbidden.

[PROVED_HERE_AWAITING_INDEPENDENT_QC] The numbered theorem proves positive
RMS from nonconstancy and exact computation despite irrational segment lengths.
Honest subdivision of a straight traversal preserves the map; arbitrary
resampling does not. The theorem quantifies over every finite valid input,
not just inputs small enough to finish under a particular implementation cap.

## Candidate API and wire contract

[IMPLEMENTED_UNVERIFIED] Production public functions are in
`src/meru_geometry/v0_9/qo2d_exact/core.py`: `rational`, `validate`, `calculate`,
`execute`, `canonical`, `digest`. `Tower` implements exact scalar operations.
The independent API is `reference.v0_9.qo2d_exact.checker.check(c, expected)`.
It does not import production code. The JSON schema and its documentation
specify the full structured request and certificate. Coordinates are reduced
`[numerator_string, denominator_string]`, with strictly positive denominator.
Binary64, rounded decimals, booleans and nonreduced spellings are not exact input.

[IMPLEMENTED_UNVERIFIED] Requests must declare the exact lane
`P0A3D_QO_2D_OPEN_RATIONAL_VERTEX_SO2_EXACT`, authority commit, `SO2_ONLY`,
two distinct input IDs, `ordered: true`, `parameter_domain: OPEN_INTERVAL`,
`endpoints: [0,n-1]`, `provenance: INDEPENDENT_GENERIC` and explicit limits.
The literal OPEN_INTERVAL denotes an open-path traversal with distinguished
ends, not exclusion of endpoints from the integration interval [0,1].
Independent IDs and a provenance declaration are metadata: code cannot prove
that an external submitter obtained them independently or without target access.

[IMPLEMENTED_UNVERIFIED] Successful output is always
`EXACT_THEOREM_CERTIFICATE_CANDIDATE_UNVALIDATED`. Exact sign records are -1/0/+1;
zero and positive are not approximate statuses. Tie classification is
`EXACT_WHOLE_ROLL_TIE`, otherwise `EXACT_UNIQUE_PROPER_ROTATION`.
Production `execute` maps its typed malformed-input, constant-path and budget
exceptions to `INVALID_INPUT`, `NOT_EVALUABLE`, `RESOURCE_INCOMPLETE` envelopes.
The checker raises `InvalidProof` or `Incomplete` instead of granting approval.
An isolation-cap `Incomplete` names `UNRESOLVED_EXACT_PREDICATE` in its reason;
it never yields a tie or a guessed score. Exact-domain contradictions are not
caught as successful scores and require stopping and preserving evidence.

## Important software limitations

[UNRESOLVED] This is a structured Python-object API, not a hardened raw-JSON
service. No production CLI or duplicate-key-detecting raw JSON reader is supplied.
An external reader must reject duplicate keys and nonfinite constants before
forming canonical objects. The normative JSON schema is supplied for structural
review, but a schema is not the exact verifier and is not automatically invoked
by `check`. Some malformed nested object shapes can raise Python exceptions
instead of the intended typed envelope; certificate edge-index metadata is
compared by Python equality, which does not by itself distinguish booleans from
integers. These are engineering hardening blockers, not alterations of QO.

[UNRESOLVED] Huge integer conversion, recursion exhaustion, memory exhaustion
and externally killed processes are not uniformly translated to typed results.
Arithmetic caps count software operations/constructed coefficient sizes; they
are not a hard bound on every temporary allocation. The DEV runner adds a
60-second wall-time and 1 GiB address-space limit, but the bare API does not.
Reviewers must not infer safe arbitrary hostile-input handling or completion
for all finite inputs from the theorem or bounded DEV. No software readiness
or registered-validation eligibility is claimed.

[DEFERRED] There is no 3D lift, QH, camera A/B family, continuous viewing capacity,
Hebrew metric selection, target preparation or candidate/null evaluation here.
