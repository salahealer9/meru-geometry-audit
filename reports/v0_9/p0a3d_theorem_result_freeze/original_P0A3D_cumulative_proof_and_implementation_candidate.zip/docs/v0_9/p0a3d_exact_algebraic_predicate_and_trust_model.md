# Exact algebraic predicates and trust boundary

[PROVED_HERE_AWAITING_INDEPENDENT_QC] See THEOREM_PROOF lemmas 1.2–1.7 for a
constructive positive-square-root tower, with no irreducibility assumption.
It represents the constructible real algebraic subfield needed by this exact
QO problem; it is not a general solver for every real algebraic polynomial.
All operations required by the registered domain lie in this subfield.

## Production derivation

[PROVED_HERE_AWAITING_INDEPENDENT_QC] Write x=A+B sqrt(r), r>0 in a lower
tower. If A and B have the same sign, x has that sign; zero A/B are handled
separately. For opposite signs, sign(x)=sign(A)*sign(A²-B²r). Every comparison
reduces tower height. Thus equality of dependent radicals is decidable without
an oracle or a floating separation threshold. Nonzero x is invertible by its
conjugate divided by A²-B²r when that norm is nonzero. If the norm is zero,
nonzero x=2A, so invert 2A in the lower tower. Treating a formal quotient as an
irreducible field would miss this case. The proof explicitly does not do that.

[IMPLEMENTED_UNVERIFIED] Production uses sparse monomial masks, rational
coefficient combination, root-square reduction, the descending sign rule and
exact rational-square shortcut using integer `isqrt`. Root radicands refer only
to earlier indices and are embedded by positive roots. Caches are keyed by
construction vectors within one append-only tower. Canonical serialization is
of a construction, not a unique representation of its evaluated algebraic value.

## Separately derived reference route

[IMPLEMENTED_UNVERIFIED] The reference uses dense recursive coefficient vectors,
recursive quadratic multiplication, a separately coded norm-based zero decision,
and rational outward enclosures for the sign of a proven nonzero value. Its
integer square-root endpoints use integer bisection, not production `isqrt`.
It reconstructs global-u affine coefficients, integrates their antiderivatives,
computes raw second moment minus squared mean, and directly integrates the
rotated residual. Production instead uses local endpoint quadrature and centered
midpoint/difference variance. Parsers, partition assembly and source hashing
are separately authored. No production imports occur in reference code.

[PROVED_HERE_AWAITING_INDEPENDENT_QC] Reference zero test: for x=A+B sqrt(r),
if B=0 then x=0 iff A=0; if A=0 and B!=0 then x!=0. Otherwise x=0 iff
A²-B²r=0 and sign(A) differs from sign(B). All zero and sign calls involved
are in strictly lower towers. Inductively they terminate in the unbounded model.

[PROVED_HERE_AWAITING_INDEPENDENT_QC] For sign after nonzero has been established,
enclose rational constants exactly. Interval addition and all four endpoint
products enclose sums/products. For a radicand enclosure [l,h] known to contain
a positive value, replace l by max(0,l) and use dyadic lower/upper square-root
bounds computed by exact squared integer comparison. The lower endpoint is
floor(2^b sqrt(max(0,l)))/2^b; the upper is the corresponding ceiling for h.
They enclose the intended positive branch. By induction in tower height,
enclosure widths tend to zero as b tends to infinity: finite sums/products are
continuous, square root is continuous on [0,infinity), and endpoint rounding
width tends to zero. Hence any *already proven nonzero* value eventually has
a strictly positive lower bound or strictly negative upper bound. Zero is never
inferred from overlapping intervals. The software's doubling sequence 8,16,...
and fixed maximum may instead report unresolved exact predicate; that is not
mathematical nontermination. No analytic lower bound on separation is assumed.

## Common trust, limitations and review obligations

[UNRESOLVED] Both implementations share CPython integer semantics, stdlib
`fractions.Fraction`, JSON/SHA-256, the operating system and hardware. They also
share the mathematics of positive quadratic towers and the reducible-norm
inversion identity. Separate source is not fully independent mathematical or
runtime trust. There is no formal proof assistant, verified compiler or external
arithmetic oracle. An independent reviewer must audit these common foundations,
including exact comparisons of dependent generators and the reference enclosure
induction. DEV agreement cannot establish absence of a common-mode defect.

[UNRESOLVED] Certificate verification requires detached expected request and
production/reference source hashes. `observed_pins` is only a convenience
hashing utility; calling it on an untrusted deployment does not create trust.
It hashes live source files, not an attestation of all loaded runtime code.
DEV expected pins are harness observations, not human-signed source authority.
An independent freeze must establish reviewed source/runtime identities before
any future registered validation. The signed protocol is not a signed code freeze.

[IMPLEMENTED_UNVERIFIED] Finite budgets cover vertices, input/coefficient bits,
terms, formal tower degree, operation count and reference isolation. A formal
degree of 2^k is a representation-size ceiling, not the irreducible field degree.
Dependent roots can waste formal dimension; failure at a cap says nothing about
the exact value or theorem. Production and reference operation counts differ.
No timing/optimizer benchmark or asymptotic performance claim is supplied.

[UNRESOLVED] The contract document lists parser, raw-JSON and process-resource
hardening blockers. Keep `P0A3D_EXACT_PREDICATE_UNQUALIFIED` and
`P0A3D_REFERENCE_INDEPENDENCE_UNQUALIFIED` until substantive independent review;
these labels refer to qualification, not a discovered contradiction in the proof.
