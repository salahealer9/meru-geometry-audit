"""Prospectively bounded generic DEV; never a registered numerical run."""
import copy,json,os,unittest
from pathlib import Path
from fractions import Fraction as F
from meru_geometry.v0_9.qo2d_exact import core as prod
from meru_geometry.v0_9.qo2d_exact.algebra import Tower
from reference.v0_9.qo2d_exact import checker as ref
from reference.v0_9.qo2d_exact.arithmetic import Algebra,InvalidProof,Incomplete

LIMITS={'max_vertices':6,'max_input_bits':64,'max_operations':2000000,'max_coefficient_bits':16384,'max_terms':1024,'max_formal_degree':256,'reference_max_bits':256}
A=[(1,3),(2,4),(4,5)];ROT=[(4,-1),(3,0),(2,2)];LINE=[(-3,0),(3,0)];TIE=[(2,0),(-2,0),(2,0)]
def pair(x):x=F(x);return [str(x.numerator),str(x.denominator)]
def request(a,b):
    def path(p,i):return {'id':i,'ordered':True,'parameter_domain':'OPEN_INTERVAL','endpoints':[0,len(p)-1],'provenance':'INDEPENDENT_GENERIC','vertices':[[pair(x),pair(y)] for x,y in p]}
    return {'schema':'qo2d-request-1','lane':prod.LANE,'authority':prod.AUTHORITY,'nuisance':'SO2_ONLY','paths':[path(a,'generic-source'),path(b,'generic-comparison')],'limits':dict(LIMITS)}

class CoreDEV(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.evidence={'scope':'P0A3D_BOUNDED_DEV_ONLY','cases':{},'checks':{}};cls.cases={}
        fixtures=[('irrational',A,ROT),('straight',LINE,[(1,-5),(1,1)]),('subdivision',[(1,3),(1,3),(F(3,2),F(7,2)),(2,4),(4,5)],A),('tie',LINE,TIE),('tiny',LINE,[(2,0),(-2,0),(2+F(1,2**20),0)]),('traversal',A,list(reversed(A)))]
        for name,a,b in fixtures:
            req=request(a,b);pins=ref.observed_pins(req);cert=prod.execute(req)
            cls.cases[name]=(req,cert,pins);cls.evidence['cases'][name]={'request':req,'external_DEV_pins':pins,'certificate':cert};cls.save()
    @classmethod
    def save(cls):Path(os.environ['P0A3D_DEV_EVIDENCE']).write_text(json.dumps(cls.evidence,sort_keys=True,indent=2)+'\n')
    def verified(self,name):
        r,c,p=self.cases[name];self.assertEqual(c['machine_state'],'EXACT_THEOREM_CERTIFICATE_CANDIDATE_UNVALIDATED')
        result=ref.check(c,p);self.evidence['checks'][name]=result;self.save();return c
    def test_01_rational_parser(self):
        self.assertEqual(prod.rational(['-7','3']),F(-7,3))
        for x in (0.5,True,['1.0','2'],['01','2'],['-0','1'],['2','4'],['1','0'],['1','-2']):
            with self.assertRaises(ValueError):prod.rational(x)
    def test_02_contract(self):
        for kind in ('order','closed','dim','nuisance'):
            r=request(A,ROT)
            if kind=='order':r['paths'][0]['ordered']=False
            elif kind=='closed':r['paths'][0]['parameter_domain']='CLOSED'
            elif kind=='dim':r['paths'][0]['vertices'][0].append(['0','1'])
            else:r['nuisance']='ALLOW_REVERSAL'
            self.assertEqual(prod.execute(r)['state'],'INVALID_INPUT')
        with self.subTest('Boolean endpoint indices must not equal integer indices'):
            r=request(LINE,[(1,-5),(1,1)]);r['paths'][0]['endpoints']=[False,True]
            with self.assertRaises(prod.InvalidInput):prod.validate(r)  # parser only, no seventh score evaluation
        with self.subTest('Noncanonical NaN input has a typed unscored failure'):
            r=request(A,ROT);r['paths'][0]['vertices'][0][0]=float('nan')
            self.assertEqual(prod.execute(r)['state'],'INVALID_INPUT')
    def test_03_irrational(self):
        c=self.verified('irrational');self.assertEqual(c['q'],[]);self.assertGreaterEqual(len(c['roots']),2)
    def test_04_moments(self):
        c=self.verified('straight');self.assertEqual(c['q'],[])
        self.assertEqual(c['paths'][0]['centroid'],[[],[]]);self.assertEqual(c['paths'][0]['variance'],[[0,['3','1']]])
    def test_05_subdivision(self):
        c=self.verified('subdivision');self.assertEqual(c['q'],[]);self.assertEqual(c['paths'][0]['zero_edges'],[{'edge_index':0,'reason':'EXACT_ZERO_CONSECUTIVE_EDGE'}]);self.assertEqual(c['paths'][0]['surviving_edge_indices'],[1,2,3])
    def test_06_whole_tie(self):
        c=self.verified('tie');self.assertEqual(c['roll_state'],'EXACT_WHOLE_ROLL_TIE');self.assertEqual(c['q_squared'],[[0,['2','1']]]);self.assertEqual(c['s'],[])
    def test_07_tiny_positive(self):
        c=self.verified('tiny');self.assertEqual(c['roll_state'],'EXACT_UNIQUE_PROPER_ROTATION');self.assertEqual(next(d['sign'] for d in c['decisions'] if d['label']=='s'),1)
    def test_08_fixed_traversal(self):
        c=self.verified('traversal');self.assertEqual(len(c['union']),4);self.assertNotEqual(c['q'],[])
    def test_09_nested_exact_zero(self):
        t=Tower(LIMITS);r=t.root(2);s=t.root(3+2*r);self.assertEqual(t.sign(s-1-r),0)
    def test_10_independent_nested(self):
        t=Algebra(LIMITS);r=t.root(t.number(2));s=t.root(t.plus(t.number(3),t.scale(r,2)));self.assertTrue(t.zero(t.minus(s,t.plus(t.number(1),r))))
    def test_11_zero_conjugate_inverse(self):
        t=Tower(LIMITS);r=t.root(2);s=t.root(3+2*r);x=1+r+s;self.assertEqual(t.sign(x*(1/x)-1),0)
        z=Algebra(LIMITS);r=z.root(z.number(2));s=z.root(z.plus(z.number(3),z.scale(r,2)));x=z.plus(z.plus(z.number(1),r),s);self.assertTrue(z.zero(z.minus(z.product(x,z.inverse(x)),z.number(1))))
    def test_12_tiny_root_difference(self):
        t=Tower(LIMITS);self.assertEqual(t.sign(t.root(F(2)+F(1,2**20))-t.root(2)),1)
        z=Algebra(LIMITS);self.assertEqual(z.sign(z.minus(z.root(z.number(F(2)+F(1,2**20))),z.root(z.number(2)))),1)
    def forged(self,change):
        r,c,p=self.cases['straight'];c=copy.deepcopy(c);change(c)
        with self.assertRaises(InvalidProof):ref.check(c,p)
    def test_13_forged_score(self):self.forged(lambda c:c.update(q_squared=[[0,['99','1']]]))
    def test_14_forged_rotation(self):
        # Identity is itself proper, but not the optimal J for this fixed pair.
        self.forged(lambda c:c.update(rotation=[[[[0,['1','1']]],[]],[[],[[0,['1','1']]]]]))
    def test_15_omitted_union(self):
        r,c,p=self.cases['traversal'];c=copy.deepcopy(c);c['union'].pop(1)
        with self.assertRaises(InvalidProof):ref.check(c,p)
    def test_16_external_backend_order(self):
        r,c,p=self.cases['straight'];fake=dict(p);fake['request_sha256']='0'*64
        with self.assertRaises(InvalidProof):ref.check(c,fake)
        self.forged(lambda c:c.update(backend='unknown'))
        self.forged(lambda c:c['request']['paths'][0]['vertices'].reverse())
    def test_17_bad_root_definition(self):
        self.forged(lambda c:c['roots'].__setitem__(0,[[0,['-2','1']]]))
        self.forged(lambda c:c['roots'].__setitem__(0,[[1,['2','1']]]))
    def test_18_false_decision(self):self.forged(lambda c:c['decisions'][0].update(expression=[],sign=0))
    def test_19_serialization_and_constant(self):
        c=self.cases['straight'][1];self.assertEqual(prod.canonical(c),prod.canonical(json.loads(prod.canonical(c))))
        self.assertEqual(prod.execute(request([(2,7),(2,7)],LINE))['state'],'NOT_EVALUABLE')
    def test_20_resource(self):
        for key,value in [('max_operations',1),('max_formal_degree',1),('max_input_bits',1),('max_coefficient_bits',1)]:
            r=request(A,ROT);r['limits'][key]=value;c=prod.execute(r);self.assertEqual(c['state'],'RESOURCE_INCOMPLETE');self.assertNotIn('q',c)
        lim=dict(LIMITS);lim['max_operations']=1;z=Algebra(lim)
        with self.assertRaises(Incomplete):z.sign(z.number(2))

if __name__=='__main__':unittest.main(verbosity=2)
