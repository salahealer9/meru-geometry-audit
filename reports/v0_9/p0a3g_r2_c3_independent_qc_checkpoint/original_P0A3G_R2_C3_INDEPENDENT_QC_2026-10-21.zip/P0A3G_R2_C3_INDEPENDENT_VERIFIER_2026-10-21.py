#!/usr/bin/env python3
"""Independent, read-only C3 audit. No candidate or agent-provided checker import/run."""
import hashlib, io, json, pathlib, stat, zipfile
from collections import Counter

ROOT=pathlib.Path('/mnt/data')
C3='P0A3G_R2_C3_RECEIPT_CHAIN_CLOSEOUT_CANDIDATE.zip'
FIXED_ARCHIVES={
 'P0A3G_R2-C0.zip':(63036,'e99811f3eefd90a49726e9ea37d8eae8b739829cc90bc825f3dec489d731bbb5'),
 'P0A3G_R2-C1.zip':(175429,'740da6990834846a579cc07dccdafcab23f147c5f00117c25505a1cbce847589'),
 'P0A3G_R2-C1-REV1.zip':(197250,'b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1'),
 'P0A3G_R2-C2.zip':(1388186,'860d93dce952a73b65b097e3f7b4da420c0a327ee0ca8b6d4c213865db2d1cbb'),
 'P0A3G_R2-CFINAL.zip':(1224562,'7c9770d15a3a578f61def2571813d84baadda34bfe3d31cfc1b5cdd722a51eb4')}
FIVE={
 'receipts/R2-C0_RECEIPT.json':(1407,'c2ee82bf82b25a69287d1b2de4bf4ec5153c7b4855dc0577a24ab60d067a3227'),
 'receipts/R2-C1-REV1_LOCK_RECEIPT.md':(6179,'2827b38bdbdc6a6d220964b16c2f41ea07fa0d9ff817a7b24b513bc456e78b41'),
 'receipts/R2-C1-REV1_RECEIPT.json':(3035,'3dcd2e71208d681591ffb8d3b9bf1d1d550bc367be9bcdfcb4711a17de1e72bf'),
 'receipts/rejected_R2-C1/R2-C1_LOCK_RECEIPT.md':(6779,'87ca678ffe3fb4585d03d176e9f8485028ea578e9f309dfd4b02d472c1f73191'),
 'receipts/rejected_R2-C1/R2-C1_RECEIPT.json':(2217,'a505d6d6853db1fa9b9f56f351f780ca0b1c7739d0426c63b5b67667f8acd370')}
C2R=('receipts/R2-C2_RECEIPT.json',2665,'9ecbeb9d17222c1e89f176ea4caa5d79b0d5aafd52e5baf5968113269caa0789')
POST=('R2-CFINAL_RECEIPT.json',2144,'b1edb13846dc316d5a0dffbb0daf54d798ffb4a84430251465f179ceb3ccae4c')
RECOV_NAME='P0A3G_R2_ORIGINAL_PRIOR_RECEIPTS_READONLY_RECOVERY_2026-10-21.zip'
RECOV=(16281,'25796ef25cd2f2734e3549aa4ddbdaf80da6fa6b80681b2415a16e1cc5919a44')
C3PIN=(56943,'5c57483ddddd6b9d25332bedea2b590d1f0f4c7079df10baf3ef50cc66d5d362')
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def verify(label, cond, extra=None):
    checks.append({'check':label,'pass':bool(cond),'detail':extra})
    if not cond:raise AssertionError(label + (': '+str(extra) if extra else ''))
def pin(label,b,expected):verify(label,len(b)==expected[0] and sha(b)==expected[1],{'bytes':len(b),'sha256':sha(b)})
def zip_audit(label,contents,inventory=True):
    z=zipfile.ZipFile(io.BytesIO(contents)); info=z.infolist(); names=[i.filename for i in info]; verify(label+'.no_duplicate_paths',len(names)==len(set(names)))
    verify(label+'.safe_regular_paths',all(i.filename and not i.filename.startswith('/') and '\\' not in i.filename and all(p not in ('.','..','') for p in i.filename.split('/')) and not i.is_dir() and (i.external_attr>>16==0 or stat.S_IFMT(i.external_attr>>16)==stat.S_IFREG) for i in info))
    verify(label+'.crc',z.testzip() is None)
    if 'SHA256SUMS' in names:
      lines=z.read('SHA256SUMS').decode().splitlines(); hashes={}
      for x in lines:
        parts=x.split('  ',1);verify(label+'.hash_line_'+str(len(hashes)),len(parts)==2 and len(parts[0])==64 and parts[1] not in hashes);hashes[parts[1]]=parts[0]
      verify(label+'.manifest_members',set(hashes)==set(names)-{'SHA256SUMS'},[len(hashes),len(names)])
      for n,d in hashes.items():verify(label+'.sha256:'+n,sha(z.read(n))==d)
    if inventory:
      v=json.loads(z.read('PACKAGE_INVENTORY.json')); files=v['payload_files']; rows={x['path']:x for x in files}; verify(label+'.inventory_paths',len(files)==len(rows) and set(rows)==set(names)-{'PACKAGE_INVENTORY.json','SHA256SUMS'})
      for n,item in rows.items():verify(label+'.inventory:'+n,item['bytes']==len(z.read(n)) and item['sha256']==sha(z.read(n)))
    return z

p=ROOT/C3; original_c3=p.read_bytes(); pin('c3_outer',original_c3,C3PIN)
c3=zip_audit('c3',original_c3)
expected_members={
 'README.md','C3_INPUT_PROVENANCE.json','C3_CHECK_LEDGER.json','C3_ABSENCE_AND_CHRONOLOGY.md','C3_EXECUTION_LOG.txt','C3_STATUS.md','C3_INDEPENDENT_QC_CHECKLIST_BLANK.md','PACKAGE_INVENTORY.json','SHA256SUMS',
 'historical_readonly_recovery/ORIGINAL_P0A3G_R2_PRIOR_RECEIPTS_READONLY_RECOVERY_2026-10-21.zip',
 'post_cfinal_context/R2-CFINAL_RECEIPT.json',
 *(('original_cfinal/'+n) for n in FIVE),
 'original_cfinal/'+C2R[0]
}
verify('c3.exact_member_set',set(c3.namelist())==expected_members)
for fname,pinpair in FIXED_ARCHIVES.items():pin('signed_original:'+fname,(ROOT/fname).read_bytes(),pinpair)
zz={name:zip_audit(name,(ROOT/name).read_bytes()) for name in FIXED_ARCHIVES}
# Independently compare originals with the signed QC preservation human signing candidate, itself frozen as e491e1 evidence.
with zipfile.ZipFile(ROOT/'P0A3G_R2_INCOMPLETE_QC_PRESERVATION_SIGNING_CANDIDATE_2026-10-21.zip') as signed:
  pre='reports/v0_9/p0a3g_r2_independent_qc_incomplete_checkpoint/'
  rawmanifest=signed.read(pre+'QC_INCOMPLETE_PRESERVATION_MANIFEST.sha256')
  verify('original_preservation_manifest_sha',sha(rawmanifest)=='362dca23bb9ad93c2ed2f67d0e2fe39a520e4797e8a123060604d33b01d9cce7')
  for n,src in {'P0A3G_R2-C0.zip':'original_P0A3G_R2_C0.zip','P0A3G_R2-C1.zip':'original_P0A3G_R2_C1_REJECTED.zip','P0A3G_R2-C1-REV1.zip':'original_P0A3G_R2_C1_REV1.zip','P0A3G_R2-C2.zip':'original_P0A3G_R2_C2.zip','P0A3G_R2-CFINAL.zip':'original_P0A3G_R2_CFINAL.zip'}.items():
    verify('original_preservation_exact:'+n,signed.read(pre+src)==(ROOT/n).read_bytes())
  manifest_lines=dict((l.split('  ',1)[1],l.split('  ',1)[0]) for l in rawmanifest.decode().splitlines());
  verify('signed_original_manifest_covers_5',all(manifest_lines.get(pre+src)==FIXED_ARCHIVES[n][1] for n,src in {'P0A3G_R2-C0.zip':'original_P0A3G_R2_C0.zip','P0A3G_R2-C1.zip':'original_P0A3G_R2_C1_REJECTED.zip','P0A3G_R2-C1-REV1.zip':'original_P0A3G_R2_C1_REV1.zip','P0A3G_R2-C2.zip':'original_P0A3G_R2_C2.zip','P0A3G_R2-CFINAL.zip':'original_P0A3G_R2_CFINAL.zip'}.items()))

# CFINAL immutable nested historical archive bytes
nested={'P0A3G_R2-C0.zip':'checkpoints/P0A3G_R2-C0.zip','P0A3G_R2-C1.zip':'checkpoints/rejected_not_released/P0A3G_R2-C1.zip','P0A3G_R2-C1-REV1.zip':'checkpoints/P0A3G_R2-C1-REV1.zip','P0A3G_R2-C2.zip':'checkpoints/P0A3G_R2-C2.zip'}
cfinal=zz['P0A3G_R2-CFINAL.zip']
for n,path in nested.items(): verify('cfinal_nested_exact:'+n,cfinal.read(path)==(ROOT/n).read_bytes())
# independent FIVE negative C2 checks: exact path, basename, and full bytes/digest
c2=zz['P0A3G_R2-C2.zip']; c2names=c2.namelist(); c2sha={sha(c2.read(n)) for n in c2names}; c2receipts=[n for n in c2names if n.endswith('.receipt.json')];
verify('c2_absent_receipts_directory',not any(x.startswith('receipts/') for x in c2names))
verify('c2_worker_receipt_count_138',len(c2receipts)==138,len(c2receipts))
for n,(length,digest) in FIVE.items():
  verify('c2_receipt_absent_path:'+n,n not in c2names)
  verify('c2_receipt_absent_basename:'+n,all(x.rsplit('/',1)[-1]!=n.rsplit('/',1)[-1] for x in c2names))
  verify('c2_receipt_absent_digest:'+n,digest not in c2sha)
  raw=cfinal.read(n);pin('original_cfinal_receipt:'+n,raw,(length,digest));verify('c3_exact_cfinal_receipt:'+n,c3.read('original_cfinal/'+n)==raw)
  if n.endswith('.json'):json.loads(raw)
# recovered original prior receipts and temporal context
recraw=c3.read('historical_readonly_recovery/ORIGINAL_P0A3G_R2_PRIOR_RECEIPTS_READONLY_RECOVERY_2026-10-21.zip')
pin('recovery_original',recraw,RECOV)
verify('recovery_equal_prior_unsigned_original',recraw==(ROOT/RECOV_NAME).read_bytes())
recovery=zip_audit('recovery',recraw,inventory=False)
for n in FIVE:verify('recovery_exact_receipt:'+n,recovery.read('original_cfinal/'+n)==cfinal.read(n))
verify('recovery_later_c2_receipt',recovery.read('post_C2_context/R2-C2_RECEIPT.json')==cfinal.read(C2R[0]))
# corroborated earlier copies exactly as protocol sets
for n,other in {'receipts/R2-C0_RECEIPT.json':'r2c0/R2-C0_RECEIPT.json','receipts/rejected_R2-C1/R2-C1_LOCK_RECEIPT.md':'review/REJECTED_R2-C1_LOCK_RECEIPT.md','receipts/rejected_R2-C1/R2-C1_RECEIPT.json':'review/REJECTED_R2-C1_RECEIPT.json'}.items():verify('c1rev1_corroboration:'+n,zz['P0A3G_R2-C1-REV1.zip'].read(other)==cfinal.read(n))
# later receipts context
r=cfinal.read(C2R[0]);pin('cfinal_later_c2_receipt',r,C2R[1:]);verify('c3_later_c2_receipt',c3.read('original_cfinal/'+C2R[0])==r)
verify('c2_has_no_later_c2_receipt',C2R[0] not in c2names and C2R[2] not in c2sha)
post=c3.read('post_cfinal_context/'+POST[0]);pin('post_cfinal_receipt',post,POST[1:]);verify('post_cfinal_standalone_byte_equal',post==(ROOT/POST[0]).read_bytes())
verify('post_cfinal_not_member_or_digest_in_cfinal',POST[0] not in cfinal.namelist() and POST[2] not in {sha(cfinal.read(n)) for n in cfinal.namelist()})
json.loads(r);json.loads(post)
# Provenance, ledger, chronology, agent limitations: preserve historical negatives, no signed authority claims.
provenance=json.loads(c3.read('C3_INPUT_PROVENANCE.json'));ledger=json.loads(c3.read('C3_CHECK_LEDGER.json'))
verify('ledger_75_distinct_pass',len(ledger['checks'])==75 and ledger['checks_total']==75 and ledger['checks_passed']==75 and len({x['id'] for x in ledger['checks']})==75 and all(x['result']=='PASS' for x in ledger['checks']) and not ledger['failed_check_ids'])
verify('ledger_critical_groups',set(x['group'] for x in ledger['checks'])=={'archive','source','corroboration','later','negative_c2','nested','positive_cfinal','recovery'})
verify('provenance_exact_c3_authority',provenance['c3_source_read_ledger_verbatim']['branch_tip_at_start']=='f5e31de09a8b79ddb1b5f0ba738443fc4012a390')
verify('provenance_signed_parent',provenance['c3_source_read_ledger_verbatim']['signed_preservation_commit']=='e491e1e9f96391cd512db0dd528765d63bc179c1')
status=c3.read('C3_STATUS.md').decode();chrono=c3.read('C3_ABSENCE_AND_CHRONOLOGY.md').decode();readme=c3.read('README.md').decode();log=c3.read('C3_EXECUTION_LOG.txt').decode();blank=c3.read('C3_INDEPENDENT_QC_CHECKLIST_BLANK.md').decode()
for marker in ('R2_QCF01_C2_PRIOR_RECEIPTS_OMITTED','P0A3G_R2_INDEPENDENT_QC_NOT_FULLY_QUALIFIED'):
 for location,s in [('status',status),('chronology',chrono),('readme',readme)]:verify('historical_retained:'+marker+':'+location,marker in s)
verify('not_agent_approved',not any('| PASS |' in s or '| APPROVED |' in s for s in blank.splitlines()))
verify('script_logged_before_first_run', 'pre-run edit' in log and 'single C3 check execution' in log)
verify('script_runs_claimed_once',log.count('python3 -I tools/c3_checks.py sources C3_CHECK_LEDGER.json')==1)
verify('no_claim_c2_complete','C3 does not discharge signed R2' in chrono)
verify('c3_receipt_seven_count',len([n for n in c3.namelist() if n.startswith('original_cfinal/receipts/') or n=='post_cfinal_context/R2-CFINAL_RECEIPT.json'])==7)
result={'verdict':'INDEPENDENT_STATIC_ARCHIVE_AND_RECEIPT_RECOMPUTATION_PASS', 'c3_zip':{'filename':C3,'bytes':len(original_c3),'sha256':sha(original_c3),'members':len(c3.namelist())},'original_checkpoints':[{'filename':n,'bytes':x[0],'sha256':x[1]} for n,x in FIXED_ARCHIVES.items()], 'five_prior_receipts_absent_from_c2':True,'five_prior_receipts_present_in_original_cfinal':True,'three_cross_archive_correlations':True,'cfinal_nested_predecessors_four_byte_identical':True, 'seven_c3_receipts_exact':True,'recovery_zip_exact':True,'worker_receipts_in_original_c2':len(c2receipts),'agent_ledger_claim':{'total':ledger['checks_total'],'passed':ledger['checks_passed']},'independent_assertions':len(checks),'checks':checks,'limitations':['Independent auditor did not observe private original agent workspace or fresh durable artifact readback.','Standalone post-CFINAL receipt is later and agent-authored, not a separate cryptographic attestation.','This is not new candidate execution, not an upgrade of R2-C2 historical qualification.']}
file=ROOT/'P0A3G_R2_C3_INDEPENDENT_VERIFICATION_2026-10-21.json';file.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print('PASS',len(checks),'independent conditions;',file,'size',file.stat().st_size)
