# P0A3G-R2-C3 — Independent QC of Prospective Administrative Receipt-Chain Closure

**QC date:** 2026-10-21 (Europe/London).  **Scope:** fixed administrative receipts, ZIP data and signed-source provenance; **no candidate-code execution**.

**Independent QC disposition:** `P0A3G_R2_C3_ADMINISTRATIVE_RECEIPT_CHAIN_QC_PASS_WITH_HISTORICAL_C2_OMISSION_PRESERVED`.

## 1. Authoritative signed scope and audit sources

- Research branch: `salahealer9/meru-geometry-audit`, `hebrew-projection-capacity-v0.9`.
- C3 signed protocol commit `f5e31de09a8b79ddb1b5f0ba738443fc4012a390`, direct signed parent `e491e1e9f96391cd512db0dd528765d63bc179c1`, protocol Git blob `b34b2008076c644fa35e162c8c3e741a91b24891`, Git compare one newly added Markdown file and branch tip at C3 commit when checked. The human supplied `VALIDSIG` output with fingerprint `D4EC014EEFCC90E619D2AA59A91239ABCF512130`; the separate GitHub connector confirmed commit/blob/parent/single-file-diff identity, **not a second cryptographic GPG signature verification with an independently sourced public key**. The agent reports fresh-keyring `git verify-commit`; its public key came from its repo.
- Original R2 protocol `7de01ab2c90afe52dd763652a9eaffd2e9a2cff9`, H04 amendment `4b488825ed35c7ac91a19abe62be068e75e9a076`, independent R2 incomplete preservation `e491e1e9f96391cd512db0dd528765d63bc179c1`. C3 provides a new administrative lane and never revises these records.
- Original submitted C3 ZIP `P0A3G_R2_C3_RECEIPT_CHAIN_CLOSEOUT_CANDIDATE.zip`, **56,943 bytes**, SHA-256 **`5c57483ddddd6b9d25332bedea2b590d1f0f4c7079df10baf3ef50cc66d5d362`**. Three separately supplied readback/verification files were reviewed as **agent attestations**, not independent proof of private artifact history.
- Original signed preserved R2 checkpoints cross-verified independently against the human signing preservation package, signed preservation manifest, and original ZIPs already retained in this conversation. `QC_INCOMPLETE_PRESERVATION_MANIFEST.sha256` exact hash `362dca23bb9ad93c2ed2f67d0e2fe39a520e4797e8a123060604d33b01d9cce7`.

## 2. Independently recomputed checks

The independent read-only verifier is included verbatim in this QC package. It relies on Python standard-library `hashlib`, `zipfile`, `json` and `stat`; it does not import or execute the engineering agent's C3 checker or R2 code. It made **4,873 PASS assertions**, dominated by each member's checksum/inventory identity across the five original R2 ZIPs, recovered ZIP, and C3; this is a count of deterministic verification assertions, **not 4,873 independent experiments**. All source bytes were read from the uploaded archives, not reconstructed from agent summary tables.

| Fixed audit target | Independent result |
|---|---|
| Original C3 ZIP | Exact 56,943 bytes and SHA-256 match; 17 safe regular unique file entries; 16/16 non-self checksum lines; 15/15 inventory identities; CRC PASS; exact registered member set |
| Five original checkpoints | C0, rejected C1, witnessed C1-REV1, C2 and CFINAL size/SHA/ZIP checksum/CRC/inventory match; all equal byte-for-byte to the earlier signed-preservation candidate originals |
| Four original checkpoint copies inside CFINAL | Each byte-identical to its original archive; rejected C1 remains explicitly historical, not the executed lock |
| Five missing prior receipt paths in original C2 | All five absent by exact path, basename **and full content digest**. No `receipts/` member exists in original C2; 138 worker-level `*.receipt.json` records are unrelated to checkpoint receipts |
| Five corresponding receipts in original CFINAL | All five present under their exact original paths and match signed C3 protocol byte-length and SHA pins |
| Recovery copy | Historical unsigned recovery ZIP matches 16,281 bytes / SHA `25796ef25cd2f2734e3549aa4ddbdaf80da6fa6b80681b2415a16e1cc5919a44`; all checksum entries verified and all five recovered receipt copies byte-identical to original CFINAL |
| Three corroborating earlier copies | Original C0 receipt and two rejected-C1 receipts byte-identical to copies inside C1-REV1; no earlier evidence for the two REV1 receipts is invented |
| Later two receipts | Original CFINAL C2 receipt (2,665 bytes / SHA `9ecbeb9d17222c1e89f176ea4caa5d79b0d5aafd52e5baf5968113269caa0789`) and standalone post-CFINAL receipt (2,144 bytes / SHA `b1edb13846dc316d5a0dffbb0daf54d798ffb4a84430251465f179ceb3ccae4c`) match pins; latter is absent from original CFINAL by name and digest |
| Agent's registered check ledger | 75 distinct recorded checks with 75 `PASS`, required group coverage; independently corroborated core assertions without executing the agent's script |
| Evidence chronology and disposition | Retained historical negative statuses appear in C3 status, chronology and README; independent QC checklist intentionally unmarked |

## 3. Agent disclosures and limitations

1. **Filename difference:** The earlier recovery ZIP's delivered basename `ORIGINAL_P0A3G_R2_PRIOR_RECEIPTS_READONLY_RECOVERY_2026-10-21.zip` differs from the title spelling in the signed C3 protocol, but its actual bytes, size, SHA-256, five receipt members and their contents match. Not a material identity discrepancy.
2. **One before-run administrative script change:** The agent changed an auxiliary recovery-ZIP full-coverage assertion into a record-only check *before* the single C3-labelled verification, by its documented chronology. Independent audit verifies full recovery checksum coverage anyway. This does not change any registered source hash, expected outcome or positive result. The exact historical edit timing is agent-reported.
3. The seven receipts were originally **agent-authored**; timestamps and internal claims do not provide independent host attestation. The reviewer confirms only the actual retained bytes and cross-archive relations, not contemporaneous original creation timestamps or private storage history.
4. Claimed one C3 run, no candidate import, no keys, no Git write and fresh base64 artifact readback are supported by submitted logs/receipts, but not independently observable in the private Claude workspace. C3 output bytes and archives were independently validated; an independently hosted full rerun of the agent's entire check programme was not performed.
5. Original signed QC status is **permanently unchanged**: `R2_QCF01_C2_PRIOR_RECEIPTS_OMITTED`, `P0A3G_R2_INDEPENDENT_QC_NOT_FULLY_QUALIFIED` and `P0A3G_R2_C2_PRIOR_RECEIPT_COMPLETENESS_NOT_QUALIFIED`. R1 and P0A3G negative dispositions remain preserved. No production trust root, complete loaded-code attestation, general software proof, new geometric result, code freeze, or P0A4 authorization is established.

## 4. Final decision and permitted next step

**C3's new administrative receipt-chain packet is independently qualified within its declared evidence scope**. The result establishes present-day byte-accurate recovery, signed-archive corroboration, the C2 absence finding and separately dated later context. **It does not and cannot retroactively qualify the original R2-C2 against signed §5**.

A subsequent human GPG-signed **additive C3 QC preservation** may record this narrow positive decision while preserving the original C3 ZIP, agent verification receipts and the separate QC verifier/results unchanged. No agent signature, Git modification, P0A4 or new scientific tests are authorized by this report.
