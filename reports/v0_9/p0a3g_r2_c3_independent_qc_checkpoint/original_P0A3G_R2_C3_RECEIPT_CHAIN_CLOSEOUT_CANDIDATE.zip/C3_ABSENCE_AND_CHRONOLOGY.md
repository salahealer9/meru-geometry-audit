# P0A3G-R2-C3 — Absence in original R2-C2, presence in original R2-CFINAL, and chronology

**Original R2-C2 is immutable and unchanged:** `original_P0A3G_R2_C2.zip`, 1,388,186 bytes, SHA-256 `860d93dce952a73b65b097e3f7b4da420c0a327ee0ca8b6d4c213865db2d1cbb` (signed preservation `e491e1e9…`). It is not rebuilt, backfilled or renamed here.

**Retained historical findings, unchanged:**
- `R2_QCF01_C2_PRIOR_RECEIPTS_OMITTED`
- `P0A3G_R2_INDEPENDENT_QC_NOT_FULLY_QUALIFIED`
- `P0A3G_R2_C2_PRIOR_RECEIPT_COMPLETENESS_NOT_QUALIFIED`

C3 does not discharge signed R2 §5.

## 1. Five prior-checkpoint receipts — ABSENT from original R2-C2 (observed in `C3_CHECK_LEDGER.json`, group `negative_c2`)
| Registered path | In C2 at exact path | Same basename anywhere in C2 | Same digest anywhere in C2 | Ledger result |
|---|---|---|---|---|
| `receipts/R2-C0_RECEIPT.json` | no | none | none | PASS (absent) |
| `receipts/R2-C1-REV1_LOCK_RECEIPT.md` | no | none | none | PASS (absent) |
| `receipts/R2-C1-REV1_RECEIPT.json` | no | none | none | PASS (absent) |
| `receipts/rejected_R2-C1/R2-C1_LOCK_RECEIPT.md` | no | none | none | PASS (absent) |
| `receipts/rejected_R2-C1/R2-C1_RECEIPT.json` | no | none | none | PASS (absent) |

The original C2 has 1,283 members; the SHA-256 of its sorted name list is `ed878839e20f432d6e3a92b3a1972fd3797c27ec89cb5e8be9c47d96fbc0ff9e`. Its top-level entries are `PACKAGE_INVENTORY.json`, `R2_C2_AGENT_CROSSCHECK.json`, `R2_EXECUTION_CHRONOLOGY.md`, `README.md`, `SHA256SUMS`, `attempt/` and `release/`. There is no `receipts/` directory.

C2 contains 138 `*.receipt.json` members. All of them are worker- or run-level caller receipts under `attempt/…/raw_workers/`, and none is a prior checkpoint receipt; they cannot satisfy the omission.

C2 also does not contain `R2-C2_RECEIPT.json`, which was written after C2.

## 2. Same five receipts — PRESENT in original R2-CFINAL with registered bytes (group `positive_cfinal`)
| CFINAL path | Bytes | SHA-256 | Further established copies (byte-identical) |
|---|---:|---|---|
| `receipts/R2-C0_RECEIPT.json` | 1,407 | `c2ee82bf…3227` | C1-REV1 `r2c0/R2-C0_RECEIPT.json`; recovery `original_cfinal/…` |
| `receipts/R2-C1-REV1_LOCK_RECEIPT.md` | 6,179 | `2827b38b…8b41` | recovery `original_cfinal/…` only (no earlier copy established or claimed) |
| `receipts/R2-C1-REV1_RECEIPT.json` | 3,035 | `3dcd2e71…72bf` | recovery `original_cfinal/…` only (no earlier copy established or claimed) |
| `receipts/rejected_R2-C1/R2-C1_LOCK_RECEIPT.md` | 6,779 | `87ca678f…3191` | C1-REV1 `review/REJECTED_R2-C1_LOCK_RECEIPT.md`; recovery |
| `receipts/rejected_R2-C1/R2-C1_RECEIPT.json` | 2,217 | `a505d6d6…d370` | C1-REV1 `review/REJECTED_R2-C1_RECEIPT.json`; recovery |

The later CFINAL receipt `receipts/R2-C2_RECEIPT.json` is 2,665 B, SHA-256 `9ecbeb9d…0789`. Its own `packaging_disclosure` field records the C2 omission.

The post-CFINAL standalone `R2-CFINAL_RECEIPT.json` is 2,144 B, SHA-256 `b1edb138…e4c`. It is **not** a CFINAL member, by name or by digest.

CFINAL nests C0, C1-REV1, C2 and the rejected C1 byte-identically to the signed originals. The rejected C1 (`740da699…7589`) is labelled in CFINAL as rejected and never executed. Its status is **NEVER RELEASED / NEVER EXECUTED**.

## 3. Chronology (UTC, 2026-10-21; historical events taken from the signed records, not re-verified by C3)
| When | Event | Source |
|---|---|---|
| ~14:51Z | R2-C0 built; R2-C0 receipt written | R2-C0 receipt / R2 chronology (agent-written) |
| ~15:01Z | First R2-C1 built and its receipts written; later rejected (R2_C1_W01), never executed | Rejected C1 receipt / signed preservation |
| ~15:23Z | R2-C1-REV1 built. It contains `r2c0/R2-C0_RECEIPT.json` and the two rejected-C1 receipts under `review/`; REV1 receipts written outside REV1 | C1-REV1 archive (this check) |
| 15:35:48Z–15:36:46Z | Single attempt `P0A3G_R2_DEV_01` | Signed preservation §1 |
| ~15:38Z | **Original R2-C2 built without the prior receipt copies** | C2 archive (this check) |
| ~15:41Z | R2-C2 receipt written; it discloses the omission | CFINAL member |
| ~15:42Z | R2-CFINAL built, including the five prior receipts and the C2 receipt under `receipts/` | CFINAL archive (this check) |
| ~15:43Z | Standalone R2-CFINAL receipt written after CFINAL | Intake bytes (this check) |
| later on 2026-10-21 | Independent R2 QC: `R2_QCF01_C2_PRIOR_RECEIPTS_OMITTED`, `P0A3G_R2_INDEPENDENT_QC_NOT_FULLY_QUALIFIED`; signed preservation `e491e1e9…` | Signed commit |
| later on 2026-10-21 | Earlier unsigned read-only receipt recovery ZIP (`25796ef2…9a44`) produced (historical exposure) | Intake bytes |
| later on 2026-10-21 | Signed C3 protocol `f5e31de0…` | Signed commit |
| 18:11Z–18:16Z | C3 intake, authentication, source-read ledger, and the fixed checks run once (75/75 PASS) | `C3_EXECUTION_LOG.txt` |

The "~" times come from agent-written receipts and chronology. They are not independently attested, and C3 cannot verify original host durability. Nothing in this package asserts that any receipt copy accompanied original C2.
