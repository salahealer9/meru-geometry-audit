# P0A3G_R2_C3_RECEIPT_CHAIN_CLOSEOUT_CANDIDATE

A new, separate, additive administrative packet under the signed C3 protocol: commit `f5e31de09a8b79ddb1b5f0ba738443fc4012a390`, parent `e491e1e9f96391cd512db0dd528765d63bc179c1`, blob `b34b2008076c644fa35e162c8c3e741a91b24891`, signer `D4EC014EEFCC90E619D2AA59A91239ABCF512130`.

This packet is **not** R2-C2. It is not a rebuilt or backfilled C2, not a new R2 test and not a qualification. Agent submission label: `P0A3G_R2_C3_RECEIPT_CHAIN_CANDIDATE_SUBMITTED_FOR_INDEPENDENT_QC`. The retained findings `R2_QCF01_C2_PRIOR_RECEIPTS_OMITTED` and `P0A3G_R2_INDEPENDENT_QC_NOT_FULLY_QUALIFIED` are unchanged.

| Path | Content |
|---|---|
| `original_cfinal/receipts/R2-C0_RECEIPT.json` | Original bytes (1,407 B, `c2ee82bf…3227`) extracted from signed original CFINAL |
| `original_cfinal/receipts/R2-C1-REV1_LOCK_RECEIPT.md` | Original bytes (6,179 B, `2827b38b…8b41`) |
| `original_cfinal/receipts/R2-C1-REV1_RECEIPT.json` | Original bytes (3,035 B, `3dcd2e71…72bf`) |
| `original_cfinal/receipts/rejected_R2-C1/R2-C1_LOCK_RECEIPT.md` | Original bytes (6,779 B, `87ca678f…3191`) |
| `original_cfinal/receipts/rejected_R2-C1/R2-C1_RECEIPT.json` | Original bytes (2,217 B, `a505d6d6…d370`) |
| `original_cfinal/receipts/R2-C2_RECEIPT.json` | **Later** receipt (2,665 B, `9ecbeb9d…0789`) from original CFINAL; not one of the five prior receipts |
| `post_cfinal_context/R2-CFINAL_RECEIPT.json` | **Post-CFINAL** standalone receipt (2,144 B, `b1edb138…e4c`), supplied separately and never a CFINAL member |
| `historical_readonly_recovery/ORIGINAL_P0A3G_R2_PRIOR_RECEIPTS_READONLY_RECOVERY_2026-10-21.zip` | The earlier **unsigned** read-only recovery, unchanged (16,281 B, `25796ef2…9a44`). This is historical exposure, not a C3 discovery. |
| `C3_INPUT_PROVENANCE.json` | Signed authority, authentication scope, the five original archive identities, recovery identity, all seven receipts with sources, temporal limits, and the verbatim source-read ledger |
| `C3_CHECK_LEDGER.json` | The single C3 check run: 75 registered checks with expected and observed values (75 PASS) |
| `C3_ABSENCE_AND_CHRONOLOGY.md` | Five receipts absent from original C2, present in original CFINAL; chronology |
| `C3_EXECUTION_LOG.txt` | Read-only commands and UTC chronology, including the exact check script executed |
| `C3_STATUS.md` | Agent observations and retained historical statuses only |
| `C3_INDEPENDENT_QC_CHECKLIST_BLANK.md` | Intentionally blank |
| `PACKAGE_INVENTORY.json` | Every member except itself and `SHA256SUMS`, with bytes and SHA-256 (N−2 entries) |
| `SHA256SUMS` | Every member except itself, including the inventory (N−1 entries; conventional self-hash exception) |

**Original checkpoint sources** (signed preservation `e491e1e9…`, `reports/v0_9/p0a3g_r2_independent_qc_incomplete_checkpoint/`):

| Archive | Bytes | SHA-256 |
|---|---:|---|
| `original_P0A3G_R2_C0.zip` | 63,036 | `e99811f3eefd90a49726e9ea37d8eae8b739829cc90bc825f3dec489d731bbb5` |
| `original_P0A3G_R2_C1_REJECTED.zip` | 175,429 | `740da6990834846a579cc07dccdafcab23f147c5f00117c25505a1cbce847589` |
| `original_P0A3G_R2_C1_REV1.zip` | 197,250 | `b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1` |
| `original_P0A3G_R2_C2.zip` | 1,388,186 | `860d93dce952a73b65b097e3f7b4da420c0a327ee0ca8b6d4c213865db2d1cbb` |
| `original_P0A3G_R2_CFINAL.zip` | 1,224,562 | `7c9770d15a3a578f61def2571813d84baadda34bfe3d31cfc1b5cdd722a51eb4` |

These archives are not copied into this packet; they are referenced by identity. The rejected C1 was never released and never executed.

Builder: the agent-side deterministic `build_zip.py` (SHA-256 `8d512a9d23f1745ed12735acd427f063975a475300e9724eb173dca74101be9e`). It uses fixed 1980 timestamps, mode 0644 and no directory entries.
