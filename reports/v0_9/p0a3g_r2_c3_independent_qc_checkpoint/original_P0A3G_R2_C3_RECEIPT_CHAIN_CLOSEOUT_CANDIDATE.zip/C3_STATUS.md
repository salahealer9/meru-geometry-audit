# P0A3G-R2-C3 — Status (agent submission only)

**Agent submission label:** `P0A3G_R2_C3_RECEIPT_CHAIN_CANDIDATE_SUBMITTED_FOR_INDEPENDENT_QC`

The agent does not and cannot issue any C3 QC disposition. Only the separate independent reviewer may issue one of `P0A3G_R2_C3_ADMINISTRATIVE_RECEIPT_CHAIN_QC_PASS_WITH_HISTORICAL_C2_OMISSION_PRESERVED`, `P0A3G_R2_C3_ADMINISTRATIVE_EVIDENCE_INCOMPLETE` or `P0A3G_R2_C3_SOURCE_INTEGRITY_QUARANTINE`.

## Observed results of the single C3 check run (agent observations, not QC)
| Target (signed C3 §2–§3) | Observed |
|---|---|
| Five signed original archives: identity, signed-manifest SHA-256, CRC, safe and unique paths, no special members, N−1 SHA256SUMS, N−2 inventory | all PASS |
| CFINAL nested C0 / C1-REV1 / C2 / rejected C1 byte-identical to originals; rejected C1 labelled never executed | all PASS |
| Five prior receipts present in original CFINAL with registered bytes (positive) | 5/5 PASS |
| Five prior receipts absent from original C2 by exact path, basename and digest (negative); worker receipts distinguished | 5/5 absent; 138 worker-level receipts, none a checkpoint receipt |
| Historical recovery ZIP identity; its five copies byte-identical to CFINAL; its R2-C2 receipt copy identical | all PASS |
| Three cross-archive corroborations in released C1-REV1 | 3/3 PASS; no earlier REV1 receipt copy exists or is claimed |
| Later receipts: CFINAL R2-C2 receipt and standalone post-CFINAL receipt identities; post-CFINAL receipt not in CFINAL; R2-C2 receipt not in C2; all JSON parses | all PASS |
| **Total** | **75 / 75 checks PASS, 0 failures** (`C3_CHECK_LEDGER.json`) |

No negative check result was observed. Observations to note:
- **Recovery ZIP name:** the signed protocol names the recovery ZIP `P0A3G_R2_ORIGINAL_PRIOR_RECEIPTS_READONLY_RECOVERY_2026-10-21.zip`, while the supplied file is named `ORIGINAL_P0A3G_R2_PRIOR_RECEIPTS_READONLY_RECOVERY_2026-10-21.zip`. The bytes and SHA-256 match the pinned identity, and the supplied name is preserved.
- **Self-reported content:** all receipts are agent-written; their contents are not external attestation.

## Retained, unchanged in every outcome
- `R2_QCF01_C2_PRIOR_RECEIPTS_OMITTED` — original R2-C2 does not contain the prior receipts. C3 confirms this and does not repair it.
- `P0A3G_R2_INDEPENDENT_QC_NOT_FULLY_QUALIFIED` and `P0A3G_R2_C2_PRIOR_RECEIPT_COMPLETENESS_NOT_QUALIFIED`.
- All P0A3G and R1 negative dispositions (`P0A3G_PROSPECTIVE_DEV_LOCK_SEQUENCE_NOT_QUALIFIED`, `P0A3G_INDEPENDENT_QC_NOT_QUALIFIED`, `P0A3F_R1_INDEPENDENT_QC_NOT_QUALIFIED`).

Any C3 result concerns only the present-day completeness and reproducibility of this new administrative record. It does not mean the historical R2-C2 satisfied §5 and does not upgrade the R2 qualification. There is no code freeze and no production readiness, and **P0A4 is NOT RUN / NOT AUTHORIZED**.
