# P0A3E cumulative implementation candidate — independent QC submission

[FROZEN THEOREM] The independently verified P0A3D exact 2D QO theorem is unchanged.
This unsigned software package has no readiness approval, implementation freeze
or registered numerical-certification status.

[IMPLEMENTED_UNVERIFIED] New engineering boundaries: strict bounded raw-byte
requests; independent strict certificate grammar; caller-provided expected code,
schema/config/runtime/input identities; separate production/reference workers;
score-free typed failures; durable complete checkpoint saving and independent
recomputation on recovery. Original production/reference arithmetic is retained
byte-for-byte and all cumulative source changes are inventoried.

[DEV_CHECKED_ONLY] Two new attempts are retained. Attempt 01 failed a formal-
vector equality assertion after five successful independent recomputations.
Attempt 02 repaired only that assertion and passed 32/32 methods. Fixed generic
fixtures and resource caps were unchanged. Historical P0A3D 01–04 are externally
preserved by signed identities; no old test runner was executed.

Start review with:

1. `reports/v0_9/p0a3e_software_qualification/provenance/WORK_HANDOFF.txt`, the
   complete signed protocol and `E0_VERIFIED.json` in that directory.
2. `ENGINEERING_QUALIFICATION_REVIEW.md`, `E0_E9_DISPOSITION_MATRIX.csv`,
   `E1_E6_ACCEPTANCE_MATRIX.csv` and the four contract/trust/design documents.
3. `src/meru_geometry/v0_9/qo2d_exact/`, `reference/v0_9/qo2d_exact/`, schemas,
   original-to-revised patch/inventory, and complete numbered DEV source snapshots.
4. Raw worker evidence, resource/failure ledgers and the unfilled independent
   QC checklist. Expected manifests are labeled DEV_UNFROZEN_EXPECTATIONS.

[UNRESOLVED] Software remains incomplete for qualification: full hostile-boundary
coverage, common arithmetic/runtime trust, external signed code authority, loaded-
module/TOCTOU trust and real hard-crash/system-isolation guarantees remain explicit.
Read the matrices for PASS/PARTIAL/DEFERRED evidence and untested branches. A test
count does not settle these obligations. No positive eligibility status is activated.

[IMPLEMENTED_UNVERIFIED] Original P0A3D candidate/QC/proof and DEV histories are
referenced through verified signed checkpoint identities rather than duplicating
their ZIPs. New worker evidence is embedded byte-for-byte under each attempt's
`worker_artifacts/`; raw evidence filenames are given a `.raw` suffix so empty,
interrupted or malformed JSON is not mistaken for a trusted package record.
The sparse disk-limit probe is a known zero-filled generic artifact, not unknown
binary/source/target data. A mapping records original paths, lengths and hashes.

[IMPLEMENTED_UNVERIFIED] `PACKAGE_INVENTORY.json` records each payload's path,
byte size and SHA-256, excluding itself and `SHA256SUMS`. `SHA256SUMS` covers
every member except itself, including the inventory. The ZIP's own identity is
delivered separately. All paths are safe regular relative files; no old P0A0
case/result payload, image/font, private key or unknown binary blob is included.

[DEFERRED] Independent QC must precede a separate human-signed code-only freeze
and any newly registered target-free validation. No commit/push/repository change,
target analysis, P0A0/P0A4 run, 3D/QH extension or candidate/null experiment is
authorized or performed by this deliverable.
