# External expected identities and reproducibility

[FROZEN THEOREM] E0 independently fetched the full P0A3E protocol and 14 adjacent
signed commit objects, checked parents and additive tree scope, reconstructed Git
objects/trees, and verified the pinned blobs. Detached GPG verification matched
`D4EC014EEFCC90E619D2AA59A91239ABCF512130`; local ownertrust is not asserted.
The signed v0.8 tag was verified; pre-P0A0 ancestry uses GitHub merge-base evidence.
Original P0A3D ZIP SHA-256 is
`c2f99b0e78849de16c8dc8167bdf5d584d4f64ab2c8a787d6a0ed507cfa9f378`;
its 136 entries, 135 manifest hashes and 134 inventory records passed.
P0A3D independent QC ZIP SHA-256 is
`4da72ab4a3347cad19e746f42ae9799f6e410a97ceb8972ad74530e6723c1e20`.

[IMPLEMENTED_UNVERIFIED] A caller supplies raw expected-manifest bytes separately
from the untrusted request/certificate. The manifest binds the signed parent,
original archive, protocol commit, every selected production/reference/schema/
configuration/DEV source file, interpreter executable bytes and runtime/dependency
descriptor, plus the canonical original request. Source-file set equality is
required, not just a few selected digests. Production and reference independently
implement these checks. All mismatches fail with CODE_IDENTITY_MISMATCH.
Reference checks expected identities before decoding the claimed certificate.

[INDEPENDENT_QC_PENDING] All delivered expected manifests are explicitly
`DEV_UNFROZEN_EXPECTATIONS`. A proposal generator is a test/review convenience,
never called by verification to manufacture expected trust. The caller is
responsible for keeping trusted expectations separate from untrusted files.
No human-signed P0A3E implementation authority exists in this package. A future
human code-only freeze must establish reviewed code/schema/config/checker/runtime
identities and the operational external-manifest distribution mechanism. The
current candidate deliberately cannot claim that a caller's string is a signature.

[IMPLEMENTED_UNVERIFIED] Rebuild: verify the original frozen ZIP first; safely
extract only its source/reference files into an empty isolated root. The full
`ORIGINAL_TO_REVISED.patch` and per-file hash inventory identify every changed or
added source/schema/test byte. Complete source snapshots for every new DEV attempt
allow exact reconstruction independent of a patch tool. `rebuild_candidate.py`
performs a deterministic snapshot-based rebuild, verifies the original archive
and output hashes, and never executes scientific modules. Historical theorem and
DEV 01–04 remain byte-exact external frozen identities; old tests are not installed.

[IMPLEMENTED_UNVERIFIED] Workers use a fresh isolated interpreter invocation
(`-I -B`) and no writable bytecode; startup rejects `.pyc`/`.pyo` and source-tree
symlinks. No dependencies were installed; a new venv uses stdlib-only Python.
Runtime details and exact pre/post source digests accompany every DEV attempt.

[UNRESOLVED] Hash checks are not runtime attestation. Mutable host files can change
between checking and execution; already loaded code and standard-library path
resolution are not cryptographically measured end-to-end. Caller-trusted private
directories and an untampered interpreter/OS are assumptions, not tested security
properties. The controller itself is part of the trust base. No repository
clean-HEAD claim or exhaustive off-host activity audit is made. The observed
workflow wrote only the new isolated workspace and the requested deliverable.
