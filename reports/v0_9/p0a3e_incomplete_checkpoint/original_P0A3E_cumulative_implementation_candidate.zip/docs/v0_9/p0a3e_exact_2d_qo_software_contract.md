# P0A3E candidate software contract

[FROZEN THEOREM] Signed authority is P0A3E commit
`c48c7a60777200a172ae3c72f5b0402162370ec7`, protocol blob
`108866549d914005c391eedea234ca27cc8604b7`, parent
`59eb47f7500d57866e4935822b78a555d3bcb515`, signer fingerprint
`D4EC014EEFCC90E619D2AA59A91239ABCF512130`. The parent preserves the independently
reviewed P0A3D theorem. Its original proof and historical software-negative
decision are included unchanged in provenance, not rewritten by this phase.

[FROZEN THEOREM] Exactly two independently supplied ordered open rational-vertex
2D polygonal paths, with fixed traversal and endpoint indices, are independently
centered and RMS-normalized using true normalized Euclidean planar arclength.
Only SO(2) is optimized. If alpha=integral B·A, beta=integral B·JA and
s=sqrt(alpha²+beta²), the attained distance is sqrt(2-2s); s>0 gives the unique
matrix [[alpha/s,-beta/s],[beta/s,alpha/s]], and s=0 gives a whole-roll tie with
canonical identity. Positive irrational lengths, exact-zero consecutive events,
retracing and coincident endpoint positions retain the frozen meanings.

[IMPLEMENTED_UNVERIFIED] Entry points:

- `wire.parse_request(raw_bytes)` reports bounded parsing/validation without scoring.
- `supervisor.run(raw_bytes, expected_manifest_bytes, new_private_directory)`
  launches a production worker and then a separate reference worker; only a
  fully checked and durably saved result returns a certificate.
- `supervisor.resume(raw_bytes, expected_manifest_bytes, existing_private_directory)`
  accepts a complete matching checkpoint only after independent exact recomputation.
- `supervisor.bounded_file(path, cap)` checks a regular no-follow file's size
  before reading at most cap+1 bytes. Callers processing streams must bound
  acquisition before allocating input; the bytes API cannot undo prior allocation.
- `reference...service.verify(raw_request, raw_certificate, raw_expected)` is
  the independent byte entry point, intended inside the bounded checker worker.

[IMPLEMENTED_UNVERIFIED] Original `core.calculate`/`execute`, arithmetic classes
and `checker.check` remain inspectable internal kernels. They are not the public
untrusted-file/process boundary and must not be advertised as resource-isolated
standalone services. The supervisor is the supported engineering boundary.

[IMPLEMENTED_UNVERIFIED] Raw decoding rejects duplicate object keys, nonfinite
constants, floats/exponent numeric tokens, non-ASCII or Unicode-escaped tokens,
oversized bytes/strings/depth/container counts and oversized numeric tokens.
Request validation rejects malformed dimensions, false/missing order, changed
scope, extra fields, Boolean indices, noncanonical rational pairs and unsupported
policy requests. All input rational coordinates remain exact; no floating
conversion, tiny-length floor or arbitrary sampling is introduced.

[IMPLEMENTED_UNVERIFIED] Canonicalization occurs after validation: sorted keys,
compact separators, ASCII encoding and no nonfinite values. Full canonical input
hashes preserve original vertex events and traversal. Invalid bytes have at most
a bounded prefix hash with the original size and prefix size explicitly stated.
They never receive a misleading canonical valid-input identity.

| State | Meaning and numeric-output rule |
|---|---|
| INVALID_INPUT | [IMPLEMENTED_UNVERIFIED] Malformed raw request/grammar; no score |
| NOT_EVALUABLE | [IMPLEMENTED_UNVERIFIED] Exact constant path; no score |
| CERTIFICATE_REJECTED | [IMPLEMENTED_UNVERIFIED] Certificate structure or independently reconstructed equality fails; no score |
| RESOURCE_INCOMPLETE | [IMPLEMENTED_UNVERIFIED] Explicit cap, timeout, memory/recursion guard or interrupted save; no score |
| UNRESOLVED_EXACT_PREDICATE | [IMPLEMENTED_UNVERIFIED] Reference isolation did not separate a proven nonzero value within its ceiling; no guessed tie |
| CODE_IDENTITY_MISMATCH | [IMPLEMENTED_UNVERIFIED] External expected source/config/environment/input identity fails; no score |
| INTERNAL_ERROR_NO_CERTIFICATE | [IMPLEMENTED_UNVERIFIED] Unexpected I/O, nonzero child exit or internal failure; no score |
| UNKNOWN_TERMINATION | [IMPLEMENTED_UNVERIFIED] Signal-terminated worker; cause not guessed from signal alone; no score |
| ENGINEERING_EXACT_CERTIFICATE_CANDIDATE_UNVALIDATED | [CHECKER_RECOMPUTED_DEV] Exact certificate recomputed in bounded DEV; independent qualification pending |

[IMPLEMENTED_UNVERIFIED] Private production-worker files can contain an unchecked
candidate. They are retained as intermediate evidence, never returned as a public
successful result before reference recomputation. The sole successful state is
still unvalidated for scientific/engineering qualification. Failure envelopes omit
certificate/q/witness fields. Serialized schemas describe the request, certificate,
expected manifest and public result; exact semantics require the executable checker.

[UNRESOLVED] ID/provenance declarations cannot prove real-world independent data
origin. Raw parsing is bounded within the supplied-byte model and audited Python
runtime, not an adversarial OS sandbox. Direct low-level calls, caller allocation,
privileged source changes, filesystem interference and parent/machine loss are
outside observed guarantees. Resource and external-trust limitations remain in
the engineering review. These do not alter the theorem domain.
