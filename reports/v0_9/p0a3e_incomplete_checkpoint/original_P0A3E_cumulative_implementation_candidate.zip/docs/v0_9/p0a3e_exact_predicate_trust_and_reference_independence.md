# Predicate fidelity and independent-reference trust

[FROZEN THEOREM] No mathematical proof was amended. In the signed positive
square-root tower, x=A+B sqrt(r), r>0 in an earlier tower. Zero coefficients
and equal signs determine sign directly. Opposite signs give
sign(x)=sign(A) sign(A²-B²r), descending tower height. For x!=0 and
D=A²-B²r!=0, invert by the conjugate divided by D. If D=0 but x!=0,
x=2A, so invert 2A in the lower tower. This covers dependent radicals without
assuming an irreducible formal basis. Frozen proof sections 1.2–1.7 are authority.

[IMPLEMENTED_UNVERIFIED] Production `algebra.py` is byte-identical to the original
P0A3D arithmetic. Sparse monomial masks are evaluated by exact Fraction arithmetic,
descending sign, conjugate/zero-conjugate inverse and positive-root generation.
Every inverse guards evaluated zero; every root checks its sign. Caps affect
completion, never exact-equality decisions. The cumulative source diff proves
that E1/E3/E4/E5 wrappers did not change the mathematical arithmetic kernel.

[IMPLEMENTED_UNVERIFIED] Reference `arithmetic.py` is also byte-identical to its
P0A3D source. It uses dense recursive coefficients, an independently coded
norm/sign zero criterion, and exact rational outward enclosures for the sign
of a value already proved nonzero. Integer bisection bounds square roots.
Overlap is never an equality proof. Induction through finite sums/products and
continuous positive square roots gives convergent enclosures in the abstract
unbounded model; the configured isolation ceiling may instead report unresolved.
Its inverse separately checks zero and handles the reducible zero-norm branch.

[IMPLEMENTED_UNVERIFIED] Production uses endpoint-product quadrature and centered
midpoint/difference variance. Reference independently reconstructs global-u affine
coefficients, polynomial antiderivatives, raw second moments minus mean²,
insertion-merged knots and midpoint segment membership. It reconstructs alpha,
beta, s, q and the optimal matrix, verifies every Gram entry and determinant +1,
and directly integrates the squared rotated residual. Certificate roots are
reconstructed with positive embeddings and compared semantically across histories.
Recorded signs are bound to the independently reconstructed expressions.

[IMPLEMENTED_UNVERIFIED] Reference imports its own byte grammar and expected-hash
logic. It imports no production parser, arithmetic, moment/integration, optimizer,
source identity or hashing function. The parent orchestrates both executables;
this orchestration is outside the reference numerical DAG. The static graph and
source/function matrix are included for inspection. No external arithmetic
backend, formal proof assistant or verified interpreter is claimed.

[CHECKER_RECOMPUTED_DEV] The final five generic certificates were independently
checked, including irrational lengths, zero events, whole-roll symmetry, small
positive correlation and unequal knots. Forged q, a proper but nonoptimal rotation,
omitted/duplicate knots, reversed records, invalid roots, Boolean metadata and
altered decisions were rejected. An alternative exact-zero construction was
accepted semantically. Attempt 01's raw-vector equality assertion was a test
defect; its retained correction makes the semantic/representational distinction
explicit without changing numerical source or the theorem.

[INDEPENDENT_QC_PENDING] Shared trust includes CPython integer and exception
semantics, Fraction, JSON, SHA-256, OS/filesystem/hardware, and positive-quadratic
mathematics. Two separately authored Python routes do not establish independence
from those common foundations. The 32-method DEV result is evidence for this
bounded catalogue, not arbitrary-input code correctness or a registered oracle
suite. `EXACT_PREDICATE_UNQUALIFIED` and `REFERENCE_INDEPENDENCE_UNQUALIFIED`
remain qualification boundaries pending substantive external source review.
