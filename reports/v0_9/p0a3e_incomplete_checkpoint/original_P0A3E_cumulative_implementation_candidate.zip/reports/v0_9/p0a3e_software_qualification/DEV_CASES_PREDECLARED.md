# P0A3E DEV scope v1 — prospective lock before any DEV

[IMPLEMENTED_UNVERIFIED] Thirty-two deterministic unittest methods, with at most
five full generic QO production computations per attempt and corresponding
independent exact recomputations. The supervised fault/recovery checks reuse a
completed generic certificate, or interrupt before numerical work. No historical
P0A3D test runner or P0A0 fixture is imported or executed. A permitted ordinary
engineering repair may rerun this same bounded catalogue with preserved source
and logs. A false mathematical certificate accepted or theorem contradiction
requires STOP_AND_QUARANTINE; record the failing run and do not continue repairs.

## Fixed generic inputs and identities

[IMPLEMENTED_UNVERIFIED] Canonical rationals use signed decimal numerator and
positive denominator strings. Let A=((0,1),(1,3),(4,4)); its edge lengths are
sqrt(5),sqrt(10). J A+(8,4)=((7,4),(5,5),(4,8)). Distinct generic IDs and fixed
endpoint indices accompany every path. The five production comparisons are:

1. A against J A+(8,4): q=0, unique witness J, genuine irrational lengths.
2. ((0,1),(0,1),(1/2,2),(1,3),(4,4)) against A: honest subdivision and one
   consecutive zero event; q=0, witness identity; original event index retained.
3. ((-4,0),(4,0)) against ((3,0),(-3,0),(3,0)): alpha=beta=0 by odd/even
   symmetry, q²=2, identity witness and coincident but distinguished endpoints.
4. Same straight source against ((3,0),(-3,0),(3+2^-18,0)): beta=0, alpha>0.
   With h=6,k=6+e,e=2^-18, the raw centered correlation is
   2*(k-h)*(h²+4hk+k²)/(3*(h+k)²)>0; positive RMS leaves its sign positive.
5. A against ((4,4),(1,3),(0,1)): fixed distinct traversal, q>0 and four union
   knots because the unequal-length turn moves. No reversal search is admitted.

## Fixed bounds and command

[IMPLEMENTED_UNVERIFIED] Raw request <=65,536 bytes; raw certificate <=2,097,152
bytes; generic document <=2,097,152 bytes; nesting <=32; token count <=100,000;
container length <=4,096; individual strings <=5,000 characters; JSON numeric
tokens <=12 ASCII digits, integer strings <=5,000 ASCII digits. Input <=8
vertices/path and <=128 numerator/denominator bits. Exact arithmetic <=2,000,000
operations/backend; coefficient <=16,384 bits; <=1,024 nonzero terms; formal
degree <=256 (at most eight root generators); reference isolation 8 bits,
doubling through <=256. Recursion limit 256 in workers. These are engineering
ceilings, never zero/tie tolerances or mathematical-domain exclusions.

[IMPLEMENTED_UNVERIFIED] Each arithmetic/checker worker: wall <=8 seconds,
CPU soft/hard 6/7 seconds where supported, address space <=256 MiB,
file size <=2 MiB, core dump disabled, open files <=32. One child at a time;
parent launches production then a separate reference executable. Dedicated
run directory <=16 MiB by application checks (no claimed filesystem quota).
No root-level process-count/security isolation claim. The test process has
wall <=120 seconds and address space <=512 MiB; all process commands/logs saved.
Diagnostic timeout uses a fixed 200 ms parent wait and worker sleeping 30 s,
then termination; no numeric computation or performance measurement there.

Command: isolated venv Python -B tests/dev_v0_9/p0a3e/test_contracts.py with
PYTHONPATH=src:., PYTHONDONTWRITEBYTECODE=1, PYTHONHASHSEED=0 and LC_ALL=C.UTF-8.
The logging driver records exact source/schema/config/fixture digests before
each attempt, timestamps, absolute command, stdout/stderr, evidence and patches.
No ceilings will be raised based on outcomes. Invalid-input/cap probes lower
limits only where explicitly part of the rejection test.

## Thirty-two fixed methods

| ID | Required engineering observation |
|---|---|
| 01 | Canonical byte parsing and idempotent serialization; traversal hashes differ |
| 02 | Duplicate keys, NaN/Infinity, float/exponent numeric tokens rejected |
| 03 | Boolean endpoint/mask/event indices rejected; dimension/order/extra fields rejected |
| 04 | Nonreduced/negative-zero/Unicode/leading-zero/zero-denominator rationals rejected |
| 05 | Byte/depth/token/string/digit/container/vertex/input-bit ceilings return typed failure |
| 06 | Constant path NOT_EVALUABLE, malformed raw type INVALID_INPUT, no score |
| 07 | Production dependent-root zero sqrt(3+2sqrt(2))=1+sqrt(2) |
| 08 | Reference same identity by separate zero/isolation route |
| 09 | Nonzero zero-conjugate inversion and exact zero denominator rejection in both routes |
| 10 | sqrt(2+2^-18)-sqrt(2)>0 in both routes; no guessed zero |
| 11 | Five generic certificates independently reconstructed with analytic outcomes |
| 12 | Positive length/RMS, zero event, equal/unequal knots and direct residual evidence |
| 13 | Forged score rejected (STOP if accepted) |
| 14 | Feasible but nonoptimal identity rotation on case 1 rejected (STOP if accepted) |
| 15 | Omitted/duplicated/reordered knots or path records rejected |
| 16 | Negative/forward/duplicate root-mask encoding and malformed nested structure rejected |
| 17 | Wrong tie/status/decision expression or root branch rejected |
| 18 | Different valid construction encoding of same algebraic value accepted semantically |
| 19 | Altered original input/order/input digest rejected before trusting output |
| 20 | Wrong parent/archive/code/schema/config/checker/environment/fixture hash fails closed |
| 21 | Missing/malformed external pins fail; unsigned DEV pins confer no approval |
| 22 | Static reference import DAG has no production/parser/identity import |
| 23 | Operation/term/degree/bit caps and reference isolation cap return incomplete |
| 24 | Byte-identical serialization of one retained certificate; no recomputation |
| 25 | Separate production/reference workers enforce and report resource limits |
| 26 | Controlled sleeping worker timeout; no score |
| 27 | Worker exit nonzero and deliberate self-SIGKILL before work; parent reports failure |
| 28 | Worker injected MemoryError/RecursionError before work; typed failure |
| 29 | Before-write and after-flush save interruption preserve old complete checkpoint |
| 30 | After-rename interruption; restart rechecks complete record under same external identity |
| 31 | Torn/malformed/mismatched checkpoint rejected; no partial score |
| 32 | Output/disk ceiling and unsupported I/O fail closed; no completion claim |

[DEFERRED] Real power failure, kernel crash, hard machine OOM, malicious replacement
of already executing interpreter/modules, privileged hostile subprocesses and
cross-user filesystem attacks are not exercised or claimed safe. Fault hooks
are explicit DEV caller arguments, not accepted fields in scientific requests.
