"""Append-only bounded generic DEV. No historical test runner imported."""
from pathlib import Path
import datetime,difflib,hashlib,json,os,resource,subprocess,sys,time
W=Path(__file__).resolve().parent;P=W/'package';R=P/'reports/v0_9/p0a3e_software_qualification';H=R/'dev_history';H.mkdir(exist_ok=True)
if any(W.glob('DEV_RUN_*/STOP_AND_QUARANTINE.txt')):raise RuntimeError('STOP_AND_QUARANTINE marker prohibits further DEV')
i=1+len(list(H.glob('P0A3E_DEV_*_result.json')));stem=f'P0A3E_DEV_{i:02}';run=W/f'DEV_RUN_{i:02}';assert not run.exists()
snapshot={p.relative_to(P).as_posix():p.read_text() for folder in ('src','reference','tests','schemas') for p in sorted((P/folder).rglob('*')) if p.is_file() and p.suffix in ('.py','.json','.md')}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
(H/(stem+'_sources.json')).write_text(json.dumps(snapshot,sort_keys=True,indent=2)+'\n')
previous={} if i==1 else json.loads((H/f'P0A3E_DEV_{i-1:02}_sources.json').read_text())
patch=''.join(''.join(difflib.unified_diff(previous.get(n,'').splitlines(True),snapshot.get(n,'').splitlines(True),fromfile='previous/'+n,tofile='candidate/'+n)) for n in sorted(set(previous)|set(snapshot)))
(H/(stem+'_source_diff.patch')).write_text(patch)
env=os.environ.copy();overrides={'PYTHONPATH':'src:.','PYTHONDONTWRITEBYTECODE':'1','PYTHONHASHSEED':'0','LC_ALL':'C.UTF-8','P0A3E_DEV_EVIDENCE':str(H/(stem+'_evidence.json')),'P0A3E_DEV_RUN':str(run)};env.update(overrides)
cmd=[str(W/'venv/bin/python'),'-B','tests/dev_v0_9/p0a3e/test_contracts.py'];start=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
def cap():resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
try:r=subprocess.run(cmd,cwd=P,env=env,capture_output=True,text=True,timeout=120,preexec_fn=cap);rc,out,err=r.returncode,r.stdout,r.stderr
except subprocess.TimeoutExpired as e:
    rc=124;out=e.stdout or b'';err=e.stderr or b''
    if isinstance(out,bytes):out=out.decode()
    if isinstance(err,bytes):err=err.decode()
    err+='\nRESOURCE_INCOMPLETE: outer DEV deadline\n'
(H/(stem+'_stdout.log')).write_text(out);(H/(stem+'_stderr.log')).write_text(err)
post={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in snapshot}
assert all(post[n]==hashlib.sha256(s.encode()).hexdigest() for n,s in snapshot.items())
artifact=[]
for p in sorted(run.rglob('*')):
    if p.is_file():artifact.append({'path':p.relative_to(run).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
(H/(stem+'_worker_artifact_inventory.json')).write_text(json.dumps(artifact,indent=2)+'\n')
record={'attempt':stem,'start_utc':start,'elapsed_seconds':time.monotonic()-clock,'command':cmd,'cwd':str(P),'environment':overrides,'returncode':rc,'timeout_seconds':120,'RLIMIT_AS':536870912,'plan_sha256':sha(R/'DEV_CASES_PREDECLARED.md'),'policy_sha256':sha(P/'schemas/v0_9/p0a3e/resource_policy.json'),'source_snapshot_sha256':sha(H/(stem+'_sources.json')),'post_source_hashes':post,'stdout_sha256':sha(H/(stem+'_stdout.log')),'stderr_sha256':sha(H/(stem+'_stderr.log')),'STOP_AND_QUARANTINE':(run/'STOP_AND_QUARANTINE.txt').exists()}
if (H/(stem+'_evidence.json')).exists():record['evidence_sha256']=sha(H/(stem+'_evidence.json'))
(H/(stem+'_result.json')).write_text(json.dumps(record,indent=2)+'\n')
with (R/'DEV_EXECUTION_CHRONOLOGY.log').open('a') as f:f.write(json.dumps(record,indent=2)+'\nSTDOUT\n'+out+'\nSTDERR\n'+err+'\n')
print(json.dumps(record,indent=2));print(err);sys.exit(rc)
