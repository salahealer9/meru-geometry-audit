"""Deterministic E7 package integrity; no numerical code imports/execution."""
from pathlib import Path,PurePosixPath
import hashlib,json,shutil,stat,zipfile
W=Path(__file__).resolve().parent;P=W/'package';R=P/'reports/v0_9/p0a3e_software_qualification';V=R/'provenance'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n')
def strict(b):
    def pairs(items):
        d={}
        for k,v in items:
            if k in d:raise ValueError('duplicate JSON key')
            d[k]=v
        return d
    def reject(x):raise ValueError('nonfinite JSON '+x)
    return json.loads(b,object_pairs_hook=pairs,parse_constant=reject)
for n in ('assembly_stdout.log','assembly_stderr.log','rebuild_stdout.log','rebuild_stderr.log'):shutil.copyfile(W/n,V/n)
shutil.copyfile(__file__,V/'package_candidate.py')
last=strict((R/'dev_history/P0A3E_DEV_02_sources.json').read_bytes())
assert all((P/n).read_bytes()==s.encode() for n,s in last.items())
assert all((W/'rebuild_check'/n).read_bytes()==s.encode() for n,s in last.items())
rawmap=strict((R/'WORKER_ARTIFACT_MAP.json').read_bytes());rawnames={r['package_path'] for r in rawmap}
for row in rawmap:
    b=(P/row['package_path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
assert (V/'P0A3D_ORIGINAL_THEOREM_PROOF.md').read_bytes()==(W/'intake/P0A3D_ORIGINAL_THEOREM_PROOF.md').read_bytes()
files=[];json_count=0
for p in sorted(P.rglob('*')):
    assert not p.is_symlink()
    if not p.is_file():continue
    n=p.relative_to(P).as_posix()
    if n in ('PACKAGE_INVENTORY.json','SHA256SUMS'):continue
    rel=PurePosixPath(n);assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in n
    assert p.suffix.lower() in {'.py','.md','.json','.csv','.txt','.log','.patch','.asc','.payload','.gpg','.sha256','.raw'},n
    assert '__pycache__' not in n
    b=p.read_bytes()
    assert not any(line.strip().startswith((b'-----BEGIN PGP PRIVATE KEY BLOCK-----',b'-----BEGIN PRIVATE KEY-----')) for line in b.splitlines()),n
    if p.suffix=='.json':strict(b);json_count+=1
    if p.suffix=='.raw':assert n in rawnames,n
    files.append({'path':n,'bytes':len(b),'sha256':sha(b)})
audit=R/'PACKAGE_PREZIP_INTEGRITY.json'
put(audit,{'classification':'ARTIFACT_INTEGRITY_ONLY_INDEPENDENT_QC_PENDING','strict_structured_JSON_checked':json_count,'raw_worker_artifacts_hashed':len(rawmap),'final_source_matches_DEV02':True,'rebuild_matches_final_source':True,'frozen_theorem_unchanged':True,'new_numerical_execution':False,'guards':['safe relative unique regular files','no symlinks or bytecode','known text/public-signature extensions','raw evidence requires original path/hash map','no private-key armor','no old P0A0 scientific payload or image/font extension'],'self_reference_convention':'Inventory excludes itself and SHA256SUMS; SHA256SUMS excludes itself; external ZIP hash binds all bytes'})
files=[f for f in files if f['path']!=audit.relative_to(P).as_posix()];files.append({'path':audit.relative_to(P).as_posix(),'bytes':audit.stat().st_size,'sha256':sha(audit.read_bytes())});files.sort(key=lambda f:f['path'])
assert len(files)==len({f['path'] for f in files})
put(P/'PACKAGE_INVENTORY.json',{'phase':'P0A3E','status':'UNSIGNED_CUMULATIVE_CANDIDATE_FOR_INDEPENDENT_QC','payload_files':files,'payload_count':len(files),'excludes':['PACKAGE_INVENTORY.json','SHA256SUMS']})
covered=files+[{'path':'PACKAGE_INVENTORY.json','sha256':sha((P/'PACKAGE_INVENTORY.json').read_bytes())}];covered.sort(key=lambda f:f['path'])
(P/'SHA256SUMS').write_text(''.join(f['sha256']+'  '+f['path']+'\n' for f in covered))
names=sorted([f['path'] for f in files]+['PACKAGE_INVENTORY.json','SHA256SUMS']);out=W/'P0A3E_cumulative_implementation_candidate.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n in names:
        zi=zipfile.ZipInfo(n,(2000,1,1,0,0,0));zi.create_system=3;zi.external_attr=(stat.S_IFREG|0o644)<<16;zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,(P/n).read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None and z.namelist()==names and len(names)==len(set(names))
    inventory=strict(z.read('PACKAGE_INVENTORY.json'));lines=z.read('SHA256SUMS').decode().splitlines()
    assert {r['path'] for r in inventory['payload_files']}==set(names)-{'SHA256SUMS','PACKAGE_INVENTORY.json'}
    assert {line.split('  ',1)[1] for line in lines}==set(names)-{'SHA256SUMS'}
    for line in lines:
        h,n=line.split('  ',1);assert sha(z.read(n))==h
    for row in inventory['payload_files']:
        b=z.read(row['path']);assert len(b)==row['bytes'] and sha(b)==row['sha256']
result={'file':str(out),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'entries':len(names),'manifest_records':len(covered),'inventory_payload_files':len(files),'CRC':'PASS','all_internal_hashes':'PASS','final_tested_source_identity':'MATCH','raw_worker_artifacts_preserved':len(rawmap),'numerical_execution_during_packaging':False}
put(W/'DELIVERY_IDENTITY.json',result);print(json.dumps(result,indent=2))
