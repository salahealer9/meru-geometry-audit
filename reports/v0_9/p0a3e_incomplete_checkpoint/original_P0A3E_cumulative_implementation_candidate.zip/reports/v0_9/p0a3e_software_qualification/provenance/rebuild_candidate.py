"""Deterministic source rebuild from verified baseline and complete final snapshot.
This script only writes a new empty destination. It imports no scientific code.
Usage: python rebuild_candidate.py ORIGINAL_ZIP FINAL_SOURCES_JSON NEW_DIRECTORY
"""
from pathlib import Path,PurePosixPath
import hashlib,json,stat,sys,zipfile
original,snapshot,destination=map(Path,sys.argv[1:]);assert not destination.exists()
assert hashlib.sha256(original.read_bytes()).hexdigest()=='c2f99b0e78849de16c8dc8167bdf5d584d4f64ab2c8a787d6a0ed507cfa9f378'
with zipfile.ZipFile(original) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
    for item in z.infolist():
        n=PurePosixPath(item.filename);assert not n.is_absolute() and '..' not in n.parts and '\\' not in item.filename and not stat.S_ISLNK(item.external_attr>>16)
    baseline={n:z.read(n) for n in z.namelist() if n.startswith(('src/','reference/'))}
desired=json.loads(snapshot.read_text());assert all(n in desired for n in baseline)
for n,s in desired.items():
    p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts and '\\' not in n and p.parts[0] in ('src','reference','tests','schemas') and type(s) is str
destination.mkdir(mode=0o700)
for n,s in desired.items():
    p=destination/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(s.encode('utf-8'))
    assert hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256(s.encode()).digest()
print(json.dumps({'rebuild':'BYTE_IDENTICAL_TO_FINAL_SNAPSHOT','files':len(desired),'baseline_retained_paths':len(baseline),'numerical_execution':False}))
