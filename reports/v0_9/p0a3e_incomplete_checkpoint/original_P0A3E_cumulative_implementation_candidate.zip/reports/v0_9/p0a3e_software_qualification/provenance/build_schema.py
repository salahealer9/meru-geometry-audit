"""Mechanical schemas and prospective mapping; no arithmetic execution."""
from pathlib import Path
import csv,json,zipfile
W=Path(__file__).resolve().parent;P=W/'package';S=P/'schemas/v0_9/p0a3e';R=P/'reports/v0_9/p0a3e_software_qualification'
def put(n,x):(S/n).write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
with zipfile.ZipFile(W/'intake/original_P0A3D_cumulative_proof_and_implementation_candidate.zip') as z:base=json.loads(z.read('reports/v0_9/p0a3d_exact_qo_core/EXACT_CERTIFICATE_SCHEMA.json'))
defs=base['$defs'];defs['input_path']['properties']['id']={'type':'string','pattern':'^[A-Za-z0-9_.-]{1,64}$'};defs['input_path']['properties']['vertices']['maxItems']=8
for x in defs['rational']['prefixItems']:x['maxLength']=5001
defs['certificate']['properties']['roots']['maxItems']=8
for n in ('request','certificate'):
    put(n+'.schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema','title':'P0A3E strict '+n+' ABI with unchanged P0A3D mathematical contract','$ref':'#/$defs/'+n,'$defs':defs,'$comment':'Grammar only; bounded raw-byte decode and exact semantic checker remain required. Independent QC pending.'})
def object_(p):return {'type':'object','properties':p,'required':list(p),'additionalProperties':False}
h={'type':'string','pattern':'^[0-9a-f]{64}$'}
put('expected.schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema',**object_({'schema':{'const':'p0a3e-expected-1'},'authority_mode':{'const':'DEV_UNFROZEN_EXPECTATIONS'},'protocol_commit':{'const':'c48c7a60777200a172ae3c72f5b0402162370ec7'},'signed_parent':{'const':'59eb47f7500d57866e4935822b78a555d3bcb515'},'original_archive_sha256':{'const':'c2f99b0e78849de16c8dc8167bdf5d584d4f64ab2c8a787d6a0ed507cfa9f378'},'files':{'type':'object','additionalProperties':h},'environment_sha256':h,'input_sha256':h})})
states=['INVALID_INPUT','NOT_EVALUABLE','CERTIFICATE_REJECTED','RESOURCE_INCOMPLETE','UNRESOLVED_EXACT_PREDICATE','CODE_IDENTITY_MISMATCH','INTERNAL_ERROR_NO_CERTIFICATE','UNKNOWN_TERMINATION']
failure=object_({'schema':{'const':'p0a3e-failure-1'},'state':{'enum':states},'reason':{'type':'string'}})
failure['properties'].update({'raw_identity':object_({'bytes':{'type':'integer','minimum':0},'hashed_prefix_bytes':{'type':'integer','minimum':0,'maximum':65536},'prefix_sha256':h}),'worker_events':{'type':'array','items':{'type':'object'}}})
success=object_({'schema':{'const':'p0a3e-result-1'},'state':{'const':'ENGINEERING_EXACT_CERTIFICATE_CANDIDATE_UNVALIDATED'},'work_identity':h,'certificate':{'$ref':'certificate.schema.json'},'verification':{'type':'object'},'worker_events':{'type':'array'}})
success['properties'].update({'durable_checkpoint':{'const':'checkpoint.json'},'recovery':{'const':'COMPLETE_RECORD_RECOMPUTED'}})
success['oneOf']=[{'required':['durable_checkpoint']},{'required':['recovery']}]
put('result.schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema','oneOf':[failure,success]})
with (R/'E1_E6_PROSPECTIVE_MATRIX.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['requirement','planned_code','reference_route','DEV_ids','pre_DEV_status'])
    w.writerows([['E1','wire.request/decode/parse_request; supervisor.bounded_file','reference.wire.read/request/certificate','01-06;15-17','LOCKED_PENDING_DEV'],['E2','Tower.sign/inv/root','Algebra.zero/sign/inverse/root','07-10;12;18;23','LOCKED_PENDING_DEV'],['E3','core.calculate; supervisor.checked_record','reference.checker.check; service.verify','11-19','LOCKED_PENDING_DEV'],['E4','identity.verify; context','reference.identity.verify','19-22','LOCKED_PENDING_DEV'],['E5','supervisor.child/atomic_save/resume; worker.main','separate checker subprocess on recovery','25-32','LOCKED_PENDING_DEV'],['E6','test_contracts.py; append-only run_dev.py','static DAG and independent original-input recomputation','01-32','LOCKED_PENDING_DEV']])
print('SCHEMA_AND_PROSPECTIVE_MATRIX_WRITTEN_NO_NUMERICAL_EXECUTION')
