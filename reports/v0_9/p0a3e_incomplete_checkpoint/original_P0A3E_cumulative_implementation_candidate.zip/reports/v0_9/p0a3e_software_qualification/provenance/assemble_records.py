"""E7–E9 metadata/diff/evidence assembly only; no numerical imports or tests."""
from pathlib import Path
import ast,csv,difflib,hashlib,json,shutil,subprocess,sys,zipfile
W=Path(__file__).resolve().parent;P=W/'package';R=P/'reports/v0_9/p0a3e_software_qualification';V=R/'provenance';H=R/'dev_history'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n')
def table(n,fields,rows):
    with (R/n).open('w',newline='') as f:w=csv.writer(f);w.writerow(fields);w.writerows(rows)
e=json.loads((W/'E0_VERIFIED.json').read_text());last=json.loads((H/'P0A3E_DEV_02_sources.json').read_text());baseline=json.loads((V/'P0A3D_ORIGINAL_SOURCE_SNAPSHOT.json').read_text())
assert all((P/n).read_text()==s for n,s in last.items())
assert (V/'P0A3D_ORIGINAL_THEOREM_PROOF.md').read_bytes()==(W/'intake/P0A3D_ORIGINAL_THEOREM_PROOF.md').read_bytes()
for n in ('prepare.py','prepare_stdout.log','prepare_stderr.log','build_schema.py','schema_stdout.log','schema_stderr.log','run_dev.py','rebuild_candidate.py','DEV_01_driver_stdout.log','DEV_01_driver_stderr.log','DEV_02_driver_stdout.log','DEV_02_driver_stderr.log'):
    shutil.copyfile(W/n,V/n)
shutil.copyfile(__file__,V/'assemble_records.py')
changes=[];patch=''
for n in sorted(set(baseline)|set(last)):
    old=baseline.get(n);new=last.get(n);status='ADDED' if old is None else ('UNCHANGED' if old==new else 'MODIFIED')
    changes.append([n,status,hashlib.sha256(old.encode()).hexdigest() if old is not None else '',hashlib.sha256(new.encode()).hexdigest() if new is not None else '',len(old.encode()) if old is not None else 0,len(new.encode()) if new is not None else 0,'Original frozen P0A3D ZIP' if old is not None else 'New P0A3E source'])
    patch+=''.join(difflib.unified_diff((old or '').splitlines(True),(new or '').splitlines(True),fromfile='original/'+n if old is not None else '/dev/null',tofile='candidate/'+n))
table('ORIGINAL_TO_REVISED_HASH_AND_DIFF_INVENTORY.csv',['path','change','original_sha256','revised_sha256','original_bytes','revised_bytes','origin'],changes)
(R/'ORIGINAL_TO_REVISED.patch').write_text(patch)
put(R/'FINAL_SOURCE_HASHES.json',{'classification':'UNSIGNED_CANDIDATE_IDENTITIES','files':[{'path':n,'bytes':len(s.encode()),'sha256':hashlib.sha256(s.encode()).hexdigest()} for n,s in sorted(last.items())],'final_tested_snapshot':'dev_history/P0A3E_DEV_02_sources.json','snapshot_sha256':sha(H/'P0A3E_DEV_02_sources.json')})
graph={}
for n,s in sorted(last.items()):
    if not n.endswith('.py'):continue
    imports=[]
    for node in ast.walk(ast.parse(s)):
        if isinstance(node,ast.Import):imports.extend(a.name for a in node.names)
        elif isinstance(node,ast.ImportFrom):imports.append('.'*node.level+(node.module or ''))
    graph[n]=imports
assert all('meru_geometry' not in x for n,xs in graph.items() if n.startswith('reference/') for x in xs)
put(R/'IMPORT_DAG.json',{'classification':'IMPLEMENTED_UNVERIFIED','imports':graph,'reference_calls_production':False,'limitation':'Static syntax graph, not end-to-end interpreter/loaded-module attestation'})
archive={s['path']:s for s in e['sources'] if s['path'].endswith('.zip')}
put(V/'EXTERNAL_FROZEN_IDENTITIES.json',{'classification':'FROZEN THEOREM','signed_parent':'59eb47f7500d57866e4935822b78a555d3bcb515','original_objects':archive,'archive_checks':e['archives'],'P0A3D_DEV_01_04':e['P0A3D_DEV'],'not_embedded':'Original archives/history remain at exact signed Git paths; their bytes were verified in E0, never replayed or recreated.','original_proof_sha256':sha(W/'intake/P0A3D_ORIGINAL_THEOREM_PROOF.md')})
attempts=[];artifact_map=[]
for i in (1,2):
    stem=f'P0A3E_DEV_{i:02}';rec=json.loads((H/(stem+'_result.json')).read_text());assert not rec['STOP_AND_QUARANTINE']
    for key,suffix in [('source_snapshot','sources.json'),('stdout','stdout.log'),('stderr','stderr.log'),('evidence','evidence.json')]:assert sha(H/(stem+'_'+suffix))==rec[key+'_sha256']
    assert sha(R/'DEV_CASES_PREDECLARED.md')==rec['plan_sha256'] and sha(P/'schemas/v0_9/p0a3e/resource_policy.json')==rec['policy_sha256']
    attempts.append({'attempt':stem,'returncode':rec['returncode'],'source_snapshot_sha256':rec['source_snapshot_sha256'],'evidence_sha256':rec['evidence_sha256'],'elapsed_seconds':rec['elapsed_seconds'],'integrity':'PASS'})
    src=W/f'DEV_RUN_{i:02}';dest=H/stem/'worker_artifacts';dest.mkdir(parents=True,exist_ok=True)
    inv=json.loads((H/(stem+'_worker_artifact_inventory.json')).read_text())
    for row in inv:
        p=src/row['path'];assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
        q=dest/(row['path']+'.raw');q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
        artifact_map.append({'attempt':stem,'original_path':row['path'],'package_path':q.relative_to(P).as_posix(),'bytes':row['bytes'],'sha256':row['sha256'],'role':'bounded generic worker/negative/fault evidence; raw bytes not trusted JSON'})
put(R/'WORKER_ARTIFACT_MAP.json',artifact_map)
put(R/'DEV_INTEGRITY_SUMMARY.json',{'classification':'DEV_CHECKED_ONLY','attempts':attempts,'final_source_matches_final_attempt':True,'new_tests':32,'final_passed':32,'historical_tests_reexecuted':0,'numerical_runs_during_assembly':0})
put(R/'EXTERNAL_TRUST_AND_PROVENANCE.json',{'classification':'INDEPENDENT_QC_PENDING','authority':{'commit':e['commit'],'protocol_blob':'108866549d914005c391eedea234ca27cc8604b7','parent':e['commits'][0]['parent'],'signer_fingerprint':'D4EC014EEFCC90E619D2AA59A91239ABCF512130'},'signed_commits_verified':14,'signed_tag_verified':True,'GitHub_and_local_GPG':'Both valid; local key matches user fingerprint, ownertrust undefined; import diagnostics retained in E0.','pre_P0A0_ancestry':e['ancestry'],'branch_at_retrieval':e['branch_at_retrieval'],'new_code_trust':'DEV_UNFROZEN_EXPECTATIONS only; no human code signature fabricated','source_check':'Caller expected exact file-set and hashes, config/schema, interpreter and dependency descriptor, canonical original input; independent reference implementation','proposal_is_not_authority':True,'source_archive_reference':'provenance/EXTERNAL_FROZEN_IDENTITIES.json','remaining_trust':['CPython/Fraction/stdlib','filesystem/OS/hardware','caller-trusted external manifest and private directories','source-hash-to-execution TOCTOU','not a loaded-module attestation'],'future_gate':'Independent QC then separate human-signed code-only freeze, then new signed target-free registered protocol'})
put(R/'INFORMATION_BARRIER.json',{'classification':'IMPLEMENTED_UNVERIFIED','writes_observed':'p0a3e_work isolated workspace plus requested deliverable save only','git_commands':[],'existing_repository_modifications':False,'original_P0A3D_untouched':True,'historical_DEV_reexecution':False,'P0A0_replay':False,'P0A4_execution':False,'targets_fonts_proxies_or_glyph_geometry':False,'candidate_null_science':False,'optimizer_benchmarks':False,'3D_cameras_QH_execution':False,'parameter_or_primary_score_selection':False,'bounded_new_DEV':'Two attempts of prospectively fixed 32-method engineering catalogue; no numerical scope expansion','source_metadata_access':'Git trees and signed text only; no historical image/glyph bytes fetched','audit_limit':'Observed session actions; no claim of exhaustive off-host forensic verification','inherited_limitations':'v0.8 negative source recovery; B07/B08; missing crop; historical P0A1 nonidentical recovery; A09 metadata limitation; original P0A3/P0A3C/P0A3D software incompleteness retained'})
# Each mandatory facet has domain, source, independent route, trust, evidence,
# untested/failure branch and an author evidence status (not independent approval).
rows=[
('E1.1','raw bytes and predecode bounds','wire.decode; supervisor.bounded_file','reference.wire.read','bounded lexical pass then stdlib JSON','DEV02 01-05','upstream stream acquisition outside bytes API','PASS'),
('E1.2','canonical rational/dimension/traversal grammar','wire.request; core.validate/rational','reference.wire.request/rational','frozen ordered rational domain; exact gcd','DEV02 03-06','exhaustive grammar review pending','PASS'),
('E1.3','canonical hashes only after validation','wire.request/parse_request; identity.verify','reference.service.verify/wire.canonical','SHA256 and canonical ASCII JSON','DEV02 01-06;19','bounded raw prefix is not whole-file canonical identity','PASS'),
('E1.4','nested certificate grammar','reference.wire.certificate/scalar','checker.check exact reconstruction','no boolean indices or forward generators','DEV02 15-18','schema external exhaustive validation not performed','PARTIAL'),
('E1.5','public typed failure/no score','supervisor.run/resume; worker.main','reference.service.verify','exception categories and separate public boundary','DEV02 02-06;20-21;26-32','low-level APIs bypass boundary; parent death cannot reply','PARTIAL'),
('E2.1','dependent-root sign/equality','Tower.sign/eq','Algebra.zero/sign','frozen proof 1.4; Fraction/CPython','DEV02 07-08;10;18','general executable correctness unproved','PASS'),
('E2.2','nonzero zero-conjugate inverse','Tower.inv','Algebra.inverse','frozen proof 1.5 lower-height inverse','DEV02 09','no independent runtime qualification','PASS'),
('E2.3','positive algebraic roots and lengths','Tower.root; core.build','Algebra.root; checker.path','frozen proof 1.6 and 2-3','DEV02 11-12;16','arbitrary growth may be incomplete','PASS'),
('E2.4','caps never guessed equality','Tower.tick/make/root','Algebra.step/tidy/sign','resource distinct from exact trichotomy','DEV02 23;26;28','temporary growth precedes some software guards','PARTIAL'),
('E3.1','original-input exact reconstruction','core.calculate','checker.path/reconstruct/check','global-u antiderivatives versus endpoint quadrature','DEV02 11-12;15;19','only five generic numerical comparisons','PASS'),
('E3.2','optimal proper rotation and direct residual','core.calculate','checker.check Gram/determinant/residual','frozen proof section 4','DEV02 13-14;17','registered adversarial certification not run','PASS'),
('E3.3','exact whole-roll and tiny positive','core.calculate decisions','checker.reconstruct/check','exact zero/nonzero branches','DEV02 10-11;17','infinite-domain software proof absent','PASS'),
('E3.4','division/root denominator predicates','Tower.inv/root','Algebra.inverse/root; wire.scalar','guards on every arithmetic inverse/root; no asserted formal independence','DEV02 07-10;16;18','no full arithmetic operation transcript or formal code proof','PARTIAL'),
('E3.5','separate reference DAG','production namespace','reference wire/identity/arithmetic/checker/service','shared runtime/math explicitly enumerated','DEV02 22; IMPORT_DAG.json','common-mode Fraction/CPython risks unresolved','PARTIAL'),
('E4.1','external expected source/config/schema/input identities','identity.verify; supervisor.context','reference.identity.verify','caller expectations separate from certificate','DEV02 19-21','only unsigned DEV expectation mode; future authority not supplied','PARTIAL'),
('E4.2','runtime and checker identities','identity.environment/files','reference.identity.verify','interpreter bytes/version/dependency descriptor','DEV02 20-21','not all loaded stdlib bytes attested; TOCTOU possible','PARTIAL'),
('E4.3','rebuild/source-before/after evidence','rebuild_candidate.py; original patch','snapshot and hashes independent of arithmetic','byte identities and exact source provenance','static rebuild and DEV pre/post hashes','rebuild is integrity evidence only','PASS'),
('E5.1','bounded parent and sequential workers','supervisor.child; worker.main','separate reference process','OS RLIMIT plus parent wall deadline','DEV02 25-28','OS hard CPU/OOM kills not induced','PARTIAL'),
('E5.2','durable complete checkpoint','atomic_save; resume','fresh reference checker worker','flush/fsync/rename/directory fsync','DEV02 29-31','real power/kernel/parent failure not tested','PARTIAL'),
('E5.3','output/disk/process limits','private_write/disk/bounded_file; worker.main','same bounded supervisor boundary','application budget plus per-file OS ceiling','DEV02 25;32','no aggregate filesystem quota or privileged process isolation','PARTIAL'),
('E5.4','no numeric output after interrupted worker','child/run/resume','service failure vocabulary','surviving controller observes exit/timeout','DEV02 26-28;31','parent/host death has no guaranteed response','PASS'),
('E6.1','prospective bounded catalogue','DEV_CASES_PREDECLARED.md; test_contracts.py','analytic identities and separate checker','locked fixture/cap digests','DEV01 and DEV02 logs','no random/registered numerical challenge suite','PASS'),
('E6.2','preserve failures and historical attempts','run_dev.py; provenance identities','archive/manifest/source hash checks','append-only history; original external signed bytes','DEV01 failed assertion plus DEV02 exact diff','original DEV01-04 referenced not installed/rerun','PASS'),
('E6.3','substantive independent QC','INDEPENDENT_QC_CHECKLIST.md','future external reviewer','no self-qualification','unfilled checklist supplied','not performed by Work author','UNRESOLVED')]
table('E1_E6_ACCEPTANCE_MATRIX.csv',['requirement','eligible_domain','code_function','independent_checker','proof_or_trust','DEV_or_integrity_evidence','untested_or_failure_branch','author_evidence_disposition'],rows)
table('REQUIREMENT_TO_CODE_AND_PROOF.csv',['requirement','code','reference','proof_trust','status'],[(r[0],r[2],r[3],r[4],r[7]) for r in rows])
table('PRODUCTION_REFERENCE_TRUST_MATRIX.csv',['component','production','reference','common_trust','status'],[
('raw parser','wire.decode/request; core parser','reference.wire.read/request/rational','JSON/CPython and shared grammar','INDEPENDENT_QC_PENDING'),('algebra','sparse masks/sign guarded squares','dense vectors/norm zero/rational isolation','Fraction/CPython and frozen quadratic theorem','INDEPENDENT_QC_PENDING'),('integration','local endpoint quadrature; centered midpoint variance','global-u antiderivative; raw moments minus mean squared','same mathematical input and objective','INDEPENDENT_QC_PENDING'),('witness','closed-form Q and endpoint residual','independent correlation/Q; Gram/determinant/direct polynomial residual','SO2 theorem and exact arithmetic','CHECKER_RECOMPUTED_DEV'),('identity','production identity.verify','reference identity.verify','SHA256/JSON/filesystem/runtime/external caller authority','EXTERNAL_TRUST_ANCHOR_UNQUALIFIED'),('process','parent controller and production worker','separate checker worker','same interpreter/OS/filesystem','RESOURCE_CRASH_ENVELOPE_INCOMPLETE')])
table('E0_E9_DISPOSITION_MATRIX.csv',['stage','evidence','frozen_theorem','engineering_candidate','independent_verifier','registered_validation'],[
('E0','E0_VERIFIED.json; exact archive/QC/history checks','UNCHANGED_INDEPENDENTLY_VERIFIED','INTEGRITY_PASS','PENDING','NOT_RUN'),('E1','strict bytes/schema/failure evidence','UNCHANGED','PARTIAL_QUALIFICATION','PENDING','NOT_RUN'),('E2','unchanged exact kernels; dependent-root checks','UNCHANGED','DEV_SUPPORTED_UNQUALIFIED','PENDING','NOT_RUN'),('E3','original-input exact residual and tamper checks','UNCHANGED','DEV_SUPPORTED_UNQUALIFIED','PENDING','NOT_RUN'),('E4','external expected manifest and mismatches','UNCHANGED','UNFROZEN_TRUST_UNQUALIFIED','PENDING','NOT_RUN'),('E5','RLIMIT/controller/checkpoint evidence','UNCHANGED','PARTIAL_CRASH_SYSTEM_GUARANTEES','PENDING','NOT_RUN'),('E6','DEV01 retained failure; DEV02 32/32','UNCHANGED','DEV_CHECKED_ONLY','CHECKER_RECOMPUTED_DEV','NOT_RUN'),('E7','cumulative source/diffs/history/ZIP identities','UNCHANGED','CANDIDATE_DELIVERY','PENDING','NOT_RUN'),('E8','unfilled external QC gate','UNCHANGED','NO_READY_STATUS_ACTIVATED','PENDING','NOT_RUN'),('E9','ENGINEERING_QUALIFICATION_REVIEW.md','P0A3D_EXACT_2D_QO_THEOREM_INDEPENDENTLY_VERIFIED','P0A3E_SOFTWARE_IMPLEMENTATION_INCOMPLETE','REFERENCE_INDEPENDENCE_UNQUALIFIED','NOT_RUN')])
print(json.dumps({'assembly':'PASS','new_DEV_attempts':len(attempts),'source_files':len(last),'worker_artifacts':len(artifact_map),'frozen_proof_unchanged':True,'numerical_execution':False}))
