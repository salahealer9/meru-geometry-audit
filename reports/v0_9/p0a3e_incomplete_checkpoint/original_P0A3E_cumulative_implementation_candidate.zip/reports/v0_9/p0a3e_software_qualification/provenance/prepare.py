"""Safe, selective baseline copy after completed E0; no archived script execution."""
from pathlib import Path
import hashlib,json,platform,shutil,subprocess,sys,zipfile
W=Path(__file__).resolve().parent;P=W/'package';R=P/'reports/v0_9/p0a3e_software_qualification';V=R/'provenance';V.mkdir(parents=True,exist_ok=True)
e=json.loads((W/'E0_VERIFIED.json').read_text());assert len(e['commits'])==14
with zipfile.ZipFile(W/'intake/original_P0A3D_cumulative_proof_and_implementation_candidate.zip') as z:
    for n in z.namelist():
        if n.startswith(('src/','reference/')):
            p=P/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(z.read(n))
    (V/'P0A3D_ORIGINAL_SOURCE_SNAPSHOT.json').write_text(json.dumps({n:z.read(n).decode() for n in z.namelist() if n.startswith(('src/','reference/'))},indent=2)+'\n')
for n in ('E0_VERIFIED.json','E0_FETCH_LOG.json','E0_stdout.log','E0_stderr.log','verify_e0.py'):
    shutil.copyfile(W/n,V/n)
for p in (W/'intake').iterdir():
    if p.suffix in ('.md','.asc','.payload','.gpg') or p.name.startswith(('commit_','tree_')) or p.name in ('tag.json','FREEZE_MANIFEST.sha256','P0A3D_independent_QC_verification_2026-10-20.json'):
        shutil.copyfile(p,V/p.name)
shutil.copyfile(W.parent/'upload/P0A3E_SIGNED_PROTOCOL_EXACT_2D_QO_SOFTWARE_QUALIFICATION_WORK_HANDOFF_2026-10-20(2).txt',V/'WORK_HANDOFF.txt')
r=subprocess.run([sys.executable,'-m','venv','--without-pip',str(W/'venv')],capture_output=True,text=True);assert r.returncode==0,r.stderr
code="import sys,platform,json,importlib.metadata;print(json.dumps({'python':sys.version,'executable':sys.executable,'prefix':sys.prefix,'base_prefix':sys.base_prefix,'platform':platform.platform(),'packages':sorted((x.metadata['Name'],x.version) for x in importlib.metadata.distributions())}))"
s=subprocess.run([str(W/'venv/bin/python'),'-B','-c',code],capture_output=True,text=True);assert s.returncode==0
env={'classification':'IMPLEMENTED_UNVERIFIED','creation_command':r.args,'creation_stdout':r.stdout,'creation_stderr':r.stderr,'runtime':json.loads(s.stdout),'OS':Path('/etc/os-release').read_text(),'dependencies':'stdlib only; no pip/package install; existing environments untouched'}
(R/'ENVIRONMENT_AND_DEPENDENCIES.json').write_text(json.dumps(env,indent=2)+'\n')
print(json.dumps({'baseline_copy':'SOURCE_AND_REFERENCE_ONLY','old_tests_executed':0,'isolated_runtime':env['runtime']}))
