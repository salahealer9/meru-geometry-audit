"""Read-only remote provenance audit. No numerical modules imported/executed."""
from pathlib import Path,PurePosixPath
import concurrent.futures,datetime,hashlib,io,json,platform,stat,subprocess,sys,zipfile
W=Path(__file__).resolve().parent;I=W/'intake';G=W/'gpg';G.mkdir(mode=0o700,exist_ok=True)
C='c48c7a60777200a172ae3c72f5b0402162370ec7';F='D4EC014EEFCC90E619D2AA59A91239ABCF512130'
IDS=[C,'59eb47f7500d57866e4935822b78a555d3bcb515','92de104cab58339df370acf96b8d849ecc2d888b','923bab7855deaee6be49dd299bbdb0d6251844c1','01270ec3bff3c9a6352c5dadc90d5d9f12da0c0d','8adbc226b1ef7234a9bedab02ca515a6c11e5c4f','2425db592e80d5f688adc0facdea9e1042c05cdb','07b64003940072e00fb2ce969ebc3866a9a3dc4d','e917fa2974997703d6ccb60b0b25d0c668d12bd5','090a1db6c95976bbb5f0d69a3cc4a4603d165505','5b0317f193c481d799e88b494ce370679fec43bc','5148712c07ac48742d3435dc14e01667280f94c3','24c00fc44e4d9d57adacd1e636e9e2d20d86a954','d15865167b4e3c454e398bd498d9d681103096f7']
PRE='8bf0babfd91bdefb0792e93707fd0b0da1c09767';TAG='12afd9f9d1cb4a9d000c0fd9555419f0383978e9';TGT='85748bff0bfae383afcc0d885f4aec505a2885dd'
BASE='reports/v0_9/p0a3d_theorem_result_freeze/';PROTO='docs/v0_9/p0a3e_exact_2d_qo_software_hardening_and_independent_certificate_qualification_protocol.md'
PINS={PROTO:'108866549d914005c391eedea234ca27cc8604b7',BASE+'P0A3D_EXACT_2D_QO_THEOREM_RESULT_CLOSEOUT.md':'fcf7867c0e06a30c429cc993846fc2e3361e5ea4',BASE+'P0A3D_NEXT_EXACT_QO_SOFTWARE_QUALIFICATION_PLAN.md':'ce16f01687c616f518c806f6a68381aa467ca657',BASE+'P0A3D_ORIGINAL_THEOREM_PROOF.md':'88c3b1158e34b60aab948e4e0f3b5cd0899f3173',BASE+'P0A3D_independent_mathematical_and_engineering_QC_2026-10-20.md':'5db9608f2413e5ea3a51db148164585fdafcd59b','reports/v0_9/p0a2_target_blind_design/score_normalization_candidates.md':'c848a6bf28471184efb9bf61ae1bd5a0e35933aa','reports/v0_9/p0a2_target_blind_design/numerical_error_failure_ledger.md':'21c4a6dfec35b90a35c36e35ceac508561f552a9'}
API='https://api.github.com/repos/salahealer9/meru-geometry-audit/'
def sha(b):return hashlib.sha256(b).hexdigest()
def obj(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
fetchlog=[]
def fetch(t):
    url,name=t;cmd=['curl','--fail','--silent','--show-error','--location','--max-time','60',url,'-o',str(I/name)]
    r=subprocess.run(cmd,capture_output=True,text=True);fetchlog.append({'command':cmd,'exit':r.returncode,'stderr':r.stderr})
    assert r.returncode==0,(name,r.stderr)
    print('RETRIEVED',name,flush=True)
def batch(ts):
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:list(ex.map(fetch,ts))
def put(n,x):(W/n).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
try:
    batch([(API+'git/commits/'+c,'commit_'+c+'.json') for c in IDS]+[(API+'git/tags/'+TAG,'tag.json'),(API+'compare/'+TGT+'...'+PRE,'ancestry.json'),(API+'branches/hebrew-projection-capacity-v0.9','branch.json'),('https://github.com/salahealer9.gpg','public.gpg')])
    commits=[json.loads((I/('commit_'+c+'.json')).read_text()) for c in IDS]
    batch([(API+'git/trees/'+a['tree']['sha']+'?recursive=1','tree_'+a['tree']['sha']+'.json') for a in commits])
    trees={};changes=[]
    for c,a in zip(IDS,commits):
        t=json.loads((I/('tree_'+a['tree']['sha']+'.json')).read_text());assert not t['truncated'];es={e['path']:e for e in t['tree']}
        for folder,expected in {'':t['sha'],**{e['path']:e['sha'] for e in t['tree'] if e['type']=='tree'}}.items():
            ch=[(q.split('/')[-1],e) for q,e in es.items() if q.rpartition('/')[0]==folder];ch.sort(key=lambda x:(x[0]+('/' if x[1]['type']=='tree' else '')).encode())
            b=b''.join((e['mode'].lstrip('0')+' '+n).encode()+b'\0'+bytes.fromhex(e['sha']) for n,e in ch);assert obj('tree',b)==expected
        trees[c]=es
    for new,old in zip(IDS,IDS[1:]):
        a,b=trees[new],trees[old];changed=[q for q,e in a.items() if e['type']=='blob' and q in b and e['sha']!=b[q]['sha']];removed=[q for q,e in b.items() if e['type']=='blob' and q not in a];added=[q for q,e in a.items() if e['type']=='blob' and q not in b]
        assert not changed and not removed;changes.append({'commit':new,'parent':old,'added':added,'changed':changed,'removed':removed})
    assert changes[0]['added']==[PROTO] and len(changes[1]['added'])==8 and all(p.startswith(BASE) for p in changes[1]['added'])
    paths=sorted(set(PINS)|set(changes[1]['added'])|{'reports/v0_9/p0a3c_incomplete_checkpoint/P0A3C_INCOMPLETE_ENGINEERING_PRESERVATION_CLOSEOUT.md'})
    batch([('https://raw.githubusercontent.com/salahealer9/meru-geometry-audit/'+C+'/'+p,Path(p).name) for p in paths])
    imp=subprocess.run(['gpg','--homedir',str(G),'--batch','--import',str(I/'public.gpg')],capture_output=True,text=True)
    def signature(v,n):
        assert v['verified'] and v['reason']=='valid'
        (I/(n+'.payload')).write_text(v['payload']);(I/(n+'.asc')).write_text(v['signature'])
        cmd=['gpg','--homedir',str(G),'--batch','--no-auto-key-retrieve','--status-fd','1','--verify',str(I/(n+'.asc')),str(I/(n+'.payload'))];r=subprocess.run(cmd,capture_output=True,text=True)
        vs=[x for x in r.stdout.splitlines() if x.startswith('[GNUPG:] VALIDSIG ')];assert r.returncode==0 and len(vs)==1 and vs[0].split()[2]==F and vs[0].split()[-1]==F
        return {'command':cmd,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
    records=[]
    for i,(c,a) in enumerate(zip(IDS,commits)):
        parent=(IDS+[PRE])[i+1];assert a['sha']==c and [x['sha'] for x in a['parents']]==[parent]
        v=a['verification'];h,msg=v['payload'].split('\n\n',1)
        assert any(obj('commit',(h+'\ngpgsig '+s.replace('\n','\n ')+'\n\n'+msg).encode())==c for s in (v['signature'],v['signature']+'\n'))
        records.append({'commit':c,'parent':parent,'tree':a['tree']['sha'],'signature':signature(v,c)})
    source=[]
    for p in paths:
        b=(I/Path(p).name).read_bytes();e=trees[C][p];assert obj('blob',b)==e['sha']
        if p in PINS:assert e['sha']==PINS[p]
        source.append({'path':p,'commit':C,'blob':e['sha'],'bytes':len(b),'sha256':sha(b)})
    assert (I/'protocol.md').read_bytes()==(I/Path(PROTO).name).read_bytes() and len((I/'protocol.md').read_bytes().splitlines())==198
    for line in (I/'FREEZE_MANIFEST.sha256').read_text().splitlines():
        h,n=line.split('  ',1);assert sha((I/Path(n).name).read_bytes())==h
    tag=json.loads((I/'tag.json').read_text());assert tag['sha']==TAG and tag['object']['sha']==TGT and obj('tag',(tag['verification']['payload']+tag['verification']['signature']).encode())==TAG
    tagrec={'sha':TAG,'target':TGT,'signature':signature(tag['verification'],'tag')}
    anc=json.loads((I/'ancestry.json').read_text());assert anc['status']=='ahead' and anc['merge_base_commit']['sha']==TGT
    def safe(z):
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
        for f in z.infolist():
            p=PurePosixPath(f.filename);assert not p.is_absolute() and '..' not in p.parts and '\\' not in f.filename and not stat.S_ISLNK(f.external_attr>>16)
    def audit(z):
        safe(z);rows=json.loads(z.read('PACKAGE_INVENTORY.json'))['payload_files'];lines=z.read('SHA256SUMS').decode().splitlines()
        assert {r['path'] for r in rows}==set(z.namelist())-{'SHA256SUMS','PACKAGE_INVENTORY.json'} and {l.split('  ',1)[1] for l in lines}==set(z.namelist())-{'SHA256SUMS'}
        for l in lines:
            h,n=l.split('  ',1);assert sha(z.read(n))==h
        for r in rows:assert len(z.read(r['path']))==r['bytes'] and sha(z.read(r['path']))==r['sha256']
        return {'entries':len(z.namelist()),'hashes':len(lines),'inventory':len(rows),'CRC':'PASS'}
    archives=[];history=[];baseline=[]
    name='original_P0A3D_cumulative_proof_and_implementation_candidate.zip';b=(I/name).read_bytes();assert len(b)==642047 and sha(b)=='c2f99b0e78849de16c8dc8167bdf5d584d4f64ab2c8a787d6a0ed507cfa9f378'
    with zipfile.ZipFile(io.BytesIO(b)) as z:
        archives.append({'name':name,'bytes':len(b),'sha256':sha(b),**audit(z)})
        assert z.read('reports/v0_9/p0a3d_exact_qo_core/THEOREM_PROOF.md')==(I/'P0A3D_ORIGINAL_THEOREM_PROOF.md').read_bytes()
        for i in range(1,5):
            stem=f'reports/v0_9/p0a3d_exact_qo_core/dev_history/P0A3D_DEV_{i:02}';r=json.loads(z.read(stem+'_result.json'))
            for key in ('sources','stdout','stderr','evidence'):
                ext='.log' if key in ('stdout','stderr') else '.json';assert sha(z.read(stem+'_'+key+ext))==r[key+'_sha256']
            history.append({'attempt':i,'result':r,'members':[{'path':n,'bytes':len(z.read(n)),'sha256':sha(z.read(n))} for n in z.namelist() if n.startswith(stem)]})
        baseline=[{'path':n,'bytes':len(z.read(n)),'sha256':sha(z.read(n))} for n in z.namelist() if n.startswith(('src/','reference/','tests/'))]
    qname='original_P0A3D_independent_QC_review_2026-10-20.zip';b=(I/qname).read_bytes();assert sha(b)=='4da72ab4a3347cad19e746f42ae9799f6e410a97ceb8972ad74530e6723c1e20'
    with zipfile.ZipFile(io.BytesIO(b)) as z:
        safe(z);archives.append({'name':qname,'bytes':len(b),'sha256':sha(b),'CRC':'PASS','members':[{'path':n,'bytes':len(z.read(n)),'sha256':sha(z.read(n))} for n in z.namelist()]})
    # Rehash byte-preserved earlier archives locally against freshly authenticated Git tree.
    for name in ('original_P0A3C_cumulative_implementation_candidate.zip','original_P0A3C_independent_QC_review_2026-10-19.zip'):
        p=W.parent/'p0a3d_work/intake'/name;b=p.read_bytes();key='reports/v0_9/p0a3c_incomplete_checkpoint/'+name;assert obj('blob',b)==trees[C][key]['sha']
        with zipfile.ZipFile(io.BytesIO(b)) as z:
            safe(z);v=audit(z) if 'PACKAGE_INVENTORY.json' in z.namelist() else {'CRC':'PASS','entries':len(z.namelist())}
            archives.append({'name':name,'source':'unchanged local preserved bytes anchored to freshly verified signed Git tree','bytes':len(b),'sha256':sha(b),**v})
    put('E0_VERIFIED.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':C,'commits':records,'tag':tagrec,'ancestry':{'method':'GitHub compare merge base v0.8 to pre-P0A0; adjacent signed parents thereafter','merge_base':TGT,'pre_p0a0':PRE},'sources':source,'changes':changes,'archives':archives,'P0A3D_DEV':history,'baseline':baseline,'key_import':{'exit':imp.returncode,'stdout':imp.stdout,'stderr':imp.stderr},'branch_at_retrieval':json.loads((I/'branch.json').read_text())['commit']['sha'],'scope':'NO existing repository writes; isolated p0a3e_work only; no scientific module or old DEV executed'})
    print(json.dumps({'E0_INTEGRITY':'PASS','signed_commits':len(records),'signed_tag':1,'archives':len(archives),'historical_DEV':len(history),'source_files':len(source)}))
finally:put('E0_FETCH_LOG.json',fetchlog)
