# Ordinary DEV assertion correction before attempt 02

[DEV_CHECKED_ONLY] P0A3E_DEV_01 stopped at method 12 after the five full
certificates had been independently recomputed successfully. A test incorrectly
compared two serialized coefficient vectors for exact equality. The direct
residual and closed-form q² can have different dependent-radical constructions
with the same real value. The independent checker had already tested semantic
equality, including a separately integrated residual, for every case.

[IMPLEMENTED_UNVERIFIED] Correct method 12 to inspect the exact-zero residual
decision and the completed independent direct-residual recomputation evidence.
Do not alter arithmetic, certificate values, inputs, resource limits, the frozen
theorem or acceptance identities. This is an invalid test assertion, not a
false mathematical certificate acceptance or a theorem contradiction. Attempt
01 source, output, stack, evidence and all workers remain preserved. Rerun the
same fixed 32-method catalogue as P0A3E_DEV_02, with the automatic exact diff.
