# Hostile input and failure ledger

[DEV_CHECKED_ONLY] Final DEV method IDs refer to attempt 02; its full stdout,
stderr, source snapshot, worker artifacts and exact expected manifests are retained.

| Branch | Observed result | Limits |
|---|---|---|
| 01 canonical bytes/traversal | Validated, idempotent; different traversal hashes differ | Metadata does not prove data origin |
| 02 duplicate keys/NaN/Infinity/float/exponent | INVALID_INPUT | Fixed listed probes, no fuzz campaign |
| 03 bool endpoint/order/dimensions/extra fields | INVALID_INPUT | No implied support for other nuisance groups |
| 04 rational syntax/reduction/Unicode/zero denominator | INVALID_INPUT | Canonical exact strings only |
| 05 raw size/depth/string/container/token/digit/vertex/bit limits | RESOURCE_INCOMPLETE | Valid large inputs are not excluded from theorem |
| 06 constant path/wrong raw type | NOT_EVALUABLE / INVALID_INPUT, no certificate | Constant path is exact geometric degeneracy |
| 13–17 malformed/forged certificate, proper nonoptimal witness | CERTIFICATE_REJECTED | No false certificate acceptance observed |
| 18 distinct construction of same exact zero | Independently accepted semantically | A coefficient-vector comparison is insufficient |
| 19 original-input/digest change | CERTIFICATE_REJECTED | Caller-supplied original input is separately bound |
| 20–21 external identity layers/missing pins | CODE_IDENTITY_MISMATCH | DEV expectations are unsigned |
| 23 arithmetic/isolation caps | Typed ResourceIncomplete / Incomplete | Internal exceptions mapped by byte service/worker |
| 26 timeout | RESOURCE_INCOMPLETE, no certificate | Surviving parent observed deadline and killed child |
| 27 nonzero exit / SIGKILL | INTERNAL_ERROR_NO_CERTIFICATE / UNKNOWN_TERMINATION | Signal is evidence, not inferred OOM cause |
| 28 injected MemoryError/RecursionError | RESOURCE_INCOMPLETE | Injection is not a real host-memory exhaustion test |
| 29–31 save interruption/recovery/torn bytes | Old complete record preserved; complete renamed record rechecked; malformed record fails | Controlled fault hooks, no real power loss |
| 32 output/disk/file-size/existing-directory I/O | Typed refusal, no success certificate | Disk bound is an application policy, not a mounted quota |

[DEV_CHECKED_ONLY] Attempt 01 failed at method 12 after five correct independent
recomputations because its test demanded identical formal representations of equal
algebraic values. The exact failure and source survive. Attempt 02 changed that
assertion to inspect semantic equality evidence; all 32 methods passed. Numerical
algorithms, fixtures, thresholds and ceilings were not changed to obtain passing
outcomes. No STOP_AND_QUARANTINE trigger was observed in these attempts.

[UNRESOLVED] The raw-byte API assumes the caller has bounded upstream acquisition;
the supplied bounded-file reader handles regular local files. The low-level
mathematical object APIs are not total hostile-input service boundaries. Structural
schemas and guards have not received independent exhaustive validation. Parent or
machine death cannot guarantee a response; unexpected host/filesystem behavior
can require separate forensic review. These are explicit qualification limits.
