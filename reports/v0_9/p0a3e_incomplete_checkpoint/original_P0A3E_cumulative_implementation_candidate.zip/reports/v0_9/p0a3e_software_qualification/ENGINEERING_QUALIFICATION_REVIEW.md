# P0A3E engineering review submission — separate dispositions

[FROZEN THEOREM] `P0A3D_EXACT_2D_QO_THEOREM_INDEPENDENTLY_VERIFIED` is preserved
by signed commit `59eb47f7500d57866e4935822b78a555d3bcb515`. Its original proof
bytes and the original P0A3D implementation-incomplete/QC-negative statuses are
unchanged. E0 verified the theorem freeze and original package directly against
GitHub. This software phase does not reassess or amend the frozen theorem.

[IMPLEMENTED_UNVERIFIED] The cumulative candidate adds bounded raw-byte parsing,
explicit canonical encoding, independent strict certificate grammar, external
expected-manifest checks, separate production/checker subprocesses and verified
checkpoint recovery. Both exact arithmetic modules and production mathematical
core remain byte-identical to P0A3D; independent checker changes concern grammar,
identity and engineering-state boundaries. Full diffs and original hashes are supplied.

[CHECKER_RECOMPUTED_DEV] Final attempt P0A3E_DEV_02 passed 32/32 methods. Five
fresh generic QO comparisons were recomputed independently, including a genuine
irrational-length proper rotation, honest subdivision/zero event, whole-roll tie,
tiny nonzero correlation and a fixed different traversal with unequal knots.
Forged scores and a feasible nonoptimal proper rotation were rejected. Distinct
representations of an equal algebraic value were handled semantically. No false
mathematical certificate acceptance or theorem contradiction was observed.

[DEV_CHECKED_ONLY] Attempt 01 stopped after 12 methods, with 11 passing and one
failing assertion in method 12; the five certificate recomputations had passed.
That assertion wrongly compared formal expression vectors. The preserved repair
uses semantic equality evidence already independently recomputed. Attempt 02
changed only that assertion. All fixtures, production/reference arithmetic,
policy ceilings and theorem bytes remained unchanged. Both attempts' complete
source states, pre/post hashes, command/exit/stack/stdout/stderr and worker files
are retained. Historical P0A3D 01–04 remain byte-exact frozen external records.

| Facet | Candidate disposition | Reason |
|---|---|---|
| Software completeness | [UNRESOLVED] `P0A3E_SOFTWARE_IMPLEMENTATION_INCOMPLETE` | Core hardening implemented; full engineering qualification remains partial on the explicit trust/process/hostile-boundary obligations below. |
| Exact predicates | [INDEPENDENT_QC_PENDING] `P0A3E_EXACT_PREDICATE_UNQUALIFIED` | Frozen proof and transparent source support the method; this phase supplies bounded code evidence, not formal executable correctness. |
| Reference independence | [INDEPENDENT_QC_PENDING] `P0A3E_REFERENCE_INDEPENDENCE_UNQUALIFIED` | Separate parser/arithmetic/integration/identity source, but shared Fraction/CPython/math/OS need external assessment. |
| Input failure envelope | [UNRESOLVED] `P0A3E_INPUT_FAILURE_ENVELOPE_INCOMPLETE` | Enumerated public byte cases pass; low-level object kernels bypass the boundary, upstream stream allocation and exhaustive malformed-schema coverage are not qualified. |
| Resource/crash envelope | [UNRESOLVED] `P0A3E_RESOURCE_CRASH_ENVELOPE_INCOMPLETE` | Controlled worker faults and checkpoint injection pass; no hard aggregate disk quota/process security sandbox or real power/host-OOM recovery established. |
| External trust | [INDEPENDENT_QC_PENDING] `P0A3E_EXTERNAL_TRUST_ANCHOR_UNQUALIFIED` | Expected-byte comparison is operational, but all new code expectations are unsigned DEV proposals and runtime TOCTOU/common trust remains. |
| Registered validation | [DEFERRED] `P0A3E_REGISTERED_VALIDATION_NOT_RUN` | No P0A4 or new registered suite was run. |

[UNRESOLVED] Concrete remaining blockers: caller-trusted directory/interpreter
assumptions; no protection against privileged mutable-host changes between source
hashing and execution; application-only aggregate disk/process-count controls;
no end-to-end loaded-module attestation; no independent exhaustive assessment of
all malformed nested certificate/grammar branches or common arithmetic runtime;
no real hard-machine-failure durability evidence. Internal object APIs must remain
explicitly internal. These are not silently marked PASS because 32 tests passed.

[DEFERRED] The positive ready-for-registered-validation status is not assigned.
Independent mathematical/source/engineering QC must decide whether further
hardening or a narrower engineering deployment contract is needed, while leaving
the theorem's rational-input domain unchanged. Only a later human-signed code-only
freeze can activate eligibility; a separately signed target-free validation
protocol is then required. The current package is unsigned and unapproved.

[FROZEN THEOREM] The v0.8 conclusion remains
`NO_REPRODUCIBLE_PUBLISHED_FIRST_HAND_CONSTRUCTION_RECOVERED`. Missing historical
algebraic functions, deformation/carrier construction and shadow law, missing crop
`aog_p07_spherical_projection.png`, historic image-dependent exclusions and A09
metadata-only JPEG limitation remain. The historic P0A1 recovery was not a
byte-identical recovery of its lost package. P0A3/P0A3C incompleteness is not
retroactively resolved. B07 rights/independent ordered observations and B08 matched
controls/fairness/inference remain unresolved; 22 letters are not assumed IID.

[DEFERRED] No Hebrew image, glyph proxy, target geometry, final primary score,
G1/G2 hierarchy, 3D/camera/A/B, QH, SEP/COV/ROUND, candidate/null experiment,
optimizer benchmark, P0A0 replay or P0A4 execution entered this phase. No Git
commit/push/repository mutation occurred in the observed workflow. This is a
scoped action record, not an exhaustive off-host forensic guarantee.
