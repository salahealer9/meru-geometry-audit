# E0 workflow and engineering lock

[FROZEN THEOREM] The complete signed P0A3E protocol, P0A3D proof/closeout/QC,
P0A2 contracts and P0A3C caveats were read before implementation. Fourteen
commit signatures and the v0.8 tag were cryptographically checked against the
user-pinned fingerprint; Git objects and trees were rehashed. GPG ownertrust
is distinct from the signature match. Full records are under provenance.

[IMPLEMENTED_UNVERIFIED] E1 will expose bytes-only guarded parsing; E2 retains
the frozen dependent-radical arithmetic with guarded resources; E3 validates
the full certificate structure then independently recomputes global-u integrals;
E4 accepts an external expected manifest covering every code/config/schema/test
file, environment and canonical input; E5 uses sequential isolated production
and reference subprocesses plus verified atomic checkpoint saving. There is
no self-selected source trust in the certificate checker. A separately labeled
DEV proposal manifest supplies test expectations without claiming human trust.

[IMPLEMENTED_UNVERIFIED] E1 public failures: INVALID_INPUT, NOT_EVALUABLE,
CERTIFICATE_REJECTED, RESOURCE_INCOMPLETE, UNRESOLVED_EXACT_PREDICATE,
CODE_IDENTITY_MISMATCH, INTERNAL_ERROR_NO_CERTIFICATE, UNKNOWN_TERMINATION.
Only a completely recomputed engineering candidate may carry a certificate.
Every failure excludes q/witness/certificate fields. Raw identities are bounded
prefix hashes with original size explicitly recorded; canonical identities are
created only after full validation. Request/certificate ABIs retain the original
theorem lane; new service/resource/schema identities are versioned separately.

[INDEPENDENT_QC_PENDING] Mandatory E1–E6 acceptance matrix is prospectively
defined by the numbered DEV rows and source mapping; final rows will report
actual evidence and untested branches, never infer full correctness from counts.
Reference and production parser/arithmetic/integration/identity modules must
be disjoint; common Python/Fraction/OS and shared mathematics remain explicit.
No old test is rerun, no theorem text changed, no original archive rewritten.
