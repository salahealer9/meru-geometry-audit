# Independent QC checklist — intentionally unfilled

[INDEPENDENT_QC_PENDING] Reviewer identity, source hashes, findings and final
decision must be supplied independently. The Work author assigns no approval.

- [ ] Verify P0A3E commit/blob/parent/fingerprint, 14-commit chain and theorem freeze.
- [ ] Rehash original ZIP/QC and historical DEV identities; verify frozen proof unchanged.
- [ ] Inspect raw-byte limits, ASCII grammar, duplicate keys, bool/int, huge digits and failure hashing.
- [ ] Confirm public versus low-level API boundary and all score-free failure states.
- [ ] Audit dependent-radical zero/sign/inverse, including nonzero zero-conjugate denominator.
- [ ] Audit reference positive roots, exact equality and interval separation only after nonzero proof.
- [ ] Reconstruct true arclength, moments, correlations and direct residual independently.
- [ ] Inspect proper but nonoptimal witness rejection and exact whole-roll versus tiny nonzero handling.
- [ ] Inspect strict nested certificate parsing, masked-generator histories and semantic equality.
- [ ] Audit production/reference import DAG and shared mathematical/Python/Fraction/OS trust.
- [ ] Confirm external expected hashes are operational and never self-authorized as signed trust.
- [ ] Review environment/source/schema/config/fixture bindings and stale-bytecode/TOCTOU limitations.
- [ ] Inspect enforced versus application-only budgets and all interruption/exit evidence.
- [ ] Review temp/fsync/rename/restart and distinguish controlled injection from real power failure.
- [ ] Inspect both DEV attempts, failed assertion, exact correction and unchanged mathematical source.
- [ ] Check full original-to-revised diffs, deterministic rebuild, package CRC/manifests/inventory.
- [ ] Confirm no repository modification, old test replay, P0A4, target/proxy, camera/QH or candidate/null work.
- [ ] Assign separate theorem-historical, software, checker, resource and external-trust dispositions.

Reviewer / date / reviewed ZIP SHA-256: ____________________

Mandatory corrections and qualification decision: ____________________

Human code-only signing decision (separate authority): ____________________
