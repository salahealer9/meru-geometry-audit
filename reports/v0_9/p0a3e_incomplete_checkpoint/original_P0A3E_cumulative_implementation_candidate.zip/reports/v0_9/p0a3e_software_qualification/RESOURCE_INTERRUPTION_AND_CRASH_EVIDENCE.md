# Resource, interruption and checkpoint evidence

[IMPLEMENTED_UNVERIFIED] The versioned policy is included under schemas. Each
numerical/reference worker is a separate `-I -B` Python process, one at a time.
The controller bounds input and output reads and enforces an eight-second wall
deadline; workers apply Linux RLIMIT_AS (256 MiB), CPU (6/7 seconds), file size
(2 MiB), open files (32), core size (0) and Python recursion (256). Exact arithmetic
also has operation/term/bit/formal-degree/reference-isolation guards. Worker
stdout and stderr are retained as private artifacts, including empty killed-process
files. Every observed return code and timeout decision is in the evidence ledger.

[IMPLEMENTED_UNVERIFIED] Workers set the Python integer-string ceiling to 5,000
digits. In a caller interpreter with a smaller active conversion ceiling, the
byte guards conservatively use the smaller of that ceiling and the policy bound;
they report RESOURCE_INCOMPLETE before conversion. This can reduce completion
in direct calls without changing any exact mathematical value or input domain.

[DEV_CHECKED_ONLY] Method 25 read back actual worker limits. Method 26 used a
predeclared 200 ms diagnostic deadline and a sleeping worker; the parent killed
the process group, waited and returned RESOURCE_INCOMPLETE. Method 27 observed
exit 17 and deliberate self-SIGKILL; the latter yielded UNKNOWN_TERMINATION.
Method 28 injected Python MemoryError and RecursionError before numerical work.
These were controlled generic fault probes, not arithmetic timing benchmarks.

[IMPLEMENTED_UNVERIFIED] Complete checkpoints bind canonical input, externally
expected source/config/schema/runtime manifest and service version through a
work identity. Saving uses a new temporary file, flush and fsync, atomic replace,
then directory fsync. Private partial files retain their identity and are never
accepted as completed work. Resume reads a bounded complete checkpoint, checks
the work identity and runs a separate independent verifier from original input.
The stored verification flag is not used as proof; fresh recomputation decides.

[DEV_CHECKED_ONLY] Before-write and after-flush injected interruptions left the
old complete checkpoint byte-identical. After-rename interruption left a complete
record that was independently recomputed on restart. Torn JSON and mismatched
checkpoint identities returned failure without a certificate. Output length,
bounded-file size and application disk checks refused their declared over-limit
cases; the sparse over-limit file is deliberate generic evidence, not target data.

[UNRESOLVED] Disk usage and the single-child policy are application-level controls,
not a security sandbox or per-directory filesystem quota. No effective root-user
RLIMIT_NPROC claim is made. CPU/memory limits were read back, but real OS OOM,
CPU-hard-limit kill, power loss, kernel crash and parent SIGKILL were not provoked.
Python exception injection does not establish those branches. Directory fsync
and atomic rename rely on the underlying filesystem; device durability is not
proven by this test. Temporary coefficient growth can occur before software bit
checks; worker memory/CPU/wall limits are the second boundary. Direct kernel API
calls bypass the supervisor. No universal termination, typed response after
parent death, privileged-code containment or arbitrary-host recovery guarantee
is claimed. These remain PARTIAL/DEFERRED in the acceptance matrix.
