# P0A3G-R2 — R2-CFINAL cumulative package (unsigned engineering evidence for independent QC)

**Agent outcome:** `P0A3G_R2_PROSPECTIVE_ENGINEERING_REPLICATION_SUBMITTED_FOR_INDEPENDENT_QC`. The single attempt `P0A3G_R2_DEV_01` ran under the witnessed release of R2-C1-REV1 and reported all 20 methods PASS with evidence reconciled. This is **not** an approved software qualification, not a code freeze and not a self-certification. P0A4 remains NOT RUN and NOT AUTHORIZED. No Git commit, push or modification was made.

## Contents
| Path | Content |
|---|---|
| `checkpoints/P0A3G_R2-C0.zip` | R2-C0 intake checkpoint, exact original bytes (`e99811f3…bbb5`, 63,036 B) |
| `checkpoints/P0A3G_R2-C1-REV1.zip` | The witnessed and released lock, exact original bytes (`b34a3cd2…09b1`, 197,250 B) |
| `checkpoints/P0A3G_R2-C2.zip` | Complete first-attempt evidence, exact original bytes (`860d93dc…1cbb`, 1,388,186 B) |
| `checkpoints/rejected_not_released/P0A3G_R2-C1.zip` | The rejected first lock (`740da699…7589`), kept as historical evidence. Never executed. |
| `receipts/` | Receipts for C0, C1-REV1 (JSON and lock receipt), C2, and the rejected R2-C1 |
| `release_and_witness/` | Verbatim release record, transcript of the REV1 witness approval, the negative pre-witness review (`R2_C1_W01`) and the driver correction diff |
| `candidate/`, `lock/SOURCE_LOCK.json` | The unmodified 51-file source and its signed G-C1 lock (`abff7aa8…5902`) |
| `r2_external/`, `lock/R2_EXTERNAL_LOCK.json` | External challenge code, fixtures, driver and reconciler (`2c8301fd…377b`) |
| `R2_TEST_CATALOGUE_LOCK.md`, `ORIGINAL_P0A3G_DEV_CASES_PREDECLARED_from_signed_G-C1.md`, `R2_SCHEMA_POLICY_AND_STATUS_REQUIREMENTS.md` | Locked catalogue and requirements (REV1) |
| `R2_TEST_OUTCOMES.md` | Observed outcomes for all 20 methods, with evidence locations |
| `R2_PRE_RUN_CHRONOLOGY_through_R2-C1-REV1.md`, `R2_EXECUTION_CHRONOLOGY.md` | Complete chronology: intake, rejected lock, REV1, release, single attempt, packaging |
| `R2_C2_AGENT_CROSSCHECK.json` | Read-only agent cross-checks after the attempt |
| `BASELINE_AND_NEGATIVE_QC_REFERENCES.md` | Original baseline identities and the permanent negative dispositions (P0A3G and R1) |
| `RUNTIME_AND_TRUST_LIMITATIONS.md` | Declared limitations, including test-only keys, unverified loaded code, a single host, same-agent authorship and the R2-C2 packaging disclosure |
| `INDEPENDENT_QC_CHECKLIST_BLANK.md` | Intentionally blank checklist for the independent reviewer |
| `r2c0/`, `protocol/`, `r2_tools/` | R2-C0 ledgers, signed documents and agent-side verifier/builder |

`SHA256SUMS` covers every member except itself (the conventional self-hash exception). `PACKAGE_INVENTORY.json` lists every payload file with its size and SHA-256. The four nested checkpoint ZIPs are byte-identical to the originals delivered and stored in the Lock Register.
