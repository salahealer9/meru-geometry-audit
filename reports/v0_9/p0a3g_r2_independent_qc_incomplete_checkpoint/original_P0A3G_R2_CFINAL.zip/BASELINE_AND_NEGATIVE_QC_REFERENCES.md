# Baseline identities and preserved negative findings (unchanged and never relabelled)

| Object | Identity | Signed disposition |
|---|---|---|
| Original P0A3G G-CFINAL (software/evidence baseline) | `original_P0A3G_G-CFINAL.zip`, 1,271,972 B, SHA-256 `8b0ec808ddea05d31422ad30308d3a5bbe8aaadb860cd613adf51bdcc9f33a6a` | Not a software approval |
| Original P0A3G G-C1 (51-file candidate lock) | 219,223 B, SHA-256 `1209547e346fb1fe222b3abd387d63efb2d04aa5f34e3b84d9448ea26eadaaf0`; `SOURCE_LOCK.json` `abff7aa8df19f73e070d9f06ebd23334f8d98b45c1736d38399b845c69835902` | Not a software approval |
| Original P0A3G G-C0 / G-C2_DEV_01 | `7e2b1f59…22fb` (66,925 B) / `34373559…18c7` (1,025,638 B) | Historical |
| P0A3G independent QC preservation | signed commit `0e86df64e30d081065bbeb75b6f53391e287f8f3`; QC archive `e4c9ed68…2247` (10,984 B) | **`P0A3G_PROSPECTIVE_DEV_LOCK_SEQUENCE_NOT_QUALIFIED`, `P0A3G_INDEPENDENT_QC_NOT_QUALIFIED`** (four pre-lock full-suite dry runs, then post-lock DEV_01). Remains permanent. |
| P0A3F R1 independent QC preservation | signed commit `d95c50ea96744ce266058c51f85fff320d1a27df` | **`P0A3F_R1_INDEPENDENT_QC_NOT_QUALIFIED`** (zero-byte stdout for `forged_q`/`null_path_record` against recorded 108 B). Remains permanent. |
| Signed R2 protocol / H04 corrigendum | `7de01ab2c90afe52dd763652a9eaffd2e9a2cff9` (blob `01cbd34f…2992`) / `4b488825ed35c7ac91a19abe62be068e75e9a076` (blob `780fc70a…7c`), signer `D4EC014EEFCC90E619D2AA59A91239ABCF512130` | Governing documents |
| Frozen kernels | `algebra.py` `442065…6d2d`, `core.py` `37701d…d420`, `arithmetic.py` `72b3c3…f0ba` | Unchanged and verified after the run |

The historical P0A3G runs (smoke1, smoke2, PRELOCK_DRYRUN_01–04, P0A3G_DEV_01) and R1's failures are historical data, **not R2 prospective evidence** (see `r2c0/R2_EXPOSURE_REGISTER.md`). R2-G01 recomputed the R1 QCF01 mismatch, reproducing exactly two declared 108→0 mismatches, as the expected outcome required.
