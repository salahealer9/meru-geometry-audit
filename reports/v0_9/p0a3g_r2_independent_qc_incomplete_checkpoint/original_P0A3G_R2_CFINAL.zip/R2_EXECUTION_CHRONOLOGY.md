# P0A3G-R2 — Execution chronology for P0A3G_R2_DEV_01 (single authorized attempt)

All times are UTC, 2026-10-21. The pre-run history through R2-C1-REV1 is in that lock's `R2_PRE_RUN_CHRONOLOGY.md`.

| Time | Event |
|---|---|
| 15:34Z | Human-relayed release received, verbatim in `release/R2_RELEASE_RECORD.txt`: `R2-C1 LOCK WITNESSED; SHA-256 b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1; AUTHORIZE ONE P0A3G_R2_DEV_01` (reviewer disposition `R2_C1_REV1_LOCK_WITNESS_PASS_WITH_DECLARED_LIMITS`). It applies only to REV1; the rejected R2-C1 `740da699…7589` was not used. |
| 15:35Z | REV1 re-retrieved from the Lock Register (version `1792596186-5554`) into a new, empty `dev/release_retrieval/`. Decoded, then checked: SHA-256 equals the released value; `zipcheck` PASS (85 members); byte-identical to the built file. |
| 15:35Z | REV1 extracted into a new, empty `dev/release_extract/`. Driver `be1ed8bc…4624` and both locks (`abff7aa8…5902`, `2c8301fd…377b`) confirmed. |
| 15:35Z | Environment check: `/usr/bin/python3.12` 3.12.3 (`e50d468e…150f`), `/usr/bin/openssl` (`b4f547c0…2503`) and `/usr/bin/python3.13` (`a35753cc…4446`) match their pins. The G01 fixture is at HEAD `adacfdbc…`, tree `51f03026…`, clean. The keyring holds public key `D4EC…2130` plus its encryption subkey `72A6…CF6C`, and no secret keys. Resource policy `9b7221fc…4e09` is unchanged. No stray python/openssl processes. Attempt directory absent. |
| 15:35:48.607Z | Driver started with the exact command from catalogue §2 (`--release-sha b34a3cd2… --c1 dev/release_retrieval/P0A3G_R2-C1-REV1.zip --work dev/P0A3G_R2_DEV_01 …`). |
| 15:35:48Z | Driver checks passed: release, CRC, SHA256SUMS, both locks on the extracted copies, binary pins, fixture and keyring. `FIRST_R2_CANDIDATE_INVOCATION`. |
| 15:35:48–15:36:38Z | **G01–G14 run once** (unchanged `g_checks.py`): 14/14 ok, runner exit 0, runner wall time 49.849 s. |
| 15:36:38Z | G decision boundary: locks unchanged after G; no key files left; external G reconciliation exit 0 (111 events, 222 stream rows, 0 unexplained). Decision **`PROCEED_TO_H`**, with no quarantine or failure reasons. |
| 15:36:38–15:36:46Z | **H01–H06 run once** (`R2_HOLDOUT_CHALLENGES.py`): 6/6 PASS, runner exit 0, 7.049 s. |
| 15:36:46Z | No H key files left; external H reconciliation exit 0 (28 events, 56 rows, all MATCH). Post-run lock check passed. Summary and attempt manifest written. |
| 15:36:46.267Z | Driver ended with exit 0. Status `R2_DEV_01_ALL_20_PASSED_EVIDENCE_RECONCILED_PENDING_CHECKPOINTS`. |
| after 15:36Z | Agent-side, read-only cross-checks with no candidate code: the attempt manifest was re-verified (1,270 files), and the reconciler row-count difference and H04 encodings were recorded (`R2_C2_AGENT_CROSSCHECK.json`). R2-C2 staged by a byte-identical copy of the attempt directory, minus the two empty controller key directories. |

**Invocation counts:** the driver ran once, the G runner once and the H runner once. There were two external reconciler processes, which are not candidate code. There were no retries, repairs, reruns, case changes, source changes or budget changes.
