"""P0A3G-R2 single-attempt driver for P0A3G_R2_DEV_01 (locked in R2-C1-REV1; NOT run before release).

REV1 (2026-10-21) corrects independent pre-witness finding R2_C1_W01: the first R2-C1 driver
(SHA-256 6153e9ff...432a, preserved in the rejected lock 740da699...7589) launched H01-H06
unconditionally after G01-G14. This revision inserts a fail-closed decision boundary after G and
before H. No candidate file, kernel, fixture, challenge, expectation or budget is changed.

usage (once, only after an exact human-relayed release citing the verified R2-C1-REV1 SHA-256):
  /usr/bin/python3.12 -I -S -B <extracted>/r2_external/R2_DRIVER.py \
      --release-sha <64-hex R2-C1-REV1 SHA-256 quoted in the human release> \
      --c1 <path to the R2-C1-REV1 ZIP re-retrieved after release> \
      --work <NEW directory, must not exist> \
      --repo-fixture /home/claude/P0A3G_R2/git/historical_g01_fixture_adacfdbc \
      --gnupghome /home/claude/P0A3G_R2/gnupg

Order (fixed, no choices):
  verify -> extract -> environment -> R2-G01..G14 (unchanged g_checks.py, exactly once)
  -> G DECISION BOUNDARY (no candidate code; see below)
  -> only if PROCEED_TO_H: R2-H01..H06 (R2_HOLDOUT_CHALLENGES.py, exactly once) -> H post-checks
  -> post-run source re-verification -> summary -> attempt file manifest.
G decision boundary (computed only from files already on disk, the independent external
reconciler and hashing; launches NO candidate process):
  QUARANTINE_STOP_BEFORE_H  any STOP_AND_QUARANTINE.txt under G/, the token STOP_AND_QUARANTINE
                            in the G runner stdout/stderr, or a source/external lock change during G
  FAILED_STOP_BEFORE_H      otherwise, any of: G runner exit != 0 (incl. driver timeout), G external
                            reconciliation exit != 0 or not run, G attempt_summary missing or not
                            attempt_passed, any G method not PASS, key files left by the G runner
  PROCEED_TO_H              none of the above
On either STOP decision H is NOT launched (no H directory, no H key directory, no H test key);
H methods are recorded NOT_LAUNCHED_AFTER_G_QUARANTINE / NOT_LAUNCHED_AFTER_G_FAILURE. All G
evidence is retained untouched; the external reconciliation of G and the attempt manifest are
still produced so that R2-C2/R2-CFINAL negative packaging needs no further candidate run.
No retry, no repair, no second attempt in any branch.
Exit codes: 0 all 20 passed; 1 P0A3G_R2_REPLICATION_FAILED_EVIDENCE_PRESERVED;
3 P0A3G_R2_STOP_AND_QUARANTINE; 2 pre-candidate stop (lock/environment), no candidate launched.
"""
import hashlib, io, json, os, subprocess, sys, time, zipfile

PY = '/usr/bin/python3.12'
PINS = {'/usr/bin/python3.12': 'e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f',
        '/usr/bin/openssl': 'b4f547c0f16272d1cc7f870330a6f2c243710c335e7a99c734ff7a0c6fdb2503',
        '/usr/bin/python3.13': 'a35753ccb97941cce1467786cce892e608141f09d717188a3235d4f51a754446'}
FIXTURE_HEAD = 'adacfdbc6efcca4922c8d087d029b67e9b0c5dc5'
FPR = 'D4EC014EEFCC90E619D2AA59A91239ABCF512130'
G_ATTEMPT = 'P0A3G_R2_DEV_01'
H_ATTEMPT = 'P0A3G_R2_DEV_01_H'
G_TIMEOUT = 1800
H_TIMEOUT = 1800
METHOD_MAP = [('R2-G%02d' % i, n) for i, n in enumerate([
    'test_G01_signed_sources_archives_kernels_r1_qc', 'test_G02_nonempty_streams_captured_and_reread',
    'test_G03_fresh_forged_q_and_null_path_record', 'test_G04_r1_type_108_vs_zero_byte_mismatch',
    'test_G05_truncated_altered_missing_streams', 'test_G06_swap_duplicate_stale_wrong_worker_collision',
    'test_G07_interrupted_short_tamper_and_retrieved_archive', 'test_G08_actual_abnormal_exit_and_timeout',
    'test_G09_saved_verdict_ignored_fresh_check_within_8s', 'test_G10_genuine_8s_checker_timeout_resource_incomplete',
    'test_G11_test_only_signed_authority', 'test_G12_missing_unsigned_promoted_runtime_loaded_code',
    'test_G13_canonical_parser_and_reference_negatives', 'test_G14_generic_RZTN_relations_and_frozen_kernels'], start=1)]


def sha(b):
    return hashlib.sha256(b).hexdigest()


def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def args():
    a = sys.argv[1:]
    out = {}
    for i in range(0, len(a), 2):
        out[a[i].lstrip('-')] = a[i + 1]
    for k in ('release-sha', 'c1', 'work', 'repo-fixture', 'gnupghome'):
        if k not in out:
            raise SystemExit('MISSING_ARGUMENT ' + k)
    return out


A = args()
WORK = os.path.abspath(A['work'])
os.makedirs(WORK, exist_ok=False)
JOURNAL = []


def log(event, **kw):
    JOURNAL.append({'utc': utc(), 'event': event, **kw})
    with open(os.path.join(WORK, 'R2_DEV_JOURNAL.json'), 'w') as f:
        json.dump(JOURNAL, f, indent=1, sort_keys=True)


def stop(status, **kw):
    log('STOP', status=status, **kw)
    with open(os.path.join(WORK, 'R2_ATTEMPT_SUMMARY.json'), 'w') as f:
        json.dump({'status': status, **kw}, f, indent=1, sort_keys=True)
    print(status)
    sys.exit(2)


# 1. Release / archive identity -------------------------------------------------------------
c1 = open(A['c1'], 'rb').read()
log('release_check', release_sha=A['release-sha'], c1_bytes=len(c1), c1_sha256=sha(c1))
if sha(c1) != A['release-sha'].lower():
    stop('P0A3G_R2_PREDEV_LOCK_NOT_WITNESSED', reason='R2-C1 bytes do not match the released SHA-256')
z = zipfile.ZipFile(io.BytesIO(c1))
if z.testzip() is not None:
    stop('P0A3G_R2_STOP_AND_QUARANTINE', reason='R2-C1 CRC failure')
names = z.namelist()
if len(names) != len(set(names)) or any(n.startswith('/') or '..' in n.split('/') for n in names):
    stop('P0A3G_R2_STOP_AND_QUARANTINE', reason='unsafe or duplicate R2-C1 member names')
for line in z.read('SHA256SUMS').decode().splitlines():
    if line.strip():
        hh, n = line.split(None, 1)
        if n != 'SHA256SUMS' and sha(z.read(n)) != hh:
            stop('P0A3G_R2_STOP_AND_QUARANTINE', reason='R2-C1 SHA256SUMS mismatch ' + n)
# 2. Extract candidate/ and r2_external/ and verify both locks -------------------------------
for n in names:
    if n.startswith(('candidate/', 'r2_external/')) and not n.endswith('/'):
        p = os.path.join(WORK, n)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, 'wb') as f:
            f.write(z.read(n))


def tree_hashes(root):
    out = {}
    for base, _, fs in os.walk(root):
        for fn in fs:
            p = os.path.join(base, fn)
            with open(p, 'rb') as f:
                b = f.read()
            out[os.path.relpath(p, root).replace(os.sep, '/')] = {'bytes': len(b), 'sha256': sha(b)}
    return out


SRC_LOCK = json.loads(z.read('lock/SOURCE_LOCK.json'))['files']
EXT_LOCK = json.loads(z.read('lock/R2_EXTERNAL_LOCK.json'))['files']


def verify_locks(label):
    c = tree_hashes(os.path.join(WORK, 'candidate'))
    e = tree_hashes(os.path.join(WORK, 'r2_external'))
    ok_c = c == SRC_LOCK
    ok_e = e == EXT_LOCK
    log('source_lock_check_' + label, candidate_files=len(c), candidate_ok=ok_c, external_files=len(e), external_ok=ok_e)
    return ok_c and ok_e


if not verify_locks('pre_run'):
    stop('P0A3G_R2_STOP_AND_QUARANTINE', reason='extracted source differs from R2-C1 locks')
# 3. Environment ----------------------------------------------------------------------------
env_ok = True
for p, pin in PINS.items():
    got = sha(open(os.path.realpath(p), 'rb').read())
    log('binary_identity', path=p, sha256=got, pinned=pin, ok=got == pin)
    env_ok = env_ok and got == pin
fx = A['repo-fixture']
head = subprocess.run(['git', '-C', fx, 'rev-parse', 'HEAD'], capture_output=True, text=True).stdout.strip()
clean = subprocess.run(['git', '-C', fx, 'status', '--porcelain'], capture_output=True, text=True).stdout == ''
keyring = subprocess.run(['gpg', '--batch', '--with-colons', '--fingerprint'], capture_output=True, text=True,
                         env={'GNUPGHOME': A['gnupghome'], 'PATH': os.defpath}).stdout
log('g01_fixture', head=head, clean=clean, fingerprint_present=FPR in keyring)
env_ok = env_ok and head == FIXTURE_HEAD and clean and FPR in keyring
if not env_ok:
    stop('R2_ENVIRONMENT_UNQUALIFIED', reason='pinned binary, fixture checkout or keyring differs')
os.makedirs(os.path.join(WORK, 'G'))
KG = os.path.join(WORK, 'controller_keys_G'); KH = os.path.join(WORK, 'controller_keys_H')
os.makedirs(KG, mode=0o700)  # KH is created only if the G decision boundary returns PROCEED_TO_H


def run(label, cmd, timeout):
    log(label + '_start', command=cmd)
    t0 = time.time()
    with open(os.path.join(WORK, label + '_runner.stdout'), 'wb') as so, open(os.path.join(WORK, label + '_runner.stderr'), 'wb') as se:
        try:
            rc = subprocess.run(cmd, stdout=so, stderr=se, cwd=WORK, timeout=timeout).returncode
        except subprocess.TimeoutExpired:
            rc = 'DRIVER_TIMEOUT_KILLED'
    with open(os.path.join(WORK, label + '_runner.exit'), 'w') as f:
        f.write(str(rc) + '\n')
    log(label + '_end', exit=rc, wall_seconds=round(time.time() - t0, 3))
    return rc


# 4. R2-G01..G14, exactly once --------------------------------------------------------------
QMARK = 'STOP_AND_QUARANTINE.txt'
QTOKEN = b'STOP_AND_QUARANTINE'
G_ROOT = os.path.join(WORK, 'G', G_ATTEMPT)
H_ROOT = os.path.join(WORK, 'H', H_ATTEMPT)
H_IDS = ['R2-H%02d' % i for i in range(1, 7)]


def markers_under(root):
    if not os.path.isdir(root):
        return []
    return sorted(os.path.relpath(os.path.join(b, f), WORK) for b, _, fs in os.walk(root) for f in fs if f == QMARK)


def token_in_runner_streams(label):
    hits = []
    for ext in ('stdout', 'stderr'):
        p = os.path.join(WORK, label + '_runner.' + ext)
        if os.path.isfile(p):
            with open(p, 'rb') as f:
                if QTOKEN in f.read():
                    hits.append(label + '_runner.' + ext)
    return hits


def scrub_keys(label, d):
    """Record, then overwrite and delete, any file a runner left in its controller key directory
    (key policy: ephemeral test keys never survive the attempt; only public keys are retained in
    evidence). A non-empty list is itself a recorded failure."""
    left = []
    if os.path.isdir(d):
        for fn in sorted(os.listdir(d)):
            p = os.path.join(d, fn)
            if os.path.isfile(p) and not os.path.islink(p):
                size = os.path.getsize(p)
                left.append({'file': fn, 'bytes': size})
                with open(p, 'r+b') as f:
                    f.write(b'\0' * size)
                    f.flush()
                    os.fsync(f.fileno())
                os.unlink(p)
            else:
                left.append({'file': fn, 'non_regular_left_in_place': True})
    log('key_dir_check_' + label, runner_left_files=left, driver_scrubbed=bool(left))
    return left


def reconcile(label, root, aid):
    """Independent external reconciler (imports nothing from candidate/); never a candidate process."""
    raw = os.path.join(root, 'raw_workers')
    if not os.path.isdir(raw):
        log('RECONCILE_' + label + '_not_possible', reason='raw_workers directory absent', path=raw)
        return 'NO_RAW_WORKERS_DIR'
    reg = os.path.join(root, 'controller/registered_faults.json')
    cmd = [PY, '-I', '-S', '-B', os.path.join(WORK, 'r2_external/r2_stream_reconcile.py'), raw, aid,
           os.path.join(WORK, 'R2_EXTERNAL_RECONCILIATION_' + label)] + ([reg] if os.path.exists(reg) else [])
    return run('RECONCILE_' + label, cmd, 600)


def read_g():
    per = {}
    try:
        with open(os.path.join(G_ROOT, 'evidence.json')) as f:
            ev = json.load(f)
        gs = [o['value'] for o in ev['observations'] if o['name'] == 'attempt_summary'][-1]
        for rid, tname in METHOD_MAP:
            per[rid] = gs['per_method'].get(tname, 'NOT_RUN')
    except Exception as e:
        gs = {'error': repr(e)}
        for rid, _ in METHOD_MAP:
            per[rid] = 'NO_EVIDENCE'
    return gs, per


def read_h():
    per = {}
    try:
        with open(os.path.join(H_ROOT, 'H_evidence.json')) as f:
            hs = json.load(f)['summary']
        for rid in H_IDS:
            per[rid] = hs['per_method'].get(rid, 'NOT_RUN')
    except Exception as e:
        hs = {'error': repr(e)}
        for rid in H_IDS:
            per[rid] = 'NO_EVIDENCE'
    return hs, per


def write_json(name, obj):
    with open(os.path.join(WORK, name), 'w') as f:
        json.dump(obj, f, indent=1, sort_keys=True, default=str)


log('FIRST_R2_CANDIDATE_INVOCATION')
g_rc = run('G', [PY, '-I', '-S', '-B', os.path.join(WORK, 'candidate/tests/dev_v0_9/p0a3g/g_checks.py'),
                 G_ROOT, fx, A['gnupghome'], KG], G_TIMEOUT)

# 5. G DECISION BOUNDARY (fail-closed; launches no candidate process) ---------------------------
g_markers = markers_under(os.path.join(WORK, 'G'))
g_tokens = token_in_runner_streams('G')
g_src_ok = verify_locks('after_G')
g_keys_left = scrub_keys('G', KG)
rec = {'G': reconcile('G', G_ROOT, G_ATTEMPT)}
gsum, per = read_g()
q_reasons = (['QUARANTINE_MARKER:' + m for m in g_markers] + ['QUARANTINE_TOKEN:' + t for t in g_tokens]
             + ([] if g_src_ok else ['SOURCE_OR_EXTERNAL_LOCK_CHANGED_DURING_G']))
f_reasons = []
if g_rc != 0:
    f_reasons.append('G_RUNNER_EXIT:%s' % g_rc)
if rec['G'] != 0:
    f_reasons.append('G_EXTERNAL_RECONCILIATION:%s' % rec['G'])
if not (isinstance(gsum, dict) and gsum.get('attempt_passed') is True):
    f_reasons.append('G_ATTEMPT_SUMMARY_MISSING_OR_NOT_PASSED')
if any(v != 'PASS' for v in per.values()):
    f_reasons.append('G_METHODS_NOT_ALL_PASS:' + ','.join(k for k, v in sorted(per.items()) if v != 'PASS'))
if g_keys_left:
    f_reasons.append('G_RUNNER_LEFT_KEY_FILES')
decision = ('QUARANTINE_STOP_BEFORE_H' if q_reasons else 'FAILED_STOP_BEFORE_H' if f_reasons else 'PROCEED_TO_H')
gate = {'decision': decision, 'quarantine_reasons': q_reasons, 'failure_reasons': f_reasons, 'g_runner_exit': g_rc,
        'g_external_reconciliation_exit': rec['G'], 'g_source_lock_ok_after_G': g_src_ok,
        'g_runner_left_key_files': g_keys_left, 'g_per_method': per, 'g_attempt_summary': gsum,
        'h_launched': decision == 'PROCEED_TO_H', 'utc': utc()}
write_json('R2_G_DECISION_BOUNDARY.json', gate)
log('G_DECISION_BOUNDARY', decision=decision, quarantine_reasons=q_reasons, failure_reasons=f_reasons)

# 6. R2-H01..H06, exactly once, ONLY if PROCEED_TO_H ---------------------------------------------
h_q_reasons, h_keys_left = [], []
if decision == 'PROCEED_TO_H':
    os.makedirs(os.path.join(WORK, 'H'))
    os.makedirs(KH, mode=0o700)
    h_rc = run('H', [PY, '-I', '-S', '-B', os.path.join(WORK, 'r2_external/R2_HOLDOUT_CHALLENGES.py'),
                     H_ROOT, os.path.join(WORK, 'candidate'), KH], H_TIMEOUT)
    h_q_reasons = (['QUARANTINE_MARKER:' + m for m in markers_under(os.path.join(WORK, 'H'))]
                   + ['QUARANTINE_TOKEN:' + t for t in token_in_runner_streams('H')])
    h_keys_left = scrub_keys('H', KH)
    rec['H'] = reconcile('H', H_ROOT, H_ATTEMPT)
    hsum, hper = read_h()
else:
    tag = 'NOT_LAUNCHED_AFTER_G_QUARANTINE' if decision == 'QUARANTINE_STOP_BEFORE_H' else 'NOT_LAUNCHED_AFTER_G_FAILURE'
    h_rc = rec['H'] = 'NOT_LAUNCHED'
    hsum = {'not_launched': tag, 'reason': 'G decision boundary ' + decision}
    hper = {rid: tag for rid in H_IDS}
    write_json('R2_H_NOT_LAUNCHED.json', {'decision': decision, 'per_method': hper, 'h_directory_created': False,
                                          'h_key_directory_created': False, 'h_test_keys_generated': 0,
                                          'protocol_basis': 'signed R2 protocol sections 4 (STOP_AND_QUARANTINE) and 5 '
                                          '(retain genuine failed result, reconcile, archive and stop)', 'utc': utc()})
    log('H_NOT_LAUNCHED', reason=tag)
per.update(hper)

# 7. Post-run checks, summary and attempt manifest (no candidate process) ----------------------
src_ok = verify_locks('post_run')
quarantine = bool(q_reasons or h_q_reasons or not src_ok)
passed = (decision == 'PROCEED_TO_H' and len(per) == 20 and all(v == 'PASS' for v in per.values()) and g_rc == 0
          and h_rc == 0 and rec.get('G') == 0 and rec.get('H') == 0 and src_ok and not g_keys_left
          and not h_keys_left and not quarantine)
status = ('P0A3G_R2_STOP_AND_QUARANTINE' if quarantine else
          'R2_DEV_01_ALL_20_PASSED_EVIDENCE_RECONCILED_PENDING_CHECKPOINTS' if passed else
          'P0A3G_R2_REPLICATION_FAILED_EVIDENCE_PRESERVED')
summary = {'attempt': 'P0A3G_R2_DEV_01', 'status': status, 'g_decision_boundary': decision,
           'quarantine_reasons': q_reasons + h_q_reasons + ([] if src_ok else ['SOURCE_OR_EXTERNAL_LOCK_CHANGED']),
           'g_failure_reasons': f_reasons, 'per_method': per, 'methods_passed': sum(v == 'PASS' for v in per.values()),
           'methods_registered': 20, 'g_runner_exit': g_rc, 'h_runner_exit': h_rc, 'external_reconciliation_exit': rec,
           'source_unchanged_after_run': src_ok, 'runner_left_key_files': {'G': g_keys_left, 'H': h_keys_left},
           'quarantine': quarantine, 'g_summary': gsum, 'h_summary': hsum, 'release_sha': A['release-sha'],
           'retry_or_repair_performed': False}
write_json('R2_ATTEMPT_SUMMARY.json', summary)
log('END', status=status)
manifest = []
for base, dirs, fs in os.walk(WORK):
    dirs.sort()
    for fn in sorted(fs):
        p = os.path.join(base, fn)
        rel = os.path.relpath(p, WORK).replace(os.sep, '/')
        if rel == 'R2_ATTEMPT_FILE_MANIFEST.json' or os.path.islink(p) or not os.path.isfile(p):
            continue
        with open(p, 'rb') as f:
            b = f.read()
        manifest.append({'path': rel, 'bytes': len(b), 'sha256': sha(b)})
write_json('R2_ATTEMPT_FILE_MANIFEST.json', {'schema': 'p0a3g-r2-attempt-manifest-1', 'attempt': 'P0A3G_R2_DEV_01',
                                             'status': status, 'files': manifest})
print(json.dumps({k: summary[k] for k in ('status', 'g_decision_boundary', 'methods_passed', 'g_runner_exit',
                                          'h_runner_exit', 'external_reconciliation_exit')}, default=str))
sys.exit(3 if quarantine else 0 if passed else 1)
