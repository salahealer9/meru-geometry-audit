# P0A3G-R2 — Complete pre-run chronology (through R2-C1-REV1)  ·  ZERO R2 candidate invocations

All times UTC, 2026-10-21. Historical P0A3G runs (four pre-lock full-catalogue dry runs, two smoke scripts and the post-lock `P0A3G_DEV_01`) are listed in `r2c0/R2_EXPOSURE_REGISTER.md`. None of them is an R2 trial.

## A. First lock candidate (R2-C1, received by the reviewer and NOT released)
| Time (approx.) | Event | R2 candidate invocation? |
|---|---|---|
| 14:44Z | Human instruction authorizes R2-P0 and R2-P1 only | — |
| 14:45–14:50Z | R2-P0 intake. Fresh clone at `4b488825…`. GPG, parent, blob and scope checks for R2, the corrigendum and the lineage. Both documents read. Preserved archives verified. The 51-file candidate extracted from signed G-CFINAL and cross-checked against G-C1. Detached historical G01 fixture at `adacfdbc…`. Host preflight (binary identity only). | No |
| 14:50–14:51Z | R2-C0 built (`e99811f3…bbb5`, 63,036 B), published to the R2 Lock Register artifact, freshly read back and verified byte-identical | No |
| 14:52–14:56Z | **Static** text review of candidate source files (file contents read only) | No |
| 14:54Z | H01–H04 request fixtures written as canonical JSON text, using only the standard library | No |
| 14:55–14:58Z | `r2_external/` sources written. One pre-lock wrapper edit dropped two fragile `q_squared` conditions. | No |
| 14:58Z | `ast.parse` (syntax only) of the three R2 sources under CPython 3.12.3 and 3.13.16 | No |
| 14:59Z | First external lock `a27aac41…89b6` frozen; R2-C1 assembled | No |
| 15:00–15:01Z | R2-C1 `740da6990834846a579cc07dccdafcab23f147c5f00117c25505a1cbce847589` (175,429 B) published, freshly read back and verified byte-identical. Receipts written and delivered. STOP. | No |
| before 15:16Z | Independent pre-witness review (external research chat). Disposition: `R2_C1_LOCK_RECEIVED_AND_VERIFIED_NOT_RELEASED`, blocking finding **`R2_C1_W01`**: the driver launched H unconditionally after G, even after a G quarantine. | — (reviewer did not execute anything) |

## B. Revision REV1 (correction of R2_C1_W01 only)
| Time (approx.) | Event | R2 candidate invocation? |
|---|---|---|
| 15:16Z | Human instruction: R2-P1 only. Preserve the rejected lock, correct the external driver, and produce a new, separately identified lock candidate. | — |
| 15:17Z | Rejected R2-C1 ZIP, its base64 copy, both receipts, the review and the locked source tree copied to `history/R2-C1_REJECTED_740da699/` (made read-only); preserved tree verified equal to the ZIP payload | No |
| 15:18–15:19Z | **Static** reading of `g_checks.py` (quarantine marker, exit logic, key destruction), `authority_fixtures.TestKey`, the H wrapper summary block, the supervisor worker command (`-I -S -B`) and the external reconciler CLI | No |
| 15:19Z | `r2_external/R2_DRIVER.py` rewritten from line 183 onward: fail-closed G decision boundary, H launched only on `PROCEED_TO_H`, typed quarantine versus failure, no-candidate post-run records and manifest. Docstring updated. H and H-key directories are no longer pre-created. The pre-candidate section is otherwise unchanged (diff in `review/R2_C1_W01_DRIVER_CORRECTION.diff`). | No |
| 15:19:58Z | `ast.parse` (syntax only, not executed, nothing imported) of the REV1 driver under CPython 3.12.3 and 3.13.16; import lines checked to be standard-library only | No |
| 15:20–15:22Z | REV1 external lock `2c8301fd…377b` frozen (only `R2_DRIVER.py` changed). `R2_TEST_CATALOGUE_LOCK.md` §2, §5, §7 and §8 revised ("run regardless of the G outcome" removed); §3–§4 checked byte-identical. Schema/status document, README and this chronology updated. `review/` populated. | No |
| 15:22Z → | R2-C1-REV1 assembled (identity in the separate `R2-C1-REV1_LOCK_RECEIPT.md`) | No |

**Totals before external witness of R2-C1-REV1:** R2 candidate imports 0; tests 0 (G01–G14: 0, H01–H06: 0); dry runs 0, including no mock run of the driver; smoke checks 0; parser requests 0; geometry previews 0; signature-verification checks 0; worker launches 0; test keys generated 0. **R2-P2 and R2-P3 have NOT begun.**

Durable storage route: private claude.ai artifact "P0A3G-R2 Lock Register" (https://claude.ai/artifact/PDchuKxE1d7t6y5Lsb3ZQC). Files are stored as base64 text copies because artifacts do not serve `.zip`. The rejected R2-C1 copy stays at its original path; REV1 is added under its own name. Readback procedure: read the artifact into a new empty directory → `base64 -d` → `r2_tools/zipcheck.py <zip> <sha> <bytes>` → `cmp` with the original.
