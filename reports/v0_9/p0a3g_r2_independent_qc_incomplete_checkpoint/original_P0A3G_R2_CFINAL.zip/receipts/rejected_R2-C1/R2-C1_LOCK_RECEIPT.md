# P0A3G-R2 — R2-C1 LOCK RECEIPT (for independent witness)

**Status:** `P0A3G_R2_C1_PREEXECUTION_LOCK_SUBMITTED_FOR_EXTERNAL_WITNESS`. R2-P2 and R2-P3 have **not** begun. This is unsigned engineering evidence, not a DEV result and not QC. Generated 2026-10-21T15:01Z.

## Archive identity
| Item | Value |
|---|---|
| File | `P0A3G_R2-C1.zip` |
| Bytes | **175,429** |
| SHA-256 | **`740da6990834846a579cc07dccdafcab23f147c5f00117c25505a1cbce847589`** |
| Members | 80 (79 covered by `SHA256SUMS` with the self-hash exception; 78 in `PACKAGE_INVENTORY.json`) |
| Durable copy | private artifact "P0A3G-R2 Lock Register", https://claude.ai/artifact/PDchuKxE1d7t6y5Lsb3ZQC, version `1792594852-40d5`, path `checkpoints/P0A3G_R2-C1.zip.b64.txt` (base64, 236,986 bytes, SHA-256 `2373d0df2c79a6a33c2a6943d10d361791023a4323eeb1a317f45c3a72cfbed2`) |

**Fresh readback proof.** I read the artifact into a new, empty directory and decoded it with `base64 -d`. The decoded file has SHA-256 `740da699…7589` and is 175,429 bytes. `zipcheck` passed: CRC, safe paths, every SHA256SUMS line and every inventory line. `cmp` against the original reported the files byte-identical.

From the readback bytes I also confirmed the following:
- All 51 candidate files match `SOURCE_LOCK.json`.
- All 7 `r2_external/` files match `R2_EXTERNAL_LOCK.json`.
- The kernel pins and the runner pins match.
- The candidate tree equals the candidate in the signed `original_P0A3G_G-CFINAL.zip`.
- The H04 fixture B is `[(0,0),(-3,0),(-3,1)]`.

R2-C0 was re-verified from the same artifact version: `e99811f3eefd90a49726e9ea37d8eae8b739829cc90bc825f3dec489d731bbb5`, 63,036 bytes, PASS.

## Locked contents
| Object | SHA-256 |
|---|---|
| `lock/SOURCE_LOCK.json` (51 files, 238,780 B; byte copy of signed G-C1 lock) | `abff7aa8df19f73e070d9f06ebd23334f8d98b45c1736d38399b845c69835902` |
| `lock/R2_EXTERNAL_LOCK.json` (7 files) | `a27aac4184cf5c115b9162966d6eea06f2ee39eb9f6a361f806dc302f34a89b6` |
| `algebra.py` / `core.py` / `arithmetic.py` | `442065…6d2d` / `37701d…d420` / `72b3c3…f0ba` |
| `g_checks.py` / `authority_fixtures.py` / `resource_policy.json` | `16c8d6…cf92` / `6e2325…27f2` / `9b7221…4e09` |
| `R2_HOLDOUT_CHALLENGES.py` (H wrapper) | `dcb3faf56d0ce9f6f7c5c2212a09c98ff46a8cc11d54c2beb14fba538f6b983e` |
| `R2_DRIVER.py` | `6153e9ff203f3fdaaf015a549aca21bc95dc64472ad8ac71b4972848e377432a` |
| `r2_stream_reconcile.py` (external reconciler) | `ae18681edf5869fa84e3fcf0411292a6a47efc911a69a68bcc59b49c94430833` |
| Fixtures H01 / H02 / H03 / H04 | `0807f224…98fa` / `27eb835c…3977` / `6623fb58…c2b1` / `27dfd8d5…50e4` |
| Source of the 14 G expectations (signed G-C1) | `12ee70df605b4080a5b418f067204328a22b6df93a8edcf67ef02febd3ca7613` |

The G01 fixture is a detached checkout at HEAD `adacfdbc6efcca4922c8d087d029b67e9b0c5dc5`, tree `51f03026…`. It is clean, with a read-only worktree. The keyring holds only `D4EC014EEFCC90E619D2AA59A91239ABCF512130`.

Runtime: `/usr/bin/python3.12` 3.12.3, run as `-I -S -B` (`e50d468e…150f`), and `/usr/bin/openssl` (`b4f547c0…2503`). The 3.13 probe is `/usr/bin/python3.13` (`a35753cc…4446`).

Worker budgets: 8 s wall, 6 s CPU, 256 MiB memory, 2 MiB streams, NOFILE 32, concurrency 1, recursion 256, 16 MiB run disk, 64 KiB request. Runner timeout is 1,800 s; reconciler timeout is 600 s.

## The 20 locked expected outcomes (full text in `R2_TEST_CATALOGUE_LOCK.md`)
| ID | Expected outcome (summary) |
|---|---|
| G01 | HEAD `adacfdbc`, clean, VALIDSIG D4EC…; all pins equal; R1 37 events, exactly two declared mismatches (108→0) |
| G02 | SUCCESS, 4 events, all streams non-empty and MATCH, TEST_AUTHORITY verified, loaded code unverified |
| G03 | forged q / null path → `CERTIFICATE_REJECTED`, streams MATCH |
| G04 | three cases → `EVIDENCE_STREAM_MISMATCH` (108/`23bcfd67…` vs 0/`e3b0c442…`) |
| G05 | 7 truncate/alter/delete runs → `EVIDENCE_STREAM_MISMATCH`, no certificate/checkpoint |
| G06 | swap/duplicate/stale/wrong path/collision/orphan/foreign copy → mismatch; reuse → `CHECKPOINT_UNVERIFIED/NEW_DIRECTORY_REQUIRED` |
| G07 | checkpoint-write faults → mismatch; torn → `CHECKPOINT_UNVERIFIED`; archives PASS/FAIL/FAIL |
| G08 | exit/kill/partial/memory/recursion/timeout → INTERNAL_ERROR / UNKNOWN×2 / RESOURCE×2 / `CONTROLLER_WALL_TIMEOUT` |
| G09 | stale saved verdict → `FRESH_REFERENCE_RECOMPUTED` SUCCESS < 8 s |
| G10 | checker timeout on resume → `RESOURCE_INCOMPLETE`, no certificate |
| G11 | valid authority accepted only in TEST_AUTHORITY; 14 negatives rejected by both signature routes |
| G12 | missing or invalid authority variants rejected; DEV_UNSIGNED distinct |
| G13 | 13 parser negatives and the checker mutations rejected; equivalent-zero positive control SUCCESS |
| G14 | R, Z, T, N SUCCESS; T whole-roll tie; N unique proper rotation with s > 0 |
| H01 | translated proper turn → `EXACT_UNIQUE_PROPER_ROTATION`, `q == []`, s = +1, 1−s = 0 |
| H02 | zero-edge subdivision → H01 checks plus B zero edge at index 0 |
| H03 | all-roll tie → `EXACT_WHOLE_ROLL_TIE`, s = 0, identity rotation |
| H04 | **corrigendum** B (−3,1) → unique proper rotation, `q != []`, s = +1, 1−s = +1; three forged certificates `CERTIFICATE_REJECTED` |
| H05 | single-byte, same-length stdout tamper → mismatch from all three reconcilers, never MATCH |
| H06 | one-byte `protocol_commit` scope tamper → rejected by OpenSSL, pure-Python and controller routes; original accepted |

**Decision rule:**
- `R2_DEV_01_ALL_20_PASSED_EVIDENCE_RECONCILED_PENDING_CHECKPOINTS` only if all 20 pass, there is no UNEXPLAINED reconciliation row, the locks are unchanged and no keys remain.
- Any STOP marker gives `P0A3G_R2_STOP_AND_QUARANTINE`.
- Anything else gives `P0A3G_R2_REPLICATION_FAILED_EVIDENCE_PRESERVED`.

## Attestation and disclosures
**ZERO R2 candidate imports, tests, geometry previews, parser requests, signed-fixture checks or worker launches BEFORE LOCK WITNESS.** No test keys have been generated. No Git writes were made.

Disclosed non-executing activity:
- Static reading of the candidate source text.
- `ast.parse` (syntax only) of the three new R2 sources.
- One pre-lock wrapper edit, which removed two fragile `q_squared` conditions.
- Agent-side hashing and ZIP tools that never import candidate code.
- The same agent's historical P0A3G exposure, recorded in R2-C0 `R2_EXPOSURE_REGISTER.md`: four pre-lock dry runs, two smoke scripts and `P0A3G_DEV_01`. All earlier negative findings are preserved.

**Release format required before any execution:**
`R2-C1 LOCK WITNESSED; SHA-256 740da6990834846a579cc07dccdafcab23f147c5f00117c25505a1cbce847589; AUTHORIZE ONE P0A3G_R2_DEV_01`
(the hash must come from the reviewer's own verification).
