# P0A3G-R2 — R2-C1-REV1 LOCK RECEIPT (corrected lock candidate, for independent witness)

**Status:** `P0A3G_R2_C1_PREEXECUTION_LOCK_SUBMITTED_FOR_EXTERNAL_WITNESS` for **R2-C1-REV1**. R2-P2 and R2-P3 have **not** begun, and no execution authorization exists. This is unsigned engineering evidence, not a DEV result and not QC. Generated 2026-10-21T15:23Z.

## Archive identity
| Item | Value |
|---|---|
| File | `P0A3G_R2-C1-REV1.zip` |
| Bytes | **197,250** |
| SHA-256 | **`b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1`** |
| Members | 85 (84 covered by `SHA256SUMS`, which does not list itself; 83 in `PACKAGE_INVENTORY.json`) |
| Durable copy | Private artifact "P0A3G-R2 Lock Register", version `1792596186-5554`, path `checkpoints/P0A3G_R2-C1-REV1.zip.b64.txt` (base64, 266,461 B, SHA-256 `febb681c8ff1788d3272e5b2fac2d3ee9142c4990951abaddf1d3bd8f9f885da`) |

**Fresh readback proof.** I retrieved all three stored copies from that version into a directory that did not exist before.
- The REV1 copy decoded to SHA-256 `b34a3cd2…09b1` (197,250 bytes). `zipcheck` passed: CRC, safe paths, 84/84 checksums and 83/83 inventory entries. `cmp` against the built file: byte-identical.
- From the decoded bytes, the 51-file `SOURCE_LOCK.json` (`abff7aa8…5902`) verified, as did the 7-file REV1 external lock (`2c8301fd…377b`).
- The candidate is byte-identical to the signed G-CFINAL candidate. H04 fixture B is `[(0,0),(-3,0),(-3,1)]`.
- The **rejected R2-C1** copy (`740da699…7589`, 175,429 B) and **R2-C0** (`e99811f3…bbb5`, 63,036 B) were re-verified from the same version. Both PASS, and the rejected copy is still byte-identical to the preserved original.

## What changed relative to the rejected R2-C1 (finding `R2_C1_W01`)
| Object | Rejected R2-C1 | R2-C1-REV1 |
|---|---|---|
| `r2_external/R2_DRIVER.py` | `6153e9ff…432a`, 10,646 B: H launched unconditionally after G | **`be1ed8bcb8f04bb4b61a05d2dc108264083c332673867da8a8794735cdfc4624`**, 18,161 B: fail-closed G decision boundary |
| `lock/R2_EXTERNAL_LOCK.json` | `a27aac41…89b6` | **`2c8301fdfb8a313163713cacd3050a77a5a6a3d0b2f1b4f7d391791af967377b`** |
| `R2_TEST_CATALOGUE_LOCK.md` | "run regardless of the G outcome" | §2 boundary, §5 decision table, §7 limits, §8 negative-state packaging; §3–§4 byte-identical (`1ee860d4…e56b`) |
| Schema/status doc, README, chronology | — | Updated for the REV1 control flow and the history |
| `review/` (new) | — | The negative witness review, both rejected receipts, a rejected-lock identity record and the exact driver diff |
| 51-file candidate, kernels, `g_checks.py`, H wrapper, external reconciler, fixtures, budgets, signed documents, `r2c0/`, `r2_tools/` | — | **Unchanged** (verified byte-identical) |

**Corrected control flow** (catalogue §2 and §5):
1. **Pre-candidate checks.** The driver verifies the release, locks and environment. Any failure exits with code 2 and launches no candidate.
2. **G01–G14 run once.**
3. **G decision boundary.** It launches no candidate process. It is computed from files on disk, hashing and the independent reconciler, and recorded in `R2_G_DECISION_BOUNDARY.json`.
   - **`QUARANTINE_STOP_BEFORE_H`** if any of these is found:
     - a `STOP_AND_QUARANTINE.txt` under `G/`;
     - the token `STOP_AND_QUARANTINE` in the G runner streams;
     - a source or external lock change during G.
   - Otherwise **`FAILED_STOP_BEFORE_H`** if any of these holds:
     - the G exit code is not 0, including a driver timeout;
     - the G external reconciliation exits non-zero or cannot run;
     - the G summary is missing or not passed;
     - any G method is not PASS;
     - the G runner left key files.
   - Otherwise **`PROCEED_TO_H`**.
4. **H01–H06 run once, only on `PROCEED_TO_H`.** On either STOP, no `H/` directory, no H key directory and no H test key are created. `R2_H_NOT_LAUNCHED.json` records `NOT_LAUNCHED_AFTER_G_QUARANTINE` or `NOT_LAUNCHED_AFTER_G_FAILURE`.
5. **Always, with no candidate process:** lock re-check, `R2_ATTEMPT_SUMMARY.json` and `R2_ATTEMPT_FILE_MANIFEST.json`. R2-C2 is then packaged from the preserved directory without any further candidate run.

| Exit code | Status |
|---|---|
| 0 | Pass |
| 1 | `P0A3G_R2_REPLICATION_FAILED_EVIDENCE_PRESERVED` |
| 3 | `P0A3G_R2_STOP_AND_QUARANTINE` |

No retry or repair is possible in any branch.

**Expected outcomes:** the 20 locked expectations (R2-G01…G14 verbatim from signed G-C1; R2-H01…H06, with H04 per the corrigendum) are unchanged. They are listed in the rejected lock receipt (`review/REJECTED_R2-C1_LOCK_RECEIPT.md`) and in catalogue §3–§4.

**Runtime and budgets:** unchanged. `/usr/bin/python3.12` 3.12.3 `-I -S -B` (`e50d468e…150f`), `/usr/bin/openssl` (`b4f547c0…2503`), and the 3.13 probe (`a35753cc…4446`). Limits: 8 s wall, 6 s CPU, 256 MiB, 2 MiB streams, NOFILE 32, concurrency 1, recursion 256, 16 MiB disk, 64 KiB request. The G01 fixture is still the detached checkout at `adacfdbc…`, tree `51f03026…`, clean and read-only.

## Attestation and disclosures
**ZERO R2 candidate imports, tests, geometry previews, parser requests, signed-fixture checks or worker launches BEFORE LOCK WITNESS.** In addition:
- No test keys have been generated.
- The REV1 driver was never executed: no mock run and no dry run.
- No Git writes were made.

Disclosed non-executing activity for REV1:
- Static reading of `g_checks.py`, `authority_fixtures.py`, the H wrapper, the supervisor worker command and the external reconciler.
- `ast.parse` of the REV1 driver (syntax only) under 3.12.3 and 3.13.16.
- Agent-side hashing, ZIP and diff tools.

The R2-C1 disclosures and the same agent's historical P0A3G exposure carry over unchanged (see `r2c0/R2_EXPOSURE_REGISTER.md` and the chronology). The rejected R2-C1, its receipts and the negative review are preserved unchanged.

**Release format required before any execution** (the hash must come from the reviewer's own verification of REV1; a release quoting `740da699…7589` is invalid):
`R2-C1 LOCK WITNESSED; SHA-256 b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1; AUTHORIZE ONE P0A3G_R2_DEV_01`
