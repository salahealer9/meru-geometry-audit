# P0A3G-R2: Independent R2-C1 pre-execution lock witness review

**Date:** 2026-10-21
**Independent reviewer:** ChatGPT research chat (not the executing Claude agent)
**Disposition:** `R2_C1_LOCK_RECEIVED_AND_VERIFIED_NOT_RELEASED` — revision required before external lock witness / test release.
**NO R2 candidate code, original G suite, or new H challenges were imported or executed by this reviewer.** Static AST parse only for the three newly authored external Python scripts.

## 1. Authenticated preregistration

- Original signed R2 commit `7de01ab2c90afe52dd763652a9eaffd2e9a2cff9`, Git blob `01cbd34f9000c50eb6810dcfd8d4dd27b6312992`.
- Signed additive H04 corrigendum / Git branch HEAD `4b488825ed35c7ac91a19abe62be068e75e9a076`; correct direct parent `7de01ab2c90afe52dd763652a9eaffd2e9a2cff9`; corrigendum Git blob `780fc70a11081fda4fa2aedc56bb2cab84e7fa3c`; GitHub scope exactly one added Markdown file.
- Signer fingerprint `D4EC014EEFCC90E619D2AA59A91239ABCF512130` from the user's locally verified VALIDSIG. Do not equate this connector metadata to independent personal ownertrust.

## 2. Independent byte-level review (PASS)

| Archive | Actual bytes | SHA-256 | Entries; manifest; inventory | Result |
|---|---:|---|---|---|
| R2-C0 | 63,036 | `e99811f3eefd90a49726e9ea37d8eae8b739829cc90bc825f3dec489d731bbb5` | 25; 24; 23 | PASS |
| R2-C1 | 175,429 | `740da6990834846a579cc07dccdafcab23f147c5f00117c25505a1cbce847589` | 80; 79; 78 | PASS |

Both archives: ZIP CRC PASS, SHA256SUMS for all non-self entries PASS, inventory entries with size/hash PASS, no duplicate/unsafe ZIP paths or symlinks. Full independent comparison of all 51 candidate files with the *actual separately retained* original P0A3G G-C1 **and** G-CFINAL ZIPs: byte-identical. Original full G01–G14 prospectively declared catalogue in C1 byte-identical to original G-C1 source. Original `SOURCE_LOCK.json` matches byte-for-byte and describes exactly 51 entries; external lock describes exactly seven files, all correct by independent recomputation. Frozen P0A3D mathematical kernels and `g_checks.py` match their exact pinned SHA-256. The new three R2 scripts are syntactically valid by static AST parse (not execution). All four H01–H04 request fixtures contain the exact signed vertices; H04 ends at (-3,+1), as corrected. Both signed protocol texts are byte-identical to the authenticated documents retained by the reviewer.

The agent declares zero R2 candidate invocations and disclosed all historical P0A3G tests and prior pre-lock edits. This reviewer can check the locked chronology and absence of test outputs inside the package, but **cannot independently prove a negative assertion about every activity in the agent's external workspace**. That limitation remains explicit.

## 3. Blocking finding — pre-execution driver fails to stop after a G-group quarantine

**Finding `R2_C1_W01`; severity: BLOCKING for lock release.**

- `r2_external/R2_DRIVER.py`, lines 163–167: launches the frozen G01–G14 runner and **unconditionally launches the H01–H06 runner** after the G process returns. No check of G runner exit status or `G/P0A3G_R2_DEV_01/STOP_AND_QUARANTINE.txt` occurs between these two candidate invocations.
- Lines 196–202 first inspect the quarantine markers **after both groups have been run**. The locked `R2_TEST_CATALOGUE_LOCK.md`, section 2, explicitly describes the H group as `run regardless of the G outcome`.
- The *signed* R2 protocol section 4 requires **STOP_AND_QUARANTINE** upon any accepted forged exact certificate, trust bypass, mathematical contradiction, or frozen-kernel failure. Section 5 forbids continuing with test execution after a mandatory integrity/authority disaster and requires preservation of the first attempt's actual evidence. The pre-release driver therefore cannot currently honor the mandatory critical stop boundary when the G suite flags a forbidden acceptance.
- This is a **static prospective control-flow finding**. It is **not evidence of an actual forged-certificate acceptance**, not proof the G suite will fail, and not a pre-release DEV result. It is discovered before the externally witnessed lock and can be corrected prospectively without modifying the 51-file candidate.

**Required disposition:** NO `R2-C1 LOCK WITNESSED` release for this SHA. No R2-P2 test invocation.

## 4. Narrow corrective path (no new scientific preregistration needed if within existing R2 protocol)

1. Preserve the first R2-C1 ZIP, SHA, its receipt, and this negative pre-witness review as distinct immutable prospective lock-review evidence.
2. In the **external** R2 driver only, insert a fail-closed decision boundary **after G completes and before H begins**. A G `STOP_AND_QUARANTINE.txt` or equivalent explicit critical trust/theorem/certificate stop must **prevent any H candidate invocation**. Preserve G stdout/stderr, returncode, original raw evidence and typed quarantine status. An ordinary G failure must not be retried; prefer stop/preserve for any nonzero G runner status, distinguishing ordinary failure from quarantine.
3. Adjust the **external** `R2_TEST_CATALOGUE_LOCK.md` execution order/negative-state handling and relevant receipt docs to match the corrected stop logic. The unconditional phrase `run regardless of the G outcome` must be removed/replaced. Reconcile any existing streams in a quarantine state **without launching another candidate**, and prepare the R2-C2/R2-CFINAL negative evidence packaging correctly.
4. Produce a **new separately identified R2-C1 lock candidate** with a new SHA-256, fresh full ZIP manifest/inventory, new external source lock, and a completely updated pre-execution chronology. Keep the candidate 51-file baseline **byte-identical** and preserve all original mathematical, case, budget and fixture definitions. No G/H test, candidate import, parser request, dry run, worker or test key before the new independent witness.
5. Durably publish and independently re-read/verify this new lock, then send it to the human to return to this independent research chat. A revised lock is **not allowed to overwrite or conceal this original rejected lock**. A new signed protocol is necessary only if changes to the scientific scope, 51-file candidate or signed constraints prove necessary.

**Review status:** No lock release has been issued. R2-P2 and R2-P3 must remain not begun.
