# P0A3G_R2_DEV_01 — observed outcomes against the locked expectations (agent summary; not QC)

Source of each verdict: for G, the unchanged runner's own unittest verdict (`G/P0A3G_R2_DEV_01/evidence.json`, observation `attempt_summary`); for H, `H/P0A3G_R2_DEV_01_H/H_evidence.json`. Both are inside `checkpoints/P0A3G_R2-C2.zip` under `attempt/P0A3G_R2_DEV_01/`. Locked expectations are in `R2_TEST_CATALOGUE_LOCK.md` §3–§4. The "Selected observation" column is an excerpt only; independent QC should judge the raw evidence.

| ID | Verdict | Selected observation (evidence location) |
|---|---|---|
| R2-G01 | PASS | Signed sources, 7 archive pins and frozen kernels equal; R1 recount reproduces the declared 108→0 mismatches (`evidence.json` G01) |
| R2-G02 | PASS | 4 events, all streams non-empty, reference reconciler 8/8 MATCH, `NON_PRODUCTION_TEST_AUTHORITY_VERIFIED` (G02, G02_result) |
| R2-G03 | PASS | `G03_forged_q` and `G03_null_path_record`: `CERTIFICATE_REJECTED`, streams MATCH; forged-q stdout 108 B `23bcfd67…` (G03) |
| R2-G04 | PASS | a/b/c `EVIDENCE_STREAM_MISMATCH`; recorded 108/`23bcfd67…` against saved 0/`e3b0c442…` (G04) |
| R2-G05 | PASS | 7 truncate/alter/delete runs → `EVIDENCE_STREAM_MISMATCH` (G05) |
| R2-G06 | PASS | swap/duplicate/stale/wrong-worker/collision/orphan/foreign copy → mismatch; reuse → `CHECKPOINT_UNVERIFIED` (G06) |
| R2-G07 | PASS | before_rename/short_write/after_rename_tamper → mismatch; checkpoint-fault and torn-resume cases; archives PASS/FAIL/FAIL (G07) |
| R2-G08 | PASS | exit 17 → `INTERNAL_ERROR_NO_CERTIFICATE`; signal −9 → `UNKNOWN_TERMINATION`; memory/recursion → `RESOURCE_INCOMPLETE`; timeout → `CONTROLLER_WALL_TIMEOUT` (G08) |
| R2-G09 | PASS | Stale saved verdict ignored; fresh reference recomputation SUCCESS within 8 s (G09) |
| R2-G10 | PASS | Genuine checker timeout → `RESOURCE_INCOMPLETE/CONTROLLER_WALL_TIMEOUT` (G10) |
| R2-G11 | PASS | Valid test authority accepted by both routes; negatives rejected; wrong-key end-to-end → `CODE_IDENTITY_MISMATCH` before any worker (G11) |
| R2-G12 | PASS | Missing/unsigned/promoted/DEPLOYMENT/3.13/mutated cases rejected; `LOADED_CODE_IDENTITY_UNVERIFIED` disclosed (G12) |
| R2-G13 | PASS | Parser and rational negatives `INVALID_INPUT`/`REJECTED` on both routes; checker mutations rejected; positive control SUCCESS (G13) |
| R2-G14 | PASS | R, Z, T, N SUCCESS (certificate SHA-256s recorded); kernels equal their pins (G14) |
| R2-H01 | PASS (13/13 checks) | `EXACT_UNIQUE_PROPER_ROTATION`, `q = []`, `s = 1`, rotation J; streams MATCH |
| R2-H02 | PASS (15/15) | As H01, plus B zero edge at index 0 and none in A |
| R2-H03 | PASS (14/14) | `EXACT_WHOLE_ROLL_TIE`, `s = []`, identity rotation, both variances +1 |
| R2-H04 | PASS (14/14) | Corrigendum B `(-3,1)`: `EXACT_UNIQUE_PROPER_ROTATION`, `alpha = -88/101`, `beta = 27/101`, `q ≠ []`, signs s +1 / 1−s +1 / residual 0; negatives zero-score, reflection-as-rotation and q=1 all `CERTIFICATE_REJECTED`, no score, streams MATCH |
| R2-H05 | PASS (13/13) | Same-length single-byte stdout tamper: external, reference and production reconcilers flag the mismatch; pristine copy MATCH |
| R2-H06 | PASS (13/13) | One-character `protocol_commit` tamper rejected by OpenSSL, pure-Python Ed25519, full verifiers, controller (`CODE_IDENTITY_MISMATCH`, no worker) and reference worker; original accepted |

**Attempt-level:**
- G decision boundary: `PROCEED_TO_H`.
- Runner exit codes: G 0, H 0.
- External reconciliation, G: 111 events, 222 rows, 0 unexplained.
- External reconciliation, H: 28 events, 56/56 MATCH.
- The same reconciler gave identical results when re-run on the freshly read-back R2-C2.
- Source and external locks were unchanged after the run, and no key files remained.
- There were no retries, repairs or reruns.

Driver status: `R2_DEV_01_ALL_20_PASSED_EVIDENCE_RECONCILED_PENDING_CHECKPOINTS`.
