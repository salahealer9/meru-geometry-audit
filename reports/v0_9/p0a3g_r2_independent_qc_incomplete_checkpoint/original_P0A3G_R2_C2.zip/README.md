# P0A3G-R2 — R2-C2: first-attempt evidence for P0A3G_R2_DEV_01

**Driver status:** `R2_DEV_01_ALL_20_PASSED_EVIDENCE_RECONCILED_PENDING_CHECKPOINTS`. This is engineering evidence submitted for independent QC. It is not an approved software qualification and not a self-certification.

The attempt ran under the release of R2-C1-REV1 (`b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1`), the signed R2 protocol `7de01ab2…` and the H04 corrigendum `4b488825…`.

| Path | Content |
|---|---|
| `attempt/P0A3G_R2_DEV_01/` | The complete attempt directory as written by the driver, byte-identical. The two controller key directories are omitted because they were empty. |
| ↳ `R2_DEV_JOURNAL.json`, `R2_ATTEMPT_SUMMARY.json`, `R2_G_DECISION_BOUNDARY.json`, `R2_ATTEMPT_FILE_MANIFEST.json` | Driver journal, summary, G decision boundary (`PROCEED_TO_H`) and the manifest of every file |
| ↳ `G_runner.*`, `H_runner.*`, `RECONCILE_{G,H}_runner.*` | Runner stdout, stderr and exit code |
| ↳ `G/P0A3G_R2_DEV_01/` | G evidence: `evidence.json`, `controller/` (registered faults, trust store, public test keys), `raw_workers/` (111 worker events, 222 stream files), the reference reconciliation CSV and JSON |
| ↳ `H/P0A3G_R2_DEV_01_H/` | H evidence: `H_evidence.json`, `controller/`, `raw_workers/` (28 events, 56 streams), `h05_copies/` (pristine and tampered) |
| ↳ `R2_EXTERNAL_RECONCILIATION_{G,H}.{csv,json}` | Independent external reconciler output |
| ↳ `candidate/`, `r2_external/` | The exact bytes executed (re-checked against both locks before and after the run) |
| `release/` | Verbatim release record, driver console streams, exit code, start and end timestamps, and the post-release REV1 retrieval check |
| `R2_EXECUTION_CHRONOLOGY.md` | Exact execution chronology |
| `R2_C2_AGENT_CROSSCHECK.json` | Read-only agent checks (no candidate code). It explains why the reference reconciler lists 7 non-event rows and the external one lists 5 for the same five files, and shows that H04 recorded `alpha = -88/101`, `beta = 27/101` |

**Per method:** R2-G01…G14 PASS (14/14), R2-H01…H06 PASS (6/6). Both runners exited 0. The external reconcilers reported G with 0 unexplained rows (199 MATCH, 21 declared injected faults, 2 registered harness faults, 5 declared orphan or pending files) and H with 56/56 MATCH. Source locks were unchanged and no key files remained.
