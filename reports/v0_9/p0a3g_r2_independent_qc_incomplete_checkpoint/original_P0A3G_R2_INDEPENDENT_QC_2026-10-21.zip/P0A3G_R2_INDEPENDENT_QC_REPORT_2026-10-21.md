# P0A3G-R2 — Independent QC of Prospectively Released Engineering Replication

**Date:** 2026-10-21 (UK). **Reviewer:** separate research chat, independent of executing Claude agent. **Review mode:** read-only inspection, independent archive/hash verification, original worker event-and-stream byte rehashing, frozen source comparison and independent cryptographic verification. **No candidate or registered method was executed by reviewer.**

**QC DISPOSITION:** `P0A3G_R2_INDEPENDENT_QC_NOT_FULLY_QUALIFIED` because **`P0A3G_R2_C2_PRIOR_RECEIPT_COMPLETENESS_NOT_QUALIFIED`**. This is one checkpoint-completeness breach, not evidence of mathematical theorem failure or a false accepted certificate. Substantial new engineering evidence is `P0A3G_R2_BOUNDENVELOPE_REPLICATION_EVIDENCE_SUPPORTED`; software readiness and registered Hebrew validation remain NOT AUTHORIZED.

## 1. Immutable signed authority and release

Repository `salahealer9/meru-geometry-audit`, branch `hebrew-projection-capacity-v0.9`. Signed original R2 preregistration `7de01ab2c90afe52dd763652a9eaffd2e9a2cff9`, Git blob `01cbd34f9000c50eb6810dcfd8d4dd27b6312992`. Signed exact-H04 corrigendum and branch HEAD at intake `4b488825ed35c7ac91a19abe62be068e75e9a076`, Git blob `780fc70a11081fda4fa2aedc56bb2cab84e7fa3c`, direct parent original R2. Expected human GPG fingerprint `D4EC014EEFCC90E619D2AA59A91239ABCF512130`; local signature verification and GitHub commit/blob/one-file lineage were independently checked in the preregistration handoff. GitHub's signature attestation and local GPG ownertrust are different claims.

P0A3D exact planar SO(2) theorem `59eb47f7500d57866e4935822b78a555d3bcb515` remains frozen; P0A3E preservation `8ed3b988f716229bc9aee97d41ded0f524371193`. Original R1 negative QC `d95c50ea96744ce266058c51f85fff320d1a27df`, original P0A3G protocol `adacfdbc6efcca4922c8d087d029b67e9b0c5dc5`, and signed P0A3G incomplete QC `0e86df64e30d081065bbeb75b6f53391e287f8f3` remain unchanged.

Earlier C1 `740da6990834846a579cc07dccdafcab23f147c5f00117c25505a1cbce847589` failed an independent pre-execution control-flow witness and was never released. R2-C1-REV1 `b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1` passed independent static lock review. The human relayed the exact SHA-specific `R2-C1 LOCK WITNESSED; SHA-256 ...; AUTHORIZE ONE P0A3G_R2_DEV_01` to the agent. The actual release text is retained in R2-C2 and R2-CFINAL. No signed amendment retrospectively changes any old failed finding.

## 2. Original delivered archive identities, independently checked

| Original uploaded archive | Bytes | SHA-256 | Members / checked sums / inventory |
|---|---:|---|---|
| R2-C0 | 63,036 | `e99811f3eefd90a49726e9ea37d8eae8b739829cc90bc825f3dec489d731bbb5` | 25 / 24 / 23 |
| R2-C1-REV1 | 197,250 | `b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1` | 85 / 84 / 83 |
| R2-C2 | 1,388,186 | `860d93dce952a73b65b097e3f7b4da420c0a327ee0ca8b6d4c213865db2d1cbb` | 1,283 / 1,282 / 1,281 |
| R2-CFINAL | 1,224,562 | `7c9770d15a3a578f61def2571813d84baadda34bfe3d31cfc1b5cdd722a51eb4` | 100 / 99 / 98 |
| Rejected original C1, retained nested in CFINAL | 175,429 | `740da6990834846a579cc07dccdafcab23f147c5f00117c25505a1cbce847589` | Historical, NOT RELEASED |

All four uploaded ZIPs pass CRC, uniqueness and safe-path checks, SHA256SUMS (every member except the sums file itself), and independent per-file `PACKAGE_INVENTORY.json` size and hash verification. The original C0, C1-REV1 and C2 uploaded files are **byte-identical** to the nested CFINAL copies. Rejected C1 nested digest/length also match the historical first lock. These checks establish artifact bytes at review time, not personal observation of the agent's internal cloud-artifact storage and retrieval chronology.

## 3. Independently checked frozen code and execution manifest

The original signed `P0A3G_G-CFINAL.zip` is 1,271,972 bytes, SHA-256 `8b0ec808ddea05d31422ad30308d3a5bbe8aaadb860cd613adf51bdcc9f33a6a`. Every one of the 51 candidate files in C1-REV1 is **byte-identical** to the original signed P0A3G G-CFINAL candidate. The same 51 files in executed C2 and delivered CFINAL are unchanged. `SOURCE_LOCK.json` SHA-256 `abff7aa8df19f73e070d9f06ebd23334f8d98b45c1736d38399b845c69835902`, with 51/51 valid source entries. All three exact theorem kernels remain unchanged.

The seven-file external lock, `R2_EXTERNAL_LOCK.json` SHA-256 `2c8301fdfb8a313163713cacd3050a77a5a6a3d0b2f1b4f7d391791af967377b`, verifies 7/7 entries in C1-REV1, executed C2 and CFINAL. Executed `R2_DRIVER.py` SHA-256 `be1ed8bcb8f04bb4b61a05d2dc108264083c332673867da8a8794735cdfc4624`; it enforces a recorded G decision boundary before H launch. Attempt `R2_ATTEMPT_FILE_MANIFEST.json` contains **1,270** entries: all 1,270 bytes/size/hash checks match, with **zero missing, altered or unlisted** attempt files (manifest itself exempt).

The retained attempt summary has 20 registered/20 passed, G and H exit 0, G-to-H decision `PROCEED_TO_H`, external reconciliation exits 0, no quarantine, no reported retry/repair. Chronology records one driver invocation 2026-10-21 15:35:48.607Z–15:36:46.267Z, with G then H; this is retained controller evidence, not an independent observation of the agent's private process history. The original four pre-lock P0A3G full-catalogue dry runs are separately declared historical exposure, not counted as R2.

## 4. Raw-worker stream reconciliation independently recomputed from the ZIP

Independent reviewer implementation enumerates each actual archived `.event.json`, reads the corresponding actual raw stdout/stderr ZIP member bytes afresh, recomputes lengths/SHA-256, compares event recorded versus captured and saved values, validates the separate externally reported row, checks worker/run/attempt IDs and cross-checks all non-matches to the original locked fault registry.

| Group | Events | Stream identities | Full byte AND identity MATCH | Registered mismatch records | Declared extra-file rows | Unexplained |
|---|---:|---:|---:|---:|---:|---:|
| G01–G14 | 111 | 222 | **199** | **23** (21 injected faults + 2 foreign-event harness records) | **5** | **0** |
| H01–H06 | 28 | 56 | **56** | **0** | **0** | **0** |

Of G's 222 streams, 203 saved bytes match the raw event recorded/captured size+digest. Four of those 203 nonetheless violate registered **attempt/run identity** (two stale-run stream records and two foreign-copy harness records), accounting for the stricter 199 true MATCH count. The other **19** stream records contain independently verified declared byte mismatches or deliberate removals; all 19 are registered. Five extra files are explicitly registered orphan/pending negative controls (3 ORPHAN + 2 PENDING). None is silently reported as a clean successful stream. No unexplained stream defect was found. This prospective evidence resolves the new engineering test condition **within the tested envelope**, not the historical missing R1 stdout bytes.

## 5. Exact geometry and external test-only trust

R2-H01 and H02 report exact `qO=0`, unique proper optimum; H03 reports true all-roll tie with canonical identity; H04 uses the **signed corrigendum** `B=[(0,0),(-3,0),(-3,1)]`. In the retained H04 certificate, `alpha=-88/101`, `beta=27/101`, and the q-squared tower encodes `2-2*sqrt(8473)/101`, which is strictly positive as `8473<10201`. All three H04 deliberately falsified certificates report `CERTIFICATE_REJECTED` without a score. This matches the independent exact-arclength fixture calculation in the preregistered corrigendum; no historical Hebrew target was used.

R2-H05 records exactly one modified byte in a same-length copied stdout and a mismatch from the independent and candidate reconcilers. R2-H06 retains an Ed25519 `NON_PRODUCTION_TEST_AUTHORITY` public key, signature, original envelope and one-byte scope-tampered envelope. Independently with the reviewer environment's `cryptography` Ed25519 verifier, the **original signature VALIDATES**, the **one-byte tampered envelope DOES NOT**, and the two messages are equal-length. No human production code authority, signature of a code-freeze or loaded-code attestation is implied.

## 6. Blocking signed-protocol completeness finding: C2 receipts

**Finding `R2_QCF01_C2_PRIOR_RECEIPTS_OMITTED` — mandatory checkpoint completeness NOT QUALIFIED.** The signed R2 protocol §5 requires R2-C2, immediately after its one authorized attempt, to include *"the untouched prior checkpoint receipts"*. The actual signed-intent original R2-C2 ZIP has **no** prior checkpoint receipt entries: no `R2-C0_RECEIPT.json`, `R2-C1-REV1_RECEIPT.json`, or `R2-C1-REV1_LOCK_RECEIPT.md`. The agent openly disclosed this omission, did **not** rebuild or overwrite C2, and CFINAL includes the intact copies under `receipts/`.

**Disposition:** Although the receipts exist in CFINAL and can be matched to their original archived identities, **CFINAL's later contents do not retroactively make the original C2 checkpoint comply** with the explicit contemporaneous C2 packaging rule. This is a procedural/preservation boundary deficiency, not an unexplained worker-stream discrepancy, false exact certificate or contradiction in the mathematical theorem. The original C2 must not be silently modified, rebuilt under the same name, or relabelled. Positive technical evidence and negative qualification must both be preserved.

## 7. Other declared limits (not additional newly discovered failures)

- Only generic rational 2D SO(2) test fixtures; no historic Hebrew inputs, no scientific specificity, no P0A4.
- One declared host and pinned CPython 3.12.3 / OpenSSL envelope, with wall/CPU/memory/output limits; reviewer did not run the candidate on the pinned agent binary.
- The same Claude agent authored the R2 wrappers and test tools; architectural independence of an external reconciler is not complete organizational independence. Test sources were independently locked/witnessed before execution.
- No human-signed code-only freeze, no real external production trust root, `LOADED_CODE_IDENTITY_UNVERIFIED`, no arbitrary-input correctness or hostile-OS, power-loss, multiwriter or controller-death guarantees.
- Historical R1 signed evidence failures and original P0A3G pre-lock violation remain immutable. The agent's report of no hidden pre-lock candidate run cannot be independently proven from supplied private-environment records.

## 8. QC decision and safe next steps

- **Engineering-method evidence:** positive within the registered 20-test declared host/test-only authority envelope; exact source immutable; raw-stream reconciliation clean of unexplained defects.
- **Mandatory R2 checkpoint packaging compliance:** `NOT_QUALIFIED` because the already published C2 lacks the prior receipt copies required at C2 time.
- **Overall independent R2 QC:** `P0A3G_R2_INDEPENDENT_QC_NOT_FULLY_QUALIFIED` (technical support preserved with explicitly blocking archival-completeness deviation).
- **Software readiness/production external trust/loaded-code:** `NOT_AUTHORIZED`.
- **Registered P0A4:** `NOT RUN; NOT AUTHORIZED`.

A human may GPG-sign an **additive, accurate incomplete preservation** containing the exact original R2 archives, this QC package and checksum manifest, under the current verified Git branch head, without editing source or earlier evidence. A later administrative supplement can cross-reference receipts without rewriting C2, but it cannot make C2 historically contain bytes that were not there. Any further claim of strict full prospective-protocol compliance needs its own human-approved prospective procedure; no rerun/repair under the completed one-attempt R2 permission.

**Report authored after independent review of actual original archives. Scripts/data in companion independent QC ZIP enable byte-level reproductions; do not execute the candidate.**
