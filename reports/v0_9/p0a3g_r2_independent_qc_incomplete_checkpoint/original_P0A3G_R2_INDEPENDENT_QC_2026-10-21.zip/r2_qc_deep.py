#!/usr/bin/env python3
"""Independent read-only P0A3G-R2 QC, no candidate execution or imports."""
import hashlib,zipfile,json,collections,io,os
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
p=Path('/mnt/data'); c2=zipfile.ZipFile(p/'P0A3G_R2-C2.zip'); c1=zipfile.ZipFile(p/'P0A3G_R2-C1-REV1(1).zip');cf=zipfile.ZipFile(p/'P0A3G_R2-CFINAL.zip');old=zipfile.ZipFile(p/'P0A3G_G-CFINAL.zip')
sha=lambda b:hashlib.sha256(b).hexdigest()
report={}
# actual 51 files in G baseline by paths and SHA
names=[n for n in c1.namelist() if n.startswith('candidate/')]
report['frozen_baseline']={'candidate_files':len(names),'against_original_signed_P0A3G_G_CFINAL':all(n in old.namelist() and old.read(n)==c1.read(n) for n in names),'changed':[]}
for n in names:
 if old.read(n)!=c1.read(n):report['frozen_baseline']['changed'].append(n)
source=json.loads(c1.read('lock/SOURCE_LOCK.json'))['files']
external=json.loads(c1.read('lock/R2_EXTERNAL_LOCK.json'))['files']
report['source_lock']={'declared_files':len(source),'mismatches':[]}
for rel,meta in source.items():
 n='candidate/'+rel
 if n not in c1.namelist() or len(c1.read(n))!=meta['bytes'] or sha(c1.read(n))!=meta['sha256']:report['source_lock']['mismatches'].append(rel)
report['external_lock']={'declared_files':len(external),'mismatches':[]}
for rel,meta in external.items():
 n='r2_external/'+rel
 if n not in c1.namelist() or len(c1.read(n))!=meta['bytes'] or sha(c1.read(n))!=meta['sha256']:report['external_lock']['mismatches'].append(rel)
base='attempt/P0A3G_R2_DEV_01/'
report['manifest']={'files':0,'changed':[],'unlisted':[]}
m=json.loads(c2.read(base+'R2_ATTEMPT_FILE_MANIFEST.json'));decl=set()
for row in m['files']:
 rel=base+row['path'];decl.add(rel)
 if rel not in c2.namelist() or len(c2.read(rel))!=row['bytes'] or sha(c2.read(rel))!=row['sha256']:report['manifest']['changed'].append(rel)
report['manifest']['files']=len(decl)
report['manifest']['unlisted']=sorted(set(x for x in c2.namelist() if x.startswith(base)) - {base+'R2_ATTEMPT_FILE_MANIFEST.json'} -decl)
# direct stream comparison and register validation
for grp in 'GH':
 root=base+grp+('/P0A3G_R2_DEV_01_H/' if grp=='H' else '/P0A3G_R2_DEV_01/')+'raw_workers/'
 ext=json.loads(c2.read(base+f'R2_EXTERNAL_RECONCILIATION_{grp}.json'))
 registry=ext['summary']['registry']; recrows=ext['rows']; expected_id=ext['summary']['expected_attempt_id']
 lookup=collections.defaultdict(list)
 for row in recrows:
  if row['event_file']!='-':lookup[(row['run_dir'],row['event_file'],row['stream'])].append(row)
 events=sorted(x for x in c2.namelist() if x.startswith(root) and x.endswith('.event.json'))
 counters=collections.Counter(); issues=[]; faults=[]; rawbytes=0
 for ep in events:
  d=json.loads(c2.read(ep));run=ep[len(root):].split('/')[0];ename=ep.split('/')[-1]
  worker=ename.split('.')[0]
  if d['worker_id']!=worker:issues.append(('worker_name',run,ename))
  declared=registry.get(run)
  for s in ('stdout','stderr'):
   m=d[s];spath=ep.rsplit('/',1)[0]+'/'+m['path'];bytes_=c2.read(spath) if spath in c2.namelist() else None
   actual=(len(bytes_),sha(bytes_)) if bytes_ is not None else None
   claimed=(m['bytes'],m['sha256']);captured=(m['capture_bytes'],m['capture_sha256'])
   rows=lookup[(run,ename,s)]
   if len(rows)!=1:issues.append(('rowcount',run,ename,s,len(rows)));continue
   row=rows[0];status=row['status']
   if (row['recorded_bytes'],row['recorded_sha256'])!=claimed or (row['capture_bytes'],row['capture_sha256'])!=captured or (row['saved_bytes'],row['saved_sha256'])!=(actual if actual else (None,None)):
    issues.append(('reported_raw_mismatch',run,ename,s))
   if d['attempt_id']!=expected_id or d['run_dir_id']!=run:
    if status!='EVIDENCE_STREAM_MISMATCH' or not declared:issues.append(('unexpected_identity',run,ename,s,status))
   if actual==claimed==captured and d['attempt_id']==expected_id and d['run_dir_id']==run:
    if status!='MATCH':issues.append(('should_match',run,ename,s,status))
    counters['MATCH']+=1
   else:
    counters['FAULT_STREAM_OR_IDENTITY']+=1;faults.append((run,ename,s,status,d.get('evidence_fault')))
    if status!='EVIDENCE_STREAM_MISMATCH' or not declared:issues.append(('undeclared_fault',run,ename,s,status,declared))
   rawbytes+=len(bytes_) if bytes_ is not None else 0
 # extra `-` file rows must all be declared, refer to existing saved paths via independent reconciler
 extras=[r for r in recrows if r['event_file']=='-']
 for row in extras:
  if not registry.get(row['run_dir']) or row['status'] not in ['ORPHAN_STREAM_FILE','PENDING_WRITE_FILE']:
   issues.append(('undeclared_extra_file',row['run_dir'],row['status']))
 counters['DECLARED_EXTRA_FILES']=len(extras)
 counters['TOTAL_EVENT_STREAMS']=len(events)*2
 counters['EVENTS']=len(events)
 report['streams_'+grp]={'counts':dict(counters),'external_claims':ext['summary']['counts'],'unexplained_agent':ext['summary']['unexplained'],'independent_issues':issues,'raw_saved_bytes_processed':rawbytes,'faults':faults}
 # if nonzero issues report, print
 print(grp,'events',len(events),'counters',dict(counters),'ISSUES',issues[:10])
# H04 fixed generic values and Ed25519
hroot=base+'H/P0A3G_R2_DEV_01_H/'
h=json.loads(c2.read(hroot+'H_evidence.json'))
h04=h['methods']['R2-H04']['detail']
report['h04']={'alpha':h04['alpha'],'beta':h04['beta'],'roll_state':h04['roll_state'],'q_squared_tower':h04['q_squared'],'three_negative_rejections':[(t['case'],t['state'],t['no_score']) for t in h04['negatives']],'all_h_verdicts':{k:v['verdict'] for k,v in h['methods'].items()}}
sig=c2.read(hroot+'controller/H06_signature.bin');org=c2.read(hroot+'controller/H06_original_envelope.json');bad=c2.read(hroot+'controller/H06_tampered_envelope.json');t=json.loads(c2.read(hroot+'raw_workers/R2_H06_valid_source_run/w0000.trust.json'));pk=Ed25519PublicKey.from_public_bytes(bytes.fromhex(t['keys'][0]['public_key_hex']));
def valid(msg):
 try:pk.verify(sig,msg);return True
 except Exception:return False
report['h06_ed25519_independent']={'original_valid':valid(org),'tampered_valid':valid(bad),'same_length':len(org)==len(bad),'byte_differences':sum(a!=b for a,b in zip(org,bad)),'original_sha256':sha(org),'tampered_sha256':sha(bad),'nonproduction_key':t['keys'][0]['scope']=='NON_PRODUCTION_TEST_AUTHORITY'}
# release and C2 receipt gap
result=[]
for k in ['R2-C0_RECEIPT.json','R2-C1-REV1_RECEIPT.json','R2-C1-REV1_LOCK_RECEIPT.md']:
 result.append({'name':k,'in_C2':any(n.endswith('/'+k) or n==k for n in c2.namelist()),'in_CFINAL':any(n.endswith('/'+k) or n==k for n in cf.namelist())})
report['receipts_gap']=result
report['release']={'record_sha256':sha(c2.read('release/R2_RELEASE_RECORD.txt')),'text':c2.read('release/R2_RELEASE_RECORD.txt').decode().strip(),'cf_record_identical':c2.read('release/R2_RELEASE_RECORD.txt')==cf.read('release_and_witness/R2_RELEASE_RECORD.txt')}
# confirm C2 no unexpected secrets? just key name pattern report
names2=c2.namelist();report['secret_name_hunt']=[n for n in names2 if ('private_key' in n.lower() or 'secret_key' in n.lower() or 'seed.bin' in n.lower())]
out=p/'P0A3G_R2_INDEPENDENT_QC_DEEP_CHECKS.json';out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print('WROTE',out)
for k in ['frozen_baseline','source_lock','external_lock','manifest','h04','h06_ed25519_independent','receipts_gap']:
 print(k,str(report[k])[:1100])
