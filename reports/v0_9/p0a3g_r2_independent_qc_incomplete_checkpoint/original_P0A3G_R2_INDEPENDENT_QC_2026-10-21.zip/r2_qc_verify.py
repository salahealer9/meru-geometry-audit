#!/usr/bin/env python3
"""Read-only independent P0A3G-R2 ZIP/manifest/source-and-events verification.
Does not run or import the candidate or R2's test tools."""
import hashlib,io,json,re,stat,zipfile,collections,sys
from pathlib import Path
P=Path('/mnt/data')
ARCH={'C0':'P0A3G_R2-C0(1).zip','C1':'P0A3G_R2-C1-REV1(1).zip','C2':'P0A3G_R2-C2.zip','CFINAL':'P0A3G_R2-CFINAL.zip'}
WANT={'C0':(63036,'e99811f3eefd90a49726e9ea37d8eae8b739829cc90bc825f3dec489d731bbb5',25),'C1':(197250,'b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1',85),'C2':(1388186,'860d93dce952a73b65b097e3f7b4da420c0a327ee0ca8b6d4c213865db2d1cbb',1283),'CFINAL':(1224562,'7c9770d15a3a578f61def2571813d84baadda34bfe3d31cfc1b5cdd722a51eb4',100)}
sha=lambda b: hashlib.sha256(b).hexdigest()
result={}
zs={}
for label,file in ARCH.items():
 raw=(P/file).read_bytes();size,digest,num=WANT[label];errs=[]
 if len(raw)!=size:errs.append('OUTER_SIZE');
 if sha(raw)!=digest:errs.append('OUTER_SHA');
 z=zipfile.ZipFile(io.BytesIO(raw));zs[label]=z;names=z.namelist();
 if len(names)!=num:errs.append('MEMBER_COUNT');
 if len(names)!=len(set(names)):errs.append('DUPLICATES');
 if z.testzip() is not None:errs.append('CRC');
 for info in z.infolist():
  name=info.filename
  if name.startswith('/') or '\\' in name or '..' in name.split('/') or not name or re.match('^[a-zA-Z]:',name):errs.append('UNSAFE_PATH:'+name)
  mode=(info.external_attr>>16)
  if stat.S_ISLNK(mode):errs.append('SYMLINK:'+name)
  if info.file_size>20*1024*1024:errs.append('OVERSIZE_MEMBER:'+name)
 lines=z.read('SHA256SUMS').decode().splitlines();sums={};
 for row in lines:
  m=re.fullmatch(r'([0-9a-f]{64})  (.+)',row)
  if not m:errs.append('MALFORMED_SUM_LINE');continue
  digest_i,name=m.groups()
  if name in sums:errs.append('DUPLICATE_SUM')
  sums[name]=digest_i
  if name not in names or sha(z.read(name))!=digest_i:errs.append('HASH_FAIL:'+name)
 if set(sums)!=set(names)-{'SHA256SUMS'}:errs.append('SHA_UNCOVERED')
 inventory=json.loads(z.read('PACKAGE_INVENTORY.json'))
 files=inventory.get('payload_files',[])
 invmap={x['path']:x for x in files}
 for name,x in invmap.items():
  if name not in names:errs.append('INVENTORY_MISSING:'+name);continue
  b=z.read(name)
  if len(b)!=x['bytes'] or sha(b)!=x['sha256']:errs.append('INVENTORY_FAIL:'+name)
 if set(invmap)!=set(names)-{'PACKAGE_INVENTORY.json','SHA256SUMS'}:errs.append('INVENTORY_UNCOVERED')
 result[label]={'file':file,'bytes':len(raw),'sha256':sha(raw),'members':len(names),'sums_checked':len(sums),'inventory_checked':len(invmap),'errors':errs}
# nested originals
z=zs['CFINAL'];nested={}
for label,pth in [('C0','checkpoints/P0A3G_R2-C0.zip'),('C1','checkpoints/P0A3G_R2-C1-REV1.zip'),('C2','checkpoints/P0A3G_R2-C2.zip')]:
 b=z.read(pth);nested[label]={'sha256':sha(b),'bytes':len(b),'original_byte_identical':b==(P/ARCH[label]).read_bytes()}
rejected=z.read('checkpoints/rejected_not_released/P0A3G_R2-C1.zip')
nested['rejected_C1']={'sha256':sha(rejected),'bytes':len(rejected),'matches_known':sha(rejected)=='740da6990834846a579cc07dccdafcab23f147c5f00117c25505a1cbce847589'}
result['nested']=nested
# file-by-file crossstage lock consistency
z1=zs['C1'];z2=zs['C2'];zf=zs['CFINAL']
locks=['lock/SOURCE_LOCK.json','lock/R2_EXTERNAL_LOCK.json']
result['locks']={key:{'rev1_sha':sha(z1.read(key)),'final_sha':sha(zf.read(key)),'identical':z1.read(key)==zf.read(key)} for key in locks}
for key in ['lock/SOURCE_LOCK.json','lock/R2_EXTERNAL_LOCK.json']:
 ob=json.loads(z1.read(key));print('LOCK',key,'type',type(ob),'first',str(ob)[:700])
# candidate/external diff C1 -> CFINAL
for label,prefix in [('candidate','candidate/'),('external','r2_external/')]:
 original=[n for n in z1.namelist() if n.startswith(prefix)]; final=[n for n in zf.namelist() if n.startswith(prefix)]
 result[label+'_integrity']={'lock_files':len(original),'final_files':len(final),'missing':sorted(set(original)-set(final)),'additional':sorted(set(final)-set(original)),'changed':[n for n in original if n in final and z1.read(n)!=zf.read(n)]}
 # C2 attempt contains exact executed tree
 cd='attempt/P0A3G_R2_DEV_01/'+prefix
 result[label+'_executed_integrity']={'checked':len(original),'missing':[n for n in original if cd+n[len(prefix):] not in z2.namelist()],'changed':[n for n in original if cd+n[len(prefix):] in z2.namelist() and z1.read(n)!=z2.read(cd+n[len(prefix):]) ]}
# C2 required receipts
required=['R2-C0_RECEIPT.json','R2-C1-REV1_RECEIPT.json','R2-C1-REV1_LOCK_RECEIPT.md']
result['C2_receipts']={'stored_receipt_like':[n for n in z2.namelist() if 'RECEIPT' in n or '/receipts/' in n.lower()],'CFINAL_receipts':[n for n in zf.namelist() if n.startswith('receipts/')]}
# attempt manifest
base='attempt/P0A3G_R2_DEV_01/'
man=json.loads(z2.read(base+'R2_ATTEMPT_FILE_MANIFEST.json'))
print('ATTEMPT MANIFEST TYPE/KEYS',type(man),list(man)[:15] if isinstance(man,dict) else len(man));print(str(man)[:500])
result['attempt_manifest']={'keys':list(man)}
# evidence 20 group reports
summary=json.loads(z2.read(base+'R2_ATTEMPT_SUMMARY.json'))
result['attempt_summary']={'methods_registered':summary['methods_registered'],'methods_passed':summary['methods_passed'],'statuses':summary['per_method'],'g_decision':summary['g_decision_boundary'],'runner_exits':(summary['g_runner_exit'],summary['h_runner_exit']),'reconcile_exits':summary['external_reconciliation_exit'],'quarantine':summary['quarantine'],'retry_repair':summary['retry_or_repair_performed']}
# Inspect reconciliation files
result['event_docs']={}
for group in 'GH':
 paths=[n for n in z2.namelist() if n.startswith(base+group+'/') and ('reconcil' in n.lower() or n.endswith('.event.json'))]
 result['event_docs'][group]={'event_files':len([p for p in paths if p.endswith('.event.json')]),'reconcile_files':[p for p in paths if 'reconcil' in p.lower()][:15]}
# actual evidence zip-level counts for file members+ possible missing receipt paths
out=P/'P0A3G_R2_INDEPENDENT_QC_PRIMARY_CHECKS.json';out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print('OUTPUT',out)
for k,v in result.items():
 if k in ['C0','C1','C2','CFINAL','nested','candidate_integrity','external_integrity','candidate_executed_integrity','external_executed_integrity','C2_receipts','attempt_summary']:
  print(k,str(v)[:1300]);
