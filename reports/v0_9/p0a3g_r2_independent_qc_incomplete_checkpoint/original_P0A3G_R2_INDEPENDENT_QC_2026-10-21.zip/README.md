# P0A3G-R2 independent QC package

Scope: read-only QC of uploaded original R2-C0, R2-C1-REV1, R2-C2 and R2-CFINAL, plus prior signed P0A3G G-CFINAL baseline. No candidate code executed.

The verification scripts expect locally accessible files in /mnt/data. The script r2_qc_deep.py uses `cryptography` to independently verify a retained non-production Ed25519 signature. The primary JSON documents archive/source/manifest checks. The deep JSON records per-event raw stream and cryptographic checks. Raw stream rehashing uses event JSON and archived stdout/stderr directly; registered injected faults are not treated as clean streams.

Note: the original rejected first R2-C1 is embedded in R2-CFINAL. The necessary prior checkpoint receipts are absent from original R2-C2, but present in R2-CFINAL. This is an explicitly blocking protocol-completeness finding notwithstanding 20/20 technical test reports.

Never use these scripts or their outputs as a production code-signing authority, scientific validation, or permission to invoke P0A4.
