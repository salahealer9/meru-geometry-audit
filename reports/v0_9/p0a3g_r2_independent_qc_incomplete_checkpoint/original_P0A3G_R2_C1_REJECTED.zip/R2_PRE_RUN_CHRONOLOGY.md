# P0A3G-R2 — Complete pre-run chronology (through R2-C1)  ·  ZERO R2 candidate invocations

UTC, 2026-10-21. Historical P0A3G runs (four pre-lock full-catalogue dry runs, two smoke scripts, post-lock `P0A3G_DEV_01`) are listed in `r2c0/R2_EXPOSURE_REGISTER.md`; none is an R2 trial.

| Time (approx.) | Event | R2 candidate invocation? |
|---|---|---|
| 14:44Z | Human instruction: authorizes R2-P0 and R2-P1 only | — |
| 14:45–14:50Z | R2-P0 intake: fresh clone at `4b488825…`; GPG/parent/blob/scope checks for R2, corrigendum and lineage; both documents read; preserved archives verified; 51-file candidate extracted from signed G-CFINAL and cross-checked with G-C1; detached historical G01 fixture at `adacfdbc…`; host preflight (binary identity only) | No |
| 14:50–14:51Z | R2-C0 built (`e99811f3…bbb5`, 63,036 B), published to the R2 Lock Register artifact, freshly read back into an empty directory, decoded, verified byte-identical | No |
| 14:52–14:56Z | **Static** text review of candidate source files (`core.py`, `algebra.py`, reference `wire.py`/`checker.py`, signatures in `supervisor.py`, `streamcapture.py`, `identity.py`, `authority_fixtures.py`, `g_checks.py`) by reading file contents only | No |
| 14:54Z | H01–H04 request fixtures written as canonical JSON text by an agent script using only the Python standard library (no candidate import) | No |
| 14:55–14:58Z | `r2_external/` sources written (`r2_stream_reconcile.py`, `R2_HOLDOUT_CHALLENGES.py`, `R2_DRIVER.py`); one wrapper edit before lock (dropped two `q_squared == []` / `!= []` conditions found fragile by static review of `algebra.py`) | No |
| 14:58Z | `ast.parse` (syntax only, no execution, no import) of the three R2 sources under CPython 3.12.3 and 3.13.16 | No |
| 14:59Z | `R2_EXTERNAL_LOCK.json` frozen (`a27aac41…89b6`); `R2_TEST_CATALOGUE_LOCK.md` written; R2-C1 assembled | No |

**Totals before external witness: R2 candidate imports 0; tests 0 (G01–G14: 0, H01–H06: 0); dry runs 0; smoke checks 0; parser requests 0; geometry previews 0; signature-verification checks 0; worker launches 0; test keys generated 0. R2-P2 and R2-P3 have NOT begun.**

Durable storage route: private claude.ai artifact "P0A3G-R2 Lock Register" (https://claude.ai/artifact/PDchuKxE1d7t6y5Lsb3ZQC), base64 text copies because artifacts do not serve `.zip`; readback procedure = artifact read into a new empty directory → `base64 -d` → `r2_tools/zipcheck.py <zip> <sha> <bytes>` → `cmp` with original. Raw ZIPs are also attached to the conversation.
