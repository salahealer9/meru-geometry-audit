# P0A3G-R2 — Pre-existing exposure register (HISTORICAL; none of this is R2 evidence)

The R2 engineering agent is the **same Claude conversation** that built and ran P0A3G. Prior knowledge of the code, tests and outcomes is disclosed here. Agent identity is not independent validation.

## A. Historical candidate executions by this agent (P0A3G lane, 2026-10-21, before R2 existed)
| # | Label (historical) | What ran | Outcome | Where preserved |
|---|---|---|---|---|
| 1 | smoke1 (pre-lock, P0A3G) | `supervisor.run` on fixture R, TEST_AUTHORITY, ephemeral key | SUCCESS | `original_P0A3G_G-C1.zip` → `prelock/smoke1.py` (script only) |
| 2 | smoke2 (pre-lock, P0A3G) | R run + 12 `child()` fault cases + 8 s timeout + candidate stream reconciler | as logged in session (no runner log retained beyond script) | `original_P0A3G_G-C1.zip` → `prelock/smoke2.py` (script only) |
| 3 | `PRELOCK_DRYRUN_01` | full G01–G14 | FAIL: 6 failures, 5 errors | G-C1 `prelock/dry01.*` |
| 4 | `PRELOCK_DRYRUN_02` | full G01–G14 | 14/14 PASS | G-C1 `prelock/dry02.*` |
| 5 | `PRELOCK_DRYRUN_03` | full G01–G14 | 14/14 PASS | G-C1 `prelock/dry03.*` |
| 6 | `PRELOCK_DRYRUN_04` | full G01–G14 | 14/14 PASS | G-C1 `prelock/dry04.*` |
| 7 | `P0A3G_DEV_01` (post-lock) | full G01–G14 | 14/14 PASS; runner exit 0 | `original_P0A3G_G-C2_DEV_01.zip`, `original_P0A3G_G-CFINAL.zip` |

Signed disposition of the above (commit `0e86df64…`): `P0A3G_PROSPECTIVE_DEV_LOCK_SEQUENCE_NOT_QUALIFIED`, `P0A3G_INDEPENDENT_QC_NOT_QUALIFIED`. Rows 1–2 (smoke runs) were disclosed in the G-C1 predeclared document and are listed here for completeness; the signed QC table counts rows 3–7.

## B. Earlier signed negatives (unchanged, immutable)
* R1 (`d95c50ea…`): QCF01 — `forged_q` and `null_path_record` stdout recorded 108 B `23bcfd67…`, archived 0 B `e3b0c442…`; `P0A3F_R1_INDEPENDENT_QC_NOT_QUALIFIED` permanent. Never backfilled; same-digest streams from other events are not R1 evidence.
* Original P0A3F_DEV_01: transcript-only, quarantined (`83b9e6dc…`).
* P0A3E incomplete (`8ed3b988…`); P0A3D theorem frozen (`59eb47f7…`).

## C. R2 lane exposure (this session)
**Zero R2 candidate invocations.** No candidate import, test, dry run, smoke check, parser request, geometry preview, signature check, `runpy` or worker launch has occurred under R2. Only Git/GPG verification, archive hashing/CRC/manifest checks, extraction of bytes, interpreter/OpenSSL identity inspection and agent-side tool execution (none importing candidate code) have occurred.

## D. Other prior workspace
A stale P0A3G working directory `/home/claude/p0a3g/` from the earlier session exists on this host. Its files are **not** used by R2; the R2 candidate is extracted only from the signed, hash-verified `original_P0A3G_G-CFINAL.zip` at commit `0e86df64…` (via the R2 clone at HEAD `4b488825…`). The earlier P0A3G checkpoint base64 copies remain in the claude.ai Project docs and the P0A3G register artifact; they are historical.
