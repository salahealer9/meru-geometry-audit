# P0A3G-R2 — Pre-run chronology (R2-C0)  ·  **NO_R2_EXECUTION_YET**

All times UTC, 2026-10-21. Human instruction received 14:44Z authorizes R2-P0 and R2-P1 only.

| Time (approx.) | Event | Candidate invocation? |
|---|---|---|
| 14:45Z | Fresh clone of `hebrew-projection-capacity-v0.9` into `P0A3G_R2/git/meru-geometry-audit`; HEAD `4b488825…`, matches remote | No |
| 14:45Z | Isolated GNUPGHOME; signer public key imported from repo; fingerprint `D4EC…2130` confirmed | No |
| 14:46Z | GOODSIG/VALIDSIG for `4b488825`, `7de01ab2`, `0e86df64`; parents and one-file scopes; blobs `780fc70a…`, `01cbd34f…` | No |
| 14:46Z | Both signed R2 documents and the P0A3G QC closeout read completely | No |
| 14:47Z | P0A3G preservation manifest (`sha256sum -c`) PASS; 25/25 commits v0.8.0→HEAD signed; v0.8.0 tag signed | No |
| 14:47Z | Agent R2 tools written (`r2_tools/zipcheck.py`, `build_zip.py`); 5 preserved P0A3G archives verified (one benign note: QC ZIP `SHA256SUMS` entry has mode 0600 without file-type bits) | No |
| 14:48Z | 51-file `candidate/` extracted from signed G-CFINAL into `P0A3G_R2/baseline/candidate`; equals G-C1 candidate and SOURCE_LOCK `abff7aa8…`; kernels, `g_checks.py`, `authority_fixtures.py`, policy hashes as pinned | No |
| 14:48Z | Older signed manifests (R1 QC, incident, P0A3E, P0A3D) re-checked OK | No |
| 14:49Z | Historical G01 fixture: local clone checked out **detached** at `adacfdbc…` (tree `51f03026…`), clean, worktree made read-only; G01-pinned archive hashes match | No |
| 14:50Z | Host preflight: interpreter/OpenSSL/git/gpg identities, stdlib hashes, OS, limits (interpreter run only with `-c` version/status probes) | No |
| 14:50Z+ | R2-C0 ledgers written and packaged | No |

**Count of R2 candidate imports, tests, dry runs, smoke checks, parser requests, geometry previews, signature checks or worker launches: 0.**
