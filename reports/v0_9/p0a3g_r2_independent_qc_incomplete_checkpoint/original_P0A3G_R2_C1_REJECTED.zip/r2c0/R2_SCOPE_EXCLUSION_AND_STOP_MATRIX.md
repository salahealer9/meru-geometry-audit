# P0A3G-R2 — Scope, exclusions and stop matrix

**Authority:** R2 protocol `7de01ab2c90afe52dd763652a9eaffd2e9a2cff9` (blob `01cbd34f…2992`) plus H04 corrigendum `4b488825ed35c7ac91a19abe62be068e75e9a076` (blob `780fc70a…7fa3c`), which takes precedence **only for H04**. This session's instruction authorizes **R2-P0 and R2-P1 only**.

## In scope now
R2-P0 intake and R2-C0; R2-P1 text-only construction of the 20-case lock and R2-C1; durable save, fresh retrieval, verification; then STOP.

## Forbidden before an exact human-relayed release citing the independently verified R2-C1 SHA-256
Any candidate import, test (full or partial G01–G14, H01–H06), dry run, smoke check, `unittest`/`pytest`, `runpy`, parser request, geometry function call or mathematical preview, signature-verification check, worker launch, or evaluation of the R2 wrapper against candidate software. Test-key generation. Any accidental invocation ⇒ log, preserve, `R2_PREDEV_PROTOCOL_BREACH_NOT_QUALIFIED` / `P0A3G_R2_PROSPECTIVITY_BREACH`, STOP.

## Always forbidden
Git writes (commit/push/branch changes) in the protected repository; modification of any signed archive or historical evidence; changes to the 51-file candidate (including the three kernels); backfilling R1 streams; Hebrew glyphs/charts/fonts/targets; candidate/null analysis; P0A0 S00–S12; P0A4; G0/A/B; 3D/QH; new thresholds or theorems; human private keys; self-approval.

## Stop matrix
| Condition | Status |
|---|---|
| Git/GPG/blob/parent/scope mismatch; archive or kernel mismatch | `R2_STOP_AND_QUARANTINE` |
| Host cannot meet mandatory bounds / identity drift at release | `R2_ENVIRONMENT_UNQUALIFIED` (stop before DEV) |
| Unauthorized pre-release candidate invocation | `R2_PREDEV_PROTOCOL_BREACH_NOT_QUALIFIED` |
| R2-C0 or R2-C1 cannot be persisted and freshly retrieved | `P0A3G_R2_ENGINEERING_INCOMPLETE` |
| No reviewer witness / no byte-specific release | `P0A3G_R2_PREDEV_LOCK_NOT_WITNESSED` |
| Static review reveals an impossible challenge interface | declare before lock; STOP for revised signed protocol |
