# P0A3G-R2 — Prospective environment declaration (R2-P0; before any R2 execution)

Measured (binary identity/version only; no candidate code): `R2_HOST_PREFLIGHT.txt`.

| Item | Preferred P0A3G envelope | This R2 host (2026-10-21T14:50Z) | Status |
|---|---|---|---|
| Interpreter | `/usr/bin/python3.12 -I -S -B`, CPython 3.12.3, SHA-256 `e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f` | identical path, version, SHA-256 (Ubuntu `python3.12-minimal 3.12.3-1ubuntu0.17`) | SAME |
| OpenSSL | `/usr/bin/openssl` SHA-256 `b4f547c0f16272d1cc7f870330a6f2c243710c335e7a99c734ff7a0c6fdb2503` | identical; OpenSSL 3.0.13 (`openssl 3.0.13-0ubuntu3.16`) | SAME |
| OS / kernel | Ubuntu 24.04.5, Linux 6.18.44-fc-v139, x86_64, glibc 2.39 | identical strings | SAME |
| CPUs / RAM | 2 CPUs | 2 CPUs, 8.4 GB | SAME CLASS |
| Resource policy | `schemas/v0_9/p0a3g/resource_policy.json` SHA-256 `9b7221fc…e09` | byte-identical inside the 51-file candidate | SAME |
| Seccomp / NoNewPrivs | 0 / 0 | 0 / 0 | SAME |
| git / GnuPG (G01 only) | 2.43.0 / 2.4.4 | 2.43.0 (SHA `eb54b535…2201`) / 2.4.4 (SHA `403e04c7…8dd4`) | SAME versions |
| `/usr/bin/python3.13` (G12 probe) | 3.13.16 | SHA `a35753cc…4446` | recorded |
| stdlib dependency hashes (identity envelope) | — | recorded in preflight | recorded |

**Declaration:** R2 uses exactly the preferred envelope; no binary substitution and no cap change. Budgets (from the unchanged policy): worker wall **8 s**, CPU **6 s**, memory **256 MiB** (calibration 512 MiB), file/stream **2 MiB**, `NOFILE` 32, core 0, concurrency 1, recursion 256, run disk **16 MiB**, request **64 KiB**, document/certificate 2 MiB, drain 2 s, signature check 5 s, 64 events per run.

**Host continuity:** binary and kernel identities match the P0A3G host, but this is a sandbox session; physical/virtual host continuity is not attested. Strictly, results remain bound to these identities on this host class; cross-host qualification is not claimed. If, at release time (R2-P2), any of the identities above differ, the attempt must stop as `R2_ENVIRONMENT_UNQUALIFIED` or be declared `CROSS_HOST_REPLICATION_NOT_QUALIFIED` per protocol — the R2 driver re-checks them before launching anything.

**Not enforced (unchanged gaps):** whole-attempt disk ceiling, cgroup memory, seccomp, controller-death process-tree containment.

**Keys:** no test keys exist yet. Ephemeral NON_PRODUCTION Ed25519 test keys will be generated only after an exact human-relayed release, in a controller key directory outside `candidate/` and outside all evidence; only public portions retained. No human key is present or requested.
