"""R2-P0 signed provenance ledger (agent-side, read-only Git/GPG; no candidate code).

usage: GNUPGHOME=... python3 -I provenance.py <repo> <historical_fixture_checkout> <out.json>
"""
import json, subprocess, sys

REPO, HIST, OUT = sys.argv[1:4]
FPR = 'D4EC014EEFCC90E619D2AA59A91239ABCF512130'


def git(repo, *a):
    return subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True)


def sig(obj, kind='commit'):
    r = git(REPO, 'verify-' + kind, '--raw', obj)
    lines = [l.split()[1:] for l in r.stderr.splitlines() if l.startswith('[GNUPG:]')]
    return {'GOODSIG': any(t and t[0] == 'GOODSIG' for t in lines),
            'VALIDSIG_fpr': next((t[1] for t in lines if t and t[0] == 'VALIDSIG'), None),
            'TRUST': next((t[0] for t in lines if t and t[0].startswith('TRUST_')), None)}


pins = [
    ('R2_H04_CORRIGENDUM', '4b488825ed35c7ac91a19abe62be068e75e9a076', '7de01ab2c90afe52dd763652a9eaffd2e9a2cff9',
     'docs/v0_9/p0a3g_r2_h04_exact_geometry_corrigendum_2026_10_21.md', '780fc70a11081fda4fa2aedc56bb2cab84e7fa3c'),
    ('R2_PROTOCOL', '7de01ab2c90afe52dd763652a9eaffd2e9a2cff9', '0e86df64e30d081065bbeb75b6f53391e287f8f3',
     'docs/v0_9/p0a3g_r2_prospective_replication_and_independently_witnessed_source_lock_protocol_2026_10_21.md', '01cbd34f9000c50eb6810dcfd8d4dd27b6312992'),
    ('P0A3G_QC_INCOMPLETE_PRESERVATION', '0e86df64e30d081065bbeb75b6f53391e287f8f3', 'adacfdbc6efcca4922c8d087d029b67e9b0c5dc5',
     'docs/v0_9/p0a3g_independent_qc_incomplete_preservation_2026_10_21.md', 'ab3c2c6494228e476984682ea88a0fc1e53185f9'),
    ('P0A3G_PROTOCOL', 'adacfdbc6efcca4922c8d087d029b67e9b0c5dc5', 'd95c50ea96744ce266058c51f85fff320d1a27df',
     'docs/v0_9/p0a3g_raw_worker_evidence_and_external_trust_followup_protocol_2026_10_21.md', '00a4e6ac85403f2a6e4704963a858d43faef136b'),
    ('P0A3F_R1_QC_NEGATIVE_PRESERVATION', 'd95c50ea96744ce266058c51f85fff320d1a27df', '83b9e6dcd53b100c5ac8b081832e81659cd1884a',
     'docs/v0_9/p0a3f_r1_independent_qc_incomplete_preservation_2026_10_21.md', 'bf1dacde71c5b3a0ac3919f070c1c57a74c4ce41'),
    ('P0A3F_EVIDENCE_LOSS_R1_AMENDMENT', '83b9e6dcd53b100c5ac8b081832e81659cd1884a', '1d38ea6f53b9266d853df887a66331c59e4fc3ae',
     'docs/v0_9/p0a3f_evidence_loss_recovery_amendment_2026_10_21.md', '9fd9fba6ca509e3fcb72c2227d226847d218b354'),
    ('P0A3F_PROTOCOL', '1d38ea6f53b9266d853df887a66331c59e4fc3ae', '8ed3b988f716229bc9aee97d41ded0f524371193',
     'docs/v0_9/p0a3f_exact_2d_qo_runtime_external_trust_and_fail_closed_recovery_qualification_protocol.md', '9530a75d2346752a093367aeac24e13c5d2d6fac'),
    ('P0A3E_INCOMPLETE_PRESERVATION', '8ed3b988f716229bc9aee97d41ded0f524371193', 'c48c7a60777200a172ae3c72f5b0402162370ec7', None, None),
    ('P0A3D_THEOREM_FREEZE', '59eb47f7500d57866e4935822b78a555d3bcb515', '92de104cab58339df370acf96b8d849ecc2d888b', None, None),
]
out = {'schema': 'p0a3g-r2-signed-provenance-1', 'expected_fingerprint': FPR,
       'remote_branch_head': git(REPO, 'ls-remote', 'origin', 'refs/heads/hebrew-projection-capacity-v0.9').stdout.split()[0],
       'local_head': git(REPO, 'rev-parse', 'HEAD').stdout.strip(),
       'worktree_clean': git(REPO, 'status', '--porcelain').stdout == '', 'objects': {}}
ok = True
for name, c, parent, path, blob in pins:
    actual_parent = git(REPO, 'rev-parse', c + '^').stdout.strip()
    s = sig(c)
    rec = {'commit': c, 'expected_parent': parent, 'actual_parent': actual_parent, 'signature': s,
           'diff_vs_parent': git(REPO, 'diff', '--name-status', actual_parent, c).stdout.splitlines()}
    good = actual_parent == parent and s['GOODSIG'] and s['VALIDSIG_fpr'] == FPR
    if path:
        b = git(REPO, 'rev-parse', '%s:%s' % (c, path)).stdout.strip()
        rec.update(path=path, expected_blob=blob, actual_blob=b)
        good = good and b == blob
    rec['verdict'] = 'PASS' if good else 'FAIL'
    ok = ok and good
    out['objects'][name] = rec
for name in ('R2_H04_CORRIGENDUM', 'R2_PROTOCOL'):
    d = out['objects'][name]['diff_vs_parent']
    out['objects'][name]['one_file_additive'] = len(d) == 1 and d[0].startswith('A\t')
    ok = ok and out['objects'][name]['one_file_additive']
lineage = []
for c in git(REPO, 'rev-list', 'v0.8.0..HEAD').stdout.split():
    s = sig(c)
    lineage.append({'commit': c, 'subject': git(REPO, 'log', '-1', '--format=%s', c).stdout.strip(),
                    'GOODSIG': s['GOODSIG'], 'VALIDSIG_fpr': s['VALIDSIG_fpr']})
out['lineage_v0_8_0_to_HEAD'] = {'count': len(lineage),
                                 'all_valid': all(l['GOODSIG'] and l['VALIDSIG_fpr'] == FPR for l in lineage), 'commits': lineage}
t = sig('v0.8.0', 'tag')
out['v0_8_0_tag'] = {'tag_object': git(REPO, 'rev-parse', 'v0.8.0').stdout.strip(),
                     'target': git(REPO, 'rev-parse', 'v0.8.0^{commit}').stdout.strip(), 'signature': t,
                     'ancestor_of_HEAD': git(REPO, 'merge-base', '--is-ancestor', 'v0.8.0', 'HEAD').returncode == 0}
out['historical_g01_fixture_checkout'] = {
    'path': HIST, 'head': git(HIST, 'rev-parse', 'HEAD').stdout.strip(),
    'detached': git(HIST, 'symbolic-ref', '-q', 'HEAD').returncode != 0,
    'tree': git(HIST, 'rev-parse', 'HEAD^{tree}').stdout.strip(),
    'clean': git(HIST, 'status', '--porcelain').stdout == '',
    'tracked_files': len(git(HIST, 'ls-files').stdout.splitlines()),
    'origin': git(HIST, 'remote', 'get-url', 'origin').stdout.strip(),
    'worktree_permissions': 'files and directories outside .git made read-only (a-w); .git left writable for git status index refresh'}
ok = ok and out['lineage_v0_8_0_to_HEAD']['all_valid'] and t['GOODSIG'] and out['remote_branch_head'] == out['local_head'] == pins[0][1]
ok = ok and out['historical_g01_fixture_checkout']['head'] == 'adacfdbc6efcca4922c8d087d029b67e9b0c5dc5' and out['historical_g01_fixture_checkout']['clean']
out['evidence_distinctions'] = {
    'gpg_cryptographic': 'PERFORMED by agent in isolated GNUPGHOME; public key extracted from repo file reports/v0_9/p0a2_target_blind_design/provenance_and_information_barrier.json; primary fingerprint equals pinned fingerprint',
    'github_attestation': 'NOT CHECKED (no GitHub API access for this repository in this session)',
    'human_ownertrust': 'NOT ASSERTED by agent (TRUST_UNDEFINED in agent keyring)'}
out['verdict'] = 'PASS' if ok else 'FAIL'
json.dump(out, open(OUT, 'w'), indent=1, sort_keys=True)
print(out['verdict'], out['lineage_v0_8_0_to_HEAD']['count'])
