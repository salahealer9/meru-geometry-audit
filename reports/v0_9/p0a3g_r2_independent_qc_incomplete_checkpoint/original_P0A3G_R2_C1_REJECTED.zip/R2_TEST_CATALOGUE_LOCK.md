# P0A3G-R2 — R2_TEST_CATALOGUE_LOCK (prospective; written 2026-10-21 before any R2 execution)

**Authority:** signed R2 protocol `7de01ab2c90afe52dd763652a9eaffd2e9a2cff9` (blob `01cbd34f9000c50eb6810dcfd8d4dd27b6312992`) and signed H04 corrigendum `4b488825ed35c7ac91a19abe62be068e75e9a076` (blob `780fc70a11081fda4fa2aedc56bb2cab84e7fa3c`); the corrigendum governs **H04 only**. Single attempt: **`P0A3G_R2_DEV_01`**, only after a human-relayed release quoting the independently verified R2-C1 SHA-256. **R2-P2 and R2-P3 HAVE NOT BEGUN.**

## 1. Locked bytes
| Object | Identity |
|---|---|
| 51-file candidate (`candidate/`) | `lock/SOURCE_LOCK.json` SHA-256 `abff7aa8df19f73e070d9f06ebd23334f8d98b45c1736d38399b845c69835902` (byte copy of the signed G-C1 lock); equal to signed G-CFINAL `8b0ec808…3a6a` and G-C1 `1209547e…aaf0` candidate trees |
| Frozen kernels | `algebra.py` `442065847937252db00d3f63b02184c15d57989f958f764c5c731cb385de6d2d`; `core.py` `37701d034d98725673240a881420892893906c70387f68432b5993f8557dd420`; `arithmetic.py` `72b3c37f02be65b2df7616a94e84601d66cf4af5b7a50e878724de647e5bf0ba` |
| Historical runner / constructors | `g_checks.py` `16c8d6d5a67bdf541fe4e48d6ddaf1ca938abf53099fb93bd8768e296cb5cf92`; `authority_fixtures.py` `6e2325a27bdee39d8b085bf8c5f2cdda92aeb090f0f52c1c505bee346a7027f2` |
| Resource policy | `schemas/v0_9/p0a3g/resource_policy.json` `9b7221fcfb54dc313874c9873423001ae7856b3a1889f12b92f9638abd904e09` |
| External R2 code (`r2_external/`) | `lock/R2_EXTERNAL_LOCK.json` SHA-256 `a27aac4184cf5c115b9162966d6eea06f2ee39eb9f6a361f806dc302f34a89b6` |
| `R2_HOLDOUT_CHALLENGES.py` | `dcb3faf56d0ce9f6f7c5c2212a09c98ff46a8cc11d54c2beb14fba538f6b983e` (22,242 B) |
| `R2_DRIVER.py` | `6153e9ff203f3fdaaf015a549aca21bc95dc64472ad8ac71b4972848e377432a` (10,646 B) |
| `r2_stream_reconcile.py` (independent reconciler; no candidate imports) | `ae18681edf5869fa84e3fcf0411292a6a47efc911a69a68bcc59b49c94430833` (8,872 B) |
| `fixtures/R2_H01..H04.request.json` | `0807f224…98fa` / `27eb835c…3977` / `6623fb58…c2b1` / `27dfd8d5…50e4` (full values in `R2_EXTERNAL_LOCK.json`) |
| G01 historical fixture checkout | `/home/claude/P0A3G_R2/git/historical_g01_fixture_adacfdbc`, detached HEAD `adacfdbc6efcca4922c8d087d029b67e9b0c5dc5`, tree `51f03026251d70f258b30e7b5ed5f893fa1058be`, clean, 614 tracked files, worktree read-only |
| G01 keyring | `/home/claude/P0A3G_R2/gnupg` holding only public key `D4EC014EEFCC90E619D2AA59A91239ABCF512130` (key file SHA-256 `af66fcd2…63b8`) |
| Interpreter / OpenSSL / probe | `/usr/bin/python3.12` `e50d468e…150f`; `/usr/bin/openssl` `b4f547c0…2503`; `/usr/bin/python3.13` `a35753cc…4446` |

## 2. Exact commands and order (no optional or adaptive choices)
After the release message is received in this conversation:
1. Re-retrieve R2-C1 from the R2 Lock Register into a new empty directory, decode, and confirm its SHA-256 equals the released value (`r2_tools/zipcheck.py`).
2. Run exactly once:
```
/usr/bin/python3.12 -I -S -B <extracted R2-C1>/r2_external/R2_DRIVER.py \
  --release-sha <released 64-hex> --c1 <re-retrieved R2-C1 ZIP> \
  --work /home/claude/P0A3G_R2/dev/P0A3G_R2_DEV_01 \
  --repo-fixture /home/claude/P0A3G_R2/git/historical_g01_fixture_adacfdbc \
  --gnupghome /home/claude/P0A3G_R2/gnupg
```
The driver: verifies the ZIP against the released hash, CRC, names and SHA256SUMS; extracts `candidate/` and `r2_external/` and re-checks both locks; verifies the three binary pins, the fixture checkout and keyring; then runs, in this order and each exactly once,
   * **G group:** `/usr/bin/python3.12 -I -S -B candidate/tests/dev_v0_9/p0a3g/g_checks.py G/P0A3G_R2_DEV_01 <fixture> <gnupghome> controller_keys_G` (unchanged historical runner; its in-band lane string `P0A3G_NEW_DEV_ONLY` is preserved and bound externally to `P0A3G_R2_DEV_01` by this lock and the driver journal),
   * **H group:** `/usr/bin/python3.12 -I -S -B r2_external/R2_HOLDOUT_CHALLENGES.py H/P0A3G_R2_DEV_01_H candidate controller_keys_H` (run regardless of the G outcome),
   * **external reconciliation** of `G/P0A3G_R2_DEV_01/raw_workers` (attempt id `P0A3G_R2_DEV_01`, registry `controller/registered_faults.json`) and `H/P0A3G_R2_DEV_01_H/raw_workers` (attempt id `P0A3G_R2_DEV_01_H`, registry `controller/registered_faults.json`, expected empty),
   * post-run re-verification of both locks and that no private-key files remain.
3. Then R2-C2 (protocol §5), with no source change, retry or added case.

Timeouts: G and H runner processes 1,800 s each (driver kill → recorded failure); reconcilers 600 s. Worker budgets are the unchanged policy (8 s wall, 6 s CPU, 256 MiB, 2 MiB streams, NOFILE 32, concurrency 1, recursion 256, 16 MiB run disk, 64 KiB request).

## 3. R2-G01 … R2-G14 — copied verbatim from the signed G-C1 `P0A3G_DEV_CASES_PREDECLARED.md` §4 (file SHA-256 `12ee70df605b4080a5b418f067204328a22b6df93a8edcf67ef02febd3ca7613`, included in this package)
| ID | Fixture constructor (as coded) | Expected outcome |
|---|---|---|
| R2-G01 | Read-only: repo HEAD/parent/one-file diff/blob; `git verify-commit --raw` of P0A3G and parent; SHA-256 of the 7 signed archives; frozen kernels; in-memory recount of R1 QCF01 from R1-CFINAL | HEAD `adacfdbc…`, clean tree, VALIDSIG `D4EC…2130`; all pins equal; R1 37 events, mismatches exactly `forged_q`/`null_path_record` stdout 108→0 |
| R2-G02 | `supervisor.run(R)` mode TEST_AUTHORITY, run `G02_R` | SUCCESS; 4 events; every stdout and stderr non-empty; independent plain re-read equals recorded bytes/SHA and capture witness; reference reconciler all MATCH; `NON_PRODUCTION_TEST_AUTHORITY_VERIFIED`; `LOADED_CODE_IDENTITY_UNVERIFIED`; checkpoint written |
| R2-G03 | `child('check')` on G02's R certificate with `q=[[0,["1","1"]]]` (`G03_forged_q`) and `paths[0]=null` (`G03_null_path_record`) | `CERTIFICATE_REJECTED`, no score; complete non-empty streams, all MATCH. These are NEW events, not R1 bytes |
| R2-G04 | (a) produce with actual `kill` + simulated `forge_stdout_108`; (b) forged-q check + simulated `zero_stdout_after_save`; (c) full run R with `zero_stdout_after_save` on check | (a),(b),(c) `EVIDENCE_STREAM_MISMATCH`; recorded 108/`23bcfd67…` vs saved 0/`e3b0c442…`; (c) no checkpoint, no certificate; reference rows `MISMATCH_DECLARED_SIMULATED_FAULT` with `BYTES_OR_SHA256` |
| R2-G05 | full runs with simulated truncate/alter/delete stdout and stderr on check, and truncate stdout on produce (7 runs) | each `EVIDENCE_STREAM_MISMATCH`, no certificate, no checkpoint |
| R2-G06 | after a clean `calibrate_check`, check with simulated `swap_streams`, `duplicate_path`, `stale_run`, `wrong_worker_path`, `path_collision`, `orphan_stream_file`; harness copy of a foreign G02 event into a new run dir; reuse of `G02_R` for a new run | each `EVIDENCE_STREAM_MISMATCH`; reuse → `CHECKPOINT_UNVERIFIED/NEW_DIRECTORY_REQUIRED` |
| R2-G07 | full runs with simulated `before_rename`, `short_write`, `after_rename_tamper` on check; R1-contract checkpoint faults before_write…post_rename; resume from torn checkpoint; in-memory archives: good, outer-flipped, valid ZIP+manifest with one altered stream | runs `EVIDENCE_STREAM_MISMATCH`, no checkpoint, events `SIMULATED_EVIDENCE_FAULT` with process fault `NONE`; checkpoint faults raise; torn → `CHECKPOINT_UNVERIFIED`; archives: PASS / FAIL / FAIL |
| R2-G08 | actual produce faults `exit`, `kill`, `partial_then_kill`, `memory`, `recursion`; full run R with actual `timeout` | INTERNAL_ERROR_NO_CERTIFICATE / UNKNOWN_TERMINATION ×2 / RESOURCE_INCOMPLETE ×2; timeout → RESOURCE_INCOMPLETE `CONTROLLER_WALL_TIMEOUT`, rc −9, ≥8 s; empty stdout recorded 0/`e3b0…`; partial non-UTF-8 bytes preserved verbatim; all streams MATCH; no certificate |
| R2-G09 | copy G02 checkpoint with verification replaced by `UNTRUSTED_STALE_SAVED_VERDICT`; `resume` | SUCCESS, `FRESH_REFERENCE_RECOMPUTED`, fresh checker < 8 s, no controller timeout, all streams MATCH |
| R2-G10 | copy G02 checkpoint; `resume` with actual checker `timeout` | `RESOURCE_INCOMPLETE/CONTROLLER_WALL_TIMEOUT`, rc −9, no certificate, streams MATCH |
| R2-G11 | valid test authority via production (OpenSSL), reference (pure Python), and direct cross-checks; 14 negatives (wrong key, signer not in store, wrong scope, revoked, mode DEPLOYMENT, mode DEV_UNSIGNED, wrong parent, wrong protocol, wrong source hash, wrong input hash, wrong policy hash, wrong run, substituted trust store, signature bit flip); end-to-end wrong-key run and reference worker | valid accepted by both only in TEST_AUTHORITY; every negative rejected by **both** routes (any acceptance → STOP_AND_QUARANTINE); controller refuses before any worker; reference worker returns `CODE_IDENTITY_MISMATCH` with reconciled streams |
| R2-G12 | missing authority; signature missing; trust missing; unsigned proposal presented as signed; test authority without signature; human-freeze claimed with test key; DEPLOYMENT; altered runtime digest; loaded-code attestation claimed; same valid authority under actual CPython 3.13; mutated loaded functions (production and reference); DEV_UNSIGNED fixture run | all rejected (both routes where applicable); DEV_UNSIGNED run succeeds only as `CALLER_OWNED_DEV_FIXTURE_UNSIGNED`, distinct from test authority, with `LOADED_CODE_IDENTITY_UNVERIFIED` |
| R2-G13 | 8 raw parser negatives (production and reference) + 5 rational-grammar negatives; checker mutations: forged score, invalid nested path record, nonoptimal identity SO(2), forged tie, missing/duplicate knot, changed traversal, negative/forward/boolean root; equivalent-zero positive control | all negatives rejected with no score and reconciled streams (an accepted negative → STOP_AND_QUARANTINE); positive control SUCCESS |
| R2-G14 | full runs R, Z, T, N | all SUCCESS; R,Z q=[] and direct residual sign 0; Z zero edge at index 0; T `EXACT_WHOLE_ROLL_TIE`; N `EXACT_UNIQUE_PROPER_ROTATION` with s>0; kernels equal pins; fixtures generic |

G-group method PASS = the unchanged runner's own unittest verdict for that method (as in G-C1). G-group PASS additionally requires its final reference reconciliation verdict `ALL_STREAMS_RECONCILED_OR_DECLARED`, no quarantine marker, and the external R2 reconciler exit 0 (no `UNEXPLAINED` row). Historical P0A3G counts (111 events / 222 streams) are context only, not a criterion.

## 4. R2-H01 … R2-H06 — supplementary prospective challenges (code: `R2_HOLDOUT_CHALLENGES.py`)
All four geometric fixtures: integer coordinates as `[n,"1"]`, `OPEN_INTERVAL`, `ordered`, `INDEPENDENT_GENERIC`, endpoints `[0,len-1]`, request schema/lane/authority/limits copied from fixture R; each runs `supervisor.run` in mode TEST_AUTHORITY with a fresh post-release test key `r2-test-key-A`. A method PASSES only if **every** listed check is true; any exception = FAIL.

| ID | Construction | Required outcome (all must hold) |
|---|---|---|
| **R2-H01** proper-turn translation | A `[(0,0),(2,0),(2,1)]`; B `[(5,7),(5,9),(4,9)]` = `J(A)+(5,7)`; run `R2_H01` | state `ENGINEERING_EXACT_CERTIFICATE_CANDIDATE_UNVALIDATED`; authority `NON_PRODUCTION_TEST_AUTHORITY_VERIFIED`; `LOADED_CODE_IDENTITY_UNVERIFIED`; reference check `ORIGINAL_INPUT_EXACT_RECOMPUTATION_AND_DIRECT_RESIDUAL`; certificate and reference `roll_state` `EXACT_UNIQUE_PROPER_ROTATION`; **`q == []` (exact qO = 0)**; decision signs `s`=+1, `one_minus_s`=0, `direct_residual_minus_q2`=0; supervisor `ALL_WORKER_STREAMS_RECONCILED`; external and reference reconcilers all MATCH for the run |
| **R2-H02** zero edge / subdivision | A `[(0,0),(2,0),(2,2)]`; B `[(0,0),(0,0),(1,0),(2,0),(2,2)]`; run `R2_H02` | all H01 checks, plus B `zero_edges == [{edge_index:0, EXACT_ZERO_CONSECUTIVE_EDGE}]` and A `zero_edges == []` |
| **R2-H03** all-roll tie | A `[(-1,0),(0,0),(1,0)]`; B `[(0,1),(0,0),(0,1)]`; run `R2_H03` | SUCCESS/authority/check/stream items as H01; certificate and reference `roll_state` `EXACT_WHOLE_ROLL_TIE`; `s` sign 0 and `s == []`; rotation exactly identity `[[[[0,["1","1"]]],[]],[[],[[0,["1","1"]]]]]`; no unique optimum claimed; `a.variance` and `b.variance` signs +1; `direct_residual_minus_q2` = 0 |
| **R2-H04** reflected open bend (**corrigendum**) | A `[(0,0),(3,0),(3,1)]`; **B `[(0,0),(-3,0),(-3,1)]`** (third vertex **(-3,1)**, positive y; original `(-3,-1)` superseded); run `R2_H04` | SUCCESS/authority/check/stream items as H01; `roll_state` `EXACT_UNIQUE_PROPER_ROTATION`; **`q != []` (qO > 0)**; `s` = +1, **`one_minus_s` = +1**, `direct_residual_minus_q2` = 0; and three negative copies of the real certificate checked by the reference worker (`child('check')`), each **`CERTIFICATE_REJECTED`**, no score, streams MATCH: (i) zero score `q=[]`,`q_squared=[]`; (ii) reflection-as-rotation `rotation=diag(1,-1)`; (iii) incorrect score `q=1`. Any SUCCESS on (i)–(iii) → STOP_AND_QUARANTINE. Corrigendum values `alpha=-88/101`, `beta=27/101`, `s=sqrt(8473)/101`, `qO²=2-2·sqrt(8473)/101` are recomputed from input by the candidate reference checker (which must equal the certificate); the wrapper records the exact encodings (`alpha`,`beta`,`s`,`q`,`roots`) for independent QC and does not re-derive them itself. |
| **R2-H05** same-length stream tamper | fresh `supervisor.run(R)` in `R2_H05_source` → SUCCESS; take its `check` event (rc 0, non-empty stdout); copy event+stdout+stderr into `h05_copies/pristine/R2_H05_source/` and `h05_copies/tampered/R2_H05_source/`; in the tampered copy set stdout first byte `^= 0x01` (length unchanged), event record unchanged | fresh run SUCCESS with all streams MATCH; same length; exactly one byte differs; event identity equals pristine bytes; **external R2 reconciler**: pristine all MATCH, tampered stdout `EVIDENCE_STREAM_MISMATCH` with `BYTES_OR_SHA256`, never MATCH; reference reconciler: pristine MATCH, tampered stdout not MATCH (`BYTES_OR_SHA256`); production `reconcile_event`: pristine MATCH, tampered `EVIDENCE_STREAM_MISMATCH:STREAM_BYTES_MISMATCH:stdout`. Tampered accepted as MATCH → STOP_AND_QUARANTINE. Pristine/tampered digests and first bytes recorded |
| **R2-H06** test-authority scope tamper | fresh signed TEST_AUTHORITY envelope for R (run id `R2_H06`); tampered copy replaces the single canonical scope character in `"protocol_commit":"adacfdbc6efcca4922c8d087d029b67e9b0c5dc5"` → `…0dc4"` (same length, exactly one byte changed), signature not renewed | OpenSSL route and pure-Python RFC 8032 route each **accept the original** and **reject the tampered** bytes; full production and reference verifiers reject the tampered envelope with both the original receipt and a receipt re-bound to the tampered envelope (`CODE_IDENTITY_MISMATCH` / `IDENTITY_MISMATCH`); controller run with tampered authority → `CODE_IDENTITY_MISMATCH`, no score, no worker; the valid original authority run succeeds; reference worker checking that valid certificate under the tampered authority → `CODE_IDENTITY_MISMATCH`, no score, streams MATCH; no production/human authority claimed. Any acceptance → STOP_AND_QUARANTINE. Public key, trust store, both envelopes, signature and both receipts retained |

H-group PASS = 6/6 methods PASS, final external reconciliation of `H/…/raw_workers` with no `UNEXPLAINED` row, no quarantine marker, no private-key file left.

## 5. Attempt decision rule
`R2_DEV_01_ALL_20_PASSED_EVIDENCE_RECONCILED_PENDING_CHECKPOINTS` only if all 20 methods PASS, both runners exit 0, both external reconcilers exit 0, source locks unchanged after the run and no key files remain; any STOP marker → `P0A3G_R2_STOP_AND_QUARANTINE`; otherwise `P0A3G_R2_REPLICATION_FAILED_EVIDENCE_PRESERVED`. Final protocol status is decided only after R2-C2/R2-CFINAL verification and remains subject to independent QC.

## 6. Fault-injection register and interpretation
G group: exactly the historical simulated evidence faults (17 kinds), actual process faults and the harness `foreign_event_copy`, as recorded by the unchanged runner in `controller/registered_faults.json`; the external reconciler accepts a mismatch only when the event itself declares a `SIMULATED_EVIDENCE_FAULT` registered for that run directory and allowed to disturb that stream, or the run directory carries a registered `HARNESS:` fault. H group: **no** injected faults inside `raw_workers/`; the H05 byte flip is confined to `h05_copies/` and judged by its own rule above; H04/H06 mutations are certificate/authority data copies, not stream faults.

## 7. Known limits (declared before execution)
* The wrapper relies on the candidate reference checker for exact recomputation of alpha/beta/s/q; it does not independently zero-test tower expressions.
* H05 uses the same host and process; it tests detection, not durability against hostile filesystems.
* All test keys are ephemeral and non-production; no human-signed code authority exists.
* Static `ast.parse` of the three new R2 sources was performed for syntax only; nothing in R2 has been executed against the candidate.
