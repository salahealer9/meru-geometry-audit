# P0A3G-R2 — R2-C1 prospective lock (submitted for independent witness)  ·  NO R2 EXECUTION

**Status:** `P0A3G_R2_C1_PREEXECUTION_LOCK_SUBMITTED_FOR_EXTERNAL_WITNESS`. **R2-P2 and R2-P3 HAVE NOT BEGUN** and are blocked until a human-relayed release quoting this ZIP's independently verified SHA-256. Unsigned engineering evidence; not a DEV result, not QC.

| Path | Content |
|---|---|
| `candidate/` | the unchanged 51-file P0A3G candidate (extracted from signed G-CFINAL `8b0ec808…3a6a`; equal to signed G-C1 and its lock) |
| `lock/SOURCE_LOCK.json` | byte copy of the signed G-C1 lock (SHA-256 `abff7aa8…5902`) |
| `lock/R2_EXTERNAL_LOCK.json` | per-file lock of `r2_external/` (SHA-256 `a27aac41…89b6`) |
| `r2_external/` | `R2_HOLDOUT_CHALLENGES.py` (H01–H06), `R2_DRIVER.py` (single-attempt order/commands), `r2_stream_reconcile.py` (independent reconciler), `fixtures/R2_H0{1..4}.request.json` |
| `R2_TEST_CATALOGUE_LOCK.md` | 14 historical expectations copied verbatim from signed G-C1 + six H expectations (H04 per corrigendum), commands, order, pass rules, fault register |
| `ORIGINAL_P0A3G_DEV_CASES_PREDECLARED_from_signed_G-C1.md` | the signed G-C1 source of the 14 expectations (SHA-256 `12ee70df…7613`) |
| `R2_SCHEMA_POLICY_AND_STATUS_REQUIREMENTS.md` | input/record/authority schemas, key policy, statuses, budgets, reconcilers |
| `R2_PRE_RUN_CHRONOLOGY.md` | complete pre-run journal — **zero R2 candidate invocations** |
| `r2c0/` | R2-C0 receipt (identity and fresh-readback proof) and its ledgers: provenance, exposure register, environment declaration, host preflight, baseline verification, scope matrix |
| `protocol/` | signed R2 protocol and H04 corrigendum (blob-verified byte copies) |
| `r2_tools/` | agent-side verifier/builder used for checkpoints (no candidate imports) |

`SHA256SUMS` covers every member except itself (conventional self-hash exception); `PACKAGE_INVENTORY.json` lists every payload file. A separate human-readable `R2-C1_LOCK_RECEIPT.md` (outside this ZIP, since it states the ZIP's own SHA-256) accompanies delivery.
