"""P0A3G-R2 single-attempt driver for P0A3G_R2_DEV_01 (locked in R2-C1; NOT run before release).

usage (once, only after an exact human-relayed release citing the verified R2-C1 SHA-256):
  /usr/bin/python3.12 -I -S -B <extracted>/r2_external/R2_DRIVER.py \
      --release-sha <64-hex R2-C1 SHA-256 quoted in the human release> \
      --c1 <path to the R2-C1 ZIP re-retrieved after release> \
      --work <NEW directory, must not exist> \
      --repo-fixture /home/claude/P0A3G_R2/git/historical_g01_fixture_adacfdbc \
      --gnupghome /home/claude/P0A3G_R2/gnupg

Order (fixed, no choices): verify -> extract -> environment -> R2-G01..G14 (unchanged g_checks.py, once)
-> R2-H01..H06 (R2_HOLDOUT_CHALLENGES.py, once) -> external reconciliation of both groups -> post-run
source re-verification -> summary. No retry, no repair, no skipping H after a G failure.
"""
import hashlib, io, json, os, subprocess, sys, time, zipfile

PY = '/usr/bin/python3.12'
PINS = {'/usr/bin/python3.12': 'e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f',
        '/usr/bin/openssl': 'b4f547c0f16272d1cc7f870330a6f2c243710c335e7a99c734ff7a0c6fdb2503',
        '/usr/bin/python3.13': 'a35753ccb97941cce1467786cce892e608141f09d717188a3235d4f51a754446'}
FIXTURE_HEAD = 'adacfdbc6efcca4922c8d087d029b67e9b0c5dc5'
FPR = 'D4EC014EEFCC90E619D2AA59A91239ABCF512130'
G_ATTEMPT = 'P0A3G_R2_DEV_01'
H_ATTEMPT = 'P0A3G_R2_DEV_01_H'
G_TIMEOUT = 1800
H_TIMEOUT = 1800
METHOD_MAP = [('R2-G%02d' % i, n) for i, n in enumerate([
    'test_G01_signed_sources_archives_kernels_r1_qc', 'test_G02_nonempty_streams_captured_and_reread',
    'test_G03_fresh_forged_q_and_null_path_record', 'test_G04_r1_type_108_vs_zero_byte_mismatch',
    'test_G05_truncated_altered_missing_streams', 'test_G06_swap_duplicate_stale_wrong_worker_collision',
    'test_G07_interrupted_short_tamper_and_retrieved_archive', 'test_G08_actual_abnormal_exit_and_timeout',
    'test_G09_saved_verdict_ignored_fresh_check_within_8s', 'test_G10_genuine_8s_checker_timeout_resource_incomplete',
    'test_G11_test_only_signed_authority', 'test_G12_missing_unsigned_promoted_runtime_loaded_code',
    'test_G13_canonical_parser_and_reference_negatives', 'test_G14_generic_RZTN_relations_and_frozen_kernels'], start=1)]


def sha(b):
    return hashlib.sha256(b).hexdigest()


def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def args():
    a = sys.argv[1:]
    out = {}
    for i in range(0, len(a), 2):
        out[a[i].lstrip('-')] = a[i + 1]
    for k in ('release-sha', 'c1', 'work', 'repo-fixture', 'gnupghome'):
        if k not in out:
            raise SystemExit('MISSING_ARGUMENT ' + k)
    return out


A = args()
WORK = os.path.abspath(A['work'])
os.makedirs(WORK, exist_ok=False)
JOURNAL = []


def log(event, **kw):
    JOURNAL.append({'utc': utc(), 'event': event, **kw})
    with open(os.path.join(WORK, 'R2_DEV_JOURNAL.json'), 'w') as f:
        json.dump(JOURNAL, f, indent=1, sort_keys=True)


def stop(status, **kw):
    log('STOP', status=status, **kw)
    with open(os.path.join(WORK, 'R2_ATTEMPT_SUMMARY.json'), 'w') as f:
        json.dump({'status': status, **kw}, f, indent=1, sort_keys=True)
    print(status)
    sys.exit(2)


# 1. Release / archive identity -------------------------------------------------------------
c1 = open(A['c1'], 'rb').read()
log('release_check', release_sha=A['release-sha'], c1_bytes=len(c1), c1_sha256=sha(c1))
if sha(c1) != A['release-sha'].lower():
    stop('P0A3G_R2_PREDEV_LOCK_NOT_WITNESSED', reason='R2-C1 bytes do not match the released SHA-256')
z = zipfile.ZipFile(io.BytesIO(c1))
if z.testzip() is not None:
    stop('P0A3G_R2_STOP_AND_QUARANTINE', reason='R2-C1 CRC failure')
names = z.namelist()
if len(names) != len(set(names)) or any(n.startswith('/') or '..' in n.split('/') for n in names):
    stop('P0A3G_R2_STOP_AND_QUARANTINE', reason='unsafe or duplicate R2-C1 member names')
for line in z.read('SHA256SUMS').decode().splitlines():
    if line.strip():
        hh, n = line.split(None, 1)
        if n != 'SHA256SUMS' and sha(z.read(n)) != hh:
            stop('P0A3G_R2_STOP_AND_QUARANTINE', reason='R2-C1 SHA256SUMS mismatch ' + n)
# 2. Extract candidate/ and r2_external/ and verify both locks -------------------------------
for n in names:
    if n.startswith(('candidate/', 'r2_external/')) and not n.endswith('/'):
        p = os.path.join(WORK, n)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, 'wb') as f:
            f.write(z.read(n))


def tree_hashes(root):
    out = {}
    for base, _, fs in os.walk(root):
        for fn in fs:
            p = os.path.join(base, fn)
            with open(p, 'rb') as f:
                b = f.read()
            out[os.path.relpath(p, root).replace(os.sep, '/')] = {'bytes': len(b), 'sha256': sha(b)}
    return out


SRC_LOCK = json.loads(z.read('lock/SOURCE_LOCK.json'))['files']
EXT_LOCK = json.loads(z.read('lock/R2_EXTERNAL_LOCK.json'))['files']


def verify_locks(label):
    c = tree_hashes(os.path.join(WORK, 'candidate'))
    e = tree_hashes(os.path.join(WORK, 'r2_external'))
    ok_c = c == SRC_LOCK
    ok_e = e == EXT_LOCK
    log('source_lock_check_' + label, candidate_files=len(c), candidate_ok=ok_c, external_files=len(e), external_ok=ok_e)
    return ok_c and ok_e


if not verify_locks('pre_run'):
    stop('P0A3G_R2_STOP_AND_QUARANTINE', reason='extracted source differs from R2-C1 locks')
# 3. Environment ----------------------------------------------------------------------------
env_ok = True
for p, pin in PINS.items():
    got = sha(open(os.path.realpath(p), 'rb').read())
    log('binary_identity', path=p, sha256=got, pinned=pin, ok=got == pin)
    env_ok = env_ok and got == pin
fx = A['repo-fixture']
head = subprocess.run(['git', '-C', fx, 'rev-parse', 'HEAD'], capture_output=True, text=True).stdout.strip()
clean = subprocess.run(['git', '-C', fx, 'status', '--porcelain'], capture_output=True, text=True).stdout == ''
keyring = subprocess.run(['gpg', '--batch', '--with-colons', '--fingerprint'], capture_output=True, text=True,
                         env={'GNUPGHOME': A['gnupghome'], 'PATH': os.defpath}).stdout
log('g01_fixture', head=head, clean=clean, fingerprint_present=FPR in keyring)
env_ok = env_ok and head == FIXTURE_HEAD and clean and FPR in keyring
if not env_ok:
    stop('R2_ENVIRONMENT_UNQUALIFIED', reason='pinned binary, fixture checkout or keyring differs')
os.makedirs(os.path.join(WORK, 'G'))
os.makedirs(os.path.join(WORK, 'H'))
KG = os.path.join(WORK, 'controller_keys_G'); KH = os.path.join(WORK, 'controller_keys_H')
os.makedirs(KG, mode=0o700); os.makedirs(KH, mode=0o700)


def run(label, cmd, timeout):
    log(label + '_start', command=cmd)
    t0 = time.time()
    with open(os.path.join(WORK, label + '_runner.stdout'), 'wb') as so, open(os.path.join(WORK, label + '_runner.stderr'), 'wb') as se:
        try:
            rc = subprocess.run(cmd, stdout=so, stderr=se, cwd=WORK, timeout=timeout).returncode
        except subprocess.TimeoutExpired:
            rc = 'DRIVER_TIMEOUT_KILLED'
    with open(os.path.join(WORK, label + '_runner.exit'), 'w') as f:
        f.write(str(rc) + '\n')
    log(label + '_end', exit=rc, wall_seconds=round(time.time() - t0, 3))
    return rc


# 4. R2-G01..G14 then R2-H01..H06, each exactly once ------------------------------------------
log('FIRST_R2_CANDIDATE_INVOCATION')
g_rc = run('G', [PY, '-I', '-S', '-B', os.path.join(WORK, 'candidate/tests/dev_v0_9/p0a3g/g_checks.py'),
                 os.path.join(WORK, 'G', G_ATTEMPT), fx, A['gnupghome'], KG], G_TIMEOUT)
h_rc = run('H', [PY, '-I', '-S', '-B', os.path.join(WORK, 'r2_external/R2_HOLDOUT_CHALLENGES.py'),
                 os.path.join(WORK, 'H', H_ATTEMPT), os.path.join(WORK, 'candidate'), KH], H_TIMEOUT)
# 5. External reconciliation (independent code, separate processes) -------------------------
rec = {}
for label, root, aid in (('G', os.path.join(WORK, 'G', G_ATTEMPT), G_ATTEMPT), ('H', os.path.join(WORK, 'H', H_ATTEMPT), H_ATTEMPT)):
    reg = os.path.join(root, 'controller/registered_faults.json')
    cmd = [PY, '-I', '-S', '-B', os.path.join(WORK, 'r2_external/r2_stream_reconcile.py'), os.path.join(root, 'raw_workers'), aid,
           os.path.join(WORK, 'R2_EXTERNAL_RECONCILIATION_' + label)] + ([reg] if os.path.exists(reg) else [])
    rec[label] = run('RECONCILE_' + label, cmd, 600)
# 6. Post-run checks and summary ------------------------------------------------------------
src_ok = verify_locks('post_run')
keys_left = [f for d in (KG, KH) for f in os.listdir(d)]
per = {}
try:
    ev = json.load(open(os.path.join(WORK, 'G', G_ATTEMPT, 'evidence.json')))
    gsum = [o['value'] for o in ev['observations'] if o['name'] == 'attempt_summary'][-1]
    for rid, tname in METHOD_MAP:
        per[rid] = gsum['per_method'].get(tname, 'NOT_RUN')
except Exception as e:
    gsum = {'error': repr(e)}
    for rid, _ in METHOD_MAP:
        per[rid] = 'NO_EVIDENCE'
try:
    hl = json.load(open(os.path.join(WORK, 'H', H_ATTEMPT, 'H_evidence.json')))
    hsum = hl['summary']
    per.update(hsum['per_method'])
except Exception as e:
    hsum = {'error': repr(e)}
    for i in range(1, 7):
        per.setdefault('R2-H%02d' % i, 'NO_EVIDENCE')
quarantine = os.path.exists(os.path.join(WORK, 'G', G_ATTEMPT, 'STOP_AND_QUARANTINE.txt')) or \
    os.path.exists(os.path.join(WORK, 'H', H_ATTEMPT, 'STOP_AND_QUARANTINE.txt'))
passed = (len(per) == 20 and all(v == 'PASS' for v in per.values()) and g_rc == 0 and h_rc == 0
          and rec.get('G') == 0 and rec.get('H') == 0 and src_ok and not keys_left and not quarantine)
status = ('P0A3G_R2_STOP_AND_QUARANTINE' if quarantine else
          'R2_DEV_01_ALL_20_PASSED_EVIDENCE_RECONCILED_PENDING_CHECKPOINTS' if passed else
          'P0A3G_R2_REPLICATION_FAILED_EVIDENCE_PRESERVED')
summary = {'attempt': 'P0A3G_R2_DEV_01', 'status': status, 'per_method': per, 'methods_passed': sum(v == 'PASS' for v in per.values()),
           'methods_registered': 20, 'g_runner_exit': g_rc, 'h_runner_exit': h_rc, 'external_reconciliation_exit': rec,
           'source_unchanged_after_run': src_ok, 'private_key_files_left': keys_left, 'quarantine': quarantine,
           'g_summary': gsum, 'h_summary': hsum, 'release_sha': A['release-sha']}
with open(os.path.join(WORK, 'R2_ATTEMPT_SUMMARY.json'), 'w') as f:
    json.dump(summary, f, indent=1, sort_keys=True, default=str)
log('END', status=status)
print(json.dumps({k: summary[k] for k in ('status', 'methods_passed', 'g_runner_exit', 'h_runner_exit', 'external_reconciliation_exit')}, default=str))
sys.exit(0 if passed else 1)
