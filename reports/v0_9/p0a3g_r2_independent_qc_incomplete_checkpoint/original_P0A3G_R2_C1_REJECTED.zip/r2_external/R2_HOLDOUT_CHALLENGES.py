"""P0A3G-R2 supplementary prospective challenges R2-H01..R2-H06 (external to the 51-file candidate).

Locked in R2-C1 BEFORE any R2 execution. Runs ONCE, after R2-G14, only after an exact
human-relayed release citing the independently verified R2-C1 SHA-256.

usage (driver only):
  /usr/bin/python3.12 -I -S -B r2_external/R2_HOLDOUT_CHALLENGES.py <h_attempt_dir> <candidate_root> <controller_key_dir>

Uses the unmodified candidate (supervisor, identity, reference checker, authority fixture
constructors) through their public functions. It does not patch, monkeypatch or replace any
mathematical or identity logic. Mutations (H04 negative certificates, H05 byte flip, H06 scope
character) are applied only to copies of data, never to source or historical evidence.

H04 uses the signed corrigendum (commit 4b488825ed35c7ac91a19abe62be068e75e9a076):
  A=[(0,0),(3,0),(3,1)], B=[(0,0),(-3,0),(-3,1)]  (third B vertex has POSITIVE y).
"""
import copy, hashlib, json, os, shutil, sys, time, traceback
from pathlib import Path

ATTEMPT = Path(sys.argv[1]); CAND = Path(sys.argv[2]).resolve(); KEYDIR = Path(sys.argv[3])
HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(CAND / 'src'), str(CAND), str(CAND / 'tests/dev_v0_9/p0a3g')]
import authority_fixtures as af                                              # noqa: E402
from meru_geometry.v0_9.qo2d_exact import wire, identity, supervisor        # noqa: E402
from meru_geometry.v0_9.qo2d_exact import streamcapture as sc               # noqa: E402
from reference.v0_9.qo2d_exact import identity as refid, ed25519_ref        # noqa: E402
from reference.v0_9.qo2d_exact import stream_reconcile as refrecon          # noqa: E402

sys.path.insert(0, str(HERE))
import r2_stream_reconcile as extrecon                                       # noqa: E402

AID = ATTEMPT.name
FIXTURE_SHA = {'H01': '0807f2245f10dd3ebf819f2c9be1206587a4aa55cd0f4226163bf79f5cf898fa',
               'H02': '27eb835c52b82fca5ece073c9f9af9d527ad08b07d3ac1bfe9318a0a4bbb3977',
               'H03': '6623fb58d9ec0c2feef3b53a0a5160e6d7106fb7f37605c995f2606bf4b5c2b1',
               'H04': '27dfd8d50b9b0a59dd5b21ce532d9250bd42e050755effbd7f0b507db7c950e4',
               'R': 'a13c91344f52c34f470546670f9c8e3f1f7ac35a7f71ed802636ffd3c9f1e339'}
CHECK = 'ORIGINAL_INPUT_EXACT_RECOMPUTATION_AND_DIRECT_RESIDUAL'
ONE = [[0, ['1', '1']]]
IDENTITY_ROTATION = [[ONE, []], [[], ONE]]
REFLECTION_DIAG_1_M1 = [[ONE, []], [[], [[0, ['-1', '1']]]]]
EMPTY = hashlib.sha256(b'').hexdigest()
H06_OLD = b'"protocol_commit":"adacfdbc6efcca4922c8d087d029b67e9b0c5dc5"'
H06_NEW = b'"protocol_commit":"adacfdbc6efcca4922c8d087d029b67e9b0c5dc4"'


def h(b):
    return hashlib.sha256(b).hexdigest()


def enc(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False, default=repr).encode()


ATTEMPT.mkdir(exist_ok=False)
RUN = ATTEMPT / 'raw_workers'; RUN.mkdir()
CTRL = ATTEMPT / 'controller'; CTRL.mkdir()
COPIES = ATTEMPT / 'h05_copies'; COPIES.mkdir()
LEDGER = {'attempt': AID, 'lane': 'P0A3G_R2_SUPPLEMENTARY_H01_H06', 'bound_attempt': 'P0A3G_R2_DEV_01', 'methods': {}}
REGISTRY = {}   # run_dir -> injected faults (none expected inside raw_workers)
(CTRL / 'registered_faults.json').write_bytes(enc(REGISTRY))


def save():
    (ATTEMPT / 'H_evidence.json').write_bytes(enc(LEDGER))


def quarantine(label):
    (ATTEMPT / 'STOP_AND_QUARANTINE.txt').write_text('Forbidden acceptance: ' + label + '\n')
    raise AssertionError('STOP_AND_QUARANTINE ' + label)


def request(name):
    p = HERE / 'fixtures' / ('R2_%s.request.json' % name) if name != 'R' else CAND / 'tests/dev_v0_9/p0a3g/fixtures/R.request.json'
    b = p.read_bytes()
    if h(b) != FIXTURE_SHA[name]:
        raise AssertionError('FIXTURE_HASH_MISMATCH ' + name)
    return b


KEYS = {}


def keys():
    if not KEYS:
        KEYS['A'] = af.TestKey(KEYDIR, 'r2-test-key-A')
        KEYS['store'] = af.trust_store([KEYS['A'].public_record()], store_id='p0a3g-r2-h-controller-store')
        (CTRL / 'trust_store.json').write_bytes(KEYS['store'])
        (CTRL / 'NON_PRODUCTION_TEST_PUBLIC_KEYS.json').write_bytes(enc({
            'label': 'NON_PRODUCTION_TEST_AUTHORITY', 'generated_by': 'openssl genpkey -algorithm ed25519 (R2 H controller, after release)',
            'keys': [KEYS['A'].public_record()], 'trust_store_sha256': h(KEYS['store'])}))
    return KEYS


def bundle(raw, run_id):
    k = keys()
    env = af.envelope(CAND, raw, run_id, key_id='r2-test-key-A')
    sig = k['A'].sign(env)
    rec = af.receipt(env, run_id, 'TEST_AUTHORITY', sig, k['store'])
    return env, rec, sig, k['store']


def auth(b):
    env, rec, sig, trust = b
    return supervisor.Authority(env, rec, sig, trust, 'TEST_AUTHORITY', AID)


def signs(cert):
    return {d['label']: d['sign'] for d in cert['decisions']}


def ext_reconcile(run_rel):
    rows, summ = extrecon.reconcile(str(RUN), AID, REGISTRY)
    mine = [r for r in rows if r['run_dir'] == run_rel]
    return bool(mine) and all(r['status'] == 'MATCH' for r in mine), {'run_dir': run_rel, 'rows': len(mine),
                                                                      'statuses': sorted({r['status'] for r in mine})}


def ref_reconcile(run_rel):
    rows, _ = refrecon.reconcile_tree(refrecon.tree_from_dir(str(RUN)), expected_attempt_id=AID)
    mine = [r for r in rows if r.get('run_dir') == run_rel]
    return bool(mine) and all(r['status'] == 'MATCH' for r in mine)


def no_score(out):
    return 'certificate' not in out and 'score' not in out and 'q' not in out


def full_run(name, run_rel):
    raw = request(name)
    b = bundle(raw, run_rel)
    out = supervisor.run(raw, auth(b), RUN / run_rel)
    ok_ext, summ = ext_reconcile(run_rel)
    return raw, b, out, {'external_reconciler_all_match': ok_ext, 'external_summary': summ,
                         'reference_reconciler_all_match': ref_reconcile(run_rel)}


def common_success(out, rec):
    return {'state_success': out.get('state') == supervisor.SUCCESS,
            'test_authority_verified': out.get('authority_status') == 'NON_PRODUCTION_TEST_AUTHORITY_VERIFIED',
            'loaded_code_identity_disclosed': out.get('loaded_code_identity') == 'LOADED_CODE_IDENTITY_UNVERIFIED',
            'reference_independent_recomputation': out.get('verification', {}).get('details', {}).get('check') == CHECK,
            'streams_reconciled_by_supervisor': out.get('stream_evidence') == 'ALL_WORKER_STREAMS_RECONCILED',
            'streams_external_all_match': rec['external_reconciler_all_match'],
            'streams_reference_all_match': rec['reference_reconciler_all_match']}


def zero_score_unique(name, run_rel, extra=None):
    raw, b, out, rec = full_run(name, run_rel)
    c = out.get('certificate', {})
    sg = signs(c) if c else {}
    checks = common_success(out, rec)
    checks.update({'roll_state_unique': c.get('roll_state') == 'EXACT_UNIQUE_PROPER_ROTATION',
                   'reference_roll_state_unique': out.get('verification', {}).get('details', {}).get('roll_state') == 'EXACT_UNIQUE_PROPER_ROTATION',
                   'q_exactly_zero': c.get('q') == [],
                   's_positive': sg.get('s') == 1, 'one_minus_s_zero': sg.get('one_minus_s') == 0,
                   'direct_residual_equals_q2': sg.get('direct_residual_minus_q2') == 0})
    if extra:
        checks.update(extra(c))
    return checks, {'result_state': out.get('state'), 'reason': out.get('reason'), 'certificate_sha256': h(enc(c)) if c else None,
                    'roll_state': c.get('roll_state'), 'q': c.get('q'), 'q_squared': c.get('q_squared'), 'alpha': c.get('alpha'),
                    'beta': c.get('beta'), 's': c.get('s'), 'rotation': c.get('rotation'), 'decision_signs': sg, 'reconciliation': rec}


def H01():
    return zero_score_unique('H01', 'R2_H01')


def H02():
    return zero_score_unique('H02', 'R2_H02', lambda c: {
        'b_zero_edge_index_0': c['paths'][1]['zero_edges'] == [{'edge_index': 0, 'reason': 'EXACT_ZERO_CONSECUTIVE_EDGE'}],
        'a_no_zero_edge': c['paths'][0]['zero_edges'] == []})


def H03():
    raw, b, out, rec = full_run('H03', 'R2_H03')
    c = out.get('certificate', {})
    sg = signs(c) if c else {}
    checks = common_success(out, rec)
    checks.update({'roll_state_tie': c.get('roll_state') == 'EXACT_WHOLE_ROLL_TIE',
                   'reference_roll_state_tie': out.get('verification', {}).get('details', {}).get('roll_state') == 'EXACT_WHOLE_ROLL_TIE',
                   's_exactly_zero': sg.get('s') == 0 and c.get('s') == [],
                   'canonical_identity_witness': c.get('rotation') == IDENTITY_ROTATION,
                   'no_unique_optimum_claimed': c.get('roll_state') != 'EXACT_UNIQUE_PROPER_ROTATION',
                   'positive_rms_both': sg.get('a.variance') == 1 and sg.get('b.variance') == 1,
                   'direct_residual_equals_q2': sg.get('direct_residual_minus_q2') == 0})
    return checks, {'result_state': out.get('state'), 'reason': out.get('reason'), 'certificate_sha256': h(enc(c)) if c else None,
                    'roll_state': c.get('roll_state'), 'rotation': c.get('rotation'), 'q': c.get('q'), 'alpha': c.get('alpha'),
                    'beta': c.get('beta'), 's': c.get('s'), 'decision_signs': sg, 'reconciliation': rec}


def H04():
    raw, b, out, rec = full_run('H04', 'R2_H04')
    c = out.get('certificate', {})
    sg = signs(c) if c else {}
    checks = common_success(out, rec)
    checks.update({'roll_state_unique': c.get('roll_state') == 'EXACT_UNIQUE_PROPER_ROTATION',
                   'reference_roll_state_unique': out.get('verification', {}).get('details', {}).get('roll_state') == 'EXACT_UNIQUE_PROPER_ROTATION',
                   'q_strictly_positive_nonzero_encoding': c.get('q') not in (None, []),
                   's_positive': sg.get('s') == 1, 'one_minus_s_positive': sg.get('one_minus_s') == 1,
                   'direct_residual_equals_q2': sg.get('direct_residual_minus_q2') == 0})
    negatives = []
    if c:
        muts = []
        m = copy.deepcopy(c); m['q'] = []; m['q_squared'] = []; muts.append(('R2_H04_neg_zero_score', m))
        m = copy.deepcopy(c); m['rotation'] = REFLECTION_DIAG_1_M1; muts.append(('R2_H04_neg_reflection_as_rotation', m))
        m = copy.deepcopy(c); m['q'] = ONE; muts.append(('R2_H04_neg_incorrect_score_q_equals_1', m))
        for label, m in muts:
            d = RUN / label; d.mkdir()
            o = supervisor.child('check', d, raw, auth(b), m, events=[])
            if o.get('state') == supervisor.SUCCESS:
                quarantine(label)
            ok_ext, summ = ext_reconcile(label)
            negatives.append({'case': label, 'state': o.get('state'), 'reason': o.get('reason'), 'no_score': no_score(o),
                              'streams_external_all_match': ok_ext, 'streams_reference_all_match': ref_reconcile(label)})
    checks['negatives_all_certificate_rejected'] = len(negatives) == 3 and all(
        n['state'] == 'CERTIFICATE_REJECTED' and n['no_score'] and n['streams_external_all_match'] and n['streams_reference_all_match']
        for n in negatives)
    return checks, {'result_state': out.get('state'), 'reason': out.get('reason'), 'certificate_sha256': h(enc(c)) if c else None,
                    'roll_state': c.get('roll_state'), 'q': c.get('q'), 'q_squared': c.get('q_squared'), 'alpha': c.get('alpha'),
                    'beta': c.get('beta'), 's': c.get('s'), 'rotation': c.get('rotation'), 'roots': c.get('roots'),
                    'decision_signs': sg, 'reconciliation': rec, 'negatives': negatives,
                    'corrigendum_values_for_QC': {'alpha': '-88/101', 'beta': '27/101', 's': 'sqrt(8473)/101',
                                                  'qO^2': '2-2*sqrt(8473)/101',
                                                  'note': 'Not re-derived by this wrapper; the candidate reference checker recomputes from input and must equal the certificate. Encodings above are retained for independent QC evaluation.'}}


def H05():
    raw, b, out, rec = full_run('R', 'R2_H05_source')
    checks = {'fresh_run_success': out.get('state') == supervisor.SUCCESS,
              'fresh_run_streams_external_all_match': rec['external_reconciler_all_match']}
    src = RUN / 'R2_H05_source'
    evs = sorted(src.glob('w*.event.json'))
    target = None
    for p in evs:
        ev = json.loads(p.read_bytes())
        if ev.get('mode') == 'check' and ev.get('returncode') == 0 and ev['stdout']['bytes'] > 0:
            target = ev
    detail = {'fresh_run_state': out.get('state'), 'reconciliation': rec}
    if target is None:
        checks['target_check_stream_found'] = False
        return checks, detail
    checks['target_check_stream_found'] = True
    wid = target['worker_id']
    pristine = COPIES / 'pristine' / 'R2_H05_source'; tampered = COPIES / 'tampered' / 'R2_H05_source'
    for dst in (pristine, tampered):
        dst.mkdir(parents=True)
        for f in (wid + '.event.json', wid + '.stdout', wid + '.stderr'):
            shutil.copyfile(src / f, dst / f)
    original = (tampered / (wid + '.stdout')).read_bytes()
    altered = bytes([original[0] ^ 0x01]) + original[1:]
    (tampered / (wid + '.stdout')).write_bytes(altered)
    ev_t = json.loads((tampered / (wid + '.event.json')).read_bytes())
    checks.update({'same_length': len(altered) == len(original),
                   'exactly_one_byte_differs': sum(x != y for x, y in zip(original, altered)) == 1 and original[0] != altered[0],
                   'event_identity_unchanged': (ev_t['stdout']['bytes'], ev_t['stdout']['sha256']) == (len(original), h(original))})
    # 1) independent external reconciler (locked R2 code)
    rows_p, s_p = extrecon.reconcile(str(COPIES / 'pristine'), AID, {})
    rows_t, s_t = extrecon.reconcile(str(COPIES / 'tampered'), AID, {})
    out_t = [r for r in rows_t if r['stream'] == 'stdout']
    checks['external_pristine_all_match'] = bool(rows_p) and all(r['status'] == 'MATCH' for r in rows_p)
    checks['external_tampered_stdout_EVIDENCE_STREAM_MISMATCH'] = (len(out_t) == 1 and out_t[0]['status'] == 'EVIDENCE_STREAM_MISMATCH'
                                                                  and 'BYTES_OR_SHA256' in out_t[0]['problems'])
    checks['external_tampered_never_match'] = not any(r['status'] == 'MATCH' and r['stream'] == 'stdout' for r in rows_t)
    # 2) candidate reference reconciler (separate route)
    rr_p, _ = refrecon.reconcile_tree(refrecon.tree_from_dir(str(COPIES / 'pristine')), expected_attempt_id=AID)
    rr_t, _ = refrecon.reconcile_tree(refrecon.tree_from_dir(str(COPIES / 'tampered')), expected_attempt_id=AID)
    checks['reference_pristine_all_match'] = bool(rr_p) and all(r['status'] == 'MATCH' for r in rr_p)
    checks['reference_tampered_stdout_not_match'] = any(r['stream'] == 'stdout' and r['status'] != 'MATCH' and 'BYTES_OR_SHA256' in r['problems'] for r in rr_t)
    # 3) production capture-boundary re-read (separate route)
    ctx = {k: target[k] for k in ('attempt_id', 'run_dir_id', 'receipt_run_id', 'envelope_sha256', 'receipt_sha256',
                                  'trust_store_sha256', 'policy_sha256', 'interpreter_sha256', 'worker_source_sha256', 'code_files_sha256')}
    prod = {}
    for label, d in (('pristine', pristine), ('tampered', tampered)):
        try:
            sc.reconcile_event(d, ev_t, context=ctx, cap=supervisor.POLICY['stream_capture_bytes'])
            prod[label] = 'MATCH'
        except sc.EvidenceMismatch as e:
            prod[label] = 'EVIDENCE_STREAM_MISMATCH:' + e.reason
    checks['production_pristine_match'] = prod['pristine'] == 'MATCH'
    checks['production_tampered_EVIDENCE_STREAM_MISMATCH'] = prod['tampered'].startswith('EVIDENCE_STREAM_MISMATCH:STREAM_BYTES_MISMATCH:stdout')
    if any(r['status'] == 'MATCH' and r['stream'] == 'stdout' for r in rows_t) or prod['tampered'] == 'MATCH':
        quarantine('R2_H05 tampered stream accepted as MATCH')
    detail.update({'worker_id': wid, 'pristine_sha256': h(original), 'tampered_sha256': h(altered), 'bytes': len(original),
                   'first_byte_before': original[0], 'first_byte_after': altered[0],
                   'external': {'pristine': s_p, 'tampered': s_t, 'tampered_stdout_row': out_t},
                   'production_reconcile_event': prod})
    return checks, detail


def H06():
    raw = request('R')
    k = keys()
    env, rec, sig, trust = bundle(raw, 'R2_H06')
    canon = wire.request(raw)[1]
    if env.count(H06_OLD) != 1:
        return {'scope_field_located_once': False}, {}
    tam = env.replace(H06_OLD, H06_NEW)
    diff = [i for i, (x, y) in enumerate(zip(env, tam)) if x != y]
    checks = {'scope_field_located_once': True, 'same_length': len(tam) == len(env), 'exactly_one_character_changed': len(diff) == 1}
    checks['openssl_accepts_original'] = identity.openssl_verify(k['A'].public, env, sig) is True
    checks['reference_ed25519_accepts_original'] = ed25519_ref.verify(k['A'].public, env, sig) is True
    checks['openssl_rejects_tampered'] = identity.openssl_verify(k['A'].public, tam, sig) is False
    checks['reference_ed25519_rejects_tampered'] = ed25519_ref.verify(k['A'].public, tam, sig) is False
    rec_rebound = af.receipt(tam, 'R2_H06', 'TEST_AUTHORITY', sig, trust)
    full = {}
    for label, r in (('original_receipt', rec), ('receipt_rebound_to_tampered', rec_rebound)):
        try:
            identity.verify(tam, h(canon), r, sig, trust, mode='TEST_AUTHORITY'); p = 'ACCEPTED'
        except wire.Boundary as e:
            p = e.state
        try:
            refid.verify(tam, canon, r, sig, trust, mode='TEST_AUTHORITY'); q = 'ACCEPTED'
        except refid.IdentityMismatch:
            q = 'IDENTITY_MISMATCH'
        full[label] = {'production': p, 'reference': q}
        if p == 'ACCEPTED' or q == 'ACCEPTED':
            quarantine('R2_H06 tampered authority accepted (%s)' % label)
    checks['full_verifiers_reject_both_receipt_variants'] = all(v['production'] == 'CODE_IDENTITY_MISMATCH' and v['reference'] == 'IDENTITY_MISMATCH' for v in full.values())
    run = supervisor.run(raw, supervisor.Authority(tam, rec_rebound, sig, trust, 'TEST_AUTHORITY', AID), RUN / 'R2_H06_controller_tampered')
    checks['controller_rejects_before_any_worker'] = (run.get('state') == 'CODE_IDENTITY_MISMATCH' and no_score(run) and run.get('worker_events') == [])
    # A genuine valid certificate for the same input, checked by the independent reference worker under the tampered authority.
    good = supervisor.run(raw, auth((env, rec, sig, trust)), RUN / 'R2_H06_valid_source_run')
    checks['valid_original_authority_run_success'] = good.get('state') == supervisor.SUCCESS
    d = RUN / 'R2_H06_reference_worker_tampered'; d.mkdir()
    o = supervisor.child('check', d, raw, supervisor.Authority(tam, rec_rebound, sig, trust, 'TEST_AUTHORITY', AID), good.get('certificate'), events=[])
    if o.get('state') == supervisor.SUCCESS:
        quarantine('R2_H06 reference worker accepted tampered authority')
    checks['reference_worker_rejects'] = o.get('state') == 'CODE_IDENTITY_MISMATCH' and no_score(o)
    ok_ext, summ = ext_reconcile('R2_H06_reference_worker_tampered')
    checks['reference_worker_streams_external_all_match'] = ok_ext
    checks['no_production_authority_claim'] = all(x.get('authority_status') in (None, 'NON_PRODUCTION_TEST_AUTHORITY_VERIFIED') for x in (run, o, good))
    (CTRL / 'H06_original_envelope.json').write_bytes(env)
    (CTRL / 'H06_tampered_envelope.json').write_bytes(tam)
    (CTRL / 'H06_signature.bin').write_bytes(sig)
    (CTRL / 'H06_receipt_original.json').write_bytes(rec)
    (CTRL / 'H06_receipt_rebound.json').write_bytes(rec_rebound)
    return checks, {'changed_offset': diff, 'original_envelope_sha256': h(env), 'tampered_envelope_sha256': h(tam),
                    'signature_sha256': h(sig), 'public_key_hex': k['A'].public_hex, 'trust_store_sha256': h(trust),
                    'full_verifier_verdicts': full, 'controller_run': {'state': run.get('state'), 'reason': run.get('reason')},
                    'reference_worker': {'state': o.get('state'), 'reason': o.get('reason')}, 'reference_worker_reconciliation': summ}


METHODS = [('R2-H01', H01), ('R2-H02', H02), ('R2-H03', H03), ('R2-H04', H04), ('R2-H05', H05), ('R2-H06', H06)]

if __name__ == '__main__':
    t0 = time.time()
    try:
        for name, fn in METHODS:
            entry = {'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
            try:
                checks, detail = fn()
                entry.update(checks=checks, detail=detail,
                             verdict='PASS' if checks and all(v is True for v in checks.values()) else 'FAIL')
            except Exception:
                entry.update(verdict='FAIL', exception=traceback.format_exc())
                if (ATTEMPT / 'STOP_AND_QUARANTINE.txt').exists():
                    entry['verdict'] = 'STOP_AND_QUARANTINE'
            LEDGER['methods'][name] = entry
            save()
            print(name, entry['verdict'], flush=True)
            if entry['verdict'] == 'STOP_AND_QUARANTINE':
                break
    finally:
        if 'A' in KEYS:
            KEYS['A'].destroy()
        LEDGER['private_keys_destroyed'] = all(not p.name.endswith('.pem') for p in KEYDIR.iterdir()) if KEYDIR.exists() else True
        save()
    rows, summ = extrecon.reconcile(str(RUN), AID, REGISTRY)
    LEDGER['final_external_reconciliation'] = summ
    per = {n: LEDGER['methods'].get(n, {}).get('verdict', 'NOT_RUN') for n, _ in METHODS}
    passed = all(v == 'PASS' for v in per.values()) and summ['verdict'] == 'ALL_STREAMS_MATCH_OR_EXPLAINED' \
        and not (ATTEMPT / 'STOP_AND_QUARANTINE.txt').exists()
    LEDGER['summary'] = {'per_method': per, 'methods_passed': sum(v == 'PASS' for v in per.values()), 'methods_registered': 6,
                         'stream_reconciliation': summ['verdict'], 'quarantine': (ATTEMPT / 'STOP_AND_QUARANTINE.txt').exists(),
                         'h_group_passed': passed, 'wall_seconds': round(time.time() - t0, 3)}
    save()
    print(json.dumps(LEDGER['summary'], sort_keys=True))
    sys.exit(0 if passed else 1)
