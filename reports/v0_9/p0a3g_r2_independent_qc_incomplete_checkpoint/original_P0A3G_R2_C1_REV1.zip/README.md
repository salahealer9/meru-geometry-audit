# P0A3G-R2 — R2-C1-REV1 prospective lock candidate (submitted for independent witness)  ·  NO R2 EXECUTION

**Status:** `P0A3G_R2_C1_PREEXECUTION_LOCK_SUBMITTED_FOR_EXTERNAL_WITNESS`, for lock candidate **R2-C1-REV1**. **R2-P2 and R2-P3 HAVE NOT BEGUN.** They stay blocked until a human-relayed release quoting **this** ZIP's independently verified SHA-256. This is unsigned engineering evidence, not a DEV result and not QC.

**Why a revision.** The first R2-C1 lock (`P0A3G_R2-C1.zip`, SHA-256 `740da6990834846a579cc07dccdafcab23f147c5f00117c25505a1cbce847589`) was verified by the independent reviewer but **not released**, because of finding `R2_C1_W01`: the external driver launched H01–H06 unconditionally after G01–G14. REV1 changes **only** `r2_external/R2_DRIVER.py`, which now has a fail-closed G decision boundary, and the external documents that describe it. The first lock is preserved unchanged as historical evidence.

| Path | Content |
|---|---|
| `candidate/` | The unchanged 51-file P0A3G candidate (byte-identical to the rejected R2-C1, signed G-C1 and signed G-CFINAL) |
| `lock/SOURCE_LOCK.json` | Byte copy of the signed G-C1 lock (SHA-256 `abff7aa8…5902`), unchanged |
| `lock/R2_EXTERNAL_LOCK.json` | REV1 per-file lock of `r2_external/` (SHA-256 `2c8301fd…377b`). Only `R2_DRIVER.py` differs from the rejected lock `a27aac41…89b6`. |
| `r2_external/` | `R2_DRIVER.py` (REV1), plus these unchanged files: `R2_HOLDOUT_CHALLENGES.py` (H01–H06), `r2_stream_reconcile.py` and `fixtures/R2_H0{1..4}.request.json` |
| `R2_TEST_CATALOGUE_LOCK.md` | REV1. §2 gives the fixed order with the G decision boundary; §5 the decision rule (quarantine kept distinct from failure); §8 negative-state packaging. §3–§4 (the 20 expectations, H04 per the corrigendum) are byte-identical to the rejected lock. |
| `ORIGINAL_P0A3G_DEV_CASES_PREDECLARED_from_signed_G-C1.md` | Signed G-C1 source of the 14 expectations (SHA-256 `12ee70df…7613`), unchanged |
| `R2_SCHEMA_POLICY_AND_STATUS_REQUIREMENTS.md` | Schemas, key policy, statuses, budgets and reconcilers. Adds the REV1 driver control-flow records. |
| `R2_PRE_RUN_CHRONOLOGY.md` | Complete pre-run journal for both lock candidates: **zero R2 candidate invocations** |
| `review/` | The independent pre-witness review (negative, `R2_C1_W01`), the rejected lock's two receipts, and the exact driver correction diff |
| `r2c0/` | R2-C0 receipt and ledgers (provenance, exposure register, environment, host preflight, baseline verification, scope matrix), unchanged |
| `protocol/` | Signed R2 protocol and H04 corrigendum (blob-verified byte copies), unchanged |
| `r2_tools/` | Agent-side verifier and builder (no candidate imports), unchanged |

`SHA256SUMS` covers every member except itself (the conventional self-hash exception). `PACKAGE_INVENTORY.json` lists every payload file. A separate human-readable `R2-C1-REV1_LOCK_RECEIPT.md` accompanies delivery outside this ZIP, since it states the ZIP's own SHA-256.
