# P0A3G-R2 — Claude engineering handoff: signed corrigendum, PRE-EXECUTION ONLY, mandatory R2-C1 STOP

**Programme:** Meru Geometry Audit v0.9 — Hebrew projection specificity and effective-viewing-capacity research line  
**Date:** 2026-10-21  
**Repository:** `salahealer9/meru-geometry-audit`  
**Protected branch:** `hebrew-projection-capacity-v0.9`  
**This handoff's sole permitted engineering objective:** carry out R2-P0 and R2-P1, produce durably verified **R2-C0** and **R2-C1**, deliver original bytes to the human, then **STOP**.  
**No R2 test/worker/candidate invocation is authorized in this handoff.** A separate human relay of a byte-specific independent reviewer release is required for R2-P2/P3.

## 1. Binding signed authority: read BOTH complete documents from GitHub

The user has human-GPG-signed and pushed two additive protocol objects; both must be retrieved, read completely, checked by exact immutable commit/blob and interpreted together. The later corrigendum supersedes **only H04**, nothing else.

1. **Main R2 preregistration**, signed commit `7de01ab2c90afe52dd763652a9eaffd2e9a2cff9`, direct parent `0e86df64e30d081065bbeb75b6f53391e287f8f3`, one added file:
   `docs/v0_9/p0a3g_r2_prospective_replication_and_independently_witnessed_source_lock_protocol_2026_10_21.md`
   - Git blob `01cbd34f9000c50eb6810dcfd8d4dd27b6312992`.
2. **H04 mathematical corrigendum**, signed commit and current protected-branch HEAD `4b488825ed35c7ac91a19abe62be068e75e9a076`, direct parent **the main R2 commit** `7de01ab2c90afe52dd763652a9eaffd2e9a2cff9`, one added file:
   `docs/v0_9/p0a3g_r2_h04_exact_geometry_corrigendum_2026_10_21.md`
   - Git blob `780fc70a11081fda4fa2aedc56bb2cab84e7fa3c`.
3. **Expected human signing fingerprint:** `D4EC014EEFCC90E619D2AA59A91239ABCF512130`.

Exact browser links (retrieval must still authenticate the Git objects, not merely trust rendered pages):

- `https://github.com/salahealer9/meru-geometry-audit/blob/7de01ab2c90afe52dd763652a9eaffd2e9a2cff9/docs/v0_9/p0a3g_r2_prospective_replication_and_independently_witnessed_source_lock_protocol_2026_10_21.md`
- `https://github.com/salahealer9/meru-geometry-audit/blob/4b488825ed35c7ac91a19abe62be068e75e9a076/docs/v0_9/p0a3g_r2_h04_exact_geometry_corrigendum_2026_10_21.md`

Verify: content/blob SHA-1 identity; each commit's true direct parent; the **one-file-only additive** scope of each; signed-commit object identities and GPG cryptographic signature against the pinned fingerprint; protected branch HEAD at `4b488825...`; signed predecessor lineage and v0.8 signed tag as registered. Separate **cryptographic GPG verification**, **GitHub's verification attestation**, and **human ownertrust**. Do not claim a check not actually performed. The draft-status headers in documents already human-signed are historical wording and must not be edited.

**HARD STOP:** Any mismatch, missing authority, unverified required baseline, or evidence of an R2 candidate invocation before the signed corrigendum requires preservation of the observation and `R2_STOP_AND_QUARANTINE`. Do not improvise another authority chain or silently continue.

## 2. Why this new lane exists: keep the historical negatives immutable

- **P0A3D:** independent exact abstract planar QO theorem verified and byte-frozen at `59eb47f7500d57866e4935822b78a555d3bcb515`. Valid scope: genuinely ordered finite open rational-vertex polygonal paths; exact planar arclength; separately centred/RMS-normalized paths; only proper planar rotation `SO(2)`; `qO=sqrt(2-2 sqrt(alpha^2+beta^2))` with signed alpha/beta convention, and all-roll tie if `alpha=beta=0`.
- **P0A3E:** original incomplete software preservation `8ed3b988f716229bc9aee97d41ded0f524371193`.
- **P0A3F:** original preregistration `1d38ea6f53b9266d853df887a66331c59e4fc3ae`, incident/R1 amendment `83b9e6dcd53b100c5ac8b081832e81659cd1884a`. Original lost DEV_01 remains transcript-only quarantined.
- **P0A3F R1:** signed independent negative QC preservation `d95c50ea96744ce266058c51f85fff320d1a27df`. Two original R1 stdout files for `forged_q`/`null_path_record` are zero bytes despite 108-byte nonempty stdout claimed by their original events. **Never backfill, reconstruct, amend or treat a same-hash stream from a different event as original R1 evidence.**
- **P0A3G:** signed protocol `adacfdbc6efcca4922c8d087d029b67e9b0c5dc5`, signed incomplete QC preservation `0e86df64e30d081065bbeb75b6f53391e287f8f3`. The previous agent disclosed four pre-G-C1 full-catalogue G01–G14 dry runs (first failure, then three passes), followed by `P0A3G_DEV_01` with 14/14 reported PASS. Independent QC retained useful raw-stream and test-signature evidence but classified **`P0A3G_PROSPECTIVE_DEV_LOCK_SEQUENCE_NOT_QUALIFIED`** and **`P0A3G_INDEPENDENT_QC_NOT_QUALIFIED`**. These five exposed past runs remain HISTORICAL; they are **not new R2 trials**.
- **R2:** an independently witnessed **prospective replication**, not a retroactive cure of G or R1, not a claim of first exposure to previously tested G01–G14.

The complete P0A3G baseline preserved in the Git repository at `0e86df64...` is:

`reports/v0_9/p0a3g_independent_qc_incomplete_checkpoint/original_P0A3G_G-CFINAL.zip`

- **Size:** `1,271,972` bytes.
- **SHA-256:** `8b0ec808ddea05d31422ad30308d3a5bbe8aaadb860cd613adf51bdcc9f33a6a`.
- **Archive:** 1,074 entries; 1,073/1,073 non-self `SHA256SUMS` and 1,072/1,072 inventory entries, CRC/safe paths required.
- The earlier frozen G-C1 ZIP is `219,223` bytes, SHA-256 `1209547e346fb1fe222b3abd387d63efb2d04aa5f34e3b84d9448ea26eadaaf0`. It and G-CFINAL define the original **51-file candidate source/test/schema/docs/fixture lock**.
- Historical original independent QC archive and all other signed evidence must remain unchanged, read-only.

**Frozen mathematical kernel SHA-256 values (respectively):**

1. `candidate/src/meru_geometry/v0_9/qo2d_exact/algebra.py` → `442065847937252db00d3f63b02184c15d57989f958f764c5c731cb385de6d2d`.
2. `candidate/src/meru_geometry/v0_9/qo2d_exact/core.py` → `37701d034d98725673240a881420892893906c70387f68432b5993f8557dd420`.
3. `candidate/reference/v0_9/qo2d_exact/arithmetic.py` → `72b3c37f02be65b2df7616a94e84601d66cf4af5b7a50e878724de647e5bf0ba`.

Historical locked runner and fixtures (within `candidate/`):

- `tests/dev_v0_9/p0a3g/g_checks.py` → SHA-256 `16c8d6d5a67bdf541fe4e48d6ddaf1ca938abf53099fb93bd8768e296cb5cf92`.
- `tests/dev_v0_9/p0a3g/authority_fixtures.py` → SHA-256 `6e2325a27bdee39d8b085bf8c5f2cdda92aeb090f0f52c1c505bee346a7027f2`.

Any source difference is a stopped **non-replication**, not permission to repair code within R2. Do not write to, commit, sign or push the Git repository. Use a clean, freshly named **isolated `P0A3G_R2/` directory outside the checkout**.

## 3. Exact pre-release boundaries — restrictive by design

**Permitted before R2-C1 external witness:** read-only Git/GPG verification, downloading/copying/extracting authenticated archives, ZIP/manifest/CRC/security inspection, static review of source text without candidate imports, hashing originals, OS/kernel/binary-version and executable hashing *without executing candidate code*, writing and inspecting new prospective wrapper/challenge **source text** outside `candidate/`, writing locked expected outcomes, packaging R2-C0 and R2-C1, uploading and **freshly retrieving** checkpoint bytes, independently rehashing those exact retrieved archive bytes.

**Forbidden before the independent reviewer witnesses R2-C1 and the human explicitly authorizes an exact hash:** ANY test run, including full or partial historical G01–G14, H01–H06, any dry run or smoke test, `unittest`, `pytest`, import of a candidate module, calling candidate parser/checker/reference, `runpy`, any worker subprocess, parser request, test-only Ed25519 signature check, mathematical preview using a candidate, geometry function invocation, or evaluation of the wrapper against candidate software. **Do not run even one candidate method.** An accidental invocation must be logged, preserved and cause `R2_PREDEV_PROTOCOL_BREACH_NOT_QUALIFIED`/STOP; relabeling it “dry” does not erase it.

There is **no permission to perform unregistered preparatory microtests**. Static source construction and text review are not candidate execution. Past P0A3G pre-lock dry runs must be in the exposure ledger, never repeated before R2-C1.

No historical Hebrew glyphs, charts, fonts, proxy shapes, targets, source extraction, candidate/null analysis, P0A4 validation, 3D/QH, G0/A/B cameras, physical shadow hypotheses, new optimization/threshold or mathematical theorem change. No human production private key; test-only keys are generated **only after** an eventual independent release.

## 4. R2-P0: exact intake, genuine host preflight, R2-C0

1. Verify both signed protocols, predecessor objects/lineage/tag, prior signed negative closeouts, preserved archive identities and actual 51-file locked source. Keep evidence immutable.
2. Reconstruct a pristine isolated `candidate/` only from verified `original_P0A3G_G-CFINAL.zip`; cross-check original G-C1 lock. Any copied stale workspace source must not silently supplant it.
3. **Historical fixture checkout:** unmodified G01 runner expects its `REPO` input at clean historical HEAD `adacfdbc6efcca4922c8d087d029b67e9b0c5dc5`. Set up a distinct clean read-only **detached** historical checkout exclusively as this G01 input, without altering the actual protected branch at `4b488825...`. Record Git object identity, cleanliness and fixture path. Do not modify `g_checks.py` to work around this requirement.
4. Record complete exposure chronology: four pre-lock old G full-suite dry runs, one old post-lock G DEV, and R1 negative QC, with all results distinctly historical.
5. Pin exact host environment *prospectively*: actual OS/kernel, Python interpreter path+version+binary hash, OpenSSL path+version+binary hash, resource controls, process handling, public authority identity and observed feasibility (without testing the candidate).

Preferred previous-G environment and comparison hashes:

- CPython **3.12.3**, `/usr/bin/python3.12 -I -S -B`, executable SHA-256 `e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f`.
- OpenSSL `/usr/bin/openssl`, executable SHA-256 `b4f547c0f16272d1cc7f870330a6f2c243710c335e7a99c734ff7a0c6fdb2503`.
- Locked `candidate/schemas/v0_9/p0a3g/resource_policy.json` SHA-256 `9b7221fcfb54dc313874c9873423001ae7856b3a1889f12b92f9638abd904e09`.
- Caps: checker/worker wall **8s**, CPU **6s**, memory **256 MiB**, file/stream **2 MiB**, `NOFILE=32`, concurrency 1, recursion 256, attempt disk **16 MiB**, request **64 KiB**; preserve all remaining policy fields verbatim.

A differing host/build is to be prospectively disclosed as `CROSS_HOST_REPLICATION_NOT_QUALIFIED`; no silent replacement of executable hashes or relaxing caps. Unsupported mandatory limits: `R2_ENVIRONMENT_UNQUALIFIED`, **STOP BEFORE DEV**.

**R2-C0 gate:** produce ZIP of signed Git/baseline identities, verification ledgers, negative history and exposure register, current host preflight, immutable source hash inventory, excluded-scope matrix and a dated, explicit **`NO_R2_EXECUTION_YET`** event chronology. Save through durable user-accessible storage (Claude artifact or other actual retrievable channel); retrieve into a **new empty location**, independently verify original vs fresh-readback *size/SHA-256*, ZIP CRC, safe paths, complete checksum manifest/inventory; document the locator and immutable checkpoint ID. No R2-C1 construction until R2-C0 passes. If it cannot be stored and retrieved: STOP.

## 5. R2-P1: create and independently deliver the 20-case R2-C1 lock (NO execution)

Re-use the original **51 bytes-identical locked candidate files**, including the exact old `g_checks.py`, `authority_fixtures.py`, mathematical kernels, reference code, schemas and docs. Keep all new scripts in a separate `r2_external/` (or similarly documented OUTSIDE-`candidate/`) source tree, along with their own prospective SHA-256 lock. Prepare the complete expected outcome, deterministic fixture constructors, request IDs, run order and commands; this is **text-only construction before external witness**.

### Historical methods R2-G01…R2-G14

The 14 already exposed methods are replayed **once only AFTER independent release**, in their frozen original order, from unchanged historical `candidate/tests/dev_v0_9/p0a3g/g_checks.py`, with G01 given the read-only detached **`adacfdbc...`** fixture checkout. Retain all original case definitions, expected statuses, budgets and historical in-band lane marker; bind the prospective run to external new attempt ID `P0A3G_R2_DEV_01` without editing the old source. Past dry runs do not count. The pre-lock catalogue must copy the existing 14 expectations from the signed G-C1 exactly, not reverse-engineer them from pass logs.

### Six supplementary independent R2 challenges — all mandatory and executed ONCE AFTER G14

Each challenge wrapper must be fully specified and locked **before execution**. R2-H04 below reflects the human-signed corrigendum, NOT the erroneous original wording.

| Method | Locked construction and required prospectively stated outcome |
|---|---|
| **R2-H01** | Ordered `A=[(0,0),(2,0),(2,1)]`, `B=[(5,7),(5,9),(4,9)]`. `B=J(A)+(5,7)`; exact unique SO(2) optimum and **`qO=0`**. Independent reference must recompute and accept the real certificate; streams reconcile. |
| **R2-H02** | `A=[(0,0),(2,0),(2,2)]`, `B=[(0,0),(0,0),(1,0),(2,0),(2,2)]`. Zero edge/subdivision does not change true ordered arclength; unique optimum, **`qO=0`**, valid certificate, streams reconcile. |
| **R2-H03** | `A=[(-1,0),(0,0),(1,0)]`, `B=[(0,1),(0,0),(0,1)]`. Positive RMS but `alpha=beta=s=0`; **`EXACT_WHOLE_ROLL_TIE`**, canonical identity witness, no false unique optimum. Endpoints coinciding in coordinate space do not close the registered open *parameter* interval. |
| **R2-H04 (CORRECTED)** | `A=[(0,0),(3,0),(3,1)]`, **`B=[(0,0),(-3,0),(-3,1)]`**. This is vertical reflection (the last B vertex is **`(-3,1)`**, with **positive y**, not the original **`(-3,-1)`**). Exact values: `alpha=-88/101`, `beta=27/101`, `s=sqrt(8473)/101`, **`qO^2=2-2 sqrt(8473)/101 > 0`**, unique proper SO(2) optimum; independent reference recomputes all, rejecting a zero score or reflection-as-rotation. |
| **R2-H05** | Create a fresh, successful worker stream after release, copy in a disposable R2-H05 directory, flip first byte with XOR `0x01` **without changing length**, retain original event identity. Independently require `EVIDENCE_STREAM_MISMATCH` (or equivalent typed failure), never success; preserve pristine/tampered bytes and original/altered digests. |
| **R2-H06** | Create fresh signed **test-only** caller authority after release, preserve original signed bytes, mutate one canonical scope character without re-signing. Both independently performed OpenSSL and pure-Python reference signature verification must reject; no completed certificate or claim of production authority. |

**AUTHORITATIVE H04 COORDINATES (signed corrigendum):** `A=[(0,0),(3,0),(3,1)]`; **corrected** `B=[(0,0),(-3,0),(-3,1)]` (the third vertex is `(-3,1)`, positive y). The **original erroneous** B was `[(0,0),(-3,0),(-3,-1)]` (third vertex `(-3,-1)`, negative y), a 180-degree rotation of A. There must be no ambiguity in the wrapper: copy the full corrected tuple directly from the signed corrigendum, which supersedes original R2 H04 only. All other challenges are unchanged.

### R2-C1 archive contents: all actually present, prospectively hashed

- Full untouched 51-file candidate source/test/reference/schema/docs/fixtures; comparison with signed original `G-CFINAL` and `G-C1`, with an exact `SOURCE_LOCK.json` listing per-file bytes, SHA-256 and required frozen kernel identities.
- All external supplementary challenge wrapper source (e.g. `R2_HOLDOUT_CHALLENGES.py`), deterministic fixtures and subprocess/independent-checker invocation specifications, schema adapters and expected status mapping; no generated test-only private keys.
- `R2_TEST_CATALOGUE_LOCK.md`: each R2-G01…G14 original expected outcome and H01…H06 expected outcome, exact commands, order, no optional/conditional candidate run choices and no adaptive post-outcome modification.
- Independent raw-stream/event reconciler(s) separate from source/producer identity implementation; complete original and proposed test input/record/authority schema requirements, fault-injection register, type taxonomy, terminal and resource budgets.
- R2-C0 immutable checkpoint identity, original historical exposure ledger, G01 historical checkout identity, actual host/sha resource preflight and full pre-run chronological journal showing **ZERO R2 candidate invocations**.
- README, `PACKAGE_INVENTORY.json`, `SHA256SUMS` with self-hash exception documented; all checksums complete, archive paths unique/safe; a separate human-readable **LOCK_RECEIPT** containing **file name, exact bytes, full SHA-256** and all 20 expected outcomes.
- Explicit record that R2-P2 and R2-P3 **HAVE NOT BEGUN** and are blocked pending independent witness.

**Durable R2-C1 gate:** publish the actual binary ZIP through a user-accessible route. If only base64 text is supported, publish the complete *unmodified* base64 and provide decode instructions plus exact binary digest. Re-read the published copy from a new empty directory, decode if applicable, verify exact byte size, SHA-256, ZIP CRC, safe paths, manifest/inventory and candidate source lock. Keep a separate durable register location and receipt for both C0 and C1. Do not rely solely on an attachment title or promise of a durable link.

## 6. STOP AND RETURN: do not start R2-P2 or R2-P3

After R2-C0 and R2-C1 are durably saved and **freshly verified**, **STOP ALL candidate execution** and send the human:

1. **The original R2-C0 and R2-C1 ZIPs**, either as actual downloadable bytes or complete base64 plus exact decoding instructions; filename, exact size and full 64-digit SHA-256 for each.
2. User-accessible immutable checkpoint/register locator(s) and fresh readback proofs (size/hash/CRC/manifest/inventory); point to the binary evidence, not just a summary.
3. Complete pre-run lock receipt containing 51-file source hash totals, SHA-256 of original reference source/candidate, complete 20-case expected-outcome lock, exact G01 detached checkout HEAD, selected Python/OpenSSL binary digests, resource budget, wrapper hashes and independent reconciliation script hashes.
4. A dated unambiguous attestation: **`ZERO R2 candidate imports, tests, geometry previews, parser requests, signed-fixture checks or worker launches BEFORE LOCK WITNESS`**, or disclose any exception and STOP with the truthful negative outcome.
5. **Status:** `P0A3G_R2_C1_PREEXECUTION_LOCK_SUBMITTED_FOR_EXTERNAL_WITNESS` (not a DEV pass, not a QC result).

The human then brings **the actual R2-C1 (and R2-C0) bytes here**, to the independent research chat. The independent reviewer checks those bytes and the full lock **without running the preregistered R2 catalogue**. Only an affirmative reviewer finding allows the human to relay an exact release, using the format:

`R2-C1 LOCK WITNESSED; SHA-256 <FULL VERIFIED 64-HEX R2-C1 HASH>; AUTHORIZE ONE P0A3G_R2_DEV_01`

**This message is an example, NOT the release.** No such release has been given. A generic “continue,” agent self-report, or R2-C1 self-readback is not sufficient. Do not treat the receipt as a permission to test.

After an actual byte-specific human release, the *same Claude conversation* may execute precisely ONE prospective attempt and independently preserve R2-C2/CFINAL under the existing signed protocol; it must record the exact release, never repair or retry within R2, and return everything for the independent research-chat QC. If the reviewer finds a C1 flaw, STOP with no DEV; preserve that rejected lock and submit a newly hashed corrected lock for fresh external witness, without running a candidate test.

## 7. Fail-closed outcome taxonomy

- Missing/wrong Git/GPG/protocol/ZIP/kernel authority or mathematical contradiction: `R2_STOP_AND_QUARANTINE`.
- Host cannot satisfy mandatory bounds: `R2_ENVIRONMENT_UNQUALIFIED`; stop before DEV.
- Unauthorized candidate invocation before external lock release: `R2_PREDEV_PROTOCOL_BREACH_NOT_QUALIFIED` / `P0A3G_R2_PROSPECTIVITY_BREACH`.
- No verified real R2-C1 external reviewer witness: `P0A3G_R2_PREDEV_LOCK_NOT_WITNESSED`.
- Inaccessible or nonretrievable checkpoint: `P0A3G_R2_ENGINEERING_INCOMPLETE`, preserve last validated checkpoint.
- After future authorized DEV only: one 20-case attempt, retained success/failure evidence; no automatic retries, speculative arithmetic or retroactive redescription.

The three frozen mathematical kernels, the signed historical negatives, P0A3G byte-locked source, the exact R2/H04 signed challenge, and **P0A4 NOT AUTHORIZED** are invariant. Work/Claude **shall not self-approve** and shall not ask another engineering agent to provide the independent QC. The separate research chat will do that verification.

**THIS HANDOFF ENDS AT THE R2-C1 LOCK GATE. NO R2 TEST EXECUTION AUTHORIZED YET.**
