# P0A3G-R2 — R2-C0 checkpoint (intake, baseline, exposure, host preflight)  ·  NO_R2_EXECUTION_YET

Unsigned working evidence under signed R2 protocol `7de01ab2c90afe52dd763652a9eaffd2e9a2cff9` and signed H04 corrigendum `4b488825ed35c7ac91a19abe62be068e75e9a076`.

| File | Content |
|---|---|
| `R2_SIGNED_PROVENANCE_LEDGER.json` | commits/parents/blobs/one-file scopes/GPG for R2, corrigendum and all predecessors; 25-commit lineage; v0.8.0 tag; historical G01 fixture checkout identity |
| `archive_verification/*.json` | size/SHA/CRC/paths/SHA256SUMS/inventory for original P0A3G G-C0, G-C1, G-C2, G-CFINAL and QC ZIP |
| `R2_BASELINE_SOURCE_VERIFICATION.json`, `R2_IMMUTABLE_SOURCE_HASH_INVENTORY.json`, `SOURCE_LOCK_from_signed_G-C1.json` | 51-file candidate identity (G-CFINAL = G-C1 = lock), kernels, runner, policy |
| `R2_EXPOSURE_REGISTER.md` | historical P0A3G smoke/dry/DEV runs and R1/G negatives; zero R2 runs |
| `R2_ENVIRONMENT_DECLARATION.md`, `R2_HOST_PREFLIGHT.txt` | prospective environment (same pinned binaries), budgets, gaps |
| `R2_SCOPE_EXCLUSION_AND_STOP_MATRIX.md` | scope, forbidden activity, stop statuses |
| `R2_PRE_RUN_CHRONOLOGY.md` | dated intake chronology — **NO_R2_EXECUTION_YET** |
| `protocol/` | byte copies of the two signed R2 documents (blob-verified), the signed P0A3G QC closeout, and the unsigned handoff |
| `signer_public_key_from_repo.asc`, `r2_tools/` | public key used for GPG checks; agent tools used (none import candidate code) |

The persistence locator and fresh-readback proof of this ZIP are recorded outside it (R2-C0 receipt, carried into R2-C1).
