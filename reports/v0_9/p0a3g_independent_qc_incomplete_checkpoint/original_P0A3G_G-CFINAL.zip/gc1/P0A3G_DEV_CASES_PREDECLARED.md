# P0A3G_DEV_CASES_PREDECLARED — prospective lock (written 2026-10-21, before any P0A3G DEV attempt)

**Authority:** human-signed P0A3G protocol `adacfdbc6efcca4922c8d087d029b67e9b0c5dc5` (blob `00a4e6ac85403f2a6e4704963a858d43faef136b`, parent `d95c50ea96744ce266058c51f85fff320d1a27df`). Generic engineering DEV only; no registered science, no historical target, no P0A0 replay, no optimizer or threshold tuning.
**Source lock:** `lock/SOURCE_LOCK.json` SHA-256 `abff7aa8df19f73e070d9f06ebd23334f8d98b45c1736d38399b845c69835902` (51 files under `candidate/`; 18 added, 8 modified, 25 unchanged vs R1-CFINAL; the three frozen kernels unchanged). Unified diff `lock/BASELINE_TO_REVISED.diff` (SHA-256 `8a36d34019294018f7bc96ae587b131408a32a869d8d8addbceecd7243c4824c`).

## 1. Locked files (SHA-256)
| File | SHA-256 |
|---|---|
| `tests/dev_v0_9/p0a3g/g_checks.py` (the 14-method catalogue and runner) | `16c8d6d5a67bdf541fe4e48d6ddaf1ca938abf53099fb93bd8768e296cb5cf92` |
| `tests/dev_v0_9/p0a3g/authority_fixtures.py` (caller-side fixture constructors) | `6e2325a27bdee39d8b085bf8c5f2cdda92aeb090f0f52c1c505bee346a7027f2` |
| `tests/dev_v0_9/p0a3g/fixtures/R.request.json` | `a13c91344f52c34f470546670f9c8e3f1f7ac35a7f71ed802636ffd3c9f1e339` |
| `tests/dev_v0_9/p0a3g/fixtures/Z.request.json` | `6aa75922ce9779e3fce3ebf2707775939e20a9710720549e886576a10f3eb27c` |
| `tests/dev_v0_9/p0a3g/fixtures/T.request.json` | `79d2c7df287980630eae3cb35fd812d142a0eeaf38907a302cbd22564eb697bc` |
| `tests/dev_v0_9/p0a3g/fixtures/N.request.json` | `9b04169226802386b26b48c34176b5730eab3b22c1606c99e98ea86b5a4dc6bd` |
| `src/.../streamcapture.py` | `47df55afdad912d41359acc2dffc459ee2ef16e5f0630fe2ba3ae4cbf2153c99` |
| `src/.../supervisor.py` | `82084a1f72d2d33274e32d16fa82efedc02b0676d3ecbfa9512b4cd27337f3e9` |
| `src/.../identity.py` | `77aef8baaaa53e2642e6b13bbff86ca74401e749c6835aadd823a6ce074f7076` |
| `src/.../worker.py` | `a1bfef43e493e347c3af4c344a32ea0072d3bed01b644d9cbe29dbdb36146c72` |
| `src/.../wire.py` | `a91710fd934e7b0ee0b560c5efec78922ea325121d8bad6dd3546114752a4452` |
| `reference/.../identity.py` | `9bb68f707bb1c3bf5802276408b8ad4800f2b2f78a502f9217ad704bba04aa24` |
| `reference/.../ed25519_ref.py` | `b00151fc739f8c7136cbedae7b7f8b4e3124d807ccbd208089694a7bf37f7356` |
| `reference/.../stream_reconcile.py` | `4e727d0481b5a5d6d3c36040c07bd8a7027f78c33b6db77b4831a473e71486ae` |
| `reference/.../service.py` | `e252fd65dd5c57e7c8300075e4d340cbae0c3f0b44fcb0535c0e6306c23ec50f` |
| `reference/.../checker.py` | `30edcae9e8421ba3c5887fe5517f012613582d27f95c0f45f1598a22a075cba0` |
| `reference/.../wire.py` | `9bfa0313379a05b55bb175648f468ce73de78b93f1014ec254f9a7740a5dbb19` |
| `schemas/v0_9/p0a3g/resource_policy.json` | `9b7221fcfb54dc313874c9873423001ae7856b3a1889f12b92f9638abd904e09` |
| frozen `src/.../algebra.py` / `src/.../core.py` / `reference/.../arithmetic.py` | `442065…6d2d` / `37701d…d420` / `72b3c3…f0ba` (P0A3D = P0A3E = R1) |

The four request fixtures are byte copies of R1-CFINAL `prerun_fixtures/{R,Z,T,N}.request.json` (generic paths, provenance `INDEPENDENT_GENERIC`). Envelopes, receipts, signatures and the trust store are constructed at run time by `authority_fixtures.py` from the locked tree; nothing about them is hand-edited.

## 2. Environment, process topology and budgets (prospective; see G-C0 `G0_ENVIRONMENT_DECLARATION.md`)
* Interpreter for runner, controller and every worker: `/usr/bin/python3.12 -I -S -B`, CPython 3.12.3, binary SHA-256 `e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f` (different build from R1's `a92f0f95…`; declared before DEV). Host Ubuntu 24.04.5, Linux 6.18.44, x86_64, 2 CPUs.
* External binaries: OpenSSL 3.0.13 `/usr/bin/openssl` SHA-256 `b4f547c0f16272d1cc7f870330a6f2c243710c335e7a99c734ff7a0c6fdb2503` (pinned in policy; production signature route and controller key generation/signing); git 2.43.0 and GnuPG 2.4.4 (G01 only, read-only, keyring with the signer's public key only, keybox SHA-256 `1736f6f6…9889`); `/usr/bin/python3.13` (G12 runtime-mismatch probe only).
* Topology: one runner process (unittest, single thread) acting as controller → one worker child at a time (`concurrent_workers` 1), own session/process group, stdin `/dev/null`, stdout/stderr pipes, env `PATH=/bin:/usr/bin`, `LC_ALL=C.UTF-8`. The production worker may spawn one `openssl` child inside its process group.
* Budgets (R1 values unchanged): worker wall **8 s**, CPU 6 s, address space 256 MiB (calibration 512 MiB), file size 2 MiB, open files 32, core 0, recursion 256, integer digits 5000, request 64 KiB, document/certificate 2 MiB, run directory 16 MiB. New P0A3G caps: stream capture 2 MiB per stream, drain 2 s after kill, signature verification 5 s, 64 events per run directory.
* Not enforced: whole-attempt disk ceiling (attempt observed ≈1–2 MB in pre-lock dry runs), cgroup memory, seccomp, controller-death containment.

## 3. Exact command (per attempt N ∈ {01,02,03})
```
cd /home/claude/p0a3g/dev/P0A3G_DEV_NN            # contains only the G-C1-extracted candidate/
/usr/bin/python3.12 -I -S -B candidate/tests/dev_v0_9/p0a3g/g_checks.py \
    attempt/P0A3G_DEV_NN /home/claude/salahealer9/meru-geometry-audit <GNUPGHOME> <controller_key_dir> \
    > runner.stdout 2> runner.stderr ; echo $? > runner.exit
```
Before running, every file under `candidate/` is re-hashed against `lock/SOURCE_LOCK.json`; any difference stops the attempt.

## 4. The 14 ordered methods (subcases stay inside their method)
| ID | Fixture constructor (as coded) | Expected outcome |
|---|---|---|
| G01 | Read-only: repo HEAD/parent/one-file diff/blob; `git verify-commit --raw` of P0A3G and parent; SHA-256 of the 7 signed archives; frozen kernels; in-memory recount of R1 QCF01 from R1-CFINAL | HEAD `adacfdbc…`, clean tree, VALIDSIG `D4EC…2130`; all pins equal; R1 37 events, mismatches exactly `forged_q`/`null_path_record` stdout 108→0 |
| G02 | `supervisor.run(R)` mode TEST_AUTHORITY, run `G02_R` | SUCCESS; 4 events; every stdout and stderr non-empty; independent plain re-read equals recorded bytes/SHA and capture witness; reference reconciler all MATCH; `NON_PRODUCTION_TEST_AUTHORITY_VERIFIED`; `LOADED_CODE_IDENTITY_UNVERIFIED`; checkpoint written |
| G03 | `child('check')` on G02's R certificate with `q=[[0,["1","1"]]]` (`G03_forged_q`) and `paths[0]=null` (`G03_null_path_record`) | `CERTIFICATE_REJECTED`, no score; complete non-empty streams, all MATCH. These are NEW events, not R1 bytes |
| G04 | (a) produce with actual `kill` + simulated `forge_stdout_108`; (b) forged-q check + simulated `zero_stdout_after_save`; (c) full run R with `zero_stdout_after_save` on check | (a),(b),(c) `EVIDENCE_STREAM_MISMATCH`; recorded 108/`23bcfd67…` vs saved 0/`e3b0c442…`; (c) no checkpoint, no certificate; reference rows `MISMATCH_DECLARED_SIMULATED_FAULT` with `BYTES_OR_SHA256` |
| G05 | full runs with simulated truncate/alter/delete stdout and stderr on check, and truncate stdout on produce (7 runs) | each `EVIDENCE_STREAM_MISMATCH`, no certificate, no checkpoint |
| G06 | after a clean `calibrate_check`, check with simulated `swap_streams`, `duplicate_path`, `stale_run`, `wrong_worker_path`, `path_collision`, `orphan_stream_file`; harness copy of a foreign G02 event into a new run dir; reuse of `G02_R` for a new run | each `EVIDENCE_STREAM_MISMATCH`; reuse → `CHECKPOINT_UNVERIFIED/NEW_DIRECTORY_REQUIRED` |
| G07 | full runs with simulated `before_rename`, `short_write`, `after_rename_tamper` on check; R1-contract checkpoint faults before_write…post_rename; resume from torn checkpoint; in-memory archives: good, outer-flipped, valid ZIP+manifest with one altered stream | runs `EVIDENCE_STREAM_MISMATCH`, no checkpoint, events `SIMULATED_EVIDENCE_FAULT` with process fault `NONE`; checkpoint faults raise; torn → `CHECKPOINT_UNVERIFIED`; archives: PASS / FAIL / FAIL |
| G08 | actual produce faults `exit`, `kill`, `partial_then_kill`, `memory`, `recursion`; full run R with actual `timeout` | INTERNAL_ERROR_NO_CERTIFICATE / UNKNOWN_TERMINATION ×2 / RESOURCE_INCOMPLETE ×2; timeout → RESOURCE_INCOMPLETE `CONTROLLER_WALL_TIMEOUT`, rc −9, ≥8 s; empty stdout recorded 0/`e3b0…`; partial non-UTF-8 bytes preserved verbatim; all streams MATCH; no certificate |
| G09 | copy G02 checkpoint with verification replaced by `UNTRUSTED_STALE_SAVED_VERDICT`; `resume` | SUCCESS, `FRESH_REFERENCE_RECOMPUTED`, fresh checker < 8 s, no controller timeout, all streams MATCH |
| G10 | copy G02 checkpoint; `resume` with actual checker `timeout` | `RESOURCE_INCOMPLETE/CONTROLLER_WALL_TIMEOUT`, rc −9, no certificate, streams MATCH |
| G11 | valid test authority via production (OpenSSL), reference (pure Python), and direct cross-checks; 14 negatives (wrong key, signer not in store, wrong scope, revoked, mode DEPLOYMENT, mode DEV_UNSIGNED, wrong parent, wrong protocol, wrong source hash, wrong input hash, wrong policy hash, wrong run, substituted trust store, signature bit flip); end-to-end wrong-key run and reference worker | valid accepted by both only in TEST_AUTHORITY; every negative rejected by **both** routes (any acceptance → STOP_AND_QUARANTINE); controller refuses before any worker; reference worker returns `CODE_IDENTITY_MISMATCH` with reconciled streams |
| G12 | missing authority; signature missing; trust missing; unsigned proposal presented as signed; test authority without signature; human-freeze claimed with test key; DEPLOYMENT; altered runtime digest; loaded-code attestation claimed; same valid authority under actual CPython 3.13; mutated loaded functions (production and reference); DEV_UNSIGNED fixture run | all rejected (both routes where applicable); DEV_UNSIGNED run succeeds only as `CALLER_OWNED_DEV_FIXTURE_UNSIGNED`, distinct from test authority, with `LOADED_CODE_IDENTITY_UNVERIFIED` |
| G13 | 8 raw parser negatives (production and reference) + 5 rational-grammar negatives; checker mutations: forged score, invalid nested path record, nonoptimal identity SO(2), forged tie, missing/duplicate knot, changed traversal, negative/forward/boolean root; equivalent-zero positive control | all negatives rejected with no score and reconciled streams (an accepted negative → STOP_AND_QUARANTINE); positive control SUCCESS |
| G14 | full runs R, Z, T, N | all SUCCESS; R,Z q=[] and direct residual sign 0; Z zero edge at index 0; T `EXACT_WHOLE_ROLL_TIE`; N `EXACT_UNIQUE_PROPER_ROTATION` with s>0; kernels equal pins; fixtures generic |

After the 14 methods the runner reconciles **every** event of the attempt with the independent reference reconciler against the registered-fault ledger and writes `STREAM_EVENT_RECONCILIATION.{csv,json}`. **Attempt PASS** requires 14/14 methods passed **and** no `MISMATCH_UNEXPLAINED`/unregistered row **and** no quarantine marker. A method's PASS never rests on ZIP checksums or runner summaries alone.

## 5. Allowed fault injection
Actual process faults: `exit`, `kill`, `partial_then_kill`, `timeout`, `memory`, `recursion` (worker). Simulated evidence faults: the 17 listed in the stream contract, each declared in its event record, refused in DEPLOYMENT. Harness fault: `foreign_event_copy` (G06), registered. Simulated checkpoint faults: R1's five atomic-save boundaries.

## 6. Stop rules
* STOP_AND_QUARANTINE (no further attempts, preserve reproducer): any accepted false/forged certificate or forbidden authority; frozen-kernel mismatch; signed-source mismatch in G01; prohibited input.
* An attempt fails if any method fails or any stream row is unexplained. Then: preserve the attempt, persist and verify G-C2, and only then consider one documented repair (diff retained) and a new attempt number. Maximum three attempts `P0A3G_DEV_01..03`.
* No change to this catalogue, its expected outcomes, fixtures, budgets, interpreter or policy after any DEV outcome; such a need is a STOP for new human-signed authority.
* `ENVIRONMENT_UNQUALIFIED` if the interpreter or OpenSSL binary identity changes.

## 7. Pre-lock development disclosure
Before this lock, implementation debugging ran smoke scripts and four full dry runs of the catalogue (`PRELOCK_DRYRUN_01..04`), which are **not DEV attempts**: 01 failed on a harness helper bug (wrong directory root in the per-run reconciler call, fixed); 02, 03 and 04 passed, 03 after tightening which streams a declared fault may disturb, 04 on the final tree. Their runner logs are in `prelock/`. No budget, interpreter or expected outcome was relaxed to obtain a pass.

## 8. Rights and information barrier
Inputs: four generic rational polygon fixtures and signed project archives only. No Hebrew glyph, chart, image, font proxy, historical target, candidate/null data, 3D/QH/camera material, P0A0 S00–S12 or P0A4 content. No researcher private key; only ephemeral non-production test keys, destroyed after each attempt; only public material retained. No repository writes.
