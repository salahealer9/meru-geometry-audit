import sys,json,shutil,time
from pathlib import Path
ROOT=Path('/home/claude/p0a3g/work/candidate')
sys.path[:0]=[str(ROOT/'src'),str(ROOT),str(ROOT/'tests/dev_v0_9/p0a3g')]
import authority_fixtures as af
from meru_geometry.v0_9.qo2d_exact import supervisor
raw=(ROOT/'tests/dev_v0_9/p0a3g/fixtures/R.request.json').read_bytes()
k=af.TestKey('/home/claude/p0a3g/scratch_keys','test-key-A')
try:
    trust=af.trust_store([k.public_record()])
    env=af.envelope(ROOT,raw,'SMOKE_R')
    sig=k.sign(env)
    rec=af.receipt(env,'SMOKE_R','TEST_AUTHORITY',sig,trust)
    auth=supervisor.Authority(env,rec,sig,trust,'TEST_AUTHORITY','SMOKE_ATTEMPT')
    d=Path('/home/claude/p0a3g/devlog/smoke_runs');shutil.rmtree(d,ignore_errors=True);d.mkdir()
    t=time.time();out=supervisor.run(raw,auth,d/'R');print('elapsed',time.time()-t)
    print(out['state'],out.get('reason'),out.get('authority_status'),out.get('stream_evidence'))
    for e in out['worker_events']:print(e['worker_id'],e['mode'],e['returncode'],e['stdout']['bytes'],e['stderr']['bytes'],e.get('reconciliation'),e['elapsed_ns']/1e9)
finally:k.destroy()
