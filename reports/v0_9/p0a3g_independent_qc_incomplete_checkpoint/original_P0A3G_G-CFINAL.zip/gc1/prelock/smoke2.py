import sys,json,shutil,time,copy
from pathlib import Path
ROOT=Path('/home/claude/p0a3g/work/candidate')
sys.path[:0]=[str(ROOT/'src'),str(ROOT),str(ROOT/'tests/dev_v0_9/p0a3g')]
import authority_fixtures as af
from meru_geometry.v0_9.qo2d_exact import supervisor
from reference.v0_9.qo2d_exact import stream_reconcile as rec
raw=(ROOT/'tests/dev_v0_9/p0a3g/fixtures/R.request.json').read_bytes()
k=af.TestKey('/home/claude/p0a3g/scratch_keys','test-key-A')
d=Path('/home/claude/p0a3g/devlog/smoke_runs2');shutil.rmtree(d,ignore_errors=True);d.mkdir()
try:
    trust=af.trust_store([k.public_record()]);env=af.envelope(ROOT,raw,'SMOKE_R');sig=k.sign(env)
    auth=supervisor.Authority(env,af.receipt(env,'SMOKE_R','TEST_AUTHORITY',sig,trust),sig,trust,'TEST_AUTHORITY','SMOKE2')
    out=supervisor.run(raw,auth,d/'R');print('R',out['state'])
    cert=out['certificate']
    for label,kw in [('kill_forge',dict(mode='produce',fault='kill',evidence_fault='forge_stdout_108')),('kill',dict(mode='produce',fault='kill')),
                     ('exit',dict(mode='produce',fault='exit')),('partial',dict(mode='produce',fault='partial_then_kill')),
                     ('zero_check',dict(mode='check',certificate=cert,evidence_fault='zero_stdout_after_save')),
                     ('collide',dict(mode='check',certificate=cert,evidence_fault='path_collision')),
                     ('beforeren',dict(mode='check',certificate=cert,evidence_fault='before_rename')),
                     ('short',dict(mode='check',certificate=cert,evidence_fault='short_write')),
                     ('stale',dict(mode='check',certificate=cert,evidence_fault='stale_run')),
                     ('wrongw',dict(mode='check',certificate=cert,evidence_fault='wrong_worker_path')),
                     ('swap',dict(mode='check',certificate=cert,evidence_fault='swap_streams')),
                     ('orphan',dict(mode='check',certificate=cert,evidence_fault='orphan_stream_file'))]:
        rd=d/label;rd.mkdir();ev=[]
        mode=kw.pop('mode');o=supervisor.child(mode,rd,raw,auth,events=ev,**kw)
        print(label,o['state'],o.get('reason'),[(e['stdout']['bytes'],e['stderr']['bytes'],e['returncode']) for e in ev])
    t=time.time();o=supervisor.child('produce',d/'kill',raw,auth,events=[],fault='timeout');print('timeout',o,time.time()-t)
    rows,summ=rec.reconcile_tree(rec.tree_from_dir(str(d)));print(json.dumps(summ))
    for r in rows:
        if r['status']!='MATCH':print(' ',r['run_dir'],r.get('worker_id'),r['stream'],r['status'],r['problems'])
finally:k.destroy()
