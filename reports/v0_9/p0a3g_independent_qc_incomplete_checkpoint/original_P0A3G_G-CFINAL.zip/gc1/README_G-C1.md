# P0A3G — G-C1 checkpoint (prospective lock before any DEV)

Unsigned working evidence under the human-signed P0A3G protocol `adacfdbc6efcca4922c8d087d029b67e9b0c5dc5`. Nothing here is a code-only freeze or QC.

| Path | Content |
|---|---|
| `candidate/` | full revised source (src, reference, schemas, tests incl. the 14-method harness, docs) of the isolated R1-CFINAL descendant; three frozen kernels byte-identical |
| `P0A3G_DEV_CASES_PREDECLARED.md` | the prospective 14-method catalogue, fixture constructors, expected outcomes, budgets, topology, command, stop rules, rights ledger |
| `lock/SOURCE_LOCK.json` | per-file bytes/SHA-256 of `candidate/` (51 files) |
| `lock/BASELINE_TO_REVISED_HASH_AND_DIFF.csv`, `lock/BASELINE_TO_REVISED.diff` | R1-CFINAL → P0A3G hashes and unified diff |
| `environment/` | G0 environment declaration/preflight and the locked resource policy |
| `prelock/` | pre-lock smoke scripts and dry-run runner logs (not DEV attempts) |
| `receipts/G-C0_RECEIPT.json` | G-C0 persistence and fresh-retrieval record |
| `tools/` | checkpoint builder/verifier and G0/lock scripts used outside the candidate |
