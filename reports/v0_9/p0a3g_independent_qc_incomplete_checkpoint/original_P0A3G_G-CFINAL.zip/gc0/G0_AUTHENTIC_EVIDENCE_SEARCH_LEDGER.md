# P0A3G G0 — Bounded authentic-evidence search ledger

**Date (UTC+01:00):** 2026-10-21
**Executor:** Claude (claude.ai session bound to Project "Meru Audit"); read-only search
**Target:** original R1 `P0A3F_R1_DEV_01` worker stdout bytes for events `forged_q/worker_0000` and `null_path_record/worker_0000`, whose contemporaneous event records state **108 bytes**, SHA-256 `23bcfd677effd3a3b5ff73bfce72328c0bd19148a79617be8b896a4e1d802807`, while the archived files are **0 bytes**, SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

## 1. Locations actually searched

| # | Location / channel | Method | Objects | Result |
|---|---|---|---|---|
| S1 | All 731 Git blobs reachable in the fetched history of `salahealer9/meru-geometry-audit` (branch `hebrew-projection-capacity-v0.9` to depth 400 incl. tags `v0.7.0`, `v0.8.0`), which include every signed archive (P0A3D/E, incident, R1-C0/C1/C2/CFINAL, R1 QC ZIP) | SHA-256 of every blob and of every member of every ZIP blob, recursing into nested ZIPs to depth 4 (48 ZIP containers opened) | 4,950 byte objects hashed in total (with S2/S3) | 16 digest hits, **none from the two target events** (see §2) |
| S2 | `/mnt/user-data/uploads/` (this session's user uploads) | same | 1 file (P0A3G handoff) | no hit |
| S3 | `/root/.claude/uploads/<session>/` (attached handoff copy) | same | 1 file | no hit |
| S4 | This user's past Claude conversations within this Project (`conversation_search`: "forged_q null_path_record stdout", "P0A3F_R1_DEV_01 raw_workers") | text search | — | no R1 material found (only an Aug-2026 v0.7/v0.8 audit chat summary) |
| S5 | claude.ai Project "Meru Audit" documents (`project_info`) | listing | 0 docs, 0 files | nothing to search |

Raw machine output: `G0_authentic_search_raw.json` (produced by `tools/authentic_search.py`).

## 2. Digest-equal bytes from OTHER events — NOT recovered evidence

Inside R1-C2 (Git blob `14b9a4ad…`) and R1-CFINAL (Git blob `b515af97…`), eight **different** hostile-checker events of the same R1 attempt retain stdout files of exactly 108 bytes with SHA-256 `23bcfd67…`: `boolean_mask`, `changed_traversal`, `duplicate_knot`, `forged_tie`, `forward_root`, `missing_knot`, `negative_root`, `nonoptimal_identity_SO2` (each `worker_0000_stdout.json`). Their content is the generic checker-rejection line
`{"reason":"EXACT_CERTIFICATE_OR_GRAMMAR_REJECTED","schema":"p0a3e-failure-1","state":"CERTIFICATE_REJECTED"}`.

**Classification: `DIGEST_EQUAL_BYTES_FROM_DIFFERENT_EVENTS — NOT ORIGINAL-EVENT PROVENANCE`.** Equality of digest shows that the *recorded* metadata for `forged_q` and `null_path_record` is consistent with the generic rejection message other events emitted; it does **not** establish that those two events' stdout bytes were ever written to, or preserved in, any retained file. These bytes were **not** copied, spliced or re-labelled, and no file in any signed archive was modified. This observation is offered to independent QC as a lead only; the R1 cause remains UNKNOWN.

## 3. Locations NOT searched (and why)

- **ChatGPT Library** (`/Meru Geometry and Hebrew/…`, where R1 receipts record `persistent_path`/`library_file_id`) — not reachable from this Claude session. NOT SEARCHED.
- **R1 Work controller transcripts / the `/workspace/scratch/255e4cd6766b/` sandbox** used by R1 — not accessible. NOT SEARCHED.
- Any OpenAI / GitHub infrastructure backups, the human's local disks or other devices — not accessible. NOT SEARCHED.

This search is bounded; it does **not** claim that all backups have been exhausted.

## 4. Outcome

`AUTHENTIC_ORIGINAL_R1_STDOUT_NOT_RECOVERED` within the bounded locations above. No distinct recovered-evidence artifact is created. R1's signed negative dispositions (`P0A3F_R1_DEV_01_RAW_WORKER_EVIDENCE_INCONSISTENT`, `R1_CFINAL_RAW_EVIDENCE_COMPLETENESS_NOT_QUALIFIED`, `P0A3F_R1_SOFTWARE_QUALIFICATION_INCOMPLETE`, `P0A3F_R1_INDEPENDENT_QC_NOT_QUALIFIED`) stand unchanged.
