# P0A3G G0 — Prospective environment and resource declaration (written BEFORE any G1/G2 engineering or DEV)

Measured data: `G0_ENVIRONMENT_PREFLIGHT.json` (from `tools/env_preflight.py`; no candidate code imported).

## R1 declared runtime vs this host

| Item | R1 (`intake/environment.json` in R1-CFINAL) | This P0A3G host |
|---|---|---|
| Command | `/usr/bin/python3 -I -S -B` | `/usr/bin/python3` here resolves to **CPython 3.13.16** — NOT compatible |
| Real path | `/usr/bin/python3.12` | `/usr/bin/python3.12` present |
| Version | CPython 3.12.3 (build Jul 15 2026, GCC 13.3.0) | CPython **3.12.3** (build Aug 31 2026, GCC 13.3.0), Ubuntu package `python3.12-minimal 3.12.3-1ubuntu0.17` |
| Binary SHA-256 | `a92f0f95e883390c7256b2e441484aac06b1002dbe1d924141a77c8d82f96223` | `e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f` — **DIFFERENT BUILD** |
| OS / kernel | Linux 6.18.55, glibc 2.39, x86_64 | Ubuntu 24.04.5, Linux 6.18.44-fc-v139, glibc 2.39, x86_64 |
| CPUs | 9 (`Cpus_allowed_list 0-8`) | 2 |
| Startup VmSize (-I -S -B) | 30,396 kB | ~15.8 MB |
| Seccomp / NoNewPrivs | 2 / 1 | 0 / 0 |
| Memory cgroup | v2, `memory.max` 8 GiB | v1 memory controller path present; limit file not readable |
| RLIMITs | AS/CPU/DATA unlimited; NOFILE 16384 | AS/CPU/DATA unlimited; NOFILE 20000 |

The exact R1 precondition (same interpreter path **and** same binary SHA) **cannot be achieved** on this host.

## Prospective declaration (binding for P0A3G G3/G4)

1. **Selected interpreter:** `/usr/bin/python3.12 -I -S -B`, real path `/usr/bin/python3.12`, binary SHA-256 `e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f`, CPython 3.12.3. Justification: identical language version (3.12.3) and Ubuntu packaging line as R1; only the build differs. `/usr/bin/python3` (3.13.16) is rejected because it changes the interpreter minor version.
2. **The resource policy is carried over unchanged** from R1 `schemas/v0_9/p0a3f/resource_policy.json` except the two interpreter-identity fields, which change prospectively to the values in item 1. In particular: worker wall **8 s** (the eight-second checker deadline is unchanged), worker CPU 6 s, worker memory 256 MiB, worker file 2 MiB, open files 32, concurrency 1, recursion 256, run disk 16 MiB, startup margin 64 MiB, all digit/term/vertex caps unchanged.
3. **No cap, deadline or interpreter may change after any DEV outcome is observed.** If the selected binary's identity changes during the session, the run fails closed `ENVIRONMENT_UNQUALIFIED`.
4. **Qualification limits declared now:** results bind only to this binary/host; not the R1 binary `a92f0f95…`; this host has 2 CPUs (wall-clock margin differs from R1), no seccomp/NoNewPrivs sandbox, and an unreadable memory cgroup limit. No claim of R1 same-binary replay is made. Cross-host and production-host qualification are NOT claimed.
5. G1 additions (raw-stream capture) will declare new, separately named stream/output caps in G3 **before** DEV; they do not alter any R1 cap.
