# P0A3G — G-C0 checkpoint (signed intake, authentic-evidence search, pinned environment)

**Unsigned working evidence.** Prepared 2026-10-21 by Claude under the human-signed P0A3G protocol (`adacfdbc6efcca4922c8d087d029b67e9b0c5dc5`, blob `00a4e6ac85403f2a6e4704963a858d43faef136b`). No Git writes; no engineering or DEV has been performed at the time this checkpoint is sealed.

| File | Content |
|---|---|
| `G0_SIGNED_PROVENANCE_REPORT.json` | commit/parent/blob/one-file-scope/GPG checks for P0A3G and predecessors; 22-commit lineage from v0.8.0; signed v0.8.0 tag; evidence-type distinctions |
| `signer_public_key_from_repo.asc` | the public key used (from repo P0A2 provenance JSON); fingerprint equals the pinned one |
| `archive_verification/*.json` | size/SHA/CRC/safe-path/manifest/inventory verification for R1-C0, C1, C2, CFINAL, R1 QC ZIP, P0A3E cumulative ZIP, P0A3F incident ZIP |
| `R1_QCF01_independent_recheck.json` | independent recomputation: 37 events / 74 stream identities / 72 match; exactly the two QCF01 stdout mismatches in both C2 and CFINAL |
| `G0_AUTHENTIC_EVIDENCE_SEARCH_LEDGER.md`, `G0_authentic_search_raw.json` | bounded search; original streams NOT recovered |
| `G0_ENVIRONMENT_PREFLIGHT.json`, `G0_ENVIRONMENT_DECLARATION.md` | measured host/interpreters; prospective different-build declaration |
| `G0_ISOLATED_BASELINE_INVENTORY.json` | R1-CFINAL candidate source hashes, import graph, frozen-kernel identity |
| `G0_SCOPE_AND_STOP_MATRIX.md` | scope, prohibitions, hard stops, gates |
| `G0_STATUS.json` | machine-readable G0 verdicts |
| `protocol/…` | byte copy of the signed P0A3G protocol (blob-verified) and the unsigned handoff as received |
| `tools/…` | every script used in G0 |

The persistence location and fresh-retrieval verification of this ZIP are, necessarily, recorded **outside** it (G-C0 receipt, carried into G-C1 and G-CFINAL).
