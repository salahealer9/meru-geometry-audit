# P0A3G — Work Execution Handoff
## Raw-Worker Evidence Closure and External-Trust Boundary Follow-Up

**Project:** Meru Geometry Audit, v0.9 — Hebrew projection specificity and effective-viewing-capacity programme  
**Date prepared:** 2026-10-21  
**Repository:** `salahealer9/meru-geometry-audit`  
**Branch:** `hebrew-projection-capacity-v0.9`  
**Execution mode:** new, isolated ChatGPT Work conversation in the same project/workspace  
**Authority:** the *already human-signed* P0A3G protocol, not this unsigned execution handoff  
**Agent repository authority:** **READ ONLY — NO COMMIT, NO PUSH, NO WRITES TO THE EXISTING GIT REPOSITORY**

> **Primary command:** Execute the signed P0A3G protocol, **G0–G6 in order**, as a prospective, narrowly scoped engineering follow-up. The protocol takes precedence over any summary or interpretation in this handoff. First read the complete source protocol directly from GitHub at its pinned commit. Do not execute DEV before verified durable checkpoints G-C0 and G-C1.

## 1. Exact signed authorization to authenticate before starting

| Item | Pinned identity |
|---|---|
| **P0A3G human-signed protocol commit** | `adacfdbc6efcca4922c8d087d029b67e9b0c5dc5` |
| **Required direct parent: signed R1 independent-QC incomplete preservation** | `d95c50ea96744ce266058c51f85fff320d1a27df` |
| **P0A3G protocol Git blob** | `00a4e6ac85403f2a6e4704963a858d43faef136b` |
| **Expected human signing fingerprint** | `D4EC014EEFCC90E619D2AA59A91239ABCF512130` |
| **Exact P0A3G protocol path** | `docs/v0_9/p0a3g_raw_worker_evidence_and_external_trust_followup_protocol_2026_10_21.md` |
| **P0A3G protocol browser URL** | `https://github.com/salahealer9/meru-geometry-audit/blob/adacfdbc6efcca4922c8d087d029b67e9b0c5dc5/docs/v0_9/p0a3g_raw_worker_evidence_and_external_trust_followup_protocol_2026_10_21.md` |

The user reports successful local `git verify-commit --raw` / `VALIDSIG`, `GOODSIG`, and `TRUST_ULTIMATE` for the expected fingerprint. A subsequent GitHub connector check confirmed that the remote feature branch equals the exact P0A3G commit, the protocol Git blob matches, and the preceding commit-to-P0A3G comparison contains **one added file and no changes to earlier files**. **The execution agent must still independently perform whatever Git object, signed-message and local-GPG validation its environment can support.** GitHub attestations, local owner-trusted GPG verification and unsigned archive hashes are distinct forms of evidence. An archived `DRAFT_NON_AUTHORIZING` banner is preserved pre-signing text; the verified signed commit provides authority and is not to be edited.

**Read completely, directly from GitHub, in this order where possible:**

1. New signed P0A3G protocol (commit and blob above).
2. Signed P0A3F R1 independent-QC incomplete closeout: commit `d95c50ea96744ce266058c51f85fff320d1a27df`, document `docs/v0_9/p0a3f_r1_independent_qc_incomplete_preservation_2026_10_21.md`, blob `bf1dacde71c5b3a0ac3919f070c1c57a74c4ce41`.
3. Original P0A3F signed protocol: commit `1d38ea6f53b9266d853df887a66331c59e4fc3ae`, blob `9530a75d2346752a093367aeac24e13c5d2d6fac`.
4. P0A3F signed evidence-loss and R1 recovery amendment: commit `83b9e6dcd53b100c5ac8b081832e81659cd1884a`, blob `9fd9fba6ca509e3fcb72c2227d226847d218b354`.
5. Signed P0A3E incomplete implementation preservation `8ed3b988f716229bc9aee97d41ded0f524371193`; signed P0A3D exact theorem result `59eb47f7500d57866e4935822b78a555d3bcb515`; full ordered predecessor lineage, signed v0.8 tag where accessible, relevant QC and original-source conditions.

**Hard stop before engineering** on missing/wrong signed authority, wrong direct parent/blob/signer, altered or unavailable mandatory archives, broken source/hash lineage or unacceptable rights/target contamination. Record exact verification outcomes and limitations, rather than declaring verification of signatures or blobs not actually checked.

## 2. Historical baselines and the bounded reason for P0A3G

### P0A3D — exact mathematics already frozen

The independently reviewed abstract theorem concerns two independently supplied, genuinely ordered, finite open planar polygonal paths with rational-coordinate vertices, true planar arclength, separate centroid/RMS normalization and proper rotations `SO(2)` only. For normalized paths A and B with `J(x,y)=(-y,x)`:

- `alpha = integral_0^1 B · A du`
- `beta = integral_0^1 B · J(A) du`
- `s = +sqrt(alpha^2 + beta^2)`
- `q_O = +sqrt(2 - 2s)`
- for `s>0`, unique optimal proper rotation `[[alpha/s,-beta/s],[beta/s,alpha/s]]`; for exact `s=0`, all proper rotations tie, with identity canonical.

This is an abstract exact theorem, **not** evidence of software qualification, historical Hebrew correspondence or a reconstructible published 3D FIRST HAND.

### P0A3E and R1 — original implementation evidence

- Original P0A3E cumulative implementation archive, signed preservation source: **968,965 bytes**, SHA-256 `1e73c2685bd4eb8fba89e4e8ea609e97c7b4716805e83c64af374a4265522ea8`.
- The P0A3F_RECOVERY_R1 *unsigned engineering candidate* is the **unqualified starting source** for P0A3G, drawn from its signed-preserved R1-CFINAL ZIP, not the basis for any claim of trusted deployment.
- Historical original `P0A3F_DEV_01` (without R1 prefix) remains transcript-only lost evidence and cannot be reconstructed or reclassified.
- R1's single new attempt `P0A3F_R1_DEV_01` reports 18/18 methods, but independent QC failed **QCF01**: 37 recorded worker events / 74 stream identities; only 72 identities match their files. `forged_q` and `null_path_record` records each declare **108 stdout bytes** with SHA-256 `23bcfd677effd3a3b5ff73bfce72328c0bd19148a79617be8b896a4e1d802807`, but both archived stdout files are **zero bytes**, with SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`. This is present in R1-C2 and R1-CFINAL, not just the latest wrapper. Cause unknown.
- Signed historical dispositions are permanent: `P0A3F_R1_DEV_01_RAW_WORKER_EVIDENCE_INCONSISTENT`, `R1_CFINAL_RAW_EVIDENCE_COMPLETENESS_NOT_QUALIFIED`, `P0A3F_R1_SOFTWARE_QUALIFICATION_INCOMPLETE`, `P0A3F_R1_INDEPENDENT_QC_NOT_QUALIFIED`.
- Further R1 gaps: **QCF02** no operational human-signed code authority or comprehensive loaded-code attestation; **QCF03** limited pinned-host process/host/input guarantees. Tests alone do not resolve these.

### Exact R1 evidence archives in the signed R1 closeout

All five are under `reports/v0_9/p0a3f_r1_independent_qc_incomplete_checkpoint/` in commit `d95c50ea96744ce266058c51f85fff320d1a27df`:

| Original preserved filename | SHA-256 |
|---|---|
| `original_P0A3F_RECOVERY_R1_R1-C0.zip` | `0487dcebb13e56cb49cb51886dae2ad0a673c023bf66b52084e7756a42c2f60d` |
| `original_P0A3F_RECOVERY_R1_R1-C1.zip` | `19b34f8d691e2ea3b127a6b2b8a16d4d9d5e925f47802094b4851b2c9644c812` |
| `original_P0A3F_RECOVERY_R1_R1-C2.zip` | `f18a32551d30b8b89f8eb85242e431c8fbb1cf213903aa5710da19fab8b320f7` |
| `original_P0A3F_RECOVERY_R1_R1-CFINAL.zip` | `6ec2b6e96234836d629398fb7fc781909de8b47b0bf80f5cae11202620ff2f15` |
| `original_P0A3F_RECOVERY_R1_INDEPENDENT_QC_2026-10-21.zip` | `aa810c66ac6454a1d04a30cc597612b61006bca0dc7d5c3340726efa4a6cf305` |

The source R1-CFINAL is expected to have **407/407 internal non-self SHA-256 manifest entries** and **406/406 inventory records**, plus CRC and safe unique file paths. **An internally valid ZIP is not proof of event-to-stream consistency.** Verify identities and *both* relevant original discrepant files rather than accidentally accepting the historical 18/18 summary.

**Byte-frozen kernels in the isolated descendant** (must match P0A3D and P0A3E byte-for-byte):

- `src/meru_geometry/v0_9/qo2d_exact/algebra.py`
- `src/meru_geometry/v0_9/qo2d_exact/core.py`
- `reference/v0_9/qo2d_exact/arithmetic.py`

**P0A3G sole objective:** prospectively produce verifiable raw-worker stream evidence and a strictly external, **non-production test-only** signed-authority verification interface. Do not reconstruct R1's missing bytes, declare R1 qualified or claim any real human-signed code-only freeze has occurred.

## 3. G0 — Signed intake, authentic-evidence search, pinned environment

Before engineering, perform independent Git/GPG and archive verification, confirm QCF01–QCF03, source/kernels, and create a **dated bounded authentic-evidence search ledger** listing the exact archives, Library paths, controller transcripts and accessible authorized backup channels actually searched for the original R1 `forged_q` and `null_path_record` 108-byte streams. If any authentic originals are located, preserve unchanged bytes, metadata and a rigorous original-event provenance explanation in a distinct artifact; never splice them into signed historical ZIPs or replace historical negative statuses. A newly produced 108-byte lookalike is not original evidence. Do not claim that inaccessible backups have been searched.

Preflight the interpreter, dependencies, binary identity, OS, startup import/memory footprint and resource limits. Where compatible, use R1's declared `CPython 3.12.3` runtime `/usr/bin/python3 -I -S -B`, selected executable binary SHA, and **8-second checker deadline**. If those exact preconditions cannot be achieved, record a prospective different-environment/limit justification and its explicit qualification limits **before DEV**; when an unsupported environment defeats mandatory requirements, fail closed `ENVIRONMENT_UNQUALIFIED` and stop. Never alter caps or interpreter opportunistically after inspecting results.

**G-C0 checkpoint — mandatory gate:** create, persist to a user-accessible durable Library or equivalent channel, and **freshly retrieve and verify** the full signed-provenance report, source/baseline archive hashes, bounded search ledger, environment/host preflight, scope/stop matrix and isolated baseline inventory. Record path, byte size, SHA-256, ZIP safety/CRC/manifest/inventory results and proof of fresh retrieval. **No development past G0** until this gate is complete. If persistence/retrieval fails: STOP; deliver last verified evidence and precise incomplete status.

## 4. G1 — Actual raw stream byte provenance, not inferred serialization

Implement narrowly in the isolated descendant a **single accountable supervisor capture boundary** for worker stdout and stderr. Preserve actual bytes captured (including empty/partial/binary/non-UTF8 streams, abnormal exits, process kills) under unique attempt/run/worker/stream IDs; do not generate alleged stdout bytes from JSON reserialization, cached parsed objects or expected fixtures.

After each worker completes, **freshly read the precise saved byte files** and recompute their length and SHA-256, then independently compare with the event metadata. Verify run identity, code/checker/schema/config/runtime identity, case and stream index, process status/exit/signal, and collision/staleness. On any mismatch, missing path, unexpected empty stream, swap, truncation, duplicate/orphan, altered post-write bytes or unverified retrieval: typed fail-closed `EVIDENCE_STREAM_MISMATCH` (or a clearly documented accurate non-success status), **no completed certificate and no passing DEV disposition**. Correctly record real empty streams with `0` and the actual empty-file digest.

Enforce prospective bounds on stream sizes, filenames/relative paths, output and disk use. Preserve atomic write / flush / fsync assumptions, immutable attempt directories and independent post-retrieval verification. Distinguish actual worker SIGKILL/timeout from simulated faults. Include R1-like forged *event metadata* stating 108 stdout bytes for a zero-byte saved file as a required negative case. **Do not modify original R1 evidence or record a repair of R1 itself.**

## 5. G2 — External expected authority with test-only signatures

Review and narrowly extend the external expected-manifest/caller-receipt/reference identity design. Define/test a strict, versioned, canonical caller-supplied authority envelope binding signed Git ancestry, proposed code/checker/parser/schema/config files, declared interpreter/resource envelope, canonical inputs and certificate identities.

Use a **separately controlled non-production test verification key** and corresponding **test-only signed fixture** in the bounded DEV harness to exercise actual cryptographic signature checking. Preserve only public key material and necessary verification transcripts in final evidence; never collect/export the researcher's actual private signing key or claim Work signed the project's source. Controller owns the verification policy; candidate cannot replace the trust root, set itself trusted or bypass the checker. Test wrong signer/key/scope/parent/hash/run, missing authority, unsigned proposal promoted as signed, wrong mode and altered runtime/code identity. No completed exact certificate may be issued after a failed trust check.

Label fixture `NON_PRODUCTION_TEST_AUTHORITY`. Retain `UNSIGNED_STAGING_PROPOSAL`, `CALLER_OWNED_DEV_FIXTURE` and **real human-signed code authority** as distinguishable states; successful mock/test-only verification **does not constitute** real deployment trust. Any unproven loaded runtime instruction integrity must remain `LOADED_CODE_IDENTITY_UNVERIFIED`. Do not claim comprehensive hostile-host guarantees or an already existing future human code-only freeze.

## 6. G3 — Prospective lock, fourteen immutable DEV methods, G-C1

**Before first DEV**, write and preserve `P0A3G_DEV_CASES_PREDECLARED.md`: complete fixture constructors, 14 exact ordered methods, expected pass/negative statuses, allowed fault injection, source/test/schema/config/fixture hashes, selected interpreter/binary/environment, full unified source diffs, process topology, wall/CPU/memory/output/file/disk/recursion/concurrency limits, exact commands, stop conditions and rights/information-barrier ledger.

The 14 **ordered mandatory** methods are the signed protocol's catalogue, not a suggested menu:

| ID | Required expected check |
|---|---|
| **G01** | Authenticate signed sources/archives, all frozen kernels and R1 QC; no old evidence changed. |
| **G02** | Capture actual nonempty worker stdout/stderr, independently re-read and match exact byte lengths/hashes. |
| **G03** | Fresh generic `forged_q` and `null_path_record` rejections yield authentic complete streams and no false certificate. |
| **G04** | Inject a purported 108-byte event versus real zero-byte saved stdout: detect `EVIDENCE_STREAM_MISMATCH` and deny success. |
| **G05** | Truncated, changed or missing stdout/stderr fails before completed checkpoint. |
| **G06** | Swapped/duplicated/stale-run/wrong-worker/colliding stream paths fail closed. |
| **G07** | Interrupted/short write, rename/tamper and unverified retrieved archive fail closed; distinguish actual versus simulated faults. |
| **G08** | Actual abnormal exit and process timeout preserve matching raw event evidence and no completed certificate. |
| **G09** | Saved-verdict recovery discards saved verdict and succeeds only after fresh independent checker within declared 8-second envelope. |
| **G10** | Genuine 8-second checker timeout is `RESOURCE_INCOMPLETE` with no successful certificate. |
| **G11** | Independently verify caller-supplied **test-only signed** authority in explicit test mode; reject wrong key/signer/mode/parent/hash. |
| **G12** | Missing, unsigned-promoted-to-signed, altered-runtime or loaded-code mismatch fails closed; honestly disclose unattested loaded instructions. |
| **G13** | Canonical bytes/parser/reference negative tests: forged score, invalid nested path and nonoptimal `SO(2)` witness rejected. |
| **G14** | R/Z/T/N generic exact geometry relations and frozen mathematical kernels preserved; no historical target work. |

Keep test subcases under their single registered method; do not artificially expand experiment count. If required tests are unsafe/not executable on the prospectively declared platform, retain explicit negative/`NOT_TESTED` and stop if mandatory completion is impossible. Never silently alter the prospective catalogue or post-result budgets to manufacture a PASS.

**G-C1 checkpoint — mandatory before DEV:** persist the **actual full revised source**, reference checker, schemas, test fixtures, test harness, prospective 14-method lock, code diff and environment/resource policy to a durable user-accessible destination. Independently re-retrieve and verify size, SHA-256, safe ZIP paths, CRC and internal manifest/inventory. **No G01 and no other DEV method until verified G-C1 exists.** Do not let an ephemeral workspace be the sole copy of new code or evidence.

## 7. G4 — Bounded DEV with independent raw stream reconciliation

Execute exactly the predeclared catalogue from the verified G-C1 source/test snapshots in an isolated directory. Number independent prospective attempts `P0A3G_DEV_01`, `P0A3G_DEV_02`, `P0A3G_DEV_03`; **maximum three**, and use fewer if complete. Never call the new attempt `P0A3F_R1_DEV_02` or overwrite any historical record.

For **every attempt**, retain untouched runner stdout/stderr/exit, all genuine raw worker stdout/stderr, event/stream identity ledgers, inputs, process exit/signal/timeout, ephemeral test-only key **public** metadata, call receipts, source/test/schema/config/budget hashes, and exact failure artifacts and repair diffs. Independently reconcile *every* stream event's saved bytes, length and SHA before claiming any method passed.

**G-C2+ mandatory gate after every attempt and separately after each distinct repair:** create a new immutable checkpoint, persist and freshly retrieve it from the user-accessible durable destination, verify exact ZIP size/digest, safe paths/CRC/manifest/inventory and full stream-versus-event reconciliation **before** another source modification, repair or DEV attempt. Retain old attempts permanently; failed evidence is evidence. A substantive change to locked cases/environment/policy requires STOP and new human-signed authorization, not an unregistered rerun.

Immediate hard stop/quarantine on accepted mathematically false exact certificate, broken external trust bypass, prohibited scientific input, frozen-kernel issue or signed-source mismatch. Correct operational problems only within signed scope and retained chronological evidence.

## 8. G5 — Cumulative candidate and verified G-CFINAL

Create an **unsigned, complete, self-contained cumulative ZIP** outside the live checkout including at minimum:

- All full revised production and distinct reference source, preserving three exact mathematical kernels byte-for-byte; exact baseline-to-revised hashes and unified diffs; canonical schemas/config and production/reference import/trust dependencies.
- Git/GPG/ZIP verification matrix and R1 original immutable QC references; G0 bounded authentic-evidence search ledger and precise status of anything actually recovered.
- Full G-C0/G-C1/G-C2+ identity/size/hash/retrieval records and actual checkpoint artifacts or independently available durable references sufficient for complete audit.
- Exact 14-method pre-DEV catalogue with fixture constructors/hashes, locked environment and resource policy, all attempt-numbered chronological DEV histories, complete runner/worker stdout and stderr bytes, identity/event metadata, source/test snapshots and repairs.
- Per-worker/event **reconciliation CSV and JSON** independently proving byte count and SHA match saved files; external test-only signature-verification ledger, threat model and unqualified signed-deployment/loaded-instruction gaps.
- Environment and pinning ledger, independent QC checklist **left unfilled**, F1–F4 and additional readiness/gap matrix; truthful final disposition.
- ZIP-root `README.md`, `PACKAGE_INVENTORY` and `SHA256SUMS` with a conventional manifest self-hash exception; no unsafe paths, duplicated ZIP entries, symlinks, forbidden target artifacts, binaries or private keys.

**G-CFINAL is not complete until it is durably saved and freshly retrieved**, independently re-hashed for size/SHA-256, ZIP CRC, every non-self SHA256SUMS entry, all inventory entries and **every raw stream/event identity**. Print exact retrieval location, archive name, bytes, SHA-256, ZIP member/hash/inventory counts and the signed-source identities in the final agent report. Never represent a file merely created in ephemeral workspace as user-accessibly preserved.

## 9. G6 — Evidence-limited disposition; no Work self-approval

Report each separately: (1) preserved abstract exact theorem; (2) irreparable historical R1 QCF01 negative decision; (3) new P0A3G raw-stream integrity; (4) parser/reference regression; (5) test-only verified external authority **versus absent real signed code authority**; (6) pinned interpreter/host limitations; (7) power-loss/multiwriter/hostile-filesystem/crash exclusions; (8) unresolved loaded-code identity; (9) candidate readiness; (10) registered scientific validation not run.

Use only evidence-supported status:

- `P0A3G_ENGINEERING_CANDIDATE_SUBMITTED_FOR_INDEPENDENT_QC` **only if** all mandatory deliverables and checkpoint verifications are actually complete.
- Otherwise `P0A3G_ENGINEERING_INCOMPLETE` or `P0A3G_STOP_AND_QUARANTINE` with exact blocking evidence.

**No** `GLOBAL_CERTIFIED`; **no** arbitrary-input or production-host qualification inferred from 14/14 DEV; **no** human code-only freeze or `READY_FOR_REGISTERED_TARGET_FREE_VALIDATION` claim. P0A4 is **NOT RUN / NOT AUTHORIZED**. The Work agent does **not** independently QC its own code, approve its own readiness, sign the repository or prepare a later scientific protocol. The user will bring the complete ZIP and all checkpoints to the separate independent ChatGPT research/QC conversation, which will perform independent analysis and prepare a positive or incomplete human-signing candidate as warranted.

## 10. Non-negotiable information barrier and source restrictions

**Absolutely prohibited for this execution:** repository commit/push/writes; modifications to any signed archive or historical DEV/QC evidence; missing-stream reconstruction; edits to three frozen mathematical kernels; changes to exact scoring, normalization, ordering, group or domain; P0A0 S00–S12 reruns; P0A4 or other registered science; Hebrew glyph, chart, image, font proxy, target extraction; candidate/null numerical fitting, optimization threshold tuning; G0/A/B 3D cameras, QH or physical-shadow modelling; private human signing keys; self-signed production authority; publication/deployment and claims of historical Meru specificity.

**Decision discipline:** robust fail-closed errors, negative tests, incomplete statuses and exact source/evidence provenance take precedence over headline test counts. A correct `RESOURCE_INCOMPLETE` is not proof that a required successful recovery case completed. A valid ZIP checksum is not proof that raw stream metadata matches the underlying worker bytes.

## 11. Begin now — required first action

1. Retrieve the **complete signed P0A3G protocol** from GitHub at `adacfdbc6efcca4922c8d087d029b67e9b0c5dc5` and independently authenticate parent, single-file scope, Git blob `00a4e6ac85403f2a6e4704963a858d43faef136b`, signer, frozen lineage and previous QC artifacts.
2. Execute **G0**, including the bounded authentic-recovery search and exact platform/baseline preflight.
3. **Create, durably save, freshly retrieve and verify G-C0 before developing software**. When possible, report the checkpoint's exact path, size, SHA and verification result immediately.
4. Proceed only to G1/G2, then lock G3 and **durably verify G-C1 before G4 DEV**. After every DEV attempt/repair verify G-C2+; deliver verified G-CFINAL before any candidate disposition.
5. If a mandatory check or durable-save/readback gate fails, **STOP with the last verified checkpoint** and state `P0A3G_ENGINEERING_INCOMPLETE` or the applicable hard-stop classification. Never silently continue in volatile storage.

**This handoff is an execution aid, not a protocol amendment, a source trust signature, a permission to change the research programme or an independent QC approval.**
