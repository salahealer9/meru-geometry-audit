"""P0A3G G0 environment / host preflight (no candidate code is imported).

Launches each listed interpreter with -I -S -B in a fresh subprocess and records
version, real path, binary SHA-256, flags, platform, startup /proc/self/status,
RLIMITs, cgroup and locale. Prints canonical JSON.
"""
import hashlib
import json
import os
import platform
import subprocess
import sys

PROBE = r'''
import sys, os, platform, json, resource
lim = {}
for n in dir(resource):
    if n.startswith('RLIMIT_'):
        try: lim[n] = list(resource.getrlimit(getattr(resource, n)))
        except Exception as e: lim[n] = 'UNAVAILABLE:' + type(e).__name__
st = open('/proc/self/status').read()
keep = {}
for line in st.splitlines():
    k = line.split(':')[0]
    if k in ('VmPeak','VmSize','VmRSS','VmHWM','VmData','Threads','NoNewPrivs','Seccomp'):
        keep[k] = line.split(':',1)[1].strip()
print(json.dumps({'version': sys.version, 'implementation': sys.implementation.name,
  'version_info': list(sys.version_info[:3]),
  'flags': {'isolated': sys.flags.isolated, 'no_site': sys.flags.no_site,
            'dont_write_bytecode': sys.dont_write_bytecode},
  'executable': sys.executable, 'prefix': sys.prefix, 'path': sys.path,
  'platform': platform.platform(), 'machine': platform.machine(),
  'startup_proc_status': keep, 'rlimits': lim,
  'modules_at_startup': len(sys.modules)}, sort_keys=True))
'''


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def probe(exe):
    rp = os.path.realpath(exe)
    r = subprocess.run([exe, '-I', '-S', '-B', '-c', PROBE], capture_output=True, timeout=30)
    d = {'requested': exe, 'realpath': rp, 'binary_sha256': sha(rp), 'binary_bytes': os.path.getsize(rp),
         'returncode': r.returncode, 'stderr': r.stderr.decode('utf-8', 'replace')}
    if r.returncode == 0:
        d.update(json.loads(r.stdout))
    return d


def rd(p):
    try:
        return open(p).read()
    except Exception as e:  # noqa
        return 'UNAVAILABLE:' + type(e).__name__


if __name__ == '__main__':
    out = {'schema': 'p0a3g-g0-environment-preflight-1',
           'host': {'uname': list(platform.uname()), 'os_release': rd('/etc/os-release'),
                    'cpu_count': os.cpu_count(), 'proc_self_cgroup': rd('/proc/self/cgroup'),
                    'cgroup_v2_memory_max': rd('/sys/fs/cgroup/memory.max'),
                    'cgroup_v1_memory_limit': rd('/sys/fs/cgroup/memory/memory.limit_in_bytes'),
                    'locale_env': {k: os.environ.get(k) for k in ('LANG', 'LC_ALL')}},
           'interpreters': [probe(e) for e in sys.argv[1:]]}
    try:
        out['host']['dpkg_python312'] = subprocess.run(
            ['dpkg-query', '-W', '-f=${Package} ${Version}\n', 'python3.12-minimal', 'libpython3.12-minimal',
             'python3.13-minimal'], capture_output=True, text=True).stdout
    except Exception as e:  # noqa
        out['host']['dpkg_python312'] = 'UNAVAILABLE'
    print(json.dumps(out, indent=1, sort_keys=True))
