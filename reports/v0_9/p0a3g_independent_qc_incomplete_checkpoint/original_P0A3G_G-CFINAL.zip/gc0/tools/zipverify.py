"""P0A3G independent ZIP verifier (stdlib only; run with python3 -I).

Checks: outer byte size and SHA-256; unique member names; safe relative
paths (no absolute, '..', backslash, drive letters, empty components);
no symlink / special-file mode bits; per-member CRC by full read; every
SHA256SUMS line (except the conventional self-entry) against member bytes;
every PACKAGE_INVENTORY(.json) record (path/bytes/sha256) against member
bytes; members not covered by SHA256SUMS are listed.

Prints a canonical JSON verdict on stdout. Exit 0 only if every check passes.
"""
import hashlib
import json
import stat
import sys
import zipfile


def sha(b):
    return hashlib.sha256(b).hexdigest()


def safe(name):
    if not name or name.startswith('/') or '\\' in name or '\x00' in name:
        return False
    if len(name) > 1 and name[1] == ':':
        return False
    parts = name.rstrip('/').split('/')
    return all(p not in ('', '.', '..') for p in parts)


def verify(path, expect_sha=None, expect_bytes=None, manifest='SHA256SUMS',
           inventory=None):
    raw = open(path, 'rb').read()
    out = {'path': path, 'bytes': len(raw), 'sha256': sha(raw), 'errors': []}
    if expect_sha and out['sha256'] != expect_sha:
        out['errors'].append('OUTER_SHA256_MISMATCH')
    if expect_bytes is not None and out['bytes'] != expect_bytes:
        out['errors'].append('OUTER_BYTES_MISMATCH')
    z = zipfile.ZipFile(path)
    infos = z.infolist()
    names = [i.filename for i in infos]
    out['members'] = len(infos)
    dup = sorted({n for n in names if names.count(n) > 1})
    if dup:
        out['errors'].append('DUPLICATE_MEMBERS:%s' % dup[:5])
    data = {}
    crc_bad = []
    for i in infos:
        if not safe(i.filename):
            out['errors'].append('UNSAFE_PATH:%r' % i.filename)
        mode = (i.external_attr >> 16) & 0xFFFF
        if mode and (stat.S_ISLNK(mode) or stat.S_ISCHR(mode) or stat.S_ISBLK(mode)
                     or stat.S_ISFIFO(mode) or stat.S_ISSOCK(mode)):
            out['errors'].append('SPECIAL_FILE_MODE:%s' % i.filename)
        if i.is_dir():
            continue
        try:
            data[i.filename] = z.read(i)  # raises BadZipFile on CRC error
        except Exception as e:  # noqa
            crc_bad.append('%s:%s' % (i.filename, type(e).__name__))
    out['crc'] = 'PASS' if not crc_bad else 'FAIL'
    if crc_bad:
        out['errors'].append('CRC:%s' % crc_bad[:5])
    out['file_members'] = len(data)
    # manifest
    if manifest not in data and 'QC_PACKAGE_MANIFEST.json' in data:
        mf = json.loads(data['QC_PACKAGE_MANIFEST.json'])
        recs = mf if isinstance(mf, list) else (mf.get('files') or mf.get('payload_files') or mf.get('entries') or mf)
        if isinstance(recs, dict):
            recs = [{'path': k, **(v if isinstance(v, dict) else {'sha256': v})} for k, v in recs.items()]
        ok = 0
        for r in recs:
            p = r.get('path'); h = r.get('sha256')
            if p in data and sha(data[p]) == h and ('bytes' not in r or r['bytes'] == len(data[p])):
                ok += 1
            else:
                out['errors'].append('QC_MANIFEST_MISMATCH:%s' % p)
        out['manifest_kind'] = 'QC_PACKAGE_MANIFEST.json'
        out['manifest_entries'] = len(recs)
        out['manifest_verified_non_self'] = ok
        out['members_not_in_manifest'] = sorted(set(data) - {r.get('path') for r in recs} - {'QC_PACKAGE_MANIFEST.json'})
    elif manifest in data:
        lines = [l for l in data[manifest].decode('utf-8').splitlines() if l.strip()]
        ok = bad = 0
        covered = set()
        for l in lines:
            h, n = l.split(None, 1)
            n = n.lstrip('*').strip()
            covered.add(n)
            if n == manifest:
                continue
            if n in data and sha(data[n]) == h:
                ok += 1
            else:
                bad += 1
                out['errors'].append('MANIFEST_MISMATCH:%s' % n)
        out['manifest_entries'] = len(lines)
        out['manifest_verified_non_self'] = ok
        out['manifest_failed'] = bad
        out['members_not_in_manifest'] = sorted(set(data) - covered - {manifest})
    else:
        out['errors'].append('NO_MANIFEST')
    # inventory
    inv_name = inventory
    if inv_name is None:
        for cand in ('PACKAGE_INVENTORY.json', 'PACKAGE_INVENTORY', 'PAYLOAD_INVENTORY.json'):
            if cand in data:
                inv_name = cand
                break
    if inv_name and inv_name in data:
        inv = json.loads(data[inv_name])
        recs = inv if isinstance(inv, list) else (inv.get('payload_files') or inv.get('entries') or inv.get('files') or [])
        ok = 0
        for r in recs:
            p = r.get('path')
            if p in data and len(data[p]) == r.get('bytes') and sha(data[p]) == r.get('sha256'):
                ok += 1
            else:
                out['errors'].append('INVENTORY_MISMATCH:%s' % p)
        out['inventory_name'] = inv_name
        out['inventory_entries'] = len(recs)
        out['inventory_verified'] = ok
    else:
        out['inventory_entries'] = None
    out['verdict'] = 'PASS' if not out['errors'] else 'FAIL'
    return out, data


if __name__ == '__main__':
    p = sys.argv[1]
    es = sys.argv[2] if len(sys.argv) > 2 and sys.argv[2] != '-' else None
    eb = int(sys.argv[3]) if len(sys.argv) > 3 else None
    o, _ = verify(p, es, eb)
    print(json.dumps(o, sort_keys=True, indent=1))
    sys.exit(0 if o['verdict'] == 'PASS' else 1)
