"""Deterministic P0A3G checkpoint ZIP builder.

usage: python3 -I build_checkpoint.py <source_dir> <out.zip> <checkpoint_label>

* Adds every regular file under <source_dir> (symlinks/specials refused) in sorted order.
* Writes PACKAGE_INVENTORY.json (path, bytes, sha256 for every payload file; excludes itself
  and SHA256SUMS) and SHA256SUMS (every member incl. PACKAGE_INVENTORY.json, excluding the
  conventional SHA256SUMS self-entry).
* Fixed timestamps (1980-01-01) and mode 0644 for reproducibility; ZIP_DEFLATED.
* Refuses unsafe relative names, duplicates, and anything resembling a private key.
"""
import hashlib
import json
import os
import stat
import sys
import zipfile

# Built from parts so this source file does not itself contain the literal markers.
_B, _PK = b'-----' + b'BEGIN ', b'PRIVATE' + b' KEY'
FORBIDDEN_MARKERS = tuple(_B + p + _PK for p in (b'PGP ', b'OPENSSH ', b'', b'RSA ', b'EC '))


def sha(b):
    return hashlib.sha256(b).hexdigest()


def collect(src):
    files = []
    for root, dirs, fs in os.walk(src, followlinks=False):
        dirs.sort()
        for d in dirs:
            if os.path.islink(os.path.join(root, d)):
                raise SystemExit('REFUSED_SYMLINK_DIR:' + os.path.join(root, d))
        for f in sorted(fs):
            p = os.path.join(root, f)
            m = os.lstat(p).st_mode
            if not stat.S_ISREG(m):
                raise SystemExit('REFUSED_NON_REGULAR:' + p)
            rel = os.path.relpath(p, src).replace(os.sep, '/')
            if rel in ('SHA256SUMS', 'PACKAGE_INVENTORY.json'):
                raise SystemExit('REFUSED_RESERVED_NAME:' + rel)
            if rel.startswith('/') or '..' in rel.split('/') or '\\' in rel:
                raise SystemExit('REFUSED_UNSAFE:' + rel)
            files.append((rel, p))
    return sorted(files)


def zinfo(name):
    zi = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    zi.external_attr = (0o100644 << 16)
    zi.compress_type = zipfile.ZIP_DEFLATED
    return zi


def build(src, out, label):
    files = collect(src)
    payload = []
    blobs = {}
    for rel, p in files:
        b = open(p, 'rb').read()
        for mk in FORBIDDEN_MARKERS:
            if mk in b:
                raise SystemExit('REFUSED_PRIVATE_KEY_MATERIAL:' + rel)
        blobs[rel] = b
        payload.append({'path': rel, 'bytes': len(b), 'sha256': sha(b)})
    inv = {'schema': 'p0a3g-package-inventory-1', 'checkpoint': label,
           'excludes': ['PACKAGE_INVENTORY.json', 'SHA256SUMS'],
           'payload_count': len(payload), 'payload_files': payload}
    inv_b = (json.dumps(inv, indent=1, sort_keys=True) + '\n').encode()
    blobs['PACKAGE_INVENTORY.json'] = inv_b
    sums = ''.join('%s  %s\n' % (sha(blobs[n]), n) for n in sorted(blobs))
    blobs['SHA256SUMS'] = sums.encode()
    tmp = out + '.tmp'
    with zipfile.ZipFile(tmp, 'w') as z:
        for n in sorted(blobs):
            z.writestr(zinfo(n), blobs[n])
    with open(tmp, 'rb') as f:
        os.fsync(f.fileno())
    os.replace(tmp, out)
    b = open(out, 'rb').read()
    print(json.dumps({'checkpoint': label, 'zip': out, 'bytes': len(b), 'sha256': sha(b),
                      'members': len(blobs), 'manifest_non_self': len(blobs) - 1,
                      'inventory_entries': len(payload)}, sort_keys=True))


if __name__ == '__main__':
    build(sys.argv[1], sys.argv[2], sys.argv[3])
