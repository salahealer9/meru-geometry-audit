"""Independent read-only recomputation of R1 QCF01 (event metadata vs archived raw streams).

Usage: python3 -I r1_qcf01_recheck.py <R1 zip> [<R1 zip> ...]
Reads ZIPs in memory only; never extracts or modifies them.
"""
import hashlib
import json
import re
import sys
import zipfile

PFX = 'candidate/reports/v0_9/p0a3f_runtime_external_trust_qualification/attempts/P0A3F_R1_DEV_01/'


def sha(b):
    return hashlib.sha256(b).hexdigest()


def check(path):
    z = zipfile.ZipFile(path)
    names = set(z.namelist())
    ev = json.loads(z.read(PFX + 'evidence.json'))
    rows = []
    found = []

    def walk(x, obsname):
        if isinstance(x, dict):
            if 'command' in x and 'stdout_bytes' in x and 'stderr_bytes' in x:
                found.append((obsname, x))
            for v in x.values():
                walk(v, obsname)
        elif isinstance(x, list):
            for v in x:
                walk(v, obsname)
    for obs in ev['observations']:
        walk(obs['value'], obs['name'])
    for obsname, e in found:
        if True:
            req = [a for a in e['command'] if a.endswith('_request.json')]
            m = re.search(r'raw_workers/([^/]+)/(worker_\d+)_request\.json$', req[0])
            case, w = m.group(1), m.group(2)
            for stream, fname in (('stdout', '%s_stdout.json' % w), ('stderr', '%s_stderr.log' % w)):
                member = PFX + 'raw_workers/%s/%s' % (case, fname)
                if member in names:
                    b = z.read(member)
                    actual = (len(b), sha(b))
                else:
                    actual = (None, None)
                rec = (e[stream + '_bytes'], e[stream + '_sha256'])
                rows.append({'observation': obsname, 'case': case, 'worker': w, 'stream': stream,
                             'recorded_bytes': rec[0], 'recorded_sha256': rec[1],
                             'archived_member': member, 'archived_present': actual[0] is not None,
                             'archived_bytes': actual[0], 'archived_sha256': actual[1],
                             'match': rec == actual})
    events = len(rows) // 2
    mism = [r for r in rows if not r['match']]
    return {'archive': path, 'archive_sha256': sha(open(path, 'rb').read()), 'events': events,
            'stream_identities': len(rows), 'matches': len(rows) - len(mism),
            'mismatches': mism, 'rows': rows}


if __name__ == '__main__':
    out = [check(p) for p in sys.argv[1:]]
    print(json.dumps(out, indent=1, sort_keys=True))
