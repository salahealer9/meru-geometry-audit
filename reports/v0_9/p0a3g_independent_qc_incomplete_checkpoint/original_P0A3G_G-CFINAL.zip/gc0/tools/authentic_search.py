"""P0A3G G0 bounded, read-only authentic-evidence search.

Searches for any byte object whose SHA-256 equals the R1 recorded stdout digest
(23bcfd67...), and separately for any 108-byte object, across:
  * every member (recursively into nested ZIPs) of every given ZIP file;
  * every regular file under given directories (recursively into ZIPs);
  * every blob reachable in a given git repository (all fetched objects).
Never writes to any searched location. Prints a JSON ledger.
"""
import hashlib
import io
import json
import os
import subprocess
import sys
import zipfile

TARGET = '23bcfd677effd3a3b5ff73bfce72328c0bd19148a79617be8b896a4e1d802807'
TARGET_LEN = 108
MAX_NEST = 4


def sha(b):
    return hashlib.sha256(b).hexdigest()


class Ledger:
    def __init__(self):
        self.objects = 0
        self.hits = []
        self.len108 = []
        self.containers = []

    def see(self, label, b):
        self.objects += 1
        h = sha(b)
        if h == TARGET:
            self.hits.append({'location': label, 'bytes': len(b), 'sha256': h})
        if len(b) == TARGET_LEN:
            self.len108.append({'location': label, 'sha256': h})


def scan_zip_bytes(L, label, b, depth=0):
    try:
        z = zipfile.ZipFile(io.BytesIO(b))
    except zipfile.BadZipFile:
        return
    L.containers.append({'zip': label, 'members': len(z.infolist()), 'depth': depth})
    for i in z.infolist():
        if i.is_dir():
            continue
        d = z.read(i)
        lab = label + '!' + i.filename
        L.see(lab, d)
        if depth < MAX_NEST and d[:4] == b'PK\x03\x04':
            scan_zip_bytes(L, lab, d, depth + 1)


def scan_path(L, p):
    if os.path.isdir(p):
        for root, dirs, files in os.walk(p, followlinks=False):
            dirs[:] = [d for d in dirs if d != '.git']
            for f in files:
                fp = os.path.join(root, f)
                if os.path.islink(fp) or not os.path.isfile(fp):
                    continue
                scan_path(L, fp)
        return
    b = open(p, 'rb').read()
    L.see(p, b)
    if b[:4] == b'PK\x03\x04':
        scan_zip_bytes(L, p, b)


def scan_git(L, repo):
    objs = subprocess.run(['git', '-C', repo, 'cat-file', '--batch-all-objects', '--batch-check'],
                          capture_output=True, check=True, text=True).stdout.split('\n')
    blobs = [l.split()[0] for l in objs if l.endswith(' ') is False and ' blob ' in l]
    n = 0
    proc = subprocess.Popen(['git', '-C', repo, 'cat-file', '--batch'], stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE)
    for oid in blobs:
        proc.stdin.write((oid + '\n').encode())
        proc.stdin.flush()
        hdr = proc.stdout.readline().split()
        size = int(hdr[2])
        b = proc.stdout.read(size)
        proc.stdout.read(1)
        n += 1
        L.see('git-blob:' + oid, b)
        if b[:4] == b'PK\x03\x04':
            scan_zip_bytes(L, 'git-blob:' + oid, b)
    proc.stdin.close()
    proc.wait()
    return n


if __name__ == '__main__':
    L = Ledger()
    gitrepo = None
    blobs = 0
    for a in sys.argv[1:]:
        if a.startswith('git:'):
            gitrepo = a[4:]
            blobs = scan_git(L, gitrepo)
        else:
            scan_path(L, a)
    print(json.dumps({'target_sha256': TARGET, 'target_bytes': TARGET_LEN,
                      'objects_hashed': L.objects, 'git_repo': gitrepo, 'git_blobs_scanned': blobs,
                      'zip_containers_opened': len(L.containers),
                      'authentic_target_hits': L.hits, 'all_108_byte_objects': L.len108,
                      'containers': L.containers}, indent=1, sort_keys=True))
