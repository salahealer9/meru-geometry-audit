"""P0A3G G0 signed-provenance and isolated-baseline inventory generator (read-only on the repo).

usage: GNUPGHOME=... python3 -I g0_provenance.py <repo> <r1_cfinal_extract_dir> <p0a3e_extract_dir> <outdir>
"""
import ast
import hashlib
import json
import os
import subprocess
import sys

REPO, R1, P3E, OUT = sys.argv[1:5]
FPR = 'D4EC014EEFCC90E619D2AA59A91239ABCF512130'
PROTO = 'docs/v0_9/p0a3g_raw_worker_evidence_and_external_trust_followup_protocol_2026_10_21.md'
KERNELS = ['src/meru_geometry/v0_9/qo2d_exact/algebra.py', 'src/meru_geometry/v0_9/qo2d_exact/core.py',
           'reference/v0_9/qo2d_exact/arithmetic.py']


def git(*a):
    return subprocess.run(['git', '-C', REPO] + list(a), capture_output=True, text=True)


def sha(b):
    return hashlib.sha256(b).hexdigest()


def verify(obj, kind='commit'):
    r = git('verify-%s' % kind, '--raw', obj)
    toks = [l.split()[1:] for l in r.stderr.splitlines() if l.startswith('[GNUPG:]')]
    d = {'object': obj, 'returncode': r.returncode,
         'GOODSIG': any(t[0] == 'GOODSIG' for t in toks),
         'VALIDSIG_fpr': next((t[1] for t in toks if t[0] == 'VALIDSIG'), None),
         'TRUST': next((t[0] for t in toks if t[0].startswith('TRUST_')), None),
         'BADSIG': any(t[0] == 'BADSIG' for t in toks), 'ERRSIG': any(t[0] == 'ERRSIG' for t in toks)}
    d['fingerprint_matches_expected'] = d['VALIDSIG_fpr'] == FPR
    return d


pinned = {
    'P0A3G_protocol_commit': ('adacfdbc6efcca4922c8d087d029b67e9b0c5dc5', 'd95c50ea96744ce266058c51f85fff320d1a27df',
                              PROTO, '00a4e6ac85403f2a6e4704963a858d43faef136b'),
    'P0A3F_R1_QC_incomplete_preservation': ('d95c50ea96744ce266058c51f85fff320d1a27df', '83b9e6dcd53b100c5ac8b081832e81659cd1884a',
                                            'docs/v0_9/p0a3f_r1_independent_qc_incomplete_preservation_2026_10_21.md',
                                            'bf1dacde71c5b3a0ac3919f070c1c57a74c4ce41'),
    'P0A3F_evidence_loss_R1_amendment': ('83b9e6dcd53b100c5ac8b081832e81659cd1884a', '1d38ea6f53b9266d853df887a66331c59e4fc3ae',
                                         'docs/v0_9/p0a3f_evidence_loss_recovery_amendment_2026_10_21.md',
                                         '9fd9fba6ca509e3fcb72c2227d226847d218b354'),
    'P0A3F_original_protocol': ('1d38ea6f53b9266d853df887a66331c59e4fc3ae', '8ed3b988f716229bc9aee97d41ded0f524371193',
                                'docs/v0_9/p0a3f_exact_2d_qo_runtime_external_trust_and_fail_closed_recovery_qualification_protocol.md',
                                '9530a75d2346752a093367aeac24e13c5d2d6fac'),
    'P0A3E_incomplete_preservation': ('8ed3b988f716229bc9aee97d41ded0f524371193', 'c48c7a60777200a172ae3c72f5b0402162370ec7', None, None),
    'P0A3E_protocol': ('c48c7a60777200a172ae3c72f5b0402162370ec7', '59eb47f7500d57866e4935822b78a555d3bcb515',
                       'docs/v0_9/p0a3e_exact_2d_qo_software_hardening_and_independent_certificate_qualification_protocol.md',
                       '108866549d914005c391eedea234ca27cc8604b7'),
    'P0A3D_theorem_result_freeze': ('59eb47f7500d57866e4935822b78a555d3bcb515', '92de104cab58339df370acf96b8d849ecc2d888b', None, None),
}
prov = {'schema': 'p0a3g-g0-signed-provenance-1', 'expected_fingerprint': FPR,
        'remote': 'https://github.com/salahealer9/meru-geometry-audit (anonymous read through session git proxy)',
        'branch': 'hebrew-projection-capacity-v0.9',
        'branch_tip_at_clone': git('rev-parse', 'HEAD').stdout.strip(),
        'pinned_checks': {}}
for k, (c, parent, path, blob) in pinned.items():
    full = git('rev-parse', c).stdout.strip()
    par = git('rev-parse', full + '^').stdout.strip()
    rec = {'commit': full, 'expected_parent': parent, 'actual_parent': par, 'parent_ok': par == parent,
           'commit_object_type': git('cat-file', '-t', full).stdout.strip(),
           'signature': verify(full),
           'diff_vs_parent': git('diff', '--name-status', par, full).stdout.splitlines()}
    if path:
        actual_blob = git('rev-parse', '%s:%s' % (full, path)).stdout.strip()
        data = subprocess.run(['git', '-C', REPO, 'cat-file', 'blob', actual_blob], capture_output=True).stdout
        rec.update({'path': path, 'expected_blob': blob, 'actual_blob': actual_blob, 'blob_ok': actual_blob == blob,
                    'file_bytes': len(data), 'file_sha256': sha(data)})
    prov['pinned_checks'][k] = rec
lineage = []
for c in git('rev-list', 'v0.8.0..adacfdbc6efcca4922c8d087d029b67e9b0c5dc5').stdout.split():
    v = verify(c)
    lineage.append({'commit': c, 'subject': git('log', '-1', '--format=%s', c).stdout.strip(),
                    'GOODSIG': v['GOODSIG'], 'VALIDSIG_fpr': v['VALIDSIG_fpr']})
prov['lineage_v0_8_0_to_P0A3G'] = {'count': len(lineage), 'all_goodsig_expected_fpr':
                                   all(l['GOODSIG'] and l['VALIDSIG_fpr'] == FPR for l in lineage), 'commits': lineage}
tagv = verify('v0.8.0', 'tag')
prov['v0_8_0_tag'] = {'tag_object': git('rev-parse', 'v0.8.0').stdout.strip(),
                      'target_commit': git('rev-parse', 'v0.8.0^{commit}').stdout.strip(),
                      'signature': tagv,
                      'ancestor_of_P0A3G': git('merge-base', '--is-ancestor', 'v0.8.0^{commit}',
                                               'adacfdbc6efcca4922c8d087d029b67e9b0c5dc5').returncode == 0}
prov['repo_worktree_clean'] = git('status', '--porcelain').stdout == ''
prov['evidence_distinctions'] = {
    'local_gpg_by_this_agent': 'PERFORMED: git verify-commit/verify-tag --raw in an isolated GNUPGHOME; GOODSIG+VALIDSIG for expected fingerprint. TRUST_UNDEFINED: this agent asserts NO ownertrust; trust anchor is the externally supplied pinned fingerprint.',
    'public_key_source': 'Armored public key extracted from repo file reports/v0_9/p0a2_target_blind_design/provenance_and_information_barrier.json (field public_key_armored); its primary fingerprint equals the pinned fingerprint supplied out-of-band in the human handoff. Keyserver and github.com/<user>.gpg were NOT reachable from this sandbox.',
    'github_signature_attestation': 'NOT CHECKED BY THIS AGENT (GitHub API not available to this session for this repository). The handoff reports a prior user-side GitHub connector check; recorded as user-reported only.',
    'human_local_trust_ultimate': 'USER-REPORTED in handoff (VALIDSIG/GOODSIG/TRUST_ULTIMATE); not reproducible by this agent.',
    'archive_hashes': 'Unsigned SHA-256 of Git-tracked binary blobs; their authority derives from inclusion in signed commits verified above.'}
os.makedirs(OUT, exist_ok=True)
json.dump(prov, open(os.path.join(OUT, 'G0_SIGNED_PROVENANCE_REPORT.json'), 'w'), indent=1, sort_keys=True)

# Isolated baseline inventory (R1-CFINAL candidate code; not reports)
base = os.path.join(R1, 'candidate')
files = []
for root, dirs, fs in os.walk(base):
    dirs.sort()
    if '/reports' in root.replace(base, ''):
        continue
    for f in sorted(fs):
        p = os.path.join(root, f)
        rel = os.path.relpath(p, base)
        b = open(p, 'rb').read()
        files.append({'path': rel, 'bytes': len(b), 'sha256': sha(b)})
graph = {}
for f in files:
    if f['path'].endswith('.py'):
        t = ast.parse(open(os.path.join(base, f['path'])).read())
        imps = set()
        for n in ast.walk(t):
            if isinstance(n, ast.Import):
                imps.update(a.name for a in n.names)
            elif isinstance(n, ast.ImportFrom):
                imps.add(('.' * n.level) + (n.module or ''))
        graph[f['path']] = sorted(imps)
kern = {}
for k in KERNELS:
    a = sha(open(os.path.join(base, k), 'rb').read())
    e = sha(open(os.path.join(P3E, k), 'rb').read())
    kern[k] = {'r1_cfinal': a, 'p0a3e': e, 'identical': a == e}
inv = {'schema': 'p0a3g-g0-isolated-baseline-inventory-1',
       'baseline': 'R1-CFINAL candidate/ (unqualified engineering baseline; extracted from signed-preserved ZIP 6ec2b6e9...)',
       'excluded_from_listing': 'candidate/reports/** (historical evidence, read-only, referenced by archive hash)',
       'files': files, 'import_graph': graph, 'frozen_kernels': kern,
       'all_kernels_identical_to_p0a3e': all(v['identical'] for v in kern.values())}
json.dump(inv, open(os.path.join(OUT, 'G0_ISOLATED_BASELINE_INVENTORY.json'), 'w'), indent=1, sort_keys=True)
print(json.dumps({'pinned_ok': all(v['parent_ok'] and v['signature']['GOODSIG'] and v['signature']['fingerprint_matches_expected']
                                   and v.get('blob_ok', True) for v in prov['pinned_checks'].values()),
                  'lineage': prov['lineage_v0_8_0_to_P0A3G']['count'],
                  'lineage_ok': prov['lineage_v0_8_0_to_P0A3G']['all_goodsig_expected_fpr'],
                  'tag_ok': tagv['GOODSIG'] and tagv['fingerprint_matches_expected'],
                  'kernels_ok': inv['all_kernels_identical_to_p0a3e'], 'baseline_files': len(files),
                  'clean': prov['repo_worktree_clean']}))
