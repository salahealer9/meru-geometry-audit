# P0A3G G0 — Scope and hard-stop matrix

## Authority
Signed P0A3G protocol `adacfdbc6efcca4922c8d087d029b67e9b0c5dc5`, blob `00a4e6ac85403f2a6e4704963a858d43faef136b`, direct parent `d95c50ea96744ce266058c51f85fff320d1a27df`, signer `D4EC014EEFCC90E619D2AA59A91239ABCF512130`. The unsigned execution handoff is an aid only.

## In scope (G1–G6 only)
- Isolated descendant of R1-CFINAL `candidate/` outside the Git checkout (`/home/claude/p0a3g/…`).
- G1 single accountable raw-stream capture boundary; fresh-read byte/SHA reconciliation; typed `EVIDENCE_STREAM_MISMATCH`.
- G2 versioned caller-supplied authority envelope; test-only signature fixture `NON_PRODUCTION_TEST_AUTHORITY`; distinct `UNSIGNED_STAGING_PROPOSAL`, `CALLER_OWNED_DEV_FIXTURE`, real human-signed authority (absent); `LOADED_CODE_IDENTITY_UNVERIFIED` disclosure.
- G3 14-method lock (G01–G14); G4 ≤3 attempts `P0A3G_DEV_01..03`; G5 cumulative ZIP; G6 evidence-limited disposition.

## Prohibited
Repository commit/push/writes; modification of any signed archive or historical evidence; reconstruction of R1 stdout; edits to the three frozen kernels; changes to score/normalization/ordering/group/domain; P0A0 S00–S12; P0A4 or any registered science; Hebrew glyph/chart/image/font-proxy/target data; candidate/null fitting or threshold tuning; G0/A/B 3D cameras, QH, physical shadow; private human keys; self-signed production authority; publication/deployment; historical Meru specificity claims; Work self-QC/self-approval.

## Hard stops
| Trigger | Action | G0 state |
|---|---|---|
| Wrong/missing signed authority, parent, blob, signer | STOP before engineering | PASS (all verified) |
| Altered/unavailable mandatory archive; broken lineage | STOP | PASS (7/7 archives; 22/22 lineage commits; v0.8.0 tag) |
| Frozen-kernel mismatch | STOP_AND_QUARANTINE | PASS (3/3 identical P0A3D=P0A3E=R1) |
| Unsupported environment defeating mandatory requirements | `ENVIRONMENT_UNQUALIFIED`, STOP | Not triggered; different-build declaration recorded |
| Durable-save / fresh-retrieval failure at any gate | STOP with last verified checkpoint, `P0A3G_ENGINEERING_INCOMPLETE` | pending G-C0 |
| Accepted false exact certificate; trust bypass; prohibited input | `P0A3G_STOP_AND_QUARANTINE` | n/a |
| Need to change locked catalogue/policy | STOP; new human-signed authority | n/a |

## Checkpoint gates
G-C0 (this package) → G-C1 (before any DEV) → G-C2+ (after every attempt and every distinct repair) → G-CFINAL.
