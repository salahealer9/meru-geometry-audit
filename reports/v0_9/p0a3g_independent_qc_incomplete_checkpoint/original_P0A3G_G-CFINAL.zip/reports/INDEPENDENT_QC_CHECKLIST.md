# P0A3G independent QC checklist — UNFILLED (for the separate QC reviewer; Work does not fill this)

| # | Check | Result | Reviewer notes |
|---|---|---|---|
| 1 | G-CFINAL size/SHA-256, CRC, every SHA256SUMS entry, every PACKAGE_INVENTORY entry | | |
| 2 | Signed P0A3G commit/parent/blob/one-file scope and signer independently re-verified | | |
| 3 | Seven signed archive hashes; R1 QCF01 (37/74/72; forged_q, null_path_record) independently recomputed | | |
| 4 | Authentic-search ledger bounds; digest-equal other-event streams correctly NOT treated as recovered | | |
| 5 | Three frozen kernels byte-identical to P0A3D/P0A3E | | |
| 6 | `candidate/` equals `gc1/lock/SOURCE_LOCK.json`; diff complete; no frozen-kernel or mathematical-route change | | |
| 7 | G-C0 / G-C1 / G-C2 identities and fresh-retrieval receipts consistent with contents reproduced here | | |
| 8 | Predeclared catalogue written before DEV; DEV_01 executed exactly that catalogue and budgets | | |
| 9 | Every raw stream vs event record independently re-reconciled (rows, bytes, SHA-256, capture witness) | | |
| 10 | Every mismatch row attributable to a declared simulated fault or the registered harness fault; no unexplained row | | |
| 11 | Capture boundary code review: no path from parsed/cached objects to stream bytes; decode only after reconciliation | | |
| 12 | Authority interface review: no default key; caller trust store; mode separation; DEPLOYMENT fails closed; two independent signature routes | | |
| 13 | No private-key material in any package file; only public keys retained | | |
| 14 | Actual vs simulated fault labelling correct in events | | |
| 15 | Same-binary replay on the declared interpreter (optional, reviewer's host) | | |
| 16 | Information barrier: no target/glyph/P0A0/P0A4/3D/QH material | | |
| 17 | Disposition statuses evidence-limited; no readiness or freeze claim | | |
