# P0A3G — Final engineering disposition (G6; evidence-limited; NOT self-approval)

**Status submitted:** `P0A3G_ENGINEERING_CANDIDATE_SUBMITTED_FOR_INDEPENDENT_QC` — valid only together with the G-CFINAL persistence and fresh-retrieval verification recorded in the agent's final report (necessarily outside this package). If that verification is absent or fails, the status is `P0A3G_ENGINEERING_INCOMPLETE`.

Work does not QC its own code, approve readiness, sign the repository or prepare a later scientific protocol.

## (1) Abstract exact theorem `[FROZEN THEOREM]`
P0A3D theorem (signed `59eb47f7…`) unchanged. The three kernels (`algebra.py` `442065…6d2d`, `core.py` `37701d…d420`, `arithmetic.py` `72b3c3…f0ba`) are byte-identical to P0A3D/P0A3E/R1. No scoring, normalisation, ordering, group or domain change.

## (2) Historical R1 QCF01 `PERMANENT NEGATIVE`
Recomputed in G0 and again in G01: 37 events / 74 stream identities / 72 match; `forged_q` and `null_path_record` stdout recorded 108 B `23bcfd67…`, archived 0 B `e3b0c442…`, in R1-C2 and R1-CFINAL. Original bytes **not recovered** in the bounded search (ChatGPT Library and R1 transcripts not reachable). Eight other R1 rejection events retain digest-equal 108-byte stdout; these are different events and were not used as recovered evidence. In P0A3G DEV_01, fresh `forged_q` and `null_path_record` checks produced 108-byte stdout with the same digest: this shows the R1 metadata is consistent with the generic rejection message, and nothing more. The signed R1 statuses `P0A3F_R1_DEV_01_RAW_WORKER_EVIDENCE_INCONSISTENT`, `R1_CFINAL_RAW_EVIDENCE_COMPLETENESS_NOT_QUALIFIED`, `P0A3F_R1_SOFTWARE_QUALIFICATION_INCOMPLETE`, `P0A3F_R1_INDEPENDENT_QC_NOT_QUALIFIED` stand. Cause remains UNKNOWN.

## (3) New P0A3G raw-stream integrity `[DEV_CHECKED_ONLY]`
One attempt, `P0A3G_DEV_01`: 14/14 predeclared methods passed; 111 worker events / 222 stream identities; every row either matches (199 by the candidate reconciler, 201 byte-matches by the agent's separate tool) or is attributable to a declared simulated fault (21) or the registered harness fault (2); 0 unexplained. The R1-type condition (108-byte record vs 0-byte retained stdout) was detected as `EVIDENCE_STREAM_MISMATCH` in all three G04 forms, and no success/checkpoint followed any evidence fault. Re-reconciled from the freshly retrieved G-C2.

## (4) Parser / reference regression `[DEV_CHECKED_ONLY]`
G13: 8 raw-byte and 5 rational-grammar negatives rejected by production and reference parsers; forged score, invalid nested path record, nonoptimal identity SO(2), forged tie, missing/duplicate knot, changed traversal, negative/forward/boolean root all `CERTIFICATE_REJECTED`; equal-serialisation positive control accepted. G14: R/Z/T/N generic relations as frozen. Not arbitrary-input qualification.

## (5) Test-only external authority vs absent real signed code authority
`NON_PRODUCTION_TEST_AUTHORITY` verified by two independent signature routes (OpenSSL CLI; pure-Python RFC 8032) only in explicit `TEST_AUTHORITY` mode; 14 G11 negatives and the G12 negatives rejected by both; controller refuses before launching workers. `CALLER_OWNED_DEV_FIXTURE_UNSIGNED` remains a separate, labelled state. **No real human-signed code authority exists or was verified; `DEPLOYMENT` mode always fails closed.** Test signatures are not deployment identity.

## (6) Interpreter / host `[DEV_CHECKED_ONLY on declared host]`
`/usr/bin/python3.12 -I -S -B`, CPython 3.12.3, SHA `e50d468e…`, declared prospectively in G-C0 because R1's binary (`a92f0f95…`) is unavailable; 8 s deadline and all R1 caps unchanged. G12 shows the authority check rejects actual CPython 3.13. No R1 same-binary replay; no cross-host qualification.

## (7) Exclusions `[UNRESOLVED]`
Power loss, kernel crash, disk-full/quota, multi-writer or hostile filesystem, controller death and full process-tree containment, hostile signals, hostile host/kernel. Simulated faults are not real crashes.

## (8) Loaded-code identity `LOADED_CODE_IDENTITY_UNVERIFIED`
Module-function code-object comparison only; interpreter, loader, classes, globals, native libraries and TOCTOU file substitution are not attested.

## (9) Candidate readiness
Engineering candidate for independent QC only. No `GLOBAL_CERTIFIED`, no arbitrary-input or production-host qualification, no code-only freeze, no `READY_FOR_REGISTERED_TARGET_FREE_VALIDATION`.

## (10) Registered scientific validation
**P0A4 NOT RUN / NOT AUTHORIZED.** No P0A0 replay, no Hebrew/glyph/target data, no 3D/QH/camera work, no candidate/null fitting.

## Deviations to note for QC
* Durable channel: ChatGPT Library was not available; checkpoints were persisted as base64 text files in a private claude.ai artifact ("P0A3G Checkpoint Register") because artifacts do not serve `.zip`, and every checkpoint was freshly retrieved from there, decoded and verified byte-identical. Secondary copies: claude.ai Project docs (G-C0, G-C1; not hash-verified by the agent) and conversation attachments.
* GitHub signature attestation was not checked by the agent (no API access for this repository in the session); local GPG verification used the repository-embedded public key, matched to the out-of-band pinned fingerprint, without asserting ownertrust.
* Pre-lock dry runs of the catalogue were executed during implementation and are disclosed, not counted.
