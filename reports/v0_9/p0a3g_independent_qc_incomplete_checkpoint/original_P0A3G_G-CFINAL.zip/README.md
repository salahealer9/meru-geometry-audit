# P0A3G — G-CFINAL cumulative engineering candidate (UNSIGNED; for independent QC)

**Project:** Meru Geometry Audit v0.9 · **Authority:** human-signed P0A3G protocol `adacfdbc6efcca4922c8d087d029b67e9b0c5dc5` (blob `00a4e6ac85403f2a6e4704963a858d43faef136b`, parent `d95c50ea96744ce266058c51f85fff320d1a27df`, signer `D4EC014EEFCC90E619D2AA59A91239ABCF512130`).
**Submitted status:** `P0A3G_ENGINEERING_CANDIDATE_SUBMITTED_FOR_INDEPENDENT_QC` (see `reports/FINAL_ENGINEERING_DISPOSITION.md`). Not a code-only freeze, not qualification, not GLOBAL_CERTIFIED. P0A4 NOT RUN / NOT AUTHORIZED. No repository writes were made.

## Layout
| Path | Content |
|---|---|
| `candidate/` | full revised production and reference source, schemas, the 14-method DEV harness and contracts; identical to `gc1/lock/SOURCE_LOCK.json` (51 files); three frozen kernels byte-identical to P0A3D/P0A3E |
| `gc0/` | complete G-C0 contents: signed-provenance report, archive verification, R1 QCF01 recheck, authentic-search ledger, environment preflight/declaration, baseline inventory, scope/stop matrix, protocol copy, G0 tools |
| `gc1/` | G-C1 lock: `P0A3G_DEV_CASES_PREDECLARED.md`, `lock/` (source lock, baseline→revised hash table and unified diff), `environment/`, `prelock/` dry-run logs (not DEV) |
| `dev/P0A3G_DEV_01/` | the only DEV attempt: complete `attempt/` tree (every raw worker stdout/stderr byte, event records, inputs, envelopes, receipts, signatures, public test keys, trust store, evidence ledger), untouched runner stdout/stderr/exit, start/end UTC, pre/post source verification, agent post-run reconciliation |
| `reports/` | `STREAM_EVENT_RECONCILIATION.{csv,json}` (per worker event and stream), external test-signature verification ledger, threat model, dependency/trust table, environment and pinning ledger, checkpoint identity ledger, DEV chronology and summary, F1–F4 gap matrix, information barrier, **unfilled** independent QC checklist, final disposition |
| `receipts/` | G-C0, G-C1, G-C2 persistence and fresh-retrieval receipts |
| `tools/` | agent-side scripts (checkpoint builder/verifier, provenance, search, lock, reconciliation, report generation) |

Checkpoint ZIPs are not nested; their contents are reproduced unmodified above, and their identities are in `reports/CHECKPOINT_IDENTITY_LEDGER.json`. `SHA256SUMS` covers every member except itself; `PACKAGE_INVENTORY.json` lists every payload file. Some evidence files are raw binary by design (worker streams with non-UTF-8 bytes, 64-byte test signatures); there are no executables, symlinks or private keys.

## How to re-check streams
`python3 -I tools/attempt_reconcile.py dev/P0A3G_DEV_01/attempt/P0A3G_DEV_01` (imports nothing from the candidate), or the candidate's independent `reference/v0_9/qo2d_exact/stream_reconcile.py`.
