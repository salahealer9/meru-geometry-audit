"""Agent-side independent post-run reconciliation (third route; imports nothing from the candidate).

usage: python3 -I attempt_reconcile.py <attempt_dir_or_zip> [zip_member_prefix]
For every w####.event.json: re-read the two referenced stream files, recompute length and
SHA-256, compare with the record and the capture witness; classify by the event's own
declared fault; cross-check the counts against the candidate's STREAM_EVENT_RECONCILIATION.json.
Also scans every file for private-key markers.
"""
import hashlib, io, json, os, sys, zipfile

src = sys.argv[1]
prefix = sys.argv[2] if len(sys.argv) > 2 else ''
_B, _PK = b'-----' + b'BEGIN ', b'PRIVATE' + b' KEY'
MARKERS = tuple(_B + p + _PK for p in (b'PGP ', b'OPENSSH ', b'', b'RSA ', b'EC '))
if src.endswith('.zip'):
    z = zipfile.ZipFile(src)
    files = {i.filename[len(prefix):]: z.read(i) for i in z.infolist() if not i.is_dir() and i.filename.startswith(prefix)}
else:
    files = {}
    for r, _, fs in os.walk(src):
        for f in fs:
            p = os.path.join(r, f)
            files[os.path.relpath(p, src).replace(os.sep, '/')] = open(p, 'rb').read()
h = lambda b: hashlib.sha256(b).hexdigest()
rows = []
for name in sorted(n for n in files if os.path.basename(n).startswith('w') and n.endswith('.event.json')):
    ev = json.loads(files[name])
    d = os.path.dirname(name)
    for s in ('stdout', 'stderr'):
        rec = ev[s]
        member = d + '/' + rec['path']
        b = files.get(member)
        actual = (len(b), h(b)) if b is not None else (None, None)
        match = actual == (rec['bytes'], rec['sha256']) and (rec['capture_bytes'], rec['capture_sha256']) == (rec['bytes'], rec['sha256']) \
            and rec['path'] == ev['worker_id'] + '.' + s and os.path.basename(d) == ev['run_dir_id']
        rows.append({'event': name, 'stream': s, 'declared_fault': ev.get('evidence_fault'), 'recorded': [rec['bytes'], rec['sha256']],
                     'saved': list(actual), 'match': match})
key_hits = [n for n, b in files.items() if any(m in b for m in MARKERS)]
undeclared_mismatch = [r for r in rows if not r['match'] and r['declared_fault'] in (None, 'none')]
cand = None
for n in files:
    if n.endswith('STREAM_EVENT_RECONCILIATION.json'):
        cand = json.loads(files[n])
summary = {'source': src, 'events': len(rows) // 2, 'stream_rows': len(rows), 'match': sum(r['match'] for r in rows),
           'mismatch_declared_fault': sum((not r['match']) and r['declared_fault'] not in (None, 'none') for r in rows),
           'mismatch_without_declared_fault': len(undeclared_mismatch), 'undeclared_rows': undeclared_mismatch,
           'private_key_marker_files': key_hits,
           'candidate_reconciler_events': cand['summary']['events'] if cand else None,
           'candidate_reconciler_stream_rows': cand['summary']['stream_rows'] if cand else None,
           'candidate_reconciler_verdict': cand['verdict'] if cand else None}
print(json.dumps(summary, indent=1, sort_keys=True))
