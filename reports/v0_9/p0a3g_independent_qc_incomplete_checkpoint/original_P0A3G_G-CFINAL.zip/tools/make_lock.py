"""Build P0A3G G3 lock artifacts: baseline-to-revised hash table, unified diff, source lock.

usage: python3 -I make_lock.py <baseline_candidate_dir> <revised_candidate_dir> <outdir>
"""
import csv, difflib, hashlib, json, os, sys
from pathlib import Path

BASE, REV, OUT = (Path(a) for a in sys.argv[1:4])
FROZEN = {'src/meru_geometry/v0_9/qo2d_exact/algebra.py', 'src/meru_geometry/v0_9/qo2d_exact/core.py',
          'reference/v0_9/qo2d_exact/arithmetic.py'}


def walk(root):
    out = {}
    for folder in ('src', 'reference', 'schemas', 'tests', 'docs'):
        for p in sorted((root / folder).rglob('*')):
            if p.is_file():
                out[p.relative_to(root).as_posix()] = p.read_bytes()
    return out


def h(b):
    return hashlib.sha256(b).hexdigest()


b, r = walk(BASE), walk(REV)
OUT.mkdir(parents=True, exist_ok=True)
rows, diff = [], []
for path in sorted(set(b) | set(r)):
    ob, nb = b.get(path), r.get(path)
    change = 'UNCHANGED' if ob == nb else ('ADDED' if ob is None else ('REMOVED' if nb is None else 'MODIFIED'))
    cls = 'FROZEN_MATHEMATICAL_KERNEL' if path in FROZEN else ('NEW_P0A3G_ENGINEERING' if change == 'ADDED' else
                                                               ('REVISED_UNQUALIFIED_ENGINEERING' if change == 'MODIFIED' else 'INHERITED_UNCHANGED'))
    rows.append({'path': path, 'change': change, 'class': cls,
                 'baseline_sha256': h(ob) if ob is not None else '', 'revised_sha256': h(nb) if nb is not None else '',
                 'baseline_bytes': len(ob) if ob is not None else '', 'revised_bytes': len(nb) if nb is not None else ''})
    if change != 'UNCHANGED':
        a = ob.decode('utf-8').splitlines(keepends=True) if ob is not None else []
        c = nb.decode('utf-8').splitlines(keepends=True) if nb is not None else []
        diff.extend(difflib.unified_diff(a, c, 'baseline_R1_CFINAL/' + path, 'revised_P0A3G/' + path))
        if diff and not diff[-1].endswith('\n'):
            diff.append('\n')
for f in FROZEN:
    assert b[f] == r[f], 'FROZEN KERNEL CHANGED: ' + f
with open(OUT / 'BASELINE_TO_REVISED_HASH_AND_DIFF.csv', 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0]))
    w.writeheader(); w.writerows(rows)
(OUT / 'BASELINE_TO_REVISED.diff').write_text(''.join(diff))
lock = {'schema': 'p0a3g-source-lock-1', 'root': 'candidate/',
        'files': {p: {'bytes': len(v), 'sha256': h(v)} for p, v in sorted(r.items())},
        'frozen_kernels': {f: h(r[f]) for f in sorted(FROZEN)},
        'envelope_hashed_scope': 'src/ reference/ schemas/ tests/ (*.py, *.json, *.md); docs/ is outside the runtime source map'}
lb = (json.dumps(lock, indent=1, sort_keys=True) + '\n').encode()
(OUT / 'SOURCE_LOCK.json').write_bytes(lb)
counts = {}
for x in rows:
    counts[x['change']] = counts.get(x['change'], 0) + 1
print(json.dumps({'counts': counts, 'source_lock_sha256': h(lb), 'files': len(r),
                  'diff_sha256': h(''.join(diff).encode())}, sort_keys=True))
