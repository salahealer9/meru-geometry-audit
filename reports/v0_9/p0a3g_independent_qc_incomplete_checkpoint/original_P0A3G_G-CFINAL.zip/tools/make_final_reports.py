"""Generate P0A3G G-CFINAL machine-readable ledgers from retained evidence (read-only inputs).

usage: python3 -I make_final_reports.py <p0a3g_root> <outdir>
"""
import ast, csv, hashlib, json, os, sys
from pathlib import Path

ROOT, OUT = Path(sys.argv[1]), Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)
CAND = ROOT / 'work/candidate'
ATT = ROOT / 'dev/P0A3G_DEV_01/attempt/P0A3G_DEV_01'
h = lambda b: hashlib.sha256(b).hexdigest()
w = lambda name, obj: (OUT / name).write_text(json.dumps(obj, indent=1, sort_keys=True) + '\n')
obs = {o['name']: o['value'] for o in json.loads((ATT / 'evidence.json').read_bytes())['observations']}

# 1. Production / reference dependency and trust table
rows = []
for folder in ('src', 'reference'):
    for p in sorted((CAND / folder).rglob('*.py')):
        t = ast.parse(p.read_text())
        imps = set()
        for n in ast.walk(t):
            if isinstance(n, ast.Import):
                imps.update(a.name for a in n.names)
            elif isinstance(n, ast.ImportFrom):
                imps.add('.' * n.level + (n.module or ''))
        rel = p.relative_to(CAND).as_posix()
        rows.append({'module': rel, 'route': 'production' if folder == 'src' else 'reference',
                     'imports': ' '.join(sorted(imps)), 'imports_production_from_reference': folder == 'reference' and any('meru_geometry' in i for i in imps),
                     'sha256': h(p.read_bytes()),
                     'trust_note': {'streamcapture.py': 'single accountable stream capture boundary',
                                    'identity.py': 'external authority gate (production: OpenSSL CLI; reference: ed25519_ref)' ,
                                    'ed25519_ref.py': 'independent pure-Python RFC 8032 verify',
                                    'stream_reconcile.py': 'independent stream reconciler / archive verifier',
                                    'algebra.py': 'FROZEN KERNEL', 'core.py': 'FROZEN KERNEL', 'arithmetic.py': 'FROZEN KERNEL'}.get(p.name, '')})
with open(OUT / 'PRODUCTION_REFERENCE_DEPENDENCY_AND_TRUST.csv', 'w', newline='') as f:
    wr = csv.DictWriter(f, fieldnames=list(rows[0])); wr.writeheader(); wr.writerows(rows)
assert not any(r['imports_production_from_reference'] for r in rows)

# 2. External test-signature verification ledger
keys = json.loads((ATT / 'controller/NON_PRODUCTION_TEST_PUBLIC_KEYS.json').read_bytes())
w('EXTERNAL_TEST_SIGNATURE_VERIFICATION_LEDGER.json', {
    'label': 'NON_PRODUCTION_TEST_AUTHORITY — not deployment trust; no real human-signed code authority verified',
    'attempt': 'P0A3G_DEV_01',
    'public_keys': keys, 'trust_store_sha256': h((ATT / 'controller/trust_store.json').read_bytes()),
    'routes': {'production': 'OpenSSL 3.0.13 CLI pkeyutl -verify -rawin (binary SHA-256 b4f547c0f16272d1cc7f870330a6f2c243710c335e7a99c734ff7a0c6fdb2503)',
               'reference': 'reference/v0_9/qo2d_exact/ed25519_ref.py (pure Python RFC 8032)'},
    'valid_case': obs['G11']['valid'], 'G11_negatives': obs['G11']['negatives'], 'G11_end_to_end': {
        'controller_state': obs['G11']['end_to_end']['controller']['state'], 'controller_worker_events': len(obs['G11']['end_to_end']['controller']['worker_events']),
        'reference_worker': obs['G11']['end_to_end']['reference_worker']},
    'G12_negatives': obs['G12']['negatives'], 'G12_unsigned_dev_fixture': obs['G12']['unsigned_dev_fixture'],
    'private_keys_destroyed': obs['private_keys_destroyed'],
    'loaded_code_identity': 'LOADED_CODE_IDENTITY_UNVERIFIED'})

# 3. Environment and pinning ledger
pre = json.loads((ROOT / 'gc0/G0_ENVIRONMENT_PREFLIGHT.json').read_bytes())
policy = json.loads((CAND / 'schemas/v0_9/p0a3g/resource_policy.json').read_bytes())
w('ENVIRONMENT_AND_PINNING_LEDGER.json', {
    'declared_before_DEV': 'gc0/G0_ENVIRONMENT_DECLARATION.md (inside G-C0, verified before engineering)',
    'selected_interpreter': {'command': '/usr/bin/python3.12 -I -S -B', 'sha256': policy['interpreter_sha256'], 'version': '3.12.3'},
    'r1_interpreter_not_available': {'path': '/usr/bin/python3 (R1) -> 3.12.3 build Jul 15 2026', 'sha256': 'a92f0f95e883390c7256b2e441484aac06b1002dbe1d924141a77c8d82f96223'},
    'openssl': {'path': policy['openssl'], 'sha256': policy['openssl_sha256']},
    'resource_policy_sha256': h((CAND / 'schemas/v0_9/p0a3g/resource_policy.json').read_bytes()), 'resource_policy': policy,
    'host_preflight': pre['host'], 'interpreters_measured': [{k: i.get(k) for k in ('requested', 'realpath', 'binary_sha256', 'version_info', 'startup_proc_status')} for i in pre['interpreters']],
    'dev_01_pre_run_identity_check': json.loads((ROOT / 'dev/P0A3G_DEV_01/PRE_RUN_SOURCE_VERIFICATION.json').read_bytes()),
    'limits': ['results bind to this binary/host only', 'not the R1 binary', '2 CPUs', 'no seccomp/NoNewPrivs', 'memory cgroup limit unreadable']})

# 4. Checkpoint identity ledger
ck = {}
for n in ('G-C0', 'G-C1', 'G-C2_DEV_01'):
    ck[n] = json.loads((ROOT / 'receipts' / (n + '_RECEIPT.json')).read_bytes())
w('CHECKPOINT_IDENTITY_LEDGER.json', {'register_artifact': 'https://claude.ai/artifact/Ttex3YZFk1Ye75arDEgcG6 (private; base64 copies of each checkpoint ZIP)',
                                       'receipts': ck,
                                       'note': 'Checkpoint ZIPs are not nested in G-CFINAL; their full contents are reproduced unmodified under gc0/, gc1/ and dev/ in this package.'})

# 5. Chronology
chron = [
    '2026-10-21T13:1xZ G0 start: clone of signed branch; HEAD adacfdbc verified; parent/blob/one-file scope verified',
    '2026-10-21 G0: local GPG verify (22/22 lineage commits since v0.8.0, v0.8.0 tag) with repo-embedded public key matching pinned fingerprint',
    '2026-10-21 G0: 7 signed archives verified; QCF01 recomputed (37/74/72); kernels identical P0A3D=P0A3E=R1',
    '2026-10-21 G0: bounded authentic search: original R1 stdout NOT recovered; 8 digest-equal streams from other R1 events noted, not used',
    '2026-10-21 G0: environment declared prospectively (/usr/bin/python3.12 different build, 8 s unchanged)',
    '2026-10-21T13:20:22Z G-C0 built 7e2b1f59…22fb (66,925 B); 13:21:32Z register artifact v1 published; freshly retrieved, decoded, verified PASS',
    '2026-10-21 G1/G2 implementation in isolated descendant; pre-lock smoke runs; PRELOCK_DRYRUN_01 (harness helper bug), 02 PASS, 03 PASS (fault-stream mapping tightened), 04 PASS on final tree — none are DEV attempts',
    '2026-10-21 G3 lock: SOURCE_LOCK abff7aa8…5902; P0A3G_DEV_CASES_PREDECLARED.md',
    '2026-10-21T13:43:26Z G-C1 built 1209547e…aaf0 (219,223 B); 13:43:44Z register artifact v2; freshly retrieved, decoded, verified PASS (G-C0 re-verified)',
    '2026-10-21T13:44:36Z P0A3G_DEV_01 start (source extracted from retrieved G-C1, 51/51 lock match)',
    '2026-10-21T13:45:26Z P0A3G_DEV_01 end: runner exit 0; 14/14 methods; stream reconciliation ALL_STREAMS_RECONCILED_OR_DECLARED; keys destroyed; source unchanged after run',
    '2026-10-21 agent post-run reconciliation (separate tool): 111 events / 222 streams consistent with candidate ledger',
    '2026-10-21T13:46:12Z G-C2_DEV_01 built 34373559…18c7 (1,025,638 B); 13:46:26Z register artifact v3; freshly retrieved, decoded, verified PASS incl. stream reconciliation inside the retrieved ZIP',
    '2026-10-21 No repair, no DEV_02/DEV_03 (not needed). G5 G-CFINAL assembly.']
(OUT / 'DEV_EXECUTION_CHRONOLOGY.log').write_text('\n'.join(chron) + '\n')
summary = json.loads((ATT / 'evidence.json').read_bytes())['observations'][-1]['value']
w('DEV_ATTEMPT_SUMMARY.json', {'attempts': ['P0A3G_DEV_01'], 'P0A3G_DEV_01': summary,
                                'runner_exit': (ROOT / 'dev/P0A3G_DEV_01/runner.exit').read_text().strip()})
print('ok')
