# P0A3E byte grammar and ABI

[IMPLEMENTED_UNVERIFIED] Scientific request and exact scalar/certificate ABI
retain qo2d-request-1 and qo2d-exact-1 because the frozen mathematical meaning
is unchanged. The service, failures, expected identities and resource policy
have separate p0a3e version-1 schemas. Raw bytes must decode as ASCII JSON,
without duplicate keys, floats/exponent numeric tokens, NaN/Infinity or Unicode
escape spellings. Whitespace/key order may vary; validated canonical bytes use
sorted keys, no optional whitespace, ASCII escaping and no nonfinite numbers.
Rational strings are reduced signed ASCII numerator and positive denominator;
zero is ["0","1"]. Genuine integers exclude bool in all endpoint/mask/event
indices. Independent IDs are 1–64 ASCII letters/digits/dot/underscore/hyphen.

[IMPLEMENTED_UNVERIFIED] Bounded lexical depth/token/string/raw-byte checks
precede JSON materialization. Input dimensions/metadata/rational semantics and
policy ceilings precede canonical hashing. The reference additionally validates
all certificate nested shapes, ordered masks, backward generator references,
nonzero coefficient syntax, decision types and exact key sets before arithmetic.
Root positivity, dependent equality, sequence counts and mathematical values
are checked by independent exact recomputation. JSON Schema alone cannot prove
these semantics; implementations do not rely on an opaque schema library.

[IMPLEMENTED_UNVERIFIED] Failures never contain a score, witness or certificate.
Raw-byte failure identity hashes at most 65,536 bytes with full size and hashed
prefix length recorded. It is not presented as a canonical valid-input hash.
Engine-only candidate bytes are private intermediate output; the public
supervisor returns a numerical certificate only after a separate checker worker
recomputes it and a complete checkpoint is atomically retained. Its status
still says ENGINEERING_EXACT_CERTIFICATE_CANDIDATE_UNVALIDATED; qualification
requires external QC. Untrusted checkpoints are rechecked, never merely resumed
by trusting a stored success flag.

[INDEPENDENT_QC_PENDING] Structural schemas describe the wire; production and
reference implement separately inspectable guards. Common CPython JSON/runtime
trust, finite-resource limits and any untested branch remain in the trust ledger.
