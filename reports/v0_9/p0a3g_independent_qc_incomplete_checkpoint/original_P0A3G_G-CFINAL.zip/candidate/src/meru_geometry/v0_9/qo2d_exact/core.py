"""Exact normalized-arclength 2D QO; proper rotation only. Unverified candidate."""
import hashlib,json,re
from fractions import Fraction as F
from functools import cmp_to_key
from .algebra import Tower,ResourceIncomplete,ExactDomainError

AUTHORITY='92de104cab58339df370acf96b8d849ecc2d888b'
LANE='P0A3D_QO_2D_OPEN_RATIONAL_VERTEX_SO2_EXACT'
BACKEND='positive-radical-mask-v1'
class InvalidInput(ValueError):pass
class NotEvaluable(ValueError):pass
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)
def digest(x):return hashlib.sha256(canonical(x).encode()).hexdigest()
def rational(w):
    if type(w) is not list or len(w)!=2 or any(type(x) is not str for x in w):raise InvalidInput('rational must be [integer-string,positive-integer-string]')
    if not re.fullmatch(r'0|-?[1-9][0-9]*',w[0]) or not re.fullmatch(r'[1-9][0-9]*',w[1]):raise InvalidInput('noncanonical rational syntax')
    x=F(int(w[0]),int(w[1]))
    if [str(x.numerator),str(x.denominator)]!=w:raise InvalidInput('fraction not reduced')
    return x
def validate(req):
    if type(req) is not dict or set(req)!={'schema','lane','authority','nuisance','paths','limits'}:raise InvalidInput('request keys')
    if req['schema']!='qo2d-request-1' or req['lane']!=LANE or req['authority']!=AUTHORITY or req['nuisance']!='SO2_ONLY':raise InvalidInput('scope/version')
    limits=req['limits']
    keys={'max_vertices','max_input_bits','max_operations','max_coefficient_bits','max_terms','max_formal_degree','reference_max_bits'}
    if type(limits) is not dict or set(limits)!=keys or any(type(v) is not int or v<=0 for v in limits.values()):raise InvalidInput('resource limits')
    if type(req['paths']) is not list or len(req['paths'])!=2:raise InvalidInput('exactly two paths')
    out=[]
    for p in req['paths']:
        if type(p) is not dict or set(p)!={'id','ordered','parameter_domain','endpoints','provenance','vertices'}:raise InvalidInput('path keys')
        v=p['vertices']
        if type(p['id']) is not str or not p['id'] or p['ordered'] is not True or p['parameter_domain']!='OPEN_INTERVAL' or p['provenance']!='INDEPENDENT_GENERIC':raise InvalidInput('explicit independent open traversal required')
        ep=p['endpoints']
        if type(v) is not list or len(v)<2 or type(ep) is not list or len(ep)!=2 or any(type(i) is not int for i in ep) or ep!=[0,len(v)-1]:raise InvalidInput('vertex/endpoints')
        if len(v)>limits['max_vertices']:raise ResourceIncomplete('VERTEX_CAP')
        pp=[]
        for point in v:
            if type(point) is not list or len(point)!=2:raise InvalidInput('2D only')
            point=tuple(rational(x) for x in point)
            if any(max(abs(x.numerator).bit_length(),x.denominator.bit_length())>limits['max_input_bits'] for x in point):raise ResourceIncomplete('INPUT_BIT_CAP')
            pp.append(point)
        out.append(pp)
    if req['paths'][0]['id']==req['paths'][1]['id']:raise InvalidInput('independent input IDs required')
    return out
def dot(a,b):return sum((x*y for x,y in zip(a,b)),0)
def quad(x,z,y,w,h):return h*(2*x*y+x*w+z*y+2*z*w)/6
def build(t,pp,label):
    edges=[];events=[]
    for i,(p,q) in enumerate(zip(pp,pp[1:])):
        d=sum((q[j]-p[j])**2 for j in range(2))
        if d==0:events.append({'edge_index':i,'reason':'EXACT_ZERO_CONSECUTIVE_EDGE'});continue
        length=t.root(t.coerce(d));t.decide(label+f'.length[{i}]',length)
        edges.append((i,tuple(t.coerce(x) for x in p),tuple(t.coerce(x) for x in q),length))
    if not edges:raise NotEvaluable('EXACT_CONSTANT_PATH')
    total=sum((e[3] for e in edges),t.coerce(0));knots=[t.coerce(0)]
    for e in edges:knots.append(knots[-1]+e[3]/total)
    center=tuple(sum(((p[j]+q[j])*(knots[k+1]-knots[k])/2 for k,(_,p,q,l) in enumerate(edges)),t.coerce(0)) for j in range(2))
    centered=[(i,tuple(p[j]-center[j] for j in range(2)),tuple(q[j]-center[j] for j in range(2)),l) for i,p,q,l in edges]
    variance=sum(((knots[k+1]-knots[k])*sum((((p[j]+q[j])/2)**2+(q[j]-p[j])**2/12 for j in range(2)),t.coerce(0)) for k,(_,p,q,l) in enumerate(centered)),t.coerce(0))
    if t.decide(label+'.variance',variance)!=1:raise ExactDomainError('NONPOSITIVE_VARIANCE_CONTRADICTION')
    rms=t.root(variance);norm=[(tuple(x/rms for x in p),tuple(x/rms for x in q)) for i,p,q,l in centered]
    meta={'zero_edges':events,'surviving_edge_indices':[e[0] for e in edges],'lengths':[e[3] for e in edges],'total_length':total,'knots':knots,'centroid':list(center),'variance':variance,'rms':rms}
    return {'knots':knots,'norm':norm,'meta':meta}
def at(t,path,k,u):
    p,q=path['norm'][k];lo,hi=path['knots'][k:k+2]
    return tuple(p[j]+(q[j]-p[j])*(u-lo)/(hi-lo) for j in range(2))
def encode(x):
    if hasattr(x,'wire'):return x.wire()
    if isinstance(x,list):return [encode(v) for v in x]
    if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
    return x
def calculate(req):
    pp=validate(req);t=Tower(req['limits']);a=build(t,pp[0],'a');b=build(t,pp[1],'b')
    raw=sorted(a['knots']+b['knots'],key=cmp_to_key(lambda x,y:t.sign(x-y)));union=[]
    for x in raw:
        if not union or not t.eq(x,union[-1]):union.append(x)
    alpha=t.coerce(0);beta=t.coerce(0);cells=[];ia=ib=0
    for k,(lo,hi) in enumerate(zip(union,union[1:])):
        while ia+1<len(a['norm']) and t.sign(lo-a['knots'][ia+1])>=0:ia+=1
        while ib+1<len(b['norm']) and t.sign(lo-b['knots'][ib+1])>=0:ib+=1
        x,z=at(t,a,ia,lo),at(t,a,ia,hi);y,w=at(t,b,ib,lo),at(t,b,ib,hi);h=hi-lo
        t.decide(f'union.width[{k}]',h)
        alpha+=sum((quad(x[j],z[j],y[j],w[j],h) for j in range(2)),t.coerce(0))
        beta+=quad(x[0],z[0],y[1],w[1],h)-quad(x[1],z[1],y[0],w[0],h)
        cells.append((x,z,y,w,h))
    s=t.root(alpha*alpha+beta*beta);sgn=t.decide('s',s)
    if t.decide('one_minus_s',1-s)<0:raise ExactDomainError('CORRELATION_RANGE_CONTRADICTION')
    c,d=(t.coerce(1),t.coerce(0)) if sgn==0 else (alpha/s,beta/s)
    q2=2-2*s;q=t.root(q2);Q=[[c,-d],[d,c]]
    residual=t.coerce(0)
    for x,z,y,w,h in cells:
        v=[c*x[0]-d*x[1]-y[0],d*x[0]+c*x[1]-y[1]];v1=[c*z[0]-d*z[1]-w[0],d*z[0]+c*z[1]-w[1]]
        residual+=sum((quad(v[j],v1[j],v[j],v1[j],h) for j in range(2)),t.coerce(0))
    for name,value,expected in [('s_squared_identity',s*s-alpha*alpha-beta*beta,0),('unit_rotation',c*c+d*d-1,0),('direct_residual_minus_q2',residual-q2,0)]:
        if t.decide(name,value)!=expected:raise ExactDomainError(name+'_CONTRADICTION')
    return {'schema':'qo2d-exact-1','lane':LANE,'machine_state':'EXACT_THEOREM_CERTIFICATE_CANDIDATE_UNVALIDATED','request':req,'request_sha256':digest(req),'input_sha256':[digest(p) for p in req['paths']],'backend':BACKEND,'roots':[r.wire() for r in t.roots],'paths':[encode(a['meta']),encode(b['meta'])],'union':[x.wire() for x in union],'alpha':alpha.wire(),'beta':beta.wire(),'s':s.wire(),'q_squared':q2.wire(),'q':q.wire(),'rotation':[[x.wire() for x in row] for row in Q],'direct_residual':residual.wire(),'roll_state':'EXACT_WHOLE_ROLL_TIE' if sgn==0 else 'EXACT_UNIQUE_PROPER_ROTATION','decisions':t.decisions}
def execute(req):
    def failure(state,error):
        try:pin=digest(req)
        except (ValueError,TypeError):pin=None  # malformed/nonfinite objects have no canonical JSON identity
        return {'schema':'qo2d-failure-1','state':state,'reason':str(error),'request_sha256':pin}
    try:return calculate(req)
    except ResourceIncomplete as e:return failure('RESOURCE_INCOMPLETE',e)
    except InvalidInput as e:return failure('INVALID_INPUT',e)
    except NotEvaluable as e:return failure('NOT_EVALUABLE',e)
