"""Positive radical tower with flat monomial masks. See theorem 1.2–1.7.
Dependent generators are allowed; nonzero formal coefficients do NOT imply
nonzero real value. Exact semantic sign, including reducible inversion, is used.
"""
from fractions import Fraction as F
from math import isqrt

class ResourceIncomplete(Exception):pass
class ExactDomainError(ValueError):pass

def rational_wire(x):return [str(x.numerator),str(x.denominator)]

class E:
    __slots__=('t','terms')
    def __init__(self,t,terms):self.t=t;self.terms=terms
    def __add__(self,y):return self.t.add(self,self.t.coerce(y))
    __radd__=__add__
    def __neg__(self):return self.t.make({m:-v for m,v in self.terms})
    def __sub__(self,y):return self+-self.t.coerce(y)
    def __rsub__(self,y):return self.t.coerce(y)+-self
    def __mul__(self,y):return self.t.mul(self,self.t.coerce(y))
    __rmul__=__mul__
    def __truediv__(self,y):return self*self.t.inv(self.t.coerce(y))
    def __rtruediv__(self,y):return self.t.coerce(y)*self.t.inv(self)
    def __pow__(self,n):
        if type(n) is not int or n<0:raise ExactDomainError('nonnegative integer power only')
        out=self.t.coerce(1);base=self
        while n:
            if n&1:out=out*base
            n//=2
            if n:base=base*base
        return out
    def wire(self):return [[m,rational_wire(v)] for m,v in self.terms]

class Tower:
    def __init__(self,limits):
        self.limits=limits;self.roots=[];self.operations=0;self.sign_cache={};self.mono_cache={};self.decisions=[]
    def tick(self):
        self.operations+=1
        if self.operations>self.limits['max_operations']:raise ResourceIncomplete('OPERATION_CAP')
    def make(self,terms):
        self.tick();terms={m:F(v) for m,v in terms.items() if v}
        if len(terms)>self.limits['max_terms']:raise ResourceIncomplete('TERM_CAP')
        for v in terms.values():
            if max(abs(v.numerator).bit_length(),v.denominator.bit_length())>self.limits['max_coefficient_bits']:raise ResourceIncomplete('COEFFICIENT_BIT_CAP')
        return E(self,tuple(sorted(terms.items())))
    def coerce(self,x):
        if isinstance(x,E):
            if x.t is not self:raise ExactDomainError('different tower')
            return x
        if type(x) not in (int,F):raise ExactDomainError('exact scalar only')
        return self.make({0:F(x)})
    def add(self,x,y):
        d=dict(x.terms)
        for m,v in y.terms:d[m]=d.get(m,F(0))+v
        return self.make(d)
    def monomial(self,m,n):
        self.tick();key=tuple(sorted((m,n)))
        if key in self.mono_cache:return self.mono_cache[key]
        common=m&n;out=self.make({m^n:F(1)})
        while common:
            i=common.bit_length()-1;common^=1<<i;out=self.mul(out,self.roots[i])
        self.mono_cache[key]=out;return out
    def mul(self,x,y):
        self.tick();out={}
        for m,a in x.terms:
            for n,b in y.terms:
                for k,c in self.monomial(m,n).terms:out[k]=out.get(k,F(0))+a*b*c
        return self.make(out)
    def split(self,x):
        k=max((m.bit_length() for m,v in x.terms),default=0)-1
        if k<0:return -1,x,self.coerce(0)
        bit=1<<k
        return k,self.make({m:v for m,v in x.terms if not m&bit}),self.make({m^bit:v for m,v in x.terms if m&bit})
    def sign(self,x):
        x=self.coerce(x);self.tick();key=x.terms
        if key in self.sign_cache:return self.sign_cache[key]
        if not key:ans=0
        elif len(key)==1 and key[0][0]==0:ans=(key[0][1]>0)-(key[0][1]<0)
        else:
            k,a,b=self.split(x);sa=self.sign(a);sb=self.sign(b)
            if sa==0:ans=sb
            elif sb==0 or sa==sb:ans=sa
            else:ans=sa*self.sign(a*a-b*b*self.roots[k])
        self.sign_cache[key]=ans;return ans
    def eq(self,x,y):return self.sign(self.coerce(x)-y)==0
    def inv(self,x):
        self.tick()
        if self.sign(x)==0:raise ExactDomainError('EXACT_ZERO_DENOMINATOR')
        k,a,b=self.split(x)
        if k<0:return self.coerce(1/dict(x.terms)[0])
        if self.sign(b)==0:return self.inv(a)
        d=a*a-b*b*self.roots[k]
        if self.sign(d)==0:return self.inv(2*a)
        theta=self.make({1<<k:F(1)})
        return (a-b*theta)*self.inv(d)
    def root(self,x):
        x=self.coerce(x);s=self.sign(x)
        if s<0:raise ExactDomainError('NEGATIVE_RADICAND')
        if s==0:return self.coerce(0)
        if len(x.terms)==1 and x.terms[0][0]==0:
            v=x.terms[0][1];a,b=isqrt(v.numerator),isqrt(v.denominator)
            if a*a==v.numerator and b*b==v.denominator:return self.coerce(F(a,b))
        for k,r in enumerate(self.roots):
            if self.eq(x,r):return self.make({1<<k:F(1)})
        if 2**(len(self.roots)+1)>self.limits['max_formal_degree']:raise ResourceIncomplete('FORMAL_TOWER_DEGREE_CAP')
        self.roots.append(x);return self.make({1<<(len(self.roots)-1):F(1)})
    def decide(self,label,x):
        s=self.sign(x);self.decisions.append({'label':label,'expression':self.coerce(x).wire(),'sign':s,'method':'DESCENDING_SIGN_GUARDED_SQUARING'});return s
