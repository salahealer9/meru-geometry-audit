"""P0A3G single accountable raw-worker stream capture boundary (POSIX, stdlib only).

Contract
--------
* The supervisor is the only writer of worker stream evidence. Worker stdout and
  stderr are read from pipes; the bytes kept are exactly the bytes received
  (empty, partial, binary or non-UTF-8 included), bounded by a declared cap.
* The capture witness (byte count and SHA-256) is computed from the received
  buffer itself at capture time, never from decoded JSON or a reserialisation.
* Each stream is saved with O_CREAT|O_EXCL|O_NOFOLLOW to a temporary name, fully
  written, flushed, fsync'd, hard-linked to its final name (no clobber), the
  temporary name unlinked, the directory fsync'd, and the file made read-only.
* After saving, the exact saved file is re-read from disk and its length and
  SHA-256 recomputed. Any disagreement anywhere is EVIDENCE_STREAM_MISMATCH.

Simulated evidence faults exist only for bounded DEV and are always recorded in
the event as fault_class SIMULATED_EVIDENCE_FAULT. Actual process faults
(exit, signal, controller timeout) are recorded from os-level observations only.
"""
import hashlib
import json
import os
import re
import selectors
import signal
import stat
import subprocess
import time
from pathlib import Path

STREAMS = ('stdout', 'stderr')
EMPTY_SHA256 = hashlib.sha256(b'').hexdigest()
WORKER_ID_RE = re.compile(r'w[0-9]{4}')
SAFE_ID_RE = re.compile(r'[A-Za-z0-9_.-]{1,64}')
EVENT_SCHEMA = 'p0a3g-stream-event-1'

# Faults that alter evidence AFTER a truthful capture (simulated, DEV only).
POST_SAVE_FAULTS = {
    'zero_stdout_after_save', 'truncate_stdout', 'alter_stdout', 'delete_stdout',
    'truncate_stderr', 'alter_stderr', 'delete_stderr', 'swap_streams',
    'after_rename_tamper', 'orphan_stream_file',
}
# Faults applied to the event record itself (simulated, DEV only).
RECORD_FAULTS = {'forge_stdout_108', 'stale_run', 'wrong_worker_path', 'duplicate_path'}
# Faults applied during the save itself (simulated, DEV only).
SAVE_FAULTS = {'short_write', 'before_rename', 'path_collision'}
ALL_EVIDENCE_FAULTS = POST_SAVE_FAULTS | RECORD_FAULTS | SAVE_FAULTS
R1_RECORDED_STDOUT = (108, '23bcfd677effd3a3b5ff73bfce72328c0bd19148a79617be8b896a4e1d802807')


class EvidenceMismatch(Exception):
    def __init__(self, reason):
        self.reason = reason
        super().__init__(reason)


def sha256(b):
    return hashlib.sha256(b).hexdigest()


def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()


# --------------------------------------------------------------------------- capture
def run_captured(cmd, *, wall_seconds, cap_bytes, preexec, env, drain_seconds=2.0):
    """Spawn cmd and capture stdout/stderr through pipes. Returns a dict of raw observations."""
    start = time.monotonic_ns()
    proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            start_new_session=True, preexec_fn=preexec, env=env, close_fds=True)
    bufs = {'stdout': bytearray(), 'stderr': bytearray()}
    over = {'stdout': False, 'stderr': False}
    sel = selectors.DefaultSelector()
    for name, f in (('stdout', proc.stdout), ('stderr', proc.stderr)):
        os.set_blocking(f.fileno(), False)
        sel.register(f.fileno(), selectors.EVENT_READ, name)
    open_fds = 2
    deadline = time.monotonic() + wall_seconds
    controller_timeout = False
    cap_kill = False
    killed = False

    def kill_group():
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass

    def pump(timeout):
        nonlocal open_fds, cap_kill
        for key, _ in sel.select(timeout):
            try:
                chunk = os.read(key.fd, 65536)
            except BlockingIOError:
                continue
            name = key.data
            if not chunk:
                sel.unregister(key.fd)
                open_fds -= 1
                continue
            room = cap_bytes - len(bufs[name])
            if len(chunk) > room:
                bufs[name] += chunk[:max(room, 0)]
                over[name] = True
                cap_kill = True
            else:
                bufs[name] += chunk

    while open_fds:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            controller_timeout = True
            break
        pump(min(remaining, 0.25))
        if cap_kill:
            break
    if controller_timeout or cap_kill:
        kill_group()
        killed = True
    # Drain what the (possibly killed) process group already wrote.
    drain_deadline = time.monotonic() + drain_seconds
    while open_fds and time.monotonic() < drain_deadline:
        pump(0.1)
    drain_complete = open_fds == 0
    for key in list(sel.get_map().values()):
        sel.unregister(key.fd)
    sel.close()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        kill_group()
        killed = True
        proc.wait()
    proc.stdout.close()
    proc.stderr.close()
    rc = proc.returncode
    return {'pid': proc.pid, 'returncode': rc, 'signal': -rc if rc < 0 else None,
            'controller_timeout': controller_timeout, 'controller_killed': killed,
            'stream_cap_exceeded': dict(over), 'drain_complete': drain_complete,
            'elapsed_ns': time.monotonic_ns() - start,
            'stdout': bytes(bufs['stdout']), 'stderr': bytes(bufs['stderr'])}


# --------------------------------------------------------------------------- save / re-read
def fsync_dir(d):
    fd = os.open(d, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def save_stream(d, name, data, fault='none'):
    """Exclusive, fsync'd, no-clobber save. Returns the final path. fault is DEV-only and simulated."""
    final = Path(d) / name
    tmp = Path(d) / ('.pending_' + name)
    if fault == 'path_collision':
        # Simulated: another writer already created the final path.
        with open(final, 'xb') as f:
            f.write(b'COLLIDING_PRE_EXISTING_STREAM\n')
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as f:
        body = data[:len(data) // 2] if fault == 'short_write' else data
        f.write(body)
        f.flush()
        os.fsync(f.fileno())
    if fault == 'before_rename':
        return final  # interrupted: final name never created
    os.link(tmp, final)  # raises FileExistsError on collision: never clobbers
    os.unlink(tmp)
    fsync_dir(d)
    os.chmod(final, 0o400)
    return final


def fresh_read(path, cap):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as f:
        st = os.fstat(f.fileno())
        if not stat.S_ISREG(st.st_mode):
            raise EvidenceMismatch('STREAM_NOT_REGULAR_FILE')
        if st.st_size > cap:
            raise EvidenceMismatch('STREAM_FILE_OVER_CAP')
        b = f.read(cap + 1)
    if len(b) > cap:
        raise EvidenceMismatch('STREAM_FILE_OVER_CAP')
    return b


def write_event(d, worker_id, event):
    p = Path(d) / (worker_id + '.event.json')
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(canonical(event))
        f.flush()
        os.fsync(f.fileno())
    fsync_dir(d)
    return p


def rewrite_event_simulated(d, worker_id, event):
    p = Path(d) / (worker_id + '.event.json')
    os.chmod(p, 0o600)
    with open(p, 'wb') as f:
        f.write(canonical(event))
        f.flush()
        os.fsync(f.fileno())


def apply_post_save_fault(d, worker_id, fault):
    """Simulated post-write alteration of saved evidence (DEV only)."""
    so, se = Path(d) / (worker_id + '.stdout'), Path(d) / (worker_id + '.stderr')
    for p in (so, se):
        if p.exists():
            os.chmod(p, 0o600)
    if fault == 'zero_stdout_after_save':
        open(so, 'wb').close()
    elif fault == 'truncate_stdout':
        b = so.read_bytes(); so.write_bytes(b[:len(b) // 2])
    elif fault == 'alter_stdout':
        b = bytearray(so.read_bytes()); b[0] ^= 0x01; so.write_bytes(bytes(b))
    elif fault == 'delete_stdout':
        so.unlink()
    elif fault == 'truncate_stderr':
        b = se.read_bytes(); se.write_bytes(b[:len(b) // 2])
    elif fault == 'alter_stderr':
        b = bytearray(se.read_bytes()); b[0] ^= 0x01; se.write_bytes(bytes(b))
    elif fault == 'delete_stderr':
        se.unlink()
    elif fault == 'swap_streams':
        a, b = so.read_bytes(), se.read_bytes(); so.write_bytes(b); se.write_bytes(a)
    elif fault == 'after_rename_tamper':
        with open(so, 'ab') as f:
            f.write(b'X')
    elif fault == 'orphan_stream_file':
        (Path(d) / 'w9999.stdout').write_bytes(b'ORPHAN')
    for p in (so, se):
        if p.exists():
            os.chmod(p, 0o400)


# --------------------------------------------------------------------------- reconciliation
def reconcile_event(d, event, *, context, cap):
    """Independently re-read both saved streams of one recorded event and compare."""
    d = Path(d)
    if event.get('schema') != EVENT_SCHEMA:
        raise EvidenceMismatch('EVENT_SCHEMA')
    wid = event.get('worker_id')
    if type(wid) is not str or not WORKER_ID_RE.fullmatch(wid):
        raise EvidenceMismatch('WORKER_ID')
    for k in ('attempt_id', 'run_dir_id', 'receipt_run_id', 'envelope_sha256', 'receipt_sha256',
              'trust_store_sha256', 'policy_sha256', 'interpreter_sha256', 'worker_source_sha256',
              'code_files_sha256'):
        if event.get(k) != context.get(k):
            raise EvidenceMismatch('STALE_OR_WRONG_IDENTITY:' + k)
    if d.name != event['run_dir_id']:
        raise EvidenceMismatch('STALE_OR_WRONG_IDENTITY:run_dir')
    for s in STREAMS:
        rec = event.get(s)
        if type(rec) is not dict or set(rec) != {'path', 'bytes', 'sha256', 'capture_bytes', 'capture_sha256'}:
            raise EvidenceMismatch('STREAM_RECORD_SHAPE:' + s)
        if rec['path'] != wid + '.' + s:
            raise EvidenceMismatch('STREAM_PATH_NOT_OWN_WORKER:' + s)
        p = d / rec['path']
        if p.is_symlink() or not p.exists():
            raise EvidenceMismatch('STREAM_MISSING:' + s)
        b = fresh_read(p, cap)
        if (len(b), sha256(b)) != (rec['bytes'], rec['sha256']):
            raise EvidenceMismatch('STREAM_BYTES_MISMATCH:' + s)
        if (rec['capture_bytes'], rec['capture_sha256']) != (rec['bytes'], rec['sha256']):
            raise EvidenceMismatch('CAPTURE_WITNESS_MISMATCH:' + s)
    normal = event.get('returncode') == 0 and not event.get('controller_timeout')
    if normal and event['stdout']['bytes'] == 0:
        raise EvidenceMismatch('UNEXPECTED_EMPTY_STDOUT')
    if normal and event['stderr']['bytes'] == 0:
        raise EvidenceMismatch('UNEXPECTED_EMPTY_STDERR')
    return True


def reconcile_run(d, *, context, cap):
    """Whole-run check: every event reconciles, paths unique, no orphan/pending stream files."""
    d = Path(d)
    events = []
    for p in sorted(d.glob('w*.event.json')):
        try:
            ev = json.loads(fresh_read(p, cap))
        except EvidenceMismatch:
            raise
        except Exception:
            raise EvidenceMismatch('EVENT_UNREADABLE')
        if p.name != str(ev.get('worker_id')) + '.event.json':
            raise EvidenceMismatch('EVENT_FILENAME')
        events.append(ev)
    seen = set()
    for ev in events:
        for s in STREAMS:
            path = ev.get(s, {}).get('path') if type(ev.get(s)) is dict else None
            if path in seen:
                raise EvidenceMismatch('DUPLICATE_STREAM_PATH')
            seen.add(path)
        reconcile_event(d, ev, context=context, cap=cap)
    for p in d.iterdir():
        if p.name.startswith('.pending_'):
            raise EvidenceMismatch('INCOMPLETE_STREAM_WRITE')
        if p.suffix in ('.stdout', '.stderr') and p.name not in seen:
            raise EvidenceMismatch('ORPHAN_STREAM_FILE')
    return len(events)
