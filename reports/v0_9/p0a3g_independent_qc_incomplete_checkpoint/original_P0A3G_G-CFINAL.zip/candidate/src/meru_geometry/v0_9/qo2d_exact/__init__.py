"""Unverified exact 2D QO candidate. No camera, QH or registered-run entry points."""
