"""P0A3G single-writer POSIX controller: caller authority, raw-stream evidence, fresh recovery checking.

Changes from R1: worker stdout/stderr go through streamcapture (pipes -> exact bytes ->
exclusive fsync'd save -> fresh re-read -> event record -> reconciliation). No result,
certificate or checkpoint is accepted unless every stream of every worker event of the
run reconciles; otherwise EVIDENCE_STREAM_MISMATCH. Authority comes from caller-supplied
envelope/receipt/signature/trust store in an explicit mode (see identity.py).
"""
import os,stat,resource,tempfile,time
from pathlib import Path
from .wire import POLICY,ROOT,Boundary,request,decode,fail
from .identity import verify,canonical,sha,files
from . import streamcapture as sc
SUCCESS='ENGINEERING_EXACT_CERTIFICATE_CANDIDATE_UNVALIDATED'
FAILURES={'INVALID_INPUT','NOT_EVALUABLE','CERTIFICATE_REJECTED','CODE_IDENTITY_MISMATCH','ENVIRONMENT_UNQUALIFIED','RESOURCE_INCOMPLETE','UNRESOLVED_EXACT_PREDICATE','UNKNOWN_TERMINATION','INTERNAL_ERROR_NO_CERTIFICATE','CHECKPOINT_UNVERIFIED','EVIDENCE_STREAM_MISMATCH'}
WORKER=ROOT/'src/meru_geometry/v0_9/qo2d_exact/worker.py'
ACTUAL_FAULTS={'none','timeout','kill','exit','memory','recursion','partial_then_kill'}
def bounded_file(path,cap):
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as f:
        st=os.fstat(f.fileno())
        if not stat.S_ISREG(st.st_mode):raise Boundary('INVALID_INPUT','REGULAR_FILE_REQUIRED')
        if st.st_size>cap:raise Boundary('RESOURCE_INCOMPLETE','FILE_SIZE_CAP')
        b=f.read(cap+1)
    if len(b)>cap:raise Boundary('RESOURCE_INCOMPLETE','FILE_READ_CAP')
    return b
def disk(d):
    if d.is_symlink() or not d.is_dir():raise Boundary('CHECKPOINT_UNVERIFIED','RUN_DIRECTORY')
    total=0
    for p in d.iterdir():
        if p.is_symlink() or not p.is_file():raise Boundary('CHECKPOINT_UNVERIFIED','RUN_DIRECTORY_SHAPE')
        total+=p.stat().st_size
    if total>POLICY['run_disk_bytes']:raise Boundary('RESOURCE_INCOMPLETE','RUN_DISK_CAP')
def private_write(p,b):
    if type(b)!=bytes or len(b)>POLICY['document_bytes']:raise Boundary('RESOURCE_INCOMPLETE','WRITE_BYTE_CAP')
    with open(p,'xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def install_limits(calibration):
    # Supported only in a single-threaded trusted POSIX supervisor.
    mem=POLICY['calibration_memory_bytes'] if calibration else POLICY['worker_memory_bytes']
    for key,cap in [(resource.RLIMIT_AS,mem),(resource.RLIMIT_FSIZE,POLICY['worker_file_bytes']),(resource.RLIMIT_NOFILE,POLICY['worker_open_files']),(resource.RLIMIT_CORE,0)]:resource.setrlimit(key,(cap,cap))
    resource.setrlimit(resource.RLIMIT_CPU,(POLICY['worker_cpu_seconds'],POLICY['worker_cpu_seconds']+1))
class Authority:
    """Caller-owned authority bundle and evidence identity for one run (never produced by the candidate)."""
    def __init__(self,envelope,receipt,signature,trust,mode,attempt_id):
        if mode not in ('TEST_AUTHORITY','DEV_UNSIGNED','DEPLOYMENT'):raise Boundary('INVALID_INPUT','AUTHORITY_MODE')
        if type(attempt_id) is not str or not sc.SAFE_ID_RE.fullmatch(attempt_id):raise Boundary('INVALID_INPUT','ATTEMPT_ID')
        for x in (envelope,receipt):
            if type(x) is not bytes:raise Boundary('CODE_IDENTITY_MISMATCH','EXTERNAL_AUTHORITY_MISSING')
        self.envelope,self.receipt,self.signature,self.trust,self.mode,self.attempt_id=envelope,receipt,signature,trust,mode,attempt_id
    def context(self,d):
        try:run_id=decode(self.receipt,POLICY['document_bytes']).get('run_id')
        except Exception:run_id=None
        return {'attempt_id':self.attempt_id,'run_dir_id':Path(d).name,'receipt_run_id':run_id,
                'envelope_sha256':sha(self.envelope),'receipt_sha256':sha(self.receipt),
                'trust_store_sha256':sha(self.trust) if type(self.trust) is bytes else None,
                'policy_sha256':sha((ROOT/'schemas/v0_9/p0a3g/resource_policy.json').read_bytes()),
                'interpreter_sha256':POLICY['interpreter_sha256'],'worker_source_sha256':sha(WORKER.read_bytes()),
                'code_files_sha256':sha(canonical(files()))}
def next_worker_id(d):
    n=len([p for p in d.iterdir() if p.name.endswith('.request.json')])
    if n>=POLICY['max_events_per_run']:raise Boundary('RESOURCE_INCOMPLETE','EVENT_CAP')
    return 'w%04d'%n
def child(mode,d,raw,auth,certificate=None,*,fault='none',evidence_fault='none',events=None):
    """Run one bounded worker; capture, save, re-read, record and reconcile its raw streams."""
    events=events if events is not None else [];d=Path(d);disk(d)
    if fault not in ACTUAL_FAULTS:return fail('INVALID_INPUT','FAULT_ENUM')
    if evidence_fault!='none' and evidence_fault not in sc.ALL_EVIDENCE_FAULTS:return fail('INVALID_INPUT','EVIDENCE_FAULT_ENUM')
    if (fault!='none' or evidence_fault!='none') and auth.mode=='DEPLOYMENT':return fail('INVALID_INPUT','DEV_FAULT_DISABLED')
    wid=next_worker_id(d)
    paths={k:d/(wid+'.'+k+suffix) for k,suffix in [('request','.json'),('expected','.json'),('signature','.bin'),('trust','.json'),('certificate','.json'),('receipt','.json')]}
    for key,data in [('request',raw),('expected',auth.envelope),('receipt',auth.receipt)]:private_write(paths[key],data)
    if auth.signature is not None:private_write(paths['signature'],auth.signature)
    if auth.trust is not None:private_write(paths['trust'],auth.trust)
    if certificate is not None:private_write(paths['certificate'],canonical(certificate))
    if sha(Path(POLICY['interpreter']).read_bytes())!=POLICY['interpreter_sha256']:return fail('ENVIRONMENT_UNQUALIFIED','INTERPRETER_IDENTITY')
    arg=lambda k:str(paths[k]) if paths[k].exists() else '-'
    cmd=[POLICY['interpreter'],'-I','-S','-B',str(WORKER),mode,arg('request'),arg('expected'),arg('signature'),arg('trust'),str(paths['certificate']),arg('receipt'),fault,auth.mode]
    limit=POLICY['worker_wall_seconds']
    ctx=auth.context(d)
    obs=sc.run_captured(cmd,wall_seconds=limit,cap_bytes=POLICY['stream_capture_bytes'],preexec=lambda:install_limits(mode.startswith('calibrate_')),env={'PATH':os.defpath,'LC_ALL':'C.UTF-8'},drain_seconds=POLICY['stream_drain_seconds'])
    event={'schema':sc.EVENT_SCHEMA,'worker_id':wid,**ctx,'mode':mode,'command':cmd,'wall_limit_seconds':limit,
           'process_fault':fault,'process_fault_class':'NONE' if fault=='none' else 'ACTUAL_PROCESS_FAULT',
           'evidence_fault':evidence_fault,'evidence_fault_class':'NONE' if evidence_fault=='none' else 'SIMULATED_EVIDENCE_FAULT',
           **{k:obs[k] for k in ('pid','returncode','signal','controller_timeout','controller_killed','stream_cap_exceeded','drain_complete','elapsed_ns')}}
    save_fault=lambda s:evidence_fault if (evidence_fault in sc.SAVE_FAULTS and s=='stdout') else 'none'
    for s in sc.STREAMS:
        data=obs[s]
        # Contemporaneous witness from the captured buffer itself, recorded before saving.
        event[s]={'path':wid+'.'+s,'capture_bytes':len(data),'capture_sha256':sc.sha256(data),'bytes':len(data),'sha256':sc.sha256(data)}
    try:
        for s in sc.STREAMS:sc.save_stream(d,wid+'.'+s,obs[s],save_fault(s))
    except OSError as e:
        # Captured bytes remain in the fsync'd .pending_ file; the event is still recorded.
        event['save_error']='STREAM_PATH_COLLISION' if isinstance(e,FileExistsError) else 'STREAM_SAVE_FAILED'
        try:sc.write_event(d,wid,event)
        except OSError:event['save_error']+='+EVENT_PATH_COLLISION'
        events.append(event)
        return fail('EVIDENCE_STREAM_MISMATCH',event['save_error'])
    if evidence_fault=='forge_stdout_108':event['stdout']['bytes'],event['stdout']['sha256']=sc.R1_RECORDED_STDOUT;event['stdout']['capture_bytes'],event['stdout']['capture_sha256']=sc.R1_RECORDED_STDOUT
    if evidence_fault=='stale_run':event['attempt_id']='P0A3F_R1_DEV_01'
    if evidence_fault=='wrong_worker_path':event['stdout']['path']='w0000.stdout' if wid!='w0000' else 'w0001.stdout'
    if evidence_fault=='duplicate_path':event['stderr']['path']=event['stdout']['path']
    try:sc.write_event(d,wid,event)
    except OSError:events.append(event);return fail('EVIDENCE_STREAM_MISMATCH','EVENT_PATH_COLLISION')
    events.append(event)
    if evidence_fault in sc.POST_SAVE_FAULTS:sc.apply_post_save_fault(d,wid,evidence_fault)
    # Independent fresh re-read of everything saved in this run directory.
    try:
        n=sc.reconcile_run(d,context=ctx,cap=POLICY['stream_capture_bytes'])
        event['reconciled_events_in_run']=n
    except sc.EvidenceMismatch as e:
        event['reconciliation']='FAILED:'+e.reason
        return fail('EVIDENCE_STREAM_MISMATCH',e.reason)
    event['reconciliation']='MATCH'
    if obs['controller_timeout']:return fail('RESOURCE_INCOMPLETE','CONTROLLER_WALL_TIMEOUT')
    if any(obs['stream_cap_exceeded'].values()):return fail('RESOURCE_INCOMPLETE','STREAM_CAPTURE_CAP')
    if obs['returncode']<0:return fail('UNKNOWN_TERMINATION','WORKER_SIGNAL_'+str(-obs['returncode']))
    if obs['returncode']!=0:return fail('INTERNAL_ERROR_NO_CERTIFICATE','WORKER_NONZERO_'+str(obs['returncode']))
    disk(d)
    # Decode ONLY the freshly re-read saved stdout bytes (already reconciled to the capture witness).
    try:return decode(sc.fresh_read(d/(wid+'.stdout'),POLICY['stream_capture_bytes']),POLICY['worker_file_bytes'])
    except (Boundary,sc.EvidenceMismatch):return fail('INTERNAL_ERROR_NO_CERTIFICATE','MALFORMED_WORKER_OUTPUT')
def compatible(trace):
    try:
        v=trace['sizes']['VmSize'];rss=trace['sizes']['VmRSS']
        return trace['state']=='CALIBRATION_ONLY' and type(v) is int and type(rss) is int and 0<rss<=v and v+POLICY['startup_margin_bytes']<=POLICY['worker_memory_bytes']
    except Exception:return False
def preflight(d,raw,auth,events):
    for mode in ('produce','check'):
        t=child('calibrate_'+mode,d,raw,auth,events=events)
        if events:events[-1]['calibration']=t
        if type(t)==dict and t.get('state')=='EVIDENCE_STREAM_MISMATCH':raise Boundary('EVIDENCE_STREAM_MISMATCH',t.get('reason'))
        if not compatible(t):raise Boundary('ENVIRONMENT_UNQUALIFIED','STARTUP_PREFLIGHT_FAILED')
def context(raw,auth):
    verify(auth.envelope,None,auth.receipt,auth.signature,auth.trust,mode=auth.mode)
    r,b=request(raw);v=verify(auth.envelope,sha(b),auth.receipt,auth.signature,auth.trust,mode=auth.mode)
    trust=decode(auth.receipt,POLICY['document_bytes'])
    work=sha(canonical({'input_sha256':sha(b),'expected_sha256':sha(auth.envelope),'caller_receipt_sha256':sha(auth.receipt),'run_id':trust['run_id'],'service':'p0a3g-supervisor-1'}))
    return r,b,work,v
def atomic_save(d,record,fault='none'):
    if fault not in ('none','before_write','after_flush','before_rename','after_rename','post_rename'):raise Boundary('INVALID_INPUT','FAULT_ENUM')
    disk(d);b=canonical(record)
    if len(b)>POLICY['document_bytes']:raise Boundary('RESOURCE_INCOMPLETE','CHECKPOINT_BYTE_CAP')
    if fault=='before_write':raise Boundary('RESOURCE_INCOMPLETE','SIMULATED_BEFORE_WRITE')
    fd,tmp=tempfile.mkstemp(prefix='pending_',suffix='.json',dir=d)
    with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
    if fault in ('after_flush','before_rename'):raise Boundary('RESOURCE_INCOMPLETE','SIMULATED_'+fault.upper())
    os.replace(tmp,d/'checkpoint.json')
    if fault=='after_rename':raise Boundary('RESOURCE_INCOMPLETE','SIMULATED_AFTER_RENAME_BEFORE_DIRECTORY_FSYNC')
    sc.fsync_dir(d)
    if fault=='post_rename':raise Boundary('RESOURCE_INCOMPLETE','SIMULATED_POST_RENAME_AFTER_DIRECTORY_FSYNC')
    disk(d)
def checked_record(raw,auth,certificate,d,events,check_fault='none',evidence_fault='none'):
    checked=child('check',d,raw,auth,certificate,events=events,fault=check_fault,evidence_fault=evidence_fault)
    if type(checked)!=dict or checked.get('state')!=SUCCESS:
        if type(checked)==dict and checked.get('state') in FAILURES:return fail(checked['state'],checked.get('reason','CHECKER_FAILURE'))
        return fail('INTERNAL_ERROR_NO_CERTIFICATE','UNEXPECTED_CHECKER_OUTPUT')
    if checked.get('certificate_sha256')!=sha(canonical(certificate)):return fail('INTERNAL_ERROR_NO_CERTIFICATE','CHECKED_BYTES_MISMATCH')
    return checked
def operation(raw,auth,directory,*,resume_mode=False,dev_fault='none',save_fault='none',check_fault='none',evidence_fault='none',evidence_fault_mode='check'):
    events=[]
    try:
        if not isinstance(auth,Authority):raise Boundary('CODE_IDENTITY_MISMATCH','EXTERNAL_AUTHORITY_MISSING')
        if auth.mode=='DEPLOYMENT' and any(x!='none' for x in (dev_fault,save_fault,check_fault,evidence_fault)):raise Boundary('INVALID_INPUT','DEV_FAULT_DISABLED')
        r,b,work,authority=context(raw,auth);d=Path(directory)
        ef=lambda m:evidence_fault if m==evidence_fault_mode else 'none'
        if resume_mode:
            disk(d)
            try:record=decode(bounded_file(d/'checkpoint.json',POLICY['document_bytes']),POLICY['document_bytes'])
            except Exception as e:raise Boundary('CHECKPOINT_UNVERIFIED','ABSENT_OR_TORN_CHECKPOINT') from e
            fields={'schema','work_identity','certificate_sha256','certificate','verification'}
            if type(record)!=dict or set(record)!=fields or record['schema']!='p0a3g-checkpoint-1' or record['work_identity']!=work or record['certificate_sha256']!=sha(canonical(record['certificate'])):raise Boundary('CHECKPOINT_UNVERIFIED','CHECKPOINT_BINDING')
            cert=record['certificate']
        else:
            if d.exists():raise Boundary('CHECKPOINT_UNVERIFIED','NEW_DIRECTORY_REQUIRED')
            d.mkdir(mode=0o700,parents=False)
        preflight(d,b,auth,events)
        if not resume_mode:
            cert=child('produce',d,b,auth,fault=dev_fault,evidence_fault=ef('produce'),events=events)
            if type(cert)!=dict:raise Boundary('INTERNAL_ERROR_NO_CERTIFICATE','WORKER_OBJECT')
            if cert.get('state') in FAILURES:raise Boundary(cert['state'],cert.get('reason','WORKER_FAILURE'))
        check=checked_record(b,auth,cert,d,events,check_fault,ef('check'))
        if check.get('state')!=SUCCESS:raise Boundary(check['state'],check.get('reason','CHECK_FAILURE'))
        if check.get('authority_status')!=authority['authority_status']:raise Boundary('CODE_IDENTITY_MISMATCH','PRODUCER_REFERENCE_AUTHORITY_DISAGREE')
        # Final whole-run stream reconciliation immediately before any completion record.
        try:sc.reconcile_run(d,context=auth.context(d),cap=POLICY['stream_capture_bytes'])
        except sc.EvidenceMismatch as e:raise Boundary('EVIDENCE_STREAM_MISMATCH',e.reason)
        if not resume_mode:
            record={'schema':'p0a3g-checkpoint-1','work_identity':work,'certificate_sha256':sha(canonical(cert)),'certificate':cert,'verification':check};atomic_save(d,record,save_fault)
        return {'schema':'p0a3g-result-1','state':SUCCESS,'work_identity':work,'certificate':cert,'verification':check,'worker_events':events,
                'authority_status':authority['authority_status'],'loaded_code_identity':authority['loaded_code_identity'],
                'stream_evidence':'ALL_WORKER_STREAMS_RECONCILED','recovery':'FRESH_REFERENCE_RECOMPUTED' if resume_mode else 'NEW_CHECKED_RECORD'}
    except Boundary as e:return {**fail(e.state,e.reason,raw),'worker_events':events}
    except (MemoryError,RecursionError):return {**fail('RESOURCE_INCOMPLETE','CONTROLLER_RUNTIME_LIMIT',raw),'worker_events':events}
    except Exception:return {**fail('INTERNAL_ERROR_NO_CERTIFICATE','CONTROLLER_IO_OR_INTERNAL',raw),'worker_events':events}
def run(raw,auth,directory,**options):return operation(raw,auth,directory,**options)
def resume(raw,auth,directory,**options):return operation(raw,auth,directory,resume_mode=True,**options)
