"""Bounded raw-byte request boundary. Does not change the frozen QO objective."""
import hashlib,json,re,sys
from pathlib import Path
from .core import validate,InvalidInput,NotEvaluable,canonical
from .algebra import ResourceIncomplete
ROOT=Path(__file__).resolve().parents[4]
POLICY=json.loads((ROOT/'schemas/v0_9/p0a3g/resource_policy.json').read_text())
class Boundary(Exception):
    def __init__(self,state,reason):self.state=state;self.reason=reason;super().__init__(reason)
def fail(state,reason,raw=None):
    out={'schema':'p0a3e-failure-1','state':state,'reason':reason}
    if type(raw) is bytes:out['raw_identity']={'bytes':len(raw),'hashed_prefix_bytes':min(len(raw),POLICY['request_bytes']),'prefix_sha256':hashlib.sha256(raw[:POLICY['request_bytes']]).hexdigest()}
    return out
def decode(raw,cap):
    if type(raw) is not bytes:raise Boundary('INVALID_INPUT','BYTES_REQUIRED')
    if len(raw)>cap:raise Boundary('RESOURCE_INCOMPLETE','RAW_BYTE_CAP')
    if any(c>127 for c in raw) or b'\\u' in raw:raise Boundary('INVALID_INPUT','ASCII_CANONICAL_TOKENS_REQUIRED')
    depth=0;quoted=False;escape=False;tokens=0;size=0
    for c in raw:
        if quoted:
            size+=1
            if size>POLICY['string_chars']:raise Boundary('RESOURCE_INCOMPLETE','STRING_CAP')
            if escape:escape=False
            elif c==92:escape=True
            elif c==34:quoted=False
        elif c==34:quoted=True;size=0;tokens+=1
        elif c in (91,123):
            depth+=1;tokens+=1
            if depth>POLICY['depth']:raise Boundary('RESOURCE_INCOMPLETE','DEPTH_CAP')
        elif c in (93,125):depth-=1
        elif c in (44,58):tokens+=1
        if tokens>POLICY['tokens']:raise Boundary('RESOURCE_INCOMPLETE','TOKEN_CAP')
    def pairs(items):
        out={}
        for k,v in items:
            if k in out:raise Boundary('INVALID_INPUT','DUPLICATE_KEY')
            out[k]=v
        return out
    def integer(s):
        if len(s.lstrip('-'))>POLICY['json_integer_digits']:raise Boundary('RESOURCE_INCOMPLETE','JSON_INTEGER_DIGIT_CAP')
        return int(s)
    def bad(x):raise Boundary('INVALID_INPUT','FLOAT_OR_NONFINITE_FORBIDDEN')
    try:o=json.loads(raw,object_pairs_hook=pairs,parse_int=integer,parse_float=bad,parse_constant=bad)
    except (ValueError,UnicodeError) as e:raise Boundary('INVALID_INPUT','JSON_SYNTAX') from e
    stack=[o]
    while stack:
        x=stack.pop()
        if type(x) in (dict,list):
            if len(x)>POLICY['container_items']:raise Boundary('RESOURCE_INCOMPLETE','CONTAINER_CAP')
            stack.extend(x.values() if type(x) is dict else x)
    if canonical(o).encode("ascii")!=raw:raise Boundary("INVALID_INPUT","NONCANONICAL_JSON")
    return o
def request(raw):
    r=decode(raw,POLICY['request_bytes'])
    try:
        if type(r) is not dict or type(r.get('limits')) is not dict:raise InvalidInput('request/limits')
        for k,v in r['limits'].items():
            if k not in POLICY or type(v) is not int or v<=0:raise InvalidInput('limits')
            if v>POLICY[k]:raise ResourceIncomplete('REQUEST_POLICY_CAP')
        # Length guard precedes all int/Fraction conversions.
        for p in r.get('paths',[]):
            if type(p) is not dict:raise InvalidInput('path object')
            if not isinstance(p.get('id'),str) or re.fullmatch(r'[A-Za-z0-9_.-]{1,64}',p['id']) is None:raise InvalidInput('ASCII ID')
            if type(p.get('vertices')) is not list:raise InvalidInput('vertices')
            for point in p['vertices']:
                if type(point) is not list:raise InvalidInput('point')
                for q in point:
                    if type(q) is not list:raise InvalidInput('rational')
                    for s in q:
                        if type(s) is not str:raise InvalidInput('integer string')
                        if len(s.lstrip('-'))>min(POLICY['integer_digits'],sys.get_int_max_str_digits() or POLICY['integer_digits']):raise ResourceIncomplete('INTEGER_DIGIT_CAP')
        validate(r)
    except ResourceIncomplete as e:raise Boundary('RESOURCE_INCOMPLETE',str(e)) from e
    except (InvalidInput,TypeError,KeyError,ValueError) as e:raise Boundary('INVALID_INPUT','REQUEST_GRAMMAR') from e
    return r,canonical(r).encode('ascii')
def parse_request(raw):
    try:
        r,b=request(raw)
        return {'schema':'p0a3e-parsed-1','state':'VALIDATED_INPUT','request':r,'canonical_sha256':hashlib.sha256(b).hexdigest()}
    except Boundary as e:return fail(e.state,e.reason,raw)
    except (MemoryError,RecursionError):return fail('RESOURCE_INCOMPLETE','PARSER_RUNTIME_LIMIT',raw)
    except Exception:return fail('INTERNAL_ERROR_NO_CERTIFICATE','PARSER_INTERNAL',raw)

def request_stream(stream):
    """Read at most cap+1 bytes; a trusted blocking stream adapter is required."""
    try:
        raw=stream.read(POLICY['request_bytes']+1)
        return parse_request(raw)
    except Exception:return fail('INVALID_INPUT','BOUNDED_STREAM_READ_FAILED')
