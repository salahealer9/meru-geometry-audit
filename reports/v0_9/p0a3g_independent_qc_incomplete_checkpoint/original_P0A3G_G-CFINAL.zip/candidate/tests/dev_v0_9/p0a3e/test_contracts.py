"""Prospectively bounded P0A3E generic engineering checks, never P0A4."""
import ast,copy,hashlib,json,os,sys,tempfile,unittest
from fractions import Fraction as F
from pathlib import Path
from meru_geometry.v0_9.qo2d_exact import core
from meru_geometry.v0_9.qo2d_exact import wire,identity,supervisor
from meru_geometry.v0_9.qo2d_exact.algebra import Tower,ResourceIncomplete,ExactDomainError
from reference.v0_9.qo2d_exact.arithmetic import Algebra,Incomplete,InvalidProof
from reference.v0_9.qo2d_exact import service
ROOT=Path(__file__).resolve().parents[3];EVIDENCE=Path(os.environ['P0A3E_DEV_EVIDENCE']);RUN=Path(os.environ['P0A3E_DEV_RUN']);RUN.mkdir(exist_ok=True)
L={k:wire.POLICY[k] for k in ('max_vertices','max_input_bits','max_operations','max_coefficient_bits','max_terms','max_formal_degree','reference_max_bits')}
A=[(0,1),(1,3),(4,4)];B=[(7,4),(5,5),(4,8)];LINE=[(-4,0),(4,0)]
def rat(x):q=F(x);return [str(q.numerator),str(q.denominator)]
def req(a=A,b=B):
    return {'schema':'qo2d-request-1','lane':core.LANE,'authority':core.AUTHORITY,'nuisance':'SO2_ONLY','limits':dict(L),'paths':[{'id':name,'ordered':True,'parameter_domain':'OPEN_INTERVAL','endpoints':[0,len(p)-1],'provenance':'INDEPENDENT_GENERIC','vertices':[[rat(x),rat(y)] for x,y in p]} for name,p in [('generic_a',a),('generic_b',b)]]}
def enc(x):return core.canonical(x).encode()
def pins(r):return enc(identity.proposal(hashlib.sha256(enc(r)).hexdigest()))
history={'scope':'DEV_ONLY_UNFROZEN_NO_REGISTERED_VALIDATION','cases':{},'checks':[]}
def record(name,value):
    history['checks'].append({'name':name,'value':value});EVIDENCE.write_text(json.dumps(history,sort_keys=True,indent=2,allow_nan=False)+'\n')
def reject_cert(c,r,label):
    out=service.verify(enc(r),enc(c),pins(r));record(label,out)
    if out.get('state')==service.SUCCESS:
        (RUN/'STOP_AND_QUARANTINE.txt').write_text('False/malformed certificate accepted: '+label+'\n')
        raise AssertionError('STOP_AND_QUARANTINE '+label)
    return out
class Tests(unittest.TestCase):
    certificates={};requests={}
    def test_01_canonical(self):
        r=req();out=wire.parse_request(enc(r));self.assertEqual(out['state'],'VALIDATED_INPUT');self.assertEqual(enc(out['request']),enc(r))
        other=req(list(reversed(A)),B);self.assertNotEqual(core.digest(other),core.digest(r));record('canonical',out['canonical_sha256'])
    def test_02_json_numbers_keys(self):
        for raw in (b'{"x":0,"x":1}',b'{"x":NaN}',b'{"x":Infinity}',b'{"x":1.0}',b'{"x":1e2}'):
            with self.subTest(raw=raw):self.assertEqual(wire.parse_request(raw)['state'],'INVALID_INPUT')
    def test_03_metadata(self):
        edits=[lambda r:r['paths'][0].update(endpoints=[False,2]),lambda r:r['paths'][0].update(ordered=1),lambda r:r['paths'][0]['vertices'][0].append(rat(0)),lambda r:r.update(extra=1)]
        for edit in edits:
            r=req();edit(r);self.assertEqual(wire.parse_request(enc(r))['state'],'INVALID_INPUT')
    def test_04_rationals(self):
        for bad in (['2','2'],['-0','1'],['01','1'],['1','0'],['１','1'],['1e2','1'],[True,'1']):
            r=req();r['paths'][0]['vertices'][0][0]=bad;self.assertEqual(wire.parse_request(enc(r))['state'],'INVALID_INPUT')
    def test_05_bounds(self):
        raws=[b' '*(wire.POLICY['request_bytes']+1),b'['*33+b'0'+b']'*33,b'"'+b'x'*5001+b'"',b'['+b'0,'*4096+b'0]',b'1234567890123']
        for raw in raws:self.assertEqual(wire.parse_request(raw)['state'],'RESOURCE_INCOMPLETE')
        r=req();r['paths'][0]['vertices'][0][0]=['9'*4301,'1'];self.assertEqual(wire.parse_request(enc(r))['state'],'RESOURCE_INCOMPLETE')
        r=req([(0,0)]*9);self.assertEqual(wire.parse_request(enc(r))['state'],'RESOURCE_INCOMPLETE')
        r=req();r['paths'][0]['vertices'][0][0]=rat(2**129);self.assertEqual(wire.parse_request(enc(r))['state'],'RESOURCE_INCOMPLETE')
        # Token cap exceeds request-byte cap: test bounded generic document decoder directly.
        with self.assertRaises(wire.Boundary) as ex:wire.decode(b'['+b'0,'*100001+b'0]',wire.POLICY['document_bytes'])
        self.assertEqual(ex.exception.reason,'TOKEN_CAP')
    def test_06_non_evaluable(self):
        self.assertEqual(wire.parse_request({})['state'],'INVALID_INPUT')
        r=req([(0,0),(0,0)]);out=supervisor.run(enc(r),pins(r),RUN/'constant');record('constant',out)
        self.assertEqual(out['state'],'NOT_EVALUABLE');self.assertNotIn('certificate',out)
    def test_07_production_dependent(self):
        t=Tower(L);h=t.root(t.coerce(2));v=t.root(3+2*h);self.assertEqual(t.sign(v-1-h),0);record('production_dependent','EXACT_ZERO')
    def test_08_reference_dependent(self):
        t=Algebra(L);h=t.root(t.number(2));v=t.root(t.plus(t.number(3),t.scale(h,2)));self.assertTrue(t.zero(t.minus(v,t.plus(t.number(1),h))));record('reference_dependent','EXACT_ZERO')
    def test_09_inverse(self):
        t=Tower(L);h=t.root(t.coerce(2));v=t.root(3+2*h);x=1+h+v;self.assertEqual(t.sign(x*t.inv(x)-1),0)
        with self.assertRaises(ExactDomainError):t.inv(v-1-h)
        z=Algebra(L);a=z.root(z.number(2));b=z.root(z.plus(z.number(3),z.scale(a,2)));x=z.plus(z.plus(z.number(1),a),b);self.assertTrue(z.zero(z.minus(z.product(x,z.inverse(x)),z.number(1))))
        with self.assertRaises(InvalidProof):z.inverse(z.minus(b,z.plus(z.number(1),a)))
    def test_10_near_zero(self):
        t=Tower(L);self.assertEqual(t.sign(t.root(t.coerce(2+F(1,2**18)))-t.root(t.coerce(2))),1)
        z=Algebra(L);self.assertEqual(z.sign(z.minus(z.root(z.number(2+F(1,2**18))),z.root(z.number(2)))),1)
    def test_11_five_certificates(self):
        cases={'rotation':req(),'subdivision':req([(0,1),(0,1),(F(1,2),2),(1,3),(4,4)],A),'tie':req(LINE,[(3,0),(-3,0),(3,0)]),'tiny':req(LINE,[(3,0),(-3,0),(3+F(1,2**18),0)]),'traversal':req(A,list(reversed(A)))}
        for name,r in cases.items():
            out=supervisor.run(enc(r),pins(r),RUN/name);history['cases'][name]={'request':r,'expected_DEV_manifest':json.loads(pins(r)),'result':out};record('case_'+name,out.get('state'))
            self.assertEqual(out['state'],service.SUCCESS)
            self.certificates[name]=out['certificate'];self.requests[name]=r
        self.assertEqual(self.certificates['rotation']['q'],[]);self.assertEqual(self.certificates['subdivision']['q'],[])
        self.assertEqual(self.certificates['tie']['q_squared'],[[0,['2','1']]])
        self.assertEqual(self.certificates['tie']['roll_state'],'EXACT_WHOLE_ROLL_TIE')
        for n in ('tiny','traversal'):self.assertEqual(self.certificates[n]['roll_state'],'EXACT_UNIQUE_PROPER_ROTATION')
        self.assertEqual(next(d['sign'] for d in self.certificates['tiny']['decisions'] if d['label']=='s'),1)
        self.assertNotEqual(self.certificates['traversal']['q'],[])
    def test_12_path_evidence(self):
        c=self.certificates['subdivision'];self.assertEqual(c['paths'][0]['zero_edges'],[{'edge_index':0,'reason':'EXACT_ZERO_CONSECUTIVE_EDGE'}]);self.assertEqual(len(self.certificates['traversal']['union']),4)
        for name,c in self.certificates.items():
            # Equal evaluated algebraic values can have different tower vectors.
            self.assertEqual(next(d['sign'] for d in c['decisions'] if d['label']=='direct_residual_minus_q2'),0)
            self.assertEqual(history['cases'][name]['result']['verification']['details']['check'],'ORIGINAL_INPUT_EXACT_RECOMPUTATION_AND_DIRECT_RESIDUAL')
    def test_13_score_forgery(self):
        c=copy.deepcopy(self.certificates['rotation']);c['q']=[[0,['1','1']]];self.assertEqual(reject_cert(c,self.requests['rotation'],'forged_score')['state'],'CERTIFICATE_REJECTED')
    def test_14_nonoptimal_rotation(self):
        c=copy.deepcopy(self.certificates['rotation']);one=[[0,['1','1']]];c['rotation']=[[one,[]],[[],one]];self.assertEqual(reject_cert(c,self.requests['rotation'],'nonoptimal_SO2')['state'],'CERTIFICATE_REJECTED')
    def test_15_partition(self):
        for mode in ('omit','duplicate','reverse_paths'):
            c=copy.deepcopy(self.certificates['traversal'])
            if mode=='omit':c['union'].pop(1)
            elif mode=='duplicate':c['union'].insert(1,c['union'][1])
            else:c['paths'].reverse()
            self.assertEqual(reject_cert(c,self.requests['traversal'],mode)['state'],'CERTIFICATE_REJECTED')
    def test_16_root_and_nested_grammar(self):
        for mode in ('negative','forward','duplicate','bool_mask','none_path','bool_event'):
            c=copy.deepcopy(self.certificates['subdivision'])
            if mode=='negative':c['roots'][0]=[[0,['-1','1']]]
            elif mode=='forward':c['roots'][0]=[[1,['1','1']]]
            elif mode=='duplicate':c['roots'][0]=[[0,['1','1']],[0,['1','1']]]
            elif mode=='bool_mask':c['roots'][0]=[[False,['1','1']]]
            elif mode=='none_path':c['paths'][0]=None
            else:c['paths'][0]['zero_edges'][0]['edge_index']=False
            self.assertEqual(reject_cert(c,self.requests['subdivision'],mode)['state'],'CERTIFICATE_REJECTED')
    def test_17_decisions(self):
        for mode in ('tie','status','decision'):
            c=copy.deepcopy(self.certificates['rotation'])
            if mode=='tie':c['roll_state']='EXACT_WHOLE_ROLL_TIE'
            elif mode=='status':c['machine_state']='GLOBAL_CERTIFIED'
            else:c['decisions'][0]['expression']=[]
            self.assertEqual(reject_cert(c,self.requests['rotation'],mode)['state'],'CERTIFICATE_REJECTED')
    def test_18_semantic_encoding(self):
        c=copy.deepcopy(self.certificates['rotation']);mask=1<<len(c['roots']);c['roots'].append([[0,['1','1']]]);c['q']=[[0,['-1','1']],[mask,['1','1']]]
        out=service.verify(enc(self.requests['rotation']),enc(c),pins(self.requests['rotation']));record('different_equal_construction',out);self.assertEqual(out['state'],service.SUCCESS)
    def test_19_input_digest_order(self):
        r=self.requests['rotation']
        for mode in ('digest','order'):
            c=copy.deepcopy(self.certificates['rotation'])
            if mode=='digest':c['input_sha256'][0]='0'*64
            else:c['request']['paths'][0]['vertices'].reverse()
            self.assertEqual(reject_cert(c,r,mode)['state'],'CERTIFICATE_REJECTED')
    def test_20_identity_layers(self):
        r=self.requests['rotation'];c=self.certificates['rotation'];base=json.loads(pins(r))
        for field in ('signed_parent','original_archive_sha256','environment_sha256','input_sha256'):
            p=copy.deepcopy(base);p[field]='0'*len(p[field]);out=service.verify(enc(r),enc(c),enc(p));record('wrong_'+field,out);self.assertEqual(out['state'],'CODE_IDENTITY_MISMATCH')
        for prefix in ('src/','reference/','schemas/','tests/'):
            p=copy.deepcopy(base);n=next(n for n in p['files'] if n.startswith(prefix));p['files'][n]='0'*64;out=service.verify(enc(r),enc(c),enc(p));self.assertEqual(out['state'],'CODE_IDENTITY_MISMATCH')
    def test_21_missing_pins(self):
        r=self.requests['rotation'];c=self.certificates['rotation']
        for p in (b'{}',b'null',b'{'):
            self.assertEqual(service.verify(enc(r),enc(c),p)['state'],'CODE_IDENTITY_MISMATCH')
        self.assertEqual(json.loads(pins(r))['authority_mode'],'DEV_UNFROZEN_EXPECTATIONS')
    def test_22_import_graph(self):
        graph={}
        for p in (ROOT/'reference/v0_9/qo2d_exact').glob('*.py'):
            imports=[]
            for n in ast.walk(ast.parse(p.read_text())):
                if isinstance(n,ast.Import):imports += [a.name for a in n.names]
                elif isinstance(n,ast.ImportFrom):imports.append('.'*n.level+(n.module or ''))
            self.assertFalse(any('meru_geometry' in n for n in imports));graph[p.name]=imports
        record('reference_DAG',graph)
    def test_23_caps(self):
        for key,val,op in [('max_operations',1,lambda t:t.root(t.coerce(2))),('max_terms',1,lambda t:t.root(t.coerce(2))+1),('max_formal_degree',1,lambda t:t.root(t.coerce(2))),('max_coefficient_bits',1,lambda t:t.coerce(4))]:
            lim=dict(L);lim[key]=val
            with self.assertRaises(ResourceIncomplete):op(Tower(lim))
        lim=dict(L);lim['reference_max_bits']=1;z=Algebra(lim)
        with self.assertRaises(Incomplete) as ex:z.sign(z.root(z.number(2)))
        self.assertIn('ISOLATION_CAP',str(ex.exception))
    def test_24_serialization(self):
        c=self.certificates['rotation'];self.assertEqual(enc(c),enc(json.loads(enc(c))));record('certificate_bytes_sha256',hashlib.sha256(enc(c)).hexdigest())
    def diagnostic(self,name,fault='none'):
        d=RUN/name;d.mkdir();r=req();events=[];out=supervisor.child('limits',d,enc(r),pins(r),fault=fault,events=events);record(name,{'result':out,'events':events});return out
    def test_25_limits(self):
        out=self.diagnostic('limits');self.assertEqual(out['recursion'],256);self.assertEqual(out['limits']['RLIMIT_AS'],[268435456,268435456]);self.assertEqual(out['limits']['RLIMIT_FSIZE'],[2097152,2097152])
    def test_26_timeout(self):
        out=self.diagnostic('timeout','timeout');self.assertEqual(out['state'],'RESOURCE_INCOMPLETE');self.assertNotIn('certificate',out)
    def test_27_exit_kill(self):
        self.assertEqual(self.diagnostic('exit','exit')['state'],'INTERNAL_ERROR_NO_CERTIFICATE');self.assertEqual(self.diagnostic('kill','kill')['state'],'UNKNOWN_TERMINATION')
    def test_28_memory_recursion(self):
        for fault in ('memory','recursion'):self.assertEqual(self.diagnostic(fault,fault)['state'],'RESOURCE_INCOMPLETE')
    def test_29_save_boundaries(self):
        d=RUN/'rotation';old=(d/'checkpoint.json').read_bytes();record_=json.loads(old)
        for fault in ('before_write','after_flush'):
            with self.assertRaises(wire.Boundary):supervisor.atomic_save(d,record_,fault)
            self.assertEqual((d/'checkpoint.json').read_bytes(),old)
            record(fault,{'old_complete_sha256':hashlib.sha256(old).hexdigest(),'pending_files':[p.name for p in d.glob('pending_*')]})
    def test_30_after_rename_resume(self):
        d=RUN/'rotation';record_=json.loads((d/'checkpoint.json').read_bytes())
        with self.assertRaises(wire.Boundary):supervisor.atomic_save(d,record_,'after_rename')
        r=self.requests['rotation'];out=supervisor.resume(enc(r),pins(r),d);record('recovery_after_rename',out);self.assertEqual(out['state'],service.SUCCESS)
    def test_31_torn_checkpoint(self):
        r=self.requests['rotation']
        for name,data in [('torn',b'{'),('mismatch',enc({'schema':'p0a3e-checkpoint-1','work_identity':'0'*64,'certificate':{},'verification':{}}))]:
            d=RUN/name;d.mkdir();(d/'checkpoint.json').write_bytes(data);out=supervisor.resume(enc(r),pins(r),d);record(name,out);self.assertNotEqual(out['state'],service.SUCCESS);self.assertNotIn('certificate',out)
    def test_32_output_disk_io(self):
        d=RUN/'disk';d.mkdir()
        with self.assertRaises(wire.Boundary):supervisor.private_write(d/'too_large',b'x'*(wire.POLICY['document_bytes']+1))
        with open(d/'sparse_limit','wb') as f:f.truncate(wire.POLICY['run_disk_bytes']+1)
        with self.assertRaises(wire.Boundary):supervisor.disk(d)
        r=req();out=supervisor.run(enc(r),pins(r),d);record('existing_directory_IO',out);self.assertEqual(out['state'],'INTERNAL_ERROR_NO_CERTIFICATE')
        with self.assertRaises(wire.Boundary):supervisor.bounded_file(d/'sparse_limit',wire.POLICY['request_bytes'])
if __name__=='__main__':unittest.main(verbosity=2,failfast=True)
