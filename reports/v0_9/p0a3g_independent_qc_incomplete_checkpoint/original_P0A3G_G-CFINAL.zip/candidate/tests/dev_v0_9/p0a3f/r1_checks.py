"""NEW R1 catalogue: 18 ordered engineering methods; no archived suite replay."""
import ast,copy,hashlib,io,json,os,sys,unittest
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from meru_geometry.v0_9.qo2d_exact import wire,identity,supervisor
from meru_geometry.v0_9.qo2d_exact.algebra import Tower,ExactDomainError
from reference.v0_9.qo2d_exact.arithmetic import Algebra,InvalidProof
from reference.v0_9.qo2d_exact import identity as refid
RPT=ROOT/'reports/v0_9/p0a3f_runtime_external_trust_qualification'
ATTEMPT=Path(sys.argv.pop(1));ATTEMPT.mkdir(exist_ok=False)
RUN=ATTEMPT/'raw_workers';RUN.mkdir()
FIX=RPT/'prerun_fixtures'
H={'attempt':ATTEMPT.name,'lane':'NEW_R1_DEV_ONLY','observations':[]}
def enc(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def record(name,value):
    H['observations'].append({'name':name,'value':value});(ATTEMPT/'evidence.json').write_bytes(enc(H))
def fixture(name='R'):
    return tuple((FIX/(name+suffix)).read_bytes() for suffix in ('.request.json','.expected.json','.receipt.json'))
def no_score(out):return 'certificate' not in out and 'score' not in out and 'q' not in out
class Checks(unittest.TestCase):
    certs={};outputs={}
    def test_01_external_gate(self):
        raw,m,t=fixture()
        for bad,receipt,dev in [(None,t,True),(b'{}',t,True),(m,None,True),(m,t,False)]:
            with self.assertRaises(wire.Boundary):identity.verify(bad,identity.sha(raw),receipt,allow_dev=dev)
            with self.assertRaises(refid.IdentityMismatch):refid.verify(bad,raw,receipt,allow_dev=dev)
        record('external_missing_unsigned_rejected',True)
    def test_02_external_tampering(self):
        raw,m,t=fixture();base=json.loads(m)
        for field in ('signed_parent','protocol_commit','recovery_commit','original_archive_sha256','environment_sha256','input_sha256'):
            x=copy.deepcopy(base);x[field]='0'*len(x[field]);altered=enc(x)
            # Even a caller receipt for the wrong pinned authority must fail.
            r=json.loads(t);r['expected_sha256']=identity.sha(altered)
            with self.assertRaises(wire.Boundary):identity.verify(altered,identity.sha(raw),enc(r),allow_dev=True)
            with self.assertRaises(refid.IdentityMismatch):refid.verify(altered,raw,enc(r),allow_dev=True)
        for prefix in ('src/','reference/','schemas/','tests/'):
            x=copy.deepcopy(base);key=next(n for n in x['files'] if n.startswith(prefix));x['files'][key]='0'*64;altered=enc(x)
            with self.assertRaises(wire.Boundary):identity.verify(altered,identity.sha(raw),t,allow_dev=True)
            with self.assertRaises(refid.IdentityMismatch):refid.verify(altered,raw,t,allow_dev=True)
        for field,value in [('signer','D4EC014EEFCC90E619D2AA59A91239ABCF512130'),('trust_mode','SIGNED_CODE_FREEZE'),('run_id',False),('expected_sha256','0'*64)]:
            r=json.loads(t);r[field]=value
            with self.assertRaises(wire.Boundary):identity.verify(m,identity.sha(raw),enc(r),allow_dev=True)
            with self.assertRaises(refid.IdentityMismatch):refid.verify(m,raw,enc(r),allow_dev=True)
        record('external_tampering',True)
    def test_03_loaded_function_and_imports(self):
        raw,m,t=fixture();old=wire.parse_request
        try:
            def changed(raw):return None
            changed.__module__=wire.__name__;wire.parse_request=changed
            with self.assertRaises(wire.Boundary):identity.verify(m,identity.sha(raw),t,allow_dev=True)
        finally:wire.parse_request=old
        graph={}
        for p in (ROOT/'reference').rglob('*.py'):
            imports=[]
            for n in ast.walk(ast.parse(p.read_text())):
                if isinstance(n,ast.Import):imports += [a.name for a in n.names]
                elif isinstance(n,ast.ImportFrom):imports.append('.'*n.level+(n.module or ''))
            self.assertFalse(any('meru_geometry' in x for x in imports));graph[p.relative_to(ROOT).as_posix()]=imports
        record('reference_import_graph',graph)
    def test_04_raw_grammar(self):
        raw,_,_=fixture();obj=json.loads(raw)
        malformed=[b' '+raw,raw+b'\n',b'{"x":0,"x":1}',b'{"x":NaN}',b'{"x":1.0}',b'null',b'\xff',b'{"a":"\\u0030"}']
        for data in malformed:
            result=wire.parse_request(data);record('raw_rejection',{'hex':data[:80].hex(),'result':result});self.assertEqual(result['state'],'INVALID_INPUT');self.assertNotIn('canonical_sha256',result)
        for q in [['-0','1'],['2','2'],['01','1'],['1','0'],[True,'1']]:
            r=copy.deepcopy(obj);r['paths'][0]['vertices'][0][0]=q;self.assertEqual(wire.parse_request(enc(r))['state'],'INVALID_INPUT')
        for field,value in [('endpoints',[False,2]),('ordered',1),('parameter_domain','CIRCLE')]:
            r=copy.deepcopy(obj);r['paths'][0][field]=value;self.assertEqual(wire.parse_request(enc(r))['state'],'INVALID_INPUT')
        self.assertEqual(wire.parse_request(raw)['state'],'VALIDATED_INPUT')
    def test_05_stream_and_caps(self):
        raw,_,_=fixture()
        class Stream(io.BytesIO):
            requested=[]
            def read(self,n=-1):self.requested.append(n);return super().read(n)
        stream=Stream(b'x'*(wire.POLICY['request_bytes']+2));out=wire.request_stream(stream)
        self.assertEqual(stream.requested,[65537]);self.assertEqual(out['state'],'RESOURCE_INCOMPLETE')
        for data in [b'['*33+b'0'+b']'*33,b'"'+b'x'*5001+b'"',b'1234567890123']:
            out=wire.parse_request(data);self.assertEqual(out['state'],'RESOURCE_INCOMPLETE');self.assertNotIn('canonical_sha256',out)
        record('stream_caps',{'requested':stream.requested,'out':out})
    def test_06_dependent_radicals(self):
        lim=json.loads(fixture()[0])['limits'];t=Tower(lim);a=t.root(t.coerce(3));b=t.root(4+2*a);self.assertEqual(t.sign(b-1-a),0);x=1+a+b;self.assertEqual(t.sign(x*t.inv(x)-1),0)
        with self.assertRaises(ExactDomainError):t.inv(b-1-a)
        q=Algebra(lim);u=q.root(q.number(3));v=q.root(q.plus(q.number(4),q.scale(u,2)));z=q.minus(v,q.plus(q.number(1),u));self.assertTrue(q.zero(z));x=q.plus(q.plus(q.number(1),u),v);self.assertTrue(q.zero(q.minus(q.product(x,q.inverse(x)),q.number(1))))
        with self.assertRaises(InvalidProof):q.inverse(z)
        record('dependent_sqrt_4_plus_2sqrt3','EXACT_EQUALITY_AND_INVERSION_DEV_ONLY')
    def test_07_fake_incompatible_preflight(self):
        self.assertFalse(supervisor.compatible({'state':'CALIBRATION_ONLY','sizes':{'VmSize':437256192,'VmRSS':10000000}}))
        self.assertFalse(supervisor.compatible({'state':'CALIBRATION_ONLY','sizes':{}}))
        self.assertFalse(supervisor.compatible({'state':'CALIBRATION_ONLY','sizes':{'VmSize':True,'VmRSS':1}}))
        record('fake_preflight_trace','REJECTED_BEFORE_EXACT_WORK; not actual allocation')
    def test_08_four_new_comparisons(self):
        for name in ['R','Z','T','N']:
            raw,m,t=fixture(name);out=supervisor.run(raw,m,t,RUN/name,allow_dev=True);self.outputs[name]=out;record('comparison_'+name,out)
            self.assertEqual(out['state'],supervisor.SUCCESS);self.certs[name]=out['certificate']
            self.assertEqual(out['verification']['details']['check'],'ORIGINAL_INPUT_EXACT_RECOMPUTATION_AND_DIRECT_RESIDUAL')
            self.assertEqual([e['mode'] for e in out['worker_events']],['calibrate_produce','calibrate_check','produce','check'])
        for name in ['R','Z']:self.assertEqual(next(d['sign'] for d in self.certs[name]['decisions'] if d['label']=='direct_residual_minus_q2'),0);self.assertEqual(self.certs[name]['q'],[])
        self.assertEqual(self.certs['Z']['paths'][0]['zero_edges'],[{'edge_index':0,'reason':'EXACT_ZERO_CONSECUTIVE_EDGE'}])
        self.assertEqual(self.certs['T']['roll_state'],'EXACT_WHOLE_ROLL_TIE')
        self.assertEqual(self.certs['N']['roll_state'],'EXACT_UNIQUE_PROPER_ROTATION')
        self.assertEqual(next(d['sign'] for d in self.certs['N']['decisions'] if d['label']=='s'),1)
    def check_mutation(self,c,label,expected='CERTIFICATE_REJECTED',name='R'):
        raw,m,t=fixture(name);d=RUN/label;d.mkdir();events=[]
        out=supervisor.child('check',d,raw,m,t,c,events=events,allow_dev=True);record(label,{'result':out,'events':events})
        if expected!=supervisor.SUCCESS and out.get('state')==supervisor.SUCCESS:
            (ATTEMPT/'STOP_AND_QUARANTINE.txt').write_text('False/malformed certificate accepted: '+label+'\n');raise AssertionError('STOP_AND_QUARANTINE '+label)
        self.assertEqual(out['state'],expected)
        if expected!=supervisor.SUCCESS:self.assertTrue(no_score(out))
    def test_09_nonoptimal_and_score(self):
        c=copy.deepcopy(self.certs['R']);one=[[0,['1','1']]];c['rotation']=[[one,[]],[[],one]];self.check_mutation(c,'nonoptimal_identity_SO2')
        c=copy.deepcopy(self.certs['R']);c['q']=one;self.check_mutation(c,'forged_q')
        c=copy.deepcopy(self.certs['R']);c['roll_state']='EXACT_WHOLE_ROLL_TIE';self.check_mutation(c,'forged_tie')
    def test_10_partition_and_traversal(self):
        c=copy.deepcopy(self.certs['R']);c['union'].pop(1);self.check_mutation(c,'missing_knot')
        c=copy.deepcopy(self.certs['R']);c['union'].insert(1,c['union'][1]);self.check_mutation(c,'duplicate_knot')
        c=copy.deepcopy(self.certs['R']);c['request']['paths'][0]['vertices'].reverse();self.check_mutation(c,'changed_traversal')
    def test_11_nested_roots(self):
        for label,value in [('negative_root',[[0,['-1','1']]]),('forward_root',[[1,['1','1']]]),('boolean_mask',[[False,['1','1']]])]:
            c=copy.deepcopy(self.certs['R']);c['roots'][0]=value;self.check_mutation(c,label)
        c=copy.deepcopy(self.certs['R']);c['paths'][0]=None;self.check_mutation(c,'null_path_record')
    def test_12_equal_serialization(self):
        c=copy.deepcopy(self.certs['R']);mask=1<<len(c['roots']);c['roots'].append([[0,['1','1']]]);c['q']=[[0,['-1','1']],[mask,['1','1']]];self.check_mutation(c,'equivalent_zero',supervisor.SUCCESS)
    def test_13_atomic_boundaries(self):
        # Reuse the checked certificate: no fresh comparison or optimizer.
        original=json.loads((RUN/'R/checkpoint.json').read_bytes())
        for fault in ['before_write','after_flush','before_rename','after_rename','post_rename']:
            d=RUN/('atomic_'+fault);d.mkdir()
            with self.assertRaises(wire.Boundary):supervisor.atomic_save(d,original,fault)
            final=d/'checkpoint.json';self.assertEqual(final.exists(),fault in ('after_rename','post_rename'))
            record('simulated_'+fault,{'final_exists':final.exists(),'files':[p.name for p in d.iterdir()]})
    def test_14_stale_verdict_recovery(self):
        raw,m,t=fixture();d=RUN/'stale_verdict';d.mkdir();record_json=json.loads((RUN/'R/checkpoint.json').read_bytes());record_json['verification']={'state':'UNTRUSTED_STALE_SAVED_VERDICT'};(d/'checkpoint.json').write_bytes(enc(record_json))
        out=supervisor.resume(raw,m,t,d,allow_dev=True);record('stale_verdict_checked_completion',out)
        self.assertEqual(out['state'],supervisor.SUCCESS);self.assertEqual(out['recovery'],'FRESH_REFERENCE_RECOMPUTED');self.assertEqual(out['worker_events'][-1]['mode'],'check');self.assertEqual(out['worker_events'][-1]['wall_limit_seconds'],8)
    def test_15_recovery_genuine_timeout(self):
        raw,m,t=fixture();d=RUN/'recovery_timeout';d.mkdir();(d/'checkpoint.json').write_bytes((RUN/'R/checkpoint.json').read_bytes())
        out=supervisor.resume(raw,m,t,d,allow_dev=True,check_fault='timeout');record('recovery_actual_controller_timeout',out)
        self.assertEqual(out['state'],'RESOURCE_INCOMPLETE');self.assertTrue(no_score(out));self.assertTrue(out['worker_events'][-1]['controller_timeout']);self.assertEqual(out['worker_events'][-1]['returncode'],-9);self.assertEqual(out['worker_events'][-1]['wall_limit_seconds'],8)
    def test_16_kill_exit_memory_recursion(self):
        raw,m,t=fixture()
        for fault,state in [('kill','UNKNOWN_TERMINATION'),('exit','INTERNAL_ERROR_NO_CERTIFICATE'),('memory','RESOURCE_INCOMPLETE'),('recursion','RESOURCE_INCOMPLETE')]:
            d=RUN/('fault_'+fault);d.mkdir();events=[];out=supervisor.child('produce',d,raw,m,t,events=events,allow_dev=True,fault=fault);record('fault_'+fault,{'result':out,'events':events});self.assertEqual(out['state'],state);self.assertTrue(no_score(out))
    def test_17_torn_absent_stale(self):
        raw,m,t=fixture()
        for kind in ['torn','absent','wrong_work','wrong_digest','wrong_caller']:
            d=RUN/('restart_'+kind);d.mkdir();r=json.loads((RUN/'R/checkpoint.json').read_bytes());receipt=t
            if kind=='wrong_work':r['work_identity']='0'*64
            if kind=='wrong_digest':r['certificate_sha256']='0'*64
            if kind=='wrong_caller':v=json.loads(t);v['run_id']='different';receipt=enc(v)
            if kind!='absent':(d/'checkpoint.json').write_bytes(b'{' if kind=='torn' else enc(r))
            out=supervisor.resume(raw,m,receipt,d,allow_dev=True);record(kind,out);self.assertEqual(out['state'],'CHECKPOINT_UNVERIFIED');self.assertTrue(no_score(out));self.assertEqual(out['worker_events'],[])
    def test_18_frozen_bytes(self):
        expected=json.loads((ROOT.parent/'intake/F0_VERIFIED.json').read_bytes())['kernels']
        for n,h in expected.items():self.assertEqual(hashlib.sha256((ROOT/n).read_bytes()).hexdigest(),h)
        record('frozen_kernels',expected)
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2,failfast=True).run(unittest.defaultTestLoader.loadTestsFromTestCase(Checks))
    record('attempt_summary',{'methods_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passed':result.wasSuccessful(),'quarantine':(ATTEMPT/'STOP_AND_QUARANTINE.txt').exists()})
    raise SystemExit(0 if result.wasSuccessful() else 1)
