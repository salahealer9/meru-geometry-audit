"""P0A3G prospective DEV catalogue: 14 ordered engineering methods G01..G14 (generic DEV only).

usage (from the candidate root's parent directory, never inside the Git checkout):
  /usr/bin/python3.12 -I -S -B <candidate>/tests/dev_v0_9/p0a3g/g_checks.py \
      <attempt_dir> <repo_checkout> <gnupghome_with_public_key> <private_key_dir>

* <attempt_dir> must not exist; it receives raw_workers/, controller/ and ledgers.
* <private_key_dir> is controller-owned, outside the candidate and outside <attempt_dir>;
  ephemeral NON-PRODUCTION test private keys live there only during the run.
* Subcases stay inside their registered method; the method count is fixed at 14.
No historical target, Hebrew glyph, P0A0 replay, optimizer or registered science is used.
"""
import copy, csv, hashlib, io, json, os, shutil, subprocess, sys, time, unittest, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT), str(Path(__file__).resolve().parent)]
import authority_fixtures as af                                              # noqa: E402
from meru_geometry.v0_9.qo2d_exact import wire, identity, supervisor        # noqa: E402
from meru_geometry.v0_9.qo2d_exact import streamcapture as sc               # noqa: E402
from reference.v0_9.qo2d_exact import identity as refid, ed25519_ref        # noqa: E402
from reference.v0_9.qo2d_exact import stream_reconcile as recon             # noqa: E402
from reference.v0_9.qo2d_exact import wire as refwire                       # noqa: E402

ATTEMPT = Path(sys.argv.pop(1)); REPO = Path(sys.argv.pop(1)); GNUPG = Path(sys.argv.pop(1)); KEYDIR = Path(sys.argv.pop(1))
ATTEMPT.mkdir(exist_ok=False)
RUN = ATTEMPT / 'raw_workers'; RUN.mkdir()
CTRL = ATTEMPT / 'controller'; CTRL.mkdir()
FIX = ROOT / 'tests/dev_v0_9/p0a3g/fixtures'
AID = ATTEMPT.name
H = {'attempt': AID, 'lane': 'P0A3G_NEW_DEV_ONLY', 'observations': []}
REGISTRY = {}          # run_dir (relative to raw_workers) -> list of registered simulated/harness faults
HARNESS_FAULT_RUNS = set()
EMPTY = hashlib.sha256(b'').hexdigest()
R1_STDOUT = (108, '23bcfd677effd3a3b5ff73bfce72328c0bd19148a79617be8b896a4e1d802807')
KERNELS = {'src/meru_geometry/v0_9/qo2d_exact/algebra.py': '442065847937252db00d3f63b02184c15d57989f958f764c5c731cb385de6d2d',
           'src/meru_geometry/v0_9/qo2d_exact/core.py': '37701d034d98725673240a881420892893906c70387f68432b5993f8557dd420',
           'reference/v0_9/qo2d_exact/arithmetic.py': '72b3c37f02be65b2df7616a94e84601d66cf4af5b7a50e878724de647e5bf0ba'}
FIXTURE_REQUEST_SHA = {'R': 'a13c91344f52c34f470546670f9c8e3f1f7ac35a7f71ed802636ffd3c9f1e339',
                       'Z': '6aa75922ce9779e3fce3ebf2707775939e20a9710720549e886576a10f3eb27c',
                       'T': '79d2c7df287980630eae3cb35fd812d142a0eeaf38907a302cbd22564eb697bc',
                       'N': '9b04169226802386b26b48c34176b5730eab3b22c1606c99e98ea86b5a4dc6bd'}
SIGNED = {'P0A3G': 'adacfdbc6efcca4922c8d087d029b67e9b0c5dc5', 'PARENT': 'd95c50ea96744ce266058c51f85fff320d1a27df',
          'BLOB': '00a4e6ac85403f2a6e4704963a858d43faef136b', 'FPR': 'D4EC014EEFCC90E619D2AA59A91239ABCF512130'}
ARCHIVES = {
    'reports/v0_9/p0a3f_r1_independent_qc_incomplete_checkpoint/original_P0A3F_RECOVERY_R1_R1-C0.zip': '0487dcebb13e56cb49cb51886dae2ad0a673c023bf66b52084e7756a42c2f60d',
    'reports/v0_9/p0a3f_r1_independent_qc_incomplete_checkpoint/original_P0A3F_RECOVERY_R1_R1-C1.zip': '19b34f8d691e2ea3b127a6b2b8a16d4d9d5e925f47802094b4851b2c9644c812',
    'reports/v0_9/p0a3f_r1_independent_qc_incomplete_checkpoint/original_P0A3F_RECOVERY_R1_R1-C2.zip': 'f18a32551d30b8b89f8eb85242e431c8fbb1cf213903aa5710da19fab8b320f7',
    'reports/v0_9/p0a3f_r1_independent_qc_incomplete_checkpoint/original_P0A3F_RECOVERY_R1_R1-CFINAL.zip': '6ec2b6e96234836d629398fb7fc781909de8b47b0bf80f5cae11202620ff2f15',
    'reports/v0_9/p0a3f_r1_independent_qc_incomplete_checkpoint/original_P0A3F_RECOVERY_R1_INDEPENDENT_QC_2026-10-21.zip': 'aa810c66ac6454a1d04a30cc597612b61006bca0dc7d5c3340726efa4a6cf305',
    'reports/v0_9/p0a3e_incomplete_checkpoint/original_P0A3E_cumulative_implementation_candidate.zip': '1e73c2685bd4eb8fba89e4e8ea609e97c7b4716805e83c64af374a4265522ea8',
    'reports/v0_9/p0a3f_evidence_loss_incident/original_P0A3F_EVIDENCE_LOSS_INCIDENT_2026-10-21.zip': '8048fdf7c56d82b8f560f98cd7b40bea99eb66837ef1e7be49934a4d1303f88d'}


def enc(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False, default=repr).encode()


def h(b):
    return hashlib.sha256(b).hexdigest()


def record(name, value):
    H['observations'].append({'name': name, 'value': value})
    (ATTEMPT / 'evidence.json').write_bytes(enc(H))


def register(run_rel, fault):
    REGISTRY.setdefault(run_rel, []).append(fault)
    (CTRL / 'registered_faults.json').write_bytes(enc(REGISTRY))


def request(name):
    return (FIX / (name + '.request.json')).read_bytes()


def no_score(out):
    return 'certificate' not in out and 'score' not in out and 'q' not in out


def quarantine(label):
    (ATTEMPT / 'STOP_AND_QUARANTINE.txt').write_text('False/forbidden acceptance: ' + label + '\n')
    raise AssertionError('STOP_AND_QUARANTINE ' + label)


KEYS = {}


def keys():
    if not KEYS:
        KEYS['A'] = af.TestKey(KEYDIR, 'test-key-A')
        KEYS['B'] = af.TestKey(KEYDIR, 'test-key-B')
        KEYS['store'] = af.trust_store([KEYS['A'].public_record()])
        (CTRL / 'trust_store.json').write_bytes(KEYS['store'])
        (CTRL / 'NON_PRODUCTION_TEST_PUBLIC_KEYS.json').write_bytes(enc({
            'label': 'NON_PRODUCTION_TEST_AUTHORITY', 'generated_by': 'openssl genpkey -algorithm ed25519 (controller)',
            'keys': [KEYS['A'].public_record(), KEYS['B'].public_record(scope='NOT_IN_TRUST_STORE')],
            'trust_store_sha256': h(KEYS['store']),
            'note': 'Private keys existed only under the controller key directory during this attempt and were destroyed.'}))
    return KEYS


def bundle(raw, run_id, *, mode='TEST_AUTHORITY', signer='A', key_id='test-key-A', authority_mode='NON_PRODUCTION_TEST_AUTHORITY',
           env_over=None, rec_over=None, store=None, sign=True):
    k = keys()
    env = af.envelope(ROOT, raw, run_id, authority_mode=authority_mode, key_id=key_id, overrides=env_over)
    sig = k[signer].sign(env) if sign else None
    trust = k['store'] if store is None else store
    if mode == 'DEV_UNSIGNED':
        trust = None
    rec = af.receipt(env, run_id, mode, sig, trust, overrides=rec_over)
    return env, rec, sig, trust, mode


def auth(b):
    env, rec, sig, trust, mode = b
    return supervisor.Authority(env, rec, sig, trust, mode, AID)


def both_reject(b, raw, label):
    env, rec, sig, trust, mode = b
    canon = wire.request(raw)[1]
    prod = ref = 'ACCEPTED'
    try:
        identity.verify(env, h(canon), rec, sig, trust, mode=mode)
    except wire.Boundary as e:
        prod = e.state
    try:
        refid.verify(env, canon, rec, sig, trust, mode=mode)
    except refid.IdentityMismatch:
        ref = 'IDENTITY_MISMATCH'
    if prod == 'ACCEPTED' or ref == 'ACCEPTED':
        quarantine('authority accepted: ' + label)
    return {'case': label, 'production': prod, 'reference': ref}


def read_streams(run_dir, ev):
    out = {}
    for s in ('stdout', 'stderr'):
        with open(run_dir / ev[s]['path'], 'rb') as f:  # independent plain re-read
            b = f.read()
        out[s] = b
    return out


def event_files(run_dir):
    return [json.loads((run_dir / p.name).read_bytes()) for p in sorted(run_dir.glob('w*.event.json'))]


def tree_ok(run_rel):
    """Independent reference reconciliation of one run directory (rows must all MATCH)."""
    rows, _ = recon.reconcile_tree(recon.tree_from_dir(str(RUN)), expected_attempt_id=AID)
    mine = [r for r in rows if r.get('run_dir') == run_rel]
    summ = {'run_dir': run_rel, 'rows': len(mine), 'statuses': sorted({r['status'] for r in mine})}
    return bool(mine) and all(r['status'] == 'MATCH' for r in mine), summ


class G(unittest.TestCase):
    cert = {}
    out = {}
    bundles = {}

    # ------------------------------------------------------------------ G01
    def test_G01_signed_sources_archives_kernels_r1_qc(self):
        env = {'GNUPGHOME': str(GNUPG), 'PATH': os.defpath, 'LC_ALL': 'C.UTF-8'}
        git = lambda *a: subprocess.run(['git', '-C', str(REPO), *a], capture_output=True, text=True, env=env)
        head = git('rev-parse', 'HEAD').stdout.strip()
        self.assertEqual(head, SIGNED['P0A3G'])
        self.assertEqual(git('rev-parse', SIGNED['P0A3G'] + '^').stdout.strip(), SIGNED['PARENT'])
        self.assertEqual(git('status', '--porcelain').stdout, '')
        self.assertEqual(git('diff', '--name-status', SIGNED['PARENT'], SIGNED['P0A3G']).stdout.strip(),
                         'A\tdocs/v0_9/p0a3g_raw_worker_evidence_and_external_trust_followup_protocol_2026_10_21.md')
        self.assertEqual(git('rev-parse', SIGNED['P0A3G'] + ':docs/v0_9/p0a3g_raw_worker_evidence_and_external_trust_followup_protocol_2026_10_21.md').stdout.strip(), SIGNED['BLOB'])
        sigs = {}
        for c in (SIGNED['P0A3G'], SIGNED['PARENT']):
            r = git('verify-commit', '--raw', c)
            sigs[c] = [l for l in r.stderr.splitlines() if 'VALIDSIG' in l or 'GOODSIG' in l]
            self.assertTrue(any(('VALIDSIG ' + SIGNED['FPR']) in l for l in r.stderr.splitlines()))
        arch = {}
        for rel, pin in ARCHIVES.items():
            arch[rel] = h((REPO / rel).read_bytes())
            self.assertEqual(arch[rel], pin)
        kern = {k: h((ROOT / k).read_bytes()) for k in KERNELS}
        self.assertEqual(kern, KERNELS)
        # R1 QCF01 negative finding still exactly as signed (read-only, in memory).
        z = zipfile.ZipFile(REPO / 'reports/v0_9/p0a3f_r1_independent_qc_incomplete_checkpoint/original_P0A3F_RECOVERY_R1_R1-CFINAL.zip')
        pfx = 'candidate/reports/v0_9/p0a3f_runtime_external_trust_qualification/attempts/P0A3F_R1_DEV_01/'
        ev = json.loads(z.read(pfx + 'evidence.json'))
        found = []

        def walk(x):
            if isinstance(x, dict):
                if 'command' in x and 'stdout_bytes' in x:
                    found.append(x)
                for v in x.values():
                    walk(v)
            elif isinstance(x, list):
                for v in x:
                    walk(v)
        walk(ev)
        mism = []
        for e in found:
            req = [a for a in e['command'] if a.endswith('_request.json')][0]
            case, w = req.split('/raw_workers/')[1].split('/')[0], req.rsplit('/', 1)[1].split('_request')[0]
            for s, fn in (('stdout', w + '_stdout.json'), ('stderr', w + '_stderr.log')):
                b = z.read(pfx + 'raw_workers/%s/%s' % (case, fn))
                if (len(b), h(b)) != (e[s + '_bytes'], e[s + '_sha256']):
                    mism.append((case, s, e[s + '_bytes'], len(b)))
        self.assertEqual(len(found), 37)
        self.assertEqual(sorted(mism), [('forged_q', 'stdout', 108, 0), ('null_path_record', 'stdout', 108, 0)])
        record('G01', {'head': head, 'signature_status_lines': sigs, 'archives': arch, 'kernels': kern,
                       'r1_events': len(found), 'r1_stream_identities': 2 * len(found),
                       'r1_mismatches': mism, 'repo_clean': True})

    # ------------------------------------------------------------------ G02
    def test_G02_nonempty_streams_captured_and_reread(self):
        raw = request('R'); b = bundle(raw, 'G02_R'); self.bundles['R'] = b
        out = supervisor.run(raw, auth(b), RUN / 'G02_R'); self.out['R'] = out
        record('G02_result', out)
        self.assertEqual(out['state'], supervisor.SUCCESS)
        self.cert['R'] = out['certificate']
        self.assertEqual(out['authority_status'], 'NON_PRODUCTION_TEST_AUTHORITY_VERIFIED')
        self.assertEqual(out['loaded_code_identity'], 'LOADED_CODE_IDENTITY_UNVERIFIED')
        self.assertTrue((RUN / 'G02_R/checkpoint.json').exists())
        evs = event_files(RUN / 'G02_R')
        self.assertEqual([e['mode'] for e in evs], ['calibrate_produce', 'calibrate_check', 'produce', 'check'])
        rows = []
        for e in evs:
            st = read_streams(RUN / 'G02_R', e)
            for s in ('stdout', 'stderr'):
                self.assertGreater(len(st[s]), 0)
                self.assertEqual((len(st[s]), h(st[s])), (e[s]['bytes'], e[s]['sha256']))
                self.assertEqual((e[s]['capture_bytes'], e[s]['capture_sha256']), (e[s]['bytes'], e[s]['sha256']))
                rows.append((e['worker_id'], s, len(st[s]), h(st[s])))
        ok, summ = tree_ok('G02_R'); self.assertTrue(ok)
        record('G02', {'stream_rows': rows, 'reference_reconciler': summ})

    # ------------------------------------------------------------------ G03
    def check_mutation(self, c, label, expected='CERTIFICATE_REJECTED'):
        raw = request('R'); d = RUN / label; d.mkdir(); events = []
        out = supervisor.child('check', d, raw, auth(self.bundles['R']), c, events=events)
        if expected != supervisor.SUCCESS and out.get('state') == supervisor.SUCCESS:
            quarantine(label)
        self.assertEqual(out.get('state'), expected)
        if expected != supervisor.SUCCESS:
            self.assertTrue(no_score(out))
        ok, summ = tree_ok(label); self.assertTrue(ok)
        e = event_files(d)[0]; st = read_streams(d, e)
        self.assertGreater(len(st['stdout']), 0); self.assertGreater(len(st['stderr']), 0)
        return {'label': label, 'result': out, 'stdout_bytes': len(st['stdout']), 'stdout_sha256': h(st['stdout']),
                'stderr_bytes': len(st['stderr']), 'stderr_sha256': h(st['stderr']), 'reference_reconciler': summ}

    def test_G03_fresh_forged_q_and_null_path_record(self):
        one = [[0, ['1', '1']]]
        c = copy.deepcopy(self.cert['R']); c['q'] = one
        a = self.check_mutation(c, 'G03_forged_q')
        c = copy.deepcopy(self.cert['R']); c['paths'][0] = None
        b = self.check_mutation(c, 'G03_null_path_record')
        record('G03', {'cases': [a, b], 'note': 'NEW P0A3G events; not R1 recovered bytes'})

    # ------------------------------------------------------------------ G04
    def test_G04_r1_type_108_vs_zero_byte_mismatch(self):
        raw = request('R'); res = {}
        # (a) genuine zero-byte stdout (actual SIGKILL) + forged event metadata 108/23bcfd...
        d = RUN / 'G04a_forged_metadata'; d.mkdir(); register('G04a_forged_metadata', 'forge_stdout_108')
        out = supervisor.child('produce', d, raw, auth(self.bundles['R']), fault='kill', evidence_fault='forge_stdout_108', events=[])
        self.assertEqual((out['state'], out['reason']), ('EVIDENCE_STREAM_MISMATCH', 'STREAM_BYTES_MISMATCH:stdout'))
        e = event_files(d)[0]; st = read_streams(d, e)
        self.assertEqual((e['stdout']['bytes'], e['stdout']['sha256']), R1_STDOUT)
        self.assertEqual((len(st['stdout']), h(st['stdout'])), (0, EMPTY))
        self.assertEqual(e['process_fault_class'], 'ACTUAL_PROCESS_FAULT'); self.assertEqual(e['evidence_fault_class'], 'SIMULATED_EVIDENCE_FAULT')
        res['a'] = {'result': out, 'recorded': [e['stdout']['bytes'], e['stdout']['sha256']], 'saved': [len(st['stdout']), h(st['stdout'])]}
        # (b) truthful 108-byte rejection capture, retained file zeroed after save
        c = copy.deepcopy(self.cert['R']); c['q'] = [[0, ['1', '1']]]
        d = RUN / 'G04b_zeroed_rejection_stdout'; d.mkdir(); register('G04b_zeroed_rejection_stdout', 'zero_stdout_after_save')
        out = supervisor.child('check', d, raw, auth(self.bundles['R']), c, evidence_fault='zero_stdout_after_save', events=[])
        self.assertEqual(out['state'], 'EVIDENCE_STREAM_MISMATCH'); self.assertTrue(no_score(out))
        e = event_files(d)[0]; st = read_streams(d, e)
        self.assertEqual((e['stdout']['bytes'], e['stdout']['sha256']), R1_STDOUT)
        self.assertEqual((len(st['stdout']), h(st['stdout'])), (0, EMPTY))
        res['b'] = {'result': out, 'recorded': [e['stdout']['bytes'], e['stdout']['sha256']], 'saved': [len(st['stdout']), h(st['stdout'])]}
        # (c) a run that would otherwise succeed: checker stdout zeroed -> success denied, no checkpoint
        b = bundle(raw, 'G04c_R'); register('G04c_R', 'zero_stdout_after_save')
        out = supervisor.run(raw, auth(b), RUN / 'G04c_R', evidence_fault='zero_stdout_after_save', evidence_fault_mode='check')
        self.assertEqual(out['state'], 'EVIDENCE_STREAM_MISMATCH'); self.assertTrue(no_score(out))
        self.assertFalse((RUN / 'G04c_R/checkpoint.json').exists())
        res['c'] = {'result': out}
        for k in ('G04a_forged_metadata', 'G04b_zeroed_rejection_stdout', 'G04c_R'):
            rows, _ = recon.reconcile_tree(recon.tree_from_dir(str(RUN / k)), expected_attempt_id=AID)
            self.assertTrue(any(r['status'] == 'MISMATCH_DECLARED_SIMULATED_FAULT' and 'BYTES_OR_SHA256' in r['problems'] for r in rows))
        record('G04', res)

    # ------------------------------------------------------------------ G05
    def test_G05_truncated_altered_missing_streams(self):
        raw = request('R'); res = []
        cases = [('check', 'truncate_stdout'), ('check', 'alter_stdout'), ('check', 'delete_stdout'),
                 ('check', 'truncate_stderr'), ('check', 'alter_stderr'), ('check', 'delete_stderr'),
                 ('produce', 'truncate_stdout')]
        for mode, fault in cases:
            name = 'G05_%s_%s' % (mode, fault); register(name, fault)
            out = supervisor.run(raw, auth(bundle(raw, name)), RUN / name, evidence_fault=fault, evidence_fault_mode=mode)
            self.assertEqual(out['state'], 'EVIDENCE_STREAM_MISMATCH'); self.assertTrue(no_score(out))
            self.assertFalse((RUN / name / 'checkpoint.json').exists())
            res.append({'case': name, 'state': out['state'], 'reason': out['reason']})
        record('G05', res)

    # ------------------------------------------------------------------ G06
    def test_G06_swap_duplicate_stale_wrong_worker_collision(self):
        raw = request('R'); res = []
        for fault in ('swap_streams', 'duplicate_path', 'stale_run', 'wrong_worker_path', 'path_collision', 'orphan_stream_file'):
            name = 'G06_' + fault; d = RUN / name; d.mkdir(); register(name, fault)
            pre = supervisor.child('calibrate_check', d, raw, auth(self.bundles['R']), events=[])
            self.assertEqual(pre.get('state'), 'CALIBRATION_ONLY')
            out = supervisor.child('check', d, raw, auth(self.bundles['R']), self.cert['R'], evidence_fault=fault, events=[])
            self.assertEqual(out['state'], 'EVIDENCE_STREAM_MISMATCH'); self.assertTrue(no_score(out))
            res.append({'case': name, 'reason': out['reason']})
        # Harness-level stale evidence: a foreign run's event and streams copied into a new run directory.
        name = 'G06_foreign_event_copy'; d = RUN / name; d.mkdir(); register(name, 'HARNESS:foreign_event_copy'); HARNESS_FAULT_RUNS.add(name)
        for suffix in ('.request.json', '.event.json', '.stdout', '.stderr'):
            shutil.copy2(RUN / 'G02_R' / ('w0000' + suffix), d / ('w0000' + suffix))
        out = supervisor.child('calibrate_check', d, raw, auth(self.bundles['R']), events=[])
        self.assertEqual(out['state'], 'EVIDENCE_STREAM_MISMATCH')
        res.append({'case': name, 'reason': out['reason']})
        # Reusing an existing run directory for a new run is refused.
        out = supervisor.run(raw, auth(self.bundles['R']), RUN / 'G02_R')
        self.assertEqual((out['state'], out['reason']), ('CHECKPOINT_UNVERIFIED', 'NEW_DIRECTORY_REQUIRED'))
        res.append({'case': 'G06_reuse_existing_run_directory', 'reason': out['reason']})
        record('G06', res)

    # ------------------------------------------------------------------ G07
    def test_G07_interrupted_short_tamper_and_retrieved_archive(self):
        raw = request('R'); res = []
        for fault in ('before_rename', 'short_write', 'after_rename_tamper'):
            name = 'G07_' + fault; register(name, fault)
            out = supervisor.run(raw, auth(bundle(raw, name)), RUN / name, evidence_fault=fault, evidence_fault_mode='check')
            self.assertEqual(out['state'], 'EVIDENCE_STREAM_MISMATCH'); self.assertTrue(no_score(out))
            self.assertFalse((RUN / name / 'checkpoint.json').exists())
            evs = event_files(RUN / name)
            self.assertEqual(evs[-1]['evidence_fault_class'], 'SIMULATED_EVIDENCE_FAULT')
            self.assertEqual(evs[-1]['process_fault_class'], 'NONE')
            res.append({'case': name, 'reason': out['reason']})
        # Simulated checkpoint-write interruptions (R1 contract retained) and restart from torn record.
        original = json.loads((RUN / 'G02_R/checkpoint.json').read_bytes())
        for fault in ('before_write', 'after_flush', 'before_rename', 'after_rename', 'post_rename'):
            d = RUN / ('G07_checkpoint_' + fault); d.mkdir()
            with self.assertRaises(wire.Boundary):
                supervisor.atomic_save(d, original, fault)
            res.append({'case': 'checkpoint_' + fault, 'final_exists': (d / 'checkpoint.json').exists(),
                        'files': sorted(p.name for p in d.iterdir())})
        d = RUN / 'G07_restart_torn'; d.mkdir(); (d / 'checkpoint.json').write_bytes(b'{')
        out = supervisor.resume(raw, auth(self.bundles['R']), d)
        self.assertEqual((out['state'], out['reason']), ('CHECKPOINT_UNVERIFIED', 'ABSENT_OR_TORN_CHECKPOINT'))
        res.append({'case': 'restart_torn', 'reason': out['reason']})
        # Retrieved evidence archive verification (archives built in memory only).
        def pack(files):
            bio = io.BytesIO()
            with zipfile.ZipFile(bio, 'w', zipfile.ZIP_DEFLATED) as z:
                sums = ''
                for n in sorted(files):
                    zi = zipfile.ZipInfo(n, (1980, 1, 1, 0, 0, 0)); z.writestr(zi, files[n]); sums += '%s  %s\n' % (h(files[n]), n)
                z.writestr(zipfile.ZipInfo('SHA256SUMS', (1980, 1, 1, 0, 0, 0)), sums)
            return bio.getvalue()
        src = {'G02_R/' + p.name: p.read_bytes() for p in sorted((RUN / 'G02_R').iterdir()) if p.name.startswith('w')}
        good = pack(src)
        ok, rep = recon.verify_archive(good, h(good), len(good)); self.assertTrue(ok)
        flipped = bytearray(good); flipped[len(flipped) // 2] ^= 0xFF; flipped = bytes(flipped)
        ok2, rep2 = recon.verify_archive(flipped, h(good), len(good)); self.assertFalse(ok2)
        altered = dict(src); k = 'G02_R/w0003.stdout'; altered[k] = altered[k][:-1] + b' '
        consistent_but_wrong = pack(altered)
        ok3, rep3 = recon.verify_archive(consistent_but_wrong, h(consistent_but_wrong), len(consistent_but_wrong)); self.assertFalse(ok3)
        res.append({'case': 'archive_good', 'ok': ok, 'report': rep, 'bytes': len(good), 'sha256': h(good)})
        res.append({'case': 'archive_outer_tampered', 'ok': ok2, 'report': rep2})
        res.append({'case': 'archive_valid_zip_and_manifest_but_stream_altered', 'ok': ok3, 'report': rep3})
        record('G07', res)

    # ------------------------------------------------------------------ G08
    def test_G08_actual_abnormal_exit_and_timeout(self):
        raw = request('R'); res = []
        for fault, state in (('exit', 'INTERNAL_ERROR_NO_CERTIFICATE'), ('kill', 'UNKNOWN_TERMINATION'),
                             ('partial_then_kill', 'UNKNOWN_TERMINATION'), ('memory', 'RESOURCE_INCOMPLETE'),
                             ('recursion', 'RESOURCE_INCOMPLETE')):
            name = 'G08_' + fault; d = RUN / name; d.mkdir()
            out = supervisor.child('produce', d, raw, auth(self.bundles['R']), fault=fault, events=[])
            self.assertEqual(out['state'], state); self.assertTrue(no_score(out))
            e = event_files(d)[0]; st = read_streams(d, e)
            self.assertEqual(e['process_fault_class'], 'ACTUAL_PROCESS_FAULT')
            ok, summ = tree_ok(name); self.assertTrue(ok)
            if fault in ('exit', 'kill'):
                self.assertEqual((len(st['stdout']), h(st['stdout'])), (0, EMPTY))
            if fault == 'partial_then_kill':
                self.assertEqual(st['stdout'], b'{"partial":\xff\xfe\x00non-utf8')
                self.assertIn(b'\xc3\x28 partial stderr before kill', st['stderr'])
            res.append({'case': name, 'state': out['state'], 'reason': out['reason'], 'returncode': e['returncode'],
                        'stdout': [len(st['stdout']), h(st['stdout'])], 'stderr': [len(st['stderr']), h(st['stderr'])]})
        name = 'G08_genuine_timeout'
        out = supervisor.run(raw, auth(bundle(raw, name)), RUN / name, dev_fault='timeout')
        self.assertEqual((out['state'], out['reason']), ('RESOURCE_INCOMPLETE', 'CONTROLLER_WALL_TIMEOUT')); self.assertTrue(no_score(out))
        self.assertFalse((RUN / name / 'checkpoint.json').exists())
        e = event_files(RUN / name)[-1]; st = read_streams(RUN / name, e)
        self.assertTrue(e['controller_timeout']); self.assertEqual(e['returncode'], -9); self.assertEqual(e['wall_limit_seconds'], 8)
        self.assertGreaterEqual(e['elapsed_ns'], 8_000_000_000)
        self.assertIn(b'entering injected sleep', st['stderr'])
        ok, summ = tree_ok(name); self.assertTrue(ok)
        res.append({'case': name, 'state': out['state'], 'elapsed_s': e['elapsed_ns'] / 1e9, 'returncode': e['returncode'],
                    'stdout': [len(st['stdout']), h(st['stdout'])], 'stderr': [len(st['stderr']), h(st['stderr'])]})
        record('G08', res)

    # ------------------------------------------------------------------ G09
    def test_G09_saved_verdict_ignored_fresh_check_within_8s(self):
        raw = request('R'); d = RUN / 'G09_stale_verdict'; d.mkdir()
        rec = json.loads((RUN / 'G02_R/checkpoint.json').read_bytes())
        rec['verification'] = {'state': 'UNTRUSTED_STALE_SAVED_VERDICT'}
        (d / 'checkpoint.json').write_bytes(enc(rec))
        out = supervisor.resume(raw, auth(self.bundles['R']), d)
        record('G09', out)
        self.assertEqual(out['state'], supervisor.SUCCESS); self.assertEqual(out['recovery'], 'FRESH_REFERENCE_RECOMPUTED')
        self.assertEqual(out['verification']['state'], supervisor.SUCCESS)
        last = out['worker_events'][-1]
        self.assertEqual(last['mode'], 'check'); self.assertEqual(last['wall_limit_seconds'], 8)
        self.assertFalse(last['controller_timeout']); self.assertLess(last['elapsed_ns'], 8_000_000_000)
        self.assertEqual(out['stream_evidence'], 'ALL_WORKER_STREAMS_RECONCILED')
        ok, summ = tree_ok('G09_stale_verdict'); self.assertTrue(ok)

    # ------------------------------------------------------------------ G10
    def test_G10_genuine_8s_checker_timeout_resource_incomplete(self):
        raw = request('R'); d = RUN / 'G10_recovery_timeout'; d.mkdir()
        (d / 'checkpoint.json').write_bytes((RUN / 'G02_R/checkpoint.json').read_bytes())
        out = supervisor.resume(raw, auth(self.bundles['R']), d, check_fault='timeout')
        record('G10', out)
        self.assertEqual((out['state'], out['reason']), ('RESOURCE_INCOMPLETE', 'CONTROLLER_WALL_TIMEOUT')); self.assertTrue(no_score(out))
        last = out['worker_events'][-1]
        self.assertEqual(last['mode'], 'check'); self.assertTrue(last['controller_timeout'])
        self.assertEqual(last['returncode'], -9); self.assertEqual(last['wall_limit_seconds'], 8)
        ok, summ = tree_ok('G10_recovery_timeout'); self.assertTrue(ok)

    # ------------------------------------------------------------------ G11
    def test_G11_test_only_signed_authority(self):
        raw = request('R'); k = keys(); res = {}
        env, rec, sig, trust, mode = self.bundles['R']; canon = wire.request(raw)[1]
        p = identity.verify(env, h(canon), rec, sig, trust, mode='TEST_AUTHORITY')
        r = refid.verify(env, canon, rec, sig, trust, mode='TEST_AUTHORITY')
        self.assertEqual(p['authority_status'], 'NON_PRODUCTION_TEST_AUTHORITY_VERIFIED')
        self.assertEqual(r['authority_status'], 'NON_PRODUCTION_TEST_AUTHORITY_VERIFIED')
        self.assertTrue(identity.openssl_verify(k['A'].public, env, sig))
        self.assertTrue(ed25519_ref.verify(k['A'].public, env, sig))
        self.assertFalse(ed25519_ref.verify(k['B'].public, env, sig))
        res['valid'] = {'production': p, 'reference': r, 'signature_sha256': h(sig), 'envelope_sha256': h(env)}
        store_B_in = af.trust_store([k['A'].public_record(), k['B'].public_record(scope='HUMAN_SIGNED_CODE_FREEZE')])
        store_revoked = af.trust_store([k['A'].public_record(revoked=True)])
        attacker = af.trust_store([{'key_id': 'test-key-A', 'algorithm': 'ed25519', 'public_key_hex': k['B'].public_hex,
                                    'scope': 'NON_PRODUCTION_TEST_AUTHORITY', 'revoked': False}])
        files_bad = dict(af.source_map(ROOT)); first = sorted(files_bad)[0]; files_bad[first] = '0' * 64
        neg = []
        neg.append(both_reject(bundle(raw, 'G11', signer='B'), raw, 'wrong_key_signature'))
        neg.append(both_reject(bundle(raw, 'G11', signer='B', key_id='test-key-B'), raw, 'wrong_signer_not_in_store'))
        neg.append(both_reject(bundle(raw, 'G11', signer='B', key_id='test-key-B', store=store_B_in), raw, 'signer_scope_not_test_authority'))
        neg.append(both_reject(bundle(raw, 'G11', store=store_revoked), raw, 'revoked_key'))
        e2, r2, s2, t2, _ = self.bundles['R']
        neg.append(both_reject((e2, r2, s2, t2, 'DEPLOYMENT'), raw, 'wrong_mode_deployment'))
        neg.append(both_reject((e2, r2, s2, t2, 'DEV_UNSIGNED'), raw, 'wrong_mode_dev_unsigned'))
        neg.append(both_reject(bundle(raw, 'G11', env_over={'signed_parent': '83b9e6dcd53b100c5ac8b081832e81659cd1884a'}), raw, 'wrong_parent_resigned'))
        neg.append(both_reject(bundle(raw, 'G11', env_over={'protocol_commit': '1d38ea6f53b9266d853df887a66331c59e4fc3ae'}), raw, 'wrong_protocol_scope_resigned'))
        neg.append(both_reject(bundle(raw, 'G11', env_over={'files': files_bad}), raw, 'wrong_source_hash_resigned'))
        neg.append(both_reject(bundle(raw, 'G11', env_over={'input_sha256': '0' * 64}), raw, 'wrong_input_hash_resigned'))
        neg.append(both_reject(bundle(raw, 'G11', env_over={'resource_policy_sha256': '0' * 64}), raw, 'wrong_policy_hash_resigned'))
        neg.append(both_reject(bundle(raw, 'G11', rec_over={'run_id': 'G11_other_run'}), raw, 'wrong_run_receipt'))
        neg.append(both_reject((e2, r2, s2, attacker, 'TEST_AUTHORITY'), raw, 'trust_store_substituted_receipt_pin_unchanged'))
        bad_sig = bytearray(s2); bad_sig[5] ^= 1
        neg.append(both_reject((e2, af.receipt(e2, 'G02_R', 'TEST_AUTHORITY', bytes(bad_sig), t2), bytes(bad_sig), t2, 'TEST_AUTHORITY'), raw, 'signature_bit_flip'))
        res['negatives'] = neg
        # End to end: controller refuses before any worker; independent reference worker refuses on its own.
        wrong = bundle(raw, 'G11_e2e', signer='B')
        out = supervisor.run(raw, auth(wrong), RUN / 'G11_e2e_wrong_key')
        self.assertEqual(out['state'], 'CODE_IDENTITY_MISMATCH'); self.assertTrue(no_score(out)); self.assertEqual(out['worker_events'], [])
        d = RUN / 'G11_reference_worker_wrong_key'; d.mkdir()
        out2 = supervisor.child('check', d, raw, auth(wrong), self.cert['R'], events=[])
        self.assertEqual((out2['state'], out2['reason']), ('CODE_IDENTITY_MISMATCH', 'EXTERNAL_IDENTITY_MISMATCH'))
        ok, summ = tree_ok('G11_reference_worker_wrong_key'); self.assertTrue(ok)
        res['end_to_end'] = {'controller': out, 'reference_worker': out2}
        record('G11', res)

    # ------------------------------------------------------------------ G12
    def test_G12_missing_unsigned_promoted_runtime_loaded_code(self):
        raw = request('R'); k = keys(); res = {}
        canon = wire.request(raw)[1]
        out = supervisor.run(raw, None, RUN / 'G12_missing_authority')
        self.assertEqual((out['state'], out['reason']), ('CODE_IDENTITY_MISMATCH', 'EXTERNAL_AUTHORITY_MISSING')); self.assertTrue(no_score(out))
        with self.assertRaises(wire.Boundary):
            supervisor.Authority(None, None, None, None, 'TEST_AUTHORITY', AID)
        e, r, s, t, _ = self.bundles['R']
        neg = [both_reject((e, r, None, t, 'TEST_AUTHORITY'), raw, 'signature_missing'),
               both_reject((e, r, s, None, 'TEST_AUTHORITY'), raw, 'trust_store_missing')]
        neg.append(both_reject(bundle(raw, 'G12', authority_mode='UNSIGNED_STAGING_PROPOSAL'), raw, 'unsigned_proposal_presented_as_signed'))
        neg.append(both_reject(bundle(raw, 'G12', sign=False, rec_over={'signature_sha256': '0' * 64}), raw, 'test_authority_claimed_without_signature'))
        neg.append(both_reject(bundle(raw, 'G12', authority_mode='HUMAN_SIGNED_CODE_FREEZE'), raw, 'human_freeze_claimed_with_test_key'))
        neg.append(both_reject(bundle(raw, 'G12', authority_mode='HUMAN_SIGNED_CODE_FREEZE', mode='DEPLOYMENT'), raw, 'deployment_mode_always_absent'))
        neg.append(both_reject(bundle(raw, 'G12', env_over={'environment_sha256': '0' * 64}), raw, 'altered_runtime_identity_resigned'))
        neg.append(both_reject(bundle(raw, 'G12', env_over={'loaded_code_identity': 'LOADED_CODE_IDENTITY_VERIFIED'}), raw, 'loaded_code_attestation_claimed'))
        # Actual different interpreter: the same valid authority checked under CPython 3.13 must fail.
        probe = ('import sys;sys.path[:0]=[%r];from reference.v0_9.qo2d_exact import identity as i\n'
                 'e,c,r,s,t=[open(p,"rb").read() for p in sys.argv[1:6]]\n'
                 'try:\n i.verify(e,c,r,s,t,mode="TEST_AUTHORITY");print("ACCEPTED")\n'
                 'except i.IdentityMismatch:print("REJECTED")') % str(ROOT)
        tmp = CTRL / 'runtime_probe'; tmp.mkdir()
        for n, v in (('e', e), ('c', canon), ('r', r), ('s', s), ('t', t)):
            (tmp / n).write_bytes(v)
        pr = subprocess.run(['/usr/bin/python3.13', '-I', '-S', '-B', '-c', probe, *[str(tmp / n) for n in 'ecrst']],
                            capture_output=True, text=True, timeout=60)
        self.assertEqual(pr.stdout.strip(), 'REJECTED')
        neg.append({'case': 'actual_cpython_3_13_runtime', 'reference': pr.stdout.strip(), 'stderr': pr.stderr[-300:]})
        # Loaded-code mismatch: a mutated loaded production/reference function is refused.
        old = wire.parse_request
        try:
            def changed(raw):
                return None
            changed.__module__ = wire.__name__; wire.parse_request = changed
            with self.assertRaises(wire.Boundary):
                identity.verify(e, h(canon), r, s, t, mode='TEST_AUTHORITY')
        finally:
            wire.parse_request = old
        oldr = refwire.certificate
        try:
            def changed_ref(c):
                return None
            changed_ref.__module__ = refwire.__name__; refwire.certificate = changed_ref
            with self.assertRaises(refid.IdentityMismatch):
                refid.verify(e, canon, r, s, t, mode='TEST_AUTHORITY')
        finally:
            refwire.certificate = oldr
        neg.append({'case': 'loaded_function_mutation', 'production': 'REJECTED', 'reference': 'REJECTED'})
        # Distinguishable unsigned DEV fixture state (never a code-only freeze).
        ub = bundle(raw, 'G12_unsigned', mode='DEV_UNSIGNED', authority_mode='UNSIGNED_STAGING_PROPOSAL', key_id=None, sign=False)
        uo = supervisor.run(raw, auth(ub), RUN / 'G12_unsigned_dev_fixture')
        self.assertEqual(uo['state'], supervisor.SUCCESS)
        self.assertEqual(uo['authority_status'], 'CALLER_OWNED_DEV_FIXTURE_UNSIGNED')
        self.assertNotEqual(uo['authority_status'], self.out['R']['authority_status'])
        self.assertEqual(uo['loaded_code_identity'], 'LOADED_CODE_IDENTITY_UNVERIFIED')
        ok, summ = tree_ok('G12_unsigned_dev_fixture'); self.assertTrue(ok)
        res['negatives'] = neg
        res['missing_authority_run'] = out
        res['unsigned_dev_fixture'] = {'state': uo['state'], 'authority_status': uo['authority_status'],
                                       'loaded_code_identity': uo['loaded_code_identity']}
        res['disclosure'] = 'Successful outputs carry LOADED_CODE_IDENTITY_UNVERIFIED; loaded_check covers module functions only.'
        record('G12', res)

    # ------------------------------------------------------------------ G13
    def test_G13_canonical_parser_and_reference_negatives(self):
        res = []
        raw = request('R'); obj = json.loads(raw)
        malformed = [b' ' + raw, raw + b'\n', b'{"x":0,"x":1}', b'{"x":NaN}', b'{"x":1.0}', b'null', b'\xff', b'{"a":"\\u0030"}']
        for data in malformed:
            p = wire.parse_request(data)
            self.assertIn(p['state'], ('INVALID_INPUT', 'RESOURCE_INCOMPLETE')); self.assertNotIn('canonical_sha256', p)
            with self.assertRaises(Exception):
                refwire.request(refwire.read(data, refwire.LIMITS['request_bytes']))
            res.append({'raw_hex': data[:40].hex(), 'production': p['state'], 'reference': 'REJECTED'})
        for q in [['-0', '1'], ['2', '2'], ['01', '1'], ['1', '0'], [True, '1']]:
            r = copy.deepcopy(obj); r['paths'][0]['vertices'][0][0] = q
            self.assertEqual(wire.parse_request(enc(r))['state'], 'INVALID_INPUT')
        one = [[0, ['1', '1']]]
        muts = []
        c = copy.deepcopy(self.cert['R']); c['q'] = [[0, ['2', '1']]]; muts.append(('G13_forged_score', c))
        c = copy.deepcopy(self.cert['R']); c['paths'][0]['knots'][1] = [[0, ['-1', '0']]]; muts.append(('G13_invalid_nested_path_record', c))
        c = copy.deepcopy(self.cert['R']); c['rotation'] = [[one, []], [[], one]]; muts.append(('G13_nonoptimal_identity_SO2', c))
        c = copy.deepcopy(self.cert['R']); c['roll_state'] = 'EXACT_WHOLE_ROLL_TIE'; muts.append(('G13_forged_tie', c))
        c = copy.deepcopy(self.cert['R']); c['union'].pop(1); muts.append(('G13_missing_knot', c))
        c = copy.deepcopy(self.cert['R']); c['union'].insert(1, c['union'][1]); muts.append(('G13_duplicate_knot', c))
        c = copy.deepcopy(self.cert['R']); c['request']['paths'][0]['vertices'].reverse(); muts.append(('G13_changed_traversal', c))
        for label, value in [('G13_negative_root', [[0, ['-1', '1']]]), ('G13_forward_root', [[1, ['1', '1']]]), ('G13_boolean_mask', [[False, ['1', '1']]])]:
            c = copy.deepcopy(self.cert['R']); c['roots'][0] = value; muts.append((label, c))
        for label, c in muts:
            res.append(self.check_mutation(c, label))
        c = copy.deepcopy(self.cert['R']); mask = 1 << len(c['roots']); c['roots'].append([[0, ['1', '1']]]); c['q'] = [[0, ['-1', '1']], [mask, ['1', '1']]]
        res.append(self.check_mutation(c, 'G13_equivalent_zero_positive_control', supervisor.SUCCESS))
        record('G13', res)

    # ------------------------------------------------------------------ G14
    def test_G14_generic_RZTN_relations_and_frozen_kernels(self):
        res = {}
        for name in 'RZTN':
            raw = request(name)
            self.assertEqual(h(raw), FIXTURE_REQUEST_SHA[name])
            self.assertTrue(all(p['provenance'] == 'INDEPENDENT_GENERIC' for p in json.loads(raw)['paths']))
            out = supervisor.run(raw, auth(bundle(raw, 'G14_' + name)), RUN / ('G14_' + name))
            self.assertEqual(out['state'], supervisor.SUCCESS)
            self.assertEqual(out['verification']['details']['check'], 'ORIGINAL_INPUT_EXACT_RECOMPUTATION_AND_DIRECT_RESIDUAL')
            ok, summ = tree_ok('G14_' + name); self.assertTrue(ok)
            res[name] = out['certificate']
        for name in 'RZ':
            self.assertEqual(next(d['sign'] for d in res[name]['decisions'] if d['label'] == 'direct_residual_minus_q2'), 0)
            self.assertEqual(res[name]['q'], [])
        self.assertEqual(res['Z']['paths'][0]['zero_edges'], [{'edge_index': 0, 'reason': 'EXACT_ZERO_CONSECUTIVE_EDGE'}])
        self.assertEqual(res['T']['roll_state'], 'EXACT_WHOLE_ROLL_TIE')
        self.assertEqual(res['N']['roll_state'], 'EXACT_UNIQUE_PROPER_ROTATION')
        self.assertEqual(next(d['sign'] for d in res['N']['decisions'] if d['label'] == 's'), 1)
        kern = {k: h((ROOT / k).read_bytes()) for k in KERNELS}; self.assertEqual(kern, KERNELS)
        record('G14', {'certificate_sha256': {n: h(enc(c)) for n, c in res.items()}, 'roll_states': {n: c['roll_state'] for n, c in res.items()},
                       'q': {n: c['q'] for n, c in res.items()}, 'kernels': kern})


def final_reconciliation():
    rows, summ = recon.reconcile_tree(recon.tree_from_dir(str(RUN)), expected_attempt_id=AID,
                                      registered_faults={k: v for k, v in REGISTRY.items()})
    for r in rows:
        if r['status'] != 'MATCH' and r.get('run_dir') in HARNESS_FAULT_RUNS:
            r['status'] = 'MISMATCH_REGISTERED_HARNESS_FAULT'
    unexplained = [r for r in rows if not (r['status'] == 'MATCH' or 'DECLARED_SIMULATED_FAULT' in r['status']
                                           or r['status'] == 'MISMATCH_REGISTERED_HARNESS_FAULT')]
    cols = ['run_dir', 'worker_id', 'mode', 'stream', 'status', 'problems', 'recorded_bytes', 'saved_bytes',
            'recorded_sha256', 'saved_sha256', 'capture_bytes', 'capture_sha256', 'returncode', 'controller_timeout',
            'process_fault', 'evidence_fault', 'evidence_fault_class', 'attempt_id', 'event_file', 'stream_member']
    with open(ATTEMPT / 'STREAM_EVENT_RECONCILIATION.csv', 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction='ignore'); w.writeheader()
        for r in rows:
            w.writerow(r)
    counts = {}
    for r in rows:
        counts[r['status']] = counts.get(r['status'], 0) + 1
    out = {'attempt': AID, 'summary': summ, 'final_status_counts': counts, 'registered_faults': REGISTRY,
           'harness_fault_runs': sorted(HARNESS_FAULT_RUNS), 'unexplained_rows': unexplained,
           'verdict': 'ALL_STREAMS_RECONCILED_OR_DECLARED' if not unexplained else 'UNEXPLAINED_STREAM_MISMATCH', 'rows': rows}
    (ATTEMPT / 'STREAM_EVENT_RECONCILIATION.json').write_bytes(enc(out))
    return out


if __name__ == '__main__':
    t0 = time.time()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(G)
    names = [t.id().split('.')[-1] for t in suite]
    assert len(names) == 14 and names == sorted(names), names
    try:
        result = unittest.TextTestRunner(verbosity=2, failfast=False).run(suite)
    finally:
        for k in ('A', 'B'):
            if k in KEYS:
                KEYS[k].destroy()
        record('private_keys_destroyed', {k: not KEYS[k].private.exists() for k in ('A', 'B') if k in KEYS})
    rec = final_reconciliation()
    per = {n: 'PASS' for n in names}
    for test, _ in result.failures + result.errors:
        per[test.id().split('.')[-1]] = 'FAIL'
    for test, _ in result.skipped:
        per[test.id().split('.')[-1]] = 'NOT_TESTED'
    quarantined = (ATTEMPT / 'STOP_AND_QUARANTINE.txt').exists()
    passed = result.wasSuccessful() and rec['verdict'] == 'ALL_STREAMS_RECONCILED_OR_DECLARED' and not quarantined
    summary = {'methods_registered': 14, 'methods_run': result.testsRun, 'per_method': per,
               'failures': len(result.failures), 'errors': len(result.errors), 'unittest_success': result.wasSuccessful(),
               'stream_reconciliation': rec['verdict'], 'stream_status_counts': rec['final_status_counts'],
               'quarantine': quarantined, 'attempt_passed': passed, 'wall_seconds': round(time.time() - t0, 3)}
    record('attempt_summary', summary)
    print(json.dumps(summary, sort_keys=True))
    raise SystemExit(0 if passed else 1)
