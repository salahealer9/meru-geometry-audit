"""P0A3G controller-side (caller) authority fixtures for bounded DEV only.

Everything here plays the role of the CALLER/CONTROLLER, not the candidate:
* generates ephemeral NON-PRODUCTION Ed25519 test keys with the OpenSSL CLI inside a
  private key directory supplied on the command line (outside the candidate tree and
  outside all evidence directories); private keys are deleted by cleanup();
* computes the proposed source map / environment / policy identity with its own code;
* builds and signs `p0a3g-authority-envelope-1` envelopes, caller receipts and the
  caller-owned trust store. Only PUBLIC key material is ever written to evidence.
No real human research key is used, requested or reachable.
"""
import hashlib, json, os, platform, subprocess, sys
from pathlib import Path

OPENSSL = '/usr/bin/openssl'
SCOPE = 'NON_PRODUCTION_TEST_AUTHORITY'
PINS = {'schema': 'p0a3g-authority-envelope-1',
        'protocol_commit': 'adacfdbc6efcca4922c8d087d029b67e9b0c5dc5',
        'signed_parent': 'd95c50ea96744ce266058c51f85fff320d1a27df',
        'git_ancestry': ['adacfdbc6efcca4922c8d087d029b67e9b0c5dc5', 'd95c50ea96744ce266058c51f85fff320d1a27df',
                         '83b9e6dcd53b100c5ac8b081832e81659cd1884a', '1d38ea6f53b9266d853df887a66331c59e4fc3ae',
                         '8ed3b988f716229bc9aee97d41ded0f524371193', '59eb47f7500d57866e4935822b78a555d3bcb515'],
        'baseline_archive_sha256': '6ec2b6e96234836d629398fb7fc781909de8b47b0bf80f5cae11202620ff2f15',
        'loaded_code_identity': 'LOADED_CODE_IDENTITY_UNVERIFIED'}
DEPS = ['fractions.py', 'decimal.py', 'json/__init__.py', 'json/decoder.py', 'json/encoder.py', 'json/scanner.py',
        'hashlib.py', 'pathlib.py', 'subprocess.py', 'selectors.py', 'tempfile.py']


def enc(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()


def h(b):
    return hashlib.sha256(b).hexdigest()


def source_map(root):
    out = {}
    for folder in ('src', 'reference', 'schemas', 'tests'):
        for p in sorted((root / folder).rglob('*')):
            if p.is_file() and p.suffix in ('.py', '.json', '.md'):
                out[p.relative_to(root).as_posix()] = h(p.read_bytes())
    return out


def environment_digest():
    """Must run inside the selected interpreter with -I -S -B (the harness does)."""
    base = Path('/usr/lib/python3.12')
    env = {'python': sys.version, 'implementation': sys.implementation.name, 'platform': platform.platform(),
           'executable_realpath': str(Path(sys.executable).resolve()),
           'executable_sha256': h(Path(sys.executable).read_bytes()),
           'flags': {'isolated': sys.flags.isolated, 'no_site': sys.flags.no_site,
                     'dont_write_bytecode': sys.dont_write_bytecode},
           'dependencies': {n: h((base / n).read_bytes()) for n in DEPS}}
    return h(enc(env))


class TestKey:
    def __init__(self, keydir, key_id):
        self.key_id = key_id
        self.private = Path(keydir) / (key_id + '.pem')
        r = subprocess.run([OPENSSL, 'genpkey', '-algorithm', 'ed25519', '-out', str(self.private)],
                           capture_output=True)
        if r.returncode != 0:
            raise RuntimeError('KEYGEN_FAILED')
        os.chmod(self.private, 0o600)
        der = subprocess.run([OPENSSL, 'pkey', '-in', str(self.private), '-pubout', '-outform', 'DER'],
                             capture_output=True, check=True).stdout
        self.public = der[-32:]
        self.public_hex = self.public.hex()

    def sign(self, message):
        m = self.private.with_suffix('.msg')
        s = self.private.with_suffix('.sig')
        m.write_bytes(message)
        subprocess.run([OPENSSL, 'pkeyutl', '-sign', '-inkey', str(self.private), '-rawin', '-in', str(m),
                        '-out', str(s)], check=True, capture_output=True)
        sig = s.read_bytes()
        m.unlink(); s.unlink()
        return sig

    def public_record(self, scope=SCOPE, revoked=False):
        return {'key_id': self.key_id, 'algorithm': 'ed25519', 'public_key_hex': self.public_hex,
                'scope': scope, 'revoked': revoked}

    def destroy(self):
        if self.private.exists():
            self.private.write_bytes(b'\0' * self.private.stat().st_size)
            self.private.unlink()


def trust_store(records, store_id='p0a3g-dev-controller-store'):
    return enc({'schema': 'p0a3g-trust-store-1', 'store_id': store_id, 'keys': records})


def envelope(root, input_canonical, run_id, *, authority_mode='NON_PRODUCTION_TEST_AUTHORITY', key_id='test-key-A',
             overrides=None):
    m = dict(PINS)
    m.update({'authority_mode': authority_mode, 'files': source_map(root), 'environment_sha256': environment_digest(),
              'resource_policy_sha256': h((root / 'schemas/v0_9/p0a3g/resource_policy.json').read_bytes()),
              'input_sha256': h(input_canonical), 'run_id': run_id, 'key_id': key_id})
    m.update(overrides or {})
    return enc(m)


def receipt(env_bytes, run_id, mode, signature=None, trust=None, overrides=None):
    r = {'schema': 'p0a3g-caller-receipt-1', 'mode': mode, 'run_id': run_id, 'envelope_sha256': h(env_bytes),
         'signature_sha256': h(signature) if signature is not None else None,
         'trust_store_sha256': h(trust) if trust is not None else None}
    r.update(overrides or {})
    return enc(r)
