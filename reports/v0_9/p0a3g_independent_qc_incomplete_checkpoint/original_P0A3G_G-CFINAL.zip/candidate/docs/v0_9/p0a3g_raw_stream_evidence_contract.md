# P0A3G raw-worker stream evidence contract `[IMPLEMENTED_UNVERIFIED]` `[INDEPENDENT_QC_PENDING]`

Scope: the isolated P0A3G descendant of the unsigned R1-CFINAL candidate. Frozen P0A3D mathematics untouched.

## Single accountable capture boundary
`src/meru_geometry/v0_9/qo2d_exact/streamcapture.py` is the only code that turns worker output into evidence. `supervisor.child()` calls it for every worker (calibration, produce, check).

1. The worker runs with stdout and stderr on pipes (`stdin=/dev/null`, own session, R1 rlimits installed before exec). The supervisor reads both pipes with `selectors` until EOF or the 8-second wall deadline, keeping exactly the bytes received up to `stream_capture_bytes` (2 MiB) per stream. Over-cap output or the deadline kills the process group (SIGKILL); already-written bytes are drained for up to `stream_drain_seconds` (2 s).
2. The capture witness (`capture_bytes`, `capture_sha256`) is computed from the received buffer, before anything is written. Nothing is reconstructed from parsed JSON, cached objects or fixtures.
3. Each stream is written to `.pending_<worker>.<stream>` with `O_CREAT|O_EXCL|O_NOFOLLOW`, flushed, `fsync`'d, hard-linked to `<worker>.<stream>` (never clobbers: an existing name raises), the pending name unlinked, the directory `fsync`'d and the file set read-only (0400).
4. The event record `w####.event.json` (schema `p0a3g-stream-event-1`) is written exclusively and fsync'd. It binds attempt id, run directory, receipt run id, envelope/receipt/trust-store/policy/interpreter/worker-source/code-file identities, command, wall limit, pid, return code, signal, controller timeout/kill, cap/drain flags, elapsed time, the process-fault class (`ACTUAL_PROCESS_FAULT`) and evidence-fault class (`SIMULATED_EVIDENCE_FAULT`), and both stream records.
5. `reconcile_run()` then freshly re-reads every event file and every referenced stream file in the run directory and fails closed with `EVIDENCE_STREAM_MISMATCH` on: byte/SHA disagreement with the record; capture-witness disagreement; missing, non-regular or symlinked stream; a stream path not named for its own worker; duplicate path references; stale/wrong attempt, run directory or identity fields; leftover `.pending_` files; orphan stream files; empty stdout or stderr after a normal exit (workers always write one stderr diagnostic line and one stdout JSON object).
6. Only after reconciliation does the supervisor interpret the exit status; it decodes worker output only from the freshly re-read saved stdout bytes. A final whole-run reconciliation precedes any checkpoint write, so no checkpoint or success result exists unless every stream of the run reconciles.
7. Real empty streams are recorded as `0` bytes with SHA-256 `e3b0c442…b855`.

## Independent reconciler
`reference/v0_9/qo2d_exact/stream_reconcile.py` (no production imports) re-derives the same table for a directory tree or a ZIP and emits one row per (event, stream): `MATCH`, `MISMATCH_DECLARED_SIMULATED_FAULT` (only if the event declares a simulated fault and that fault is allowed to disturb that stream), `MISMATCH_UNEXPLAINED`, `MISMATCH_UNREGISTERED_FAULT`, orphan/pending rows. `verify_archive()` checks a retrieved ZIP's outer size/SHA-256, CRC, names and SHA256SUMS **and** re-runs stream reconciliation inside it: a self-consistent ZIP whose stream bytes disagree with event metadata is rejected.

## Simulated versus actual faults
Actual process faults (worker `exit` 17, self-`kill`, `partial_then_kill`, `timeout` killed by the controller, `memory`, `recursion`) are observed from the OS and recorded as such. Simulated evidence faults (`forge_stdout_108`, `zero_stdout_after_save`, truncate/alter/delete stdout or stderr, `swap_streams`, `duplicate_path`, `stale_run`, `wrong_worker_path`, `path_collision`, `orphan_stream_file`, `short_write`, `before_rename`, `after_rename_tamper`) exist for bounded DEV only, are refused in mode `DEPLOYMENT`, and are always declared in the event record.

## Not guaranteed `[UNRESOLVED]`
Power loss, kernel crash, disk-full, quota, hostile or multi-writer filesystems, another process modifying files between save and re-read by design, controller death (no process-tree containment beyond the session group), lost directory-fsync semantics, and hostile signal injection. Re-read after save proves agreement at that time on this host only. R1's two missing 108-byte streams are not recovered or reconstructed by anything here.
