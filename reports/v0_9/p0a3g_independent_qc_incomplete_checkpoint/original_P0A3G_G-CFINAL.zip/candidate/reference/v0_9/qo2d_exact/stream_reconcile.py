"""Independent raw-stream reconciler and retrieved-archive verifier (no production imports).

Reads every recorded worker event (``w####.event.json``) under a directory tree or a ZIP,
re-reads the referenced saved stdout/stderr bytes, recomputes length and SHA-256 and
compares them with the recorded metadata. Produces one row per (event, stream).
A valid ZIP CRC/manifest is NOT treated as evidence of event/stream consistency.
"""
import hashlib
import io
import json
import posixpath
import zipfile

EMPTY = hashlib.sha256(b'').hexdigest()
# Which streams a declared simulated evidence fault is allowed to disturb. A mismatch on any
# other stream of the same event stays MISMATCH_UNEXPLAINED.
FAULT_STREAMS = {
    'forge_stdout_108': {'stdout'}, 'zero_stdout_after_save': {'stdout'}, 'truncate_stdout': {'stdout'},
    'alter_stdout': {'stdout'}, 'delete_stdout': {'stdout'}, 'after_rename_tamper': {'stdout'},
    'short_write': {'stdout'}, 'before_rename': {'stdout'}, 'wrong_worker_path': {'stdout'},
    'truncate_stderr': {'stderr'}, 'alter_stderr': {'stderr'}, 'delete_stderr': {'stderr'},
    'duplicate_path': {'stderr'}, 'swap_streams': {'stdout', 'stderr'}, 'stale_run': {'stdout', 'stderr'},
    'path_collision': {'stdout', 'stderr'}, 'orphan_stream_file': set(),
}


def _h(b):
    return hashlib.sha256(b).hexdigest()


class _Tree:
    """Uniform read access to either a filesystem directory or ZIP members."""

    def __init__(self, names, getter):
        self.names = set(names)
        self.get = getter


def tree_from_dir(root):
    import os
    names = []
    for base, dirs, files in os.walk(root, followlinks=False):
        for f in files:
            p = os.path.join(base, f)
            if os.path.islink(p):
                names.append(('SYMLINK', os.path.relpath(p, root)))
                continue
            names.append(os.path.relpath(p, root).replace(os.sep, '/'))
    plain = [n for n in names if isinstance(n, str)]

    def get(n):
        with open(os.path.join(root, n), 'rb') as f:
            return f.read()
    t = _Tree(plain, get)
    t.symlinks = [n[1] for n in names if not isinstance(n, str)]
    return t


def tree_from_zip(data, prefix=''):
    z = zipfile.ZipFile(io.BytesIO(data))
    names = [i.filename[len(prefix):] for i in z.infolist() if not i.is_dir() and i.filename.startswith(prefix)]
    t = _Tree(names, lambda n: z.read(prefix + n))
    t.symlinks = []
    return t


def reconcile_tree(tree, *, expected_attempt_id=None, registered_faults=None):
    """Return (rows, summary). registered_faults maps run_dir -> collection of simulated faults declared in advance."""
    rows = []
    referenced = set()
    events = sorted(n for n in tree.names if posixpath.basename(n).startswith('w') and n.endswith('.event.json'))
    for en in events:
        run_dir = posixpath.dirname(en)
        try:
            ev = json.loads(tree.get(en))
        except Exception:
            rows.append({'event_file': en, 'stream': '-', 'status': 'EVENT_UNREADABLE'})
            continue
        wid = ev.get('worker_id')
        declared_fault = ev.get('evidence_fault', 'none')
        for s in ('stdout', 'stderr'):
            rec = ev.get(s) if isinstance(ev.get(s), dict) else {}
            rel = rec.get('path')
            member = posixpath.join(run_dir, rel) if isinstance(rel, str) else None
            row = {'event_file': en, 'run_dir': run_dir, 'worker_id': wid, 'mode': ev.get('mode'),
                   'attempt_id': ev.get('attempt_id'), 'stream': s, 'stream_member': member,
                   'recorded_bytes': rec.get('bytes'), 'recorded_sha256': rec.get('sha256'),
                   'capture_bytes': rec.get('capture_bytes'), 'capture_sha256': rec.get('capture_sha256'),
                   'returncode': ev.get('returncode'), 'controller_timeout': ev.get('controller_timeout'),
                   'process_fault': ev.get('process_fault'), 'evidence_fault': declared_fault,
                   'evidence_fault_class': ev.get('evidence_fault_class')}
            problems = []
            if expected_attempt_id is not None and ev.get('attempt_id') != expected_attempt_id:
                problems.append('ATTEMPT_ID')
            if ev.get('run_dir_id') != posixpath.basename(run_dir):
                problems.append('RUN_DIR_ID')
            if rel != '%s.%s' % (wid, s):
                problems.append('PATH_NOT_OWN_WORKER')
            if member is None or member not in tree.names:
                problems.append('MISSING')
                row.update(saved_bytes=None, saved_sha256=None)
            else:
                b = tree.get(member)
                row.update(saved_bytes=len(b), saved_sha256=_h(b))
                if member in referenced:
                    problems.append('DUPLICATE_REFERENCE')
                referenced.add(member)
                if (len(b), _h(b)) != (rec.get('bytes'), rec.get('sha256')):
                    problems.append('BYTES_OR_SHA256')
                if (rec.get('capture_bytes'), rec.get('capture_sha256')) != (rec.get('bytes'), rec.get('sha256')):
                    problems.append('CAPTURE_WITNESS')
                if ev.get('returncode') == 0 and not ev.get('controller_timeout') and len(b) == 0:
                    problems.append('UNEXPECTED_EMPTY')
            row['problems'] = ';'.join(problems)
            if not problems:
                row['status'] = 'MATCH'
            elif (declared_fault != 'none' and ev.get('evidence_fault_class') == 'SIMULATED_EVIDENCE_FAULT'
                  and s in FAULT_STREAMS.get(declared_fault, set())):
                row['status'] = 'MISMATCH_DECLARED_SIMULATED_FAULT'
            else:
                row['status'] = 'MISMATCH_UNEXPLAINED'
            reg = (registered_faults or {}).get(run_dir, ())
            if registered_faults is not None and declared_fault != 'none' and declared_fault not in reg:
                row['status'] = 'MISMATCH_UNREGISTERED_FAULT'
            rows.append(row)
    # Stream-like files nobody references, and leftover pending writes.
    orphans = sorted(n for n in tree.names if n.endswith(('.stdout', '.stderr')) and n not in referenced)
    pendings = sorted(n for n in tree.names if posixpath.basename(n).startswith('.pending_'))
    faulted_runs = {r['run_dir'] for r in rows if r.get('evidence_fault', 'none') != 'none'
                    and r.get('evidence_fault_class') == 'SIMULATED_EVIDENCE_FAULT'}
    for kind, items in (('ORPHAN_STREAM_FILE', orphans), ('PENDING_WRITE_FILE', pendings)):
        for n in items:
            rd = posixpath.dirname(n)
            rows.append({'event_file': '-', 'run_dir': rd, 'stream_member': n, 'stream': '-',
                         'status': kind + ('_IN_DECLARED_SIMULATED_FAULT_RUN' if rd in faulted_runs else ''),
                         'problems': kind})
    counts = {}
    for r in rows:
        counts[r['status']] = counts.get(r['status'], 0) + 1
    summary = {'events': len(events), 'stream_rows': sum(1 for r in rows if r.get('stream') in ('stdout', 'stderr')),
               'status_counts': counts, 'symlinks': list(getattr(tree, 'symlinks', []))}
    return rows, summary


def verify_archive(data, expected_sha256, expected_bytes, *, prefix=''):
    """Fail-closed verification of a retrieved evidence archive. Returns (ok, report)."""
    rep = {'bytes': len(data), 'sha256': _h(data), 'checks': []}
    if (len(data), _h(data)) != (expected_bytes, expected_sha256):
        rep['checks'].append('OUTER_IDENTITY_MISMATCH')
        return False, rep
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
        if z.testzip() is not None:
            rep['checks'].append('CRC')
            return False, rep
        names = z.namelist()
        if len(names) != len(set(names)) or any(n.startswith('/') or '..' in n.split('/') for n in names):
            rep['checks'].append('UNSAFE_OR_DUPLICATE_NAMES')
            return False, rep
        if 'SHA256SUMS' in names:
            for line in z.read('SHA256SUMS').decode().splitlines():
                if not line.strip():
                    continue
                h, n = line.split(None, 1)
                if n != 'SHA256SUMS' and (n not in names or _h(z.read(n)) != h):
                    rep['checks'].append('MANIFEST:' + n)
                    return False, rep
    except zipfile.BadZipFile:
        rep['checks'].append('BAD_ZIP')
        return False, rep
    rows, summary = reconcile_tree(tree_from_zip(data, prefix))
    rep['stream_summary'] = summary
    bad = [r for r in rows if not (r['status'] == 'MATCH' or 'DECLARED_SIMULATED_FAULT' in r['status'])]
    if bad:
        rep['checks'].append('STREAM_RECONCILIATION:%d' % len(bad))
        return False, rep
    rep['checks'].append('PASS')
    return True, rep
