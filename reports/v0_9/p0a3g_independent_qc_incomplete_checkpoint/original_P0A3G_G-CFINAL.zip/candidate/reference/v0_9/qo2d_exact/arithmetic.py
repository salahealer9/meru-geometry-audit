"""Dense recursive quadratic arithmetic; zero by norm/sign, nonzero sign by
exact rational enclosures. Independent source, shared Fraction/CPython trust.
"""
from fractions import Fraction as Q

class Incomplete(Exception):pass
class InvalidProof(ValueError):pass

class Algebra:
    def __init__(self,limits):self.limits=limits;self.radicands=[];self.ops=0;self.zeros={};self.signs={};self.boxes={}
    def step(self):
        self.ops+=1
        if self.ops>self.limits['max_operations']:raise Incomplete('REFERENCE_OPERATION_CAP')
    def tidy(self,coefficients):
        self.step();a=list(coefficients)
        while len(a)>1 and not any(a[len(a)//2:]):a=a[:len(a)//2]
        if sum(bool(x) for x in a)>self.limits['max_terms']:raise Incomplete('REFERENCE_TERM_CAP')
        if any(max(abs(x.numerator).bit_length(),x.denominator.bit_length())>self.limits['max_coefficient_bits'] for x in a):raise Incomplete('REFERENCE_BIT_CAP')
        return tuple(a)
    def number(self,x):return (Q(x),)
    def plus(self,a,b):
        n=max(len(a),len(b));return self.tidy([ (a[i] if i<len(a) else Q(0))+(b[i] if i<len(b) else Q(0)) for i in range(n)])
    def negative(self,a):return tuple(-x for x in a)
    def minus(self,a,b):return self.plus(a,self.negative(b))
    def scale(self,a,b):return self.tidy([x*Q(b) for x in a])
    def product(self,a,b):
        self.step();n=max(len(a),len(b))
        if n==1:return self.tidy([a[0]*b[0]])
        a=a+(Q(0),)*(n-len(a));b=b+(Q(0),)*(n-len(b));h=n//2;k=n.bit_length()-2
        a0,a1=self.tidy(a[:h]),self.tidy(a[h:]);b0,b1=self.tidy(b[:h]),self.tidy(b[h:])
        low=self.plus(self.product(a0,b0),self.product(self.product(a1,b1),self.radicands[k]));high=self.plus(self.product(a0,b1),self.product(a1,b0))
        return self.tidy(list(low)+( [Q(0)]*(h-len(low)))+list(high)+([Q(0)]*(h-len(high))))
    def split(self,a):
        h=len(a)//2;return self.tidy(a[:h]),self.tidy(a[h:]),len(a).bit_length()-2
    def zero(self,a):
        self.step()
        if a in self.zeros:return self.zeros[a]
        if len(a)==1:z=a[0]==0
        else:
            x,y,k=self.split(a);zx,zy=self.zero(x),self.zero(y)
            if zy:z=zx
            elif zx:z=False
            else:
                norm=self.minus(self.product(x,x),self.product(self.product(y,y),self.radicands[k]))
                z=self.zero(norm) and self.sign(x)!=self.sign(y)
        self.zeros[a]=z;return z
    @staticmethod
    def interval_add(a,b):return a[0]+b[0],a[1]+b[1]
    @staticmethod
    def interval_mul(a,b):
        vals=[x*y for x in a for y in b];return min(vals),max(vals)
    def root_bounds(self,a,bits):
        if a[1]<0:raise InvalidProof('REFERENCE_ENCLOSURE_CONTRADICTION')
        def endpoint(x,upper):
            x=max(Q(0),x);unit=2**bits;low=0;high=unit*(1+x.numerator//x.denominator)
            while low<high:
                self.step();mid=(low+high+1)//2
                if Q(mid*mid,unit*unit)<=x:low=mid
                else:high=mid-1
            return Q(low+int(upper and Q(low*low,unit*unit)!=x),unit)
        return endpoint(a[0],False),endpoint(a[1],True)
    def bounds(self,a,bits):
        self.step();key=(a,bits)
        if key in self.boxes:return self.boxes[key]
        if len(a)==1:box=(a[0],a[0])
        else:
            x,y,k=self.split(a)
            box=self.interval_add(self.bounds(x,bits),self.interval_mul(self.bounds(y,bits),self.root_bounds(self.bounds(self.radicands[k],bits),bits)))
        self.boxes[key]=box;return box
    def sign(self,a):
        self.step()
        if a in self.signs:return self.signs[a]
        if self.zero(a):s=0
        else:
            bits=8
            while True:
                if bits>self.limits['reference_max_bits']:raise Incomplete('UNRESOLVED_EXACT_PREDICATE_REFERENCE_ISOLATION_CAP')
                lo,hi=self.bounds(a,bits)
                if lo>0:s=1;break
                if hi<0:s=-1;break
                bits*=2
        self.signs[a]=s;return s
    def inverse(self,a):
        if self.zero(a):raise InvalidProof('zero inverse')
        if len(a)==1:return self.number(1/a[0])
        x,y,k=self.split(a)
        if self.zero(y):return self.inverse(x)
        norm=self.minus(self.product(x,x),self.product(self.product(y,y),self.radicands[k]))
        if self.zero(norm):return self.inverse(self.scale(x,2))
        h=len(a)//2;conjugate=self.tidy(list(a[:h])+[-z for z in a[h:]])
        return self.product(conjugate,self.inverse(norm))
    def divide(self,a,b):return self.product(a,self.inverse(b))
    def root(self,a):
        s=self.sign(a)
        if s<0:raise InvalidProof('negative root')
        if s==0:return self.number(0)
        # No shared production perfect-square shortcut: independent root equality.
        if len(a)==1:
            n,d=a[0].numerator,a[0].denominator
            nl,nh=self.root_bounds((Q(n),Q(n)),0);dl,dh=self.root_bounds((Q(d),Q(d)),0)
            if nl==nh and dl==dh:return self.number(nl/dl)
        for k,r in enumerate(self.radicands):
            if self.zero(self.minus(a,r)):
                v=[Q(0)]*(2**(k+1));v[2**k]=Q(1);return tuple(v)
        if 2**(len(self.radicands)+1)>self.limits['max_formal_degree']:raise Incomplete('REFERENCE_FORMAL_DEGREE_CAP')
        self.radicands.append(a);v=[Q(0)]*(2**len(self.radicands));v[len(v)//2]=Q(1);return tuple(v)
    def power(self,a,n):
        out=self.number(1)
        for _ in range(n):out=self.product(out,a)
        return out
