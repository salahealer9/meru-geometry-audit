"""Separately written P0A3G checker authority gate; no production identity imports.

Signature route: reference/v0_9/qo2d_exact/ed25519_ref.py (pure Python RFC 8032),
deliberately different from the production OpenSSL CLI route. Accepts only:
  mode TEST_AUTHORITY -> NON_PRODUCTION_TEST_AUTHORITY signed by a caller-trust-store key
  mode DEV_UNSIGNED   -> UNSIGNED_STAGING_PROPOSAL (CALLER_OWNED_DEV_FIXTURE, unsigned)
Mode DEPLOYMENT always fails: no real human-signed code authority exists here.
"""
import hashlib,json,platform,sys,types,re
from pathlib import Path
from .wire import ROOT,read,LIMITS
from . import ed25519_ref
class IdentityMismatch(Exception):pass
def blob(b):return hashlib.sha256(b).hexdigest()
def encoded(x):return json.dumps(x,ensure_ascii=True,allow_nan=False,sort_keys=True,separators=(',',':')).encode('ascii')
PINS={'schema':'p0a3g-authority-envelope-1','protocol_commit':'adacfdbc6efcca4922c8d087d029b67e9b0c5dc5','signed_parent':'d95c50ea96744ce266058c51f85fff320d1a27df','baseline_archive_sha256':'6ec2b6e96234836d629398fb7fc781909de8b47b0bf80f5cae11202620ff2f15','loaded_code_identity':'LOADED_CODE_IDENTITY_UNVERIFIED',
      'git_ancestry':['adacfdbc6efcca4922c8d087d029b67e9b0c5dc5','d95c50ea96744ce266058c51f85fff320d1a27df','83b9e6dcd53b100c5ac8b081832e81659cd1884a','1d38ea6f53b9266d853df887a66331c59e4fc3ae','8ed3b988f716229bc9aee97d41ded0f524371193','59eb47f7500d57866e4935822b78a555d3bcb515']}
def verify(external,input_bytes,receipt=None,signature=None,trust=None,*,mode):
    try:
        if mode not in ('TEST_AUTHORITY','DEV_UNSIGNED','DEPLOYMENT'):raise ValueError('mode')
        m=read(external,LIMITS['document_bytes']);r=read(receipt,LIMITS['document_bytes'])
        if type(m)!=dict or set(m)!=set(PINS)|{'authority_mode','files','environment_sha256','resource_policy_sha256','input_sha256','run_id','key_id'}:raise ValueError('fields')
        if any(m[k]!=v for k,v in PINS.items()):raise ValueError('authority pins')
        if type(r)!=dict or set(r)!={'schema','mode','run_id','envelope_sha256','signature_sha256','trust_store_sha256'} or r['schema']!='p0a3g-caller-receipt-1':raise ValueError('receipt fields')
        if r['mode']!=mode or r['envelope_sha256']!=blob(external) or type(r['run_id'])!=str or re.fullmatch('[A-Za-z0-9_.-]{1,64}',r['run_id']) is None or r['run_id']!=m['run_id']:raise ValueError('receipt binding')
        if mode=='DEPLOYMENT':raise ValueError('no real human-signed authority')
        if mode=='DEV_UNSIGNED':
            if m['authority_mode']!='UNSIGNED_STAGING_PROPOSAL' or m['key_id'] is not None or signature is not None or trust is not None or r['signature_sha256'] is not None or r['trust_store_sha256'] is not None:raise ValueError('unsigned shape')
            status='CALLER_OWNED_DEV_FIXTURE_UNSIGNED'
        else:
            if m['authority_mode']!='NON_PRODUCTION_TEST_AUTHORITY' or type(signature)!=bytes or type(trust)!=bytes:raise ValueError('test authority shape')
            if r['signature_sha256']!=blob(signature) or r['trust_store_sha256']!=blob(trust):raise ValueError('receipt pins')
            store=read(trust,LIMITS['document_bytes'])
            if type(store)!=dict or set(store)!={'schema','store_id','keys'} or store['schema']!='p0a3g-trust-store-1' or type(store['keys'])!=list:raise ValueError('store')
            match=[k for k in store['keys'] if type(k)==dict and k.get('key_id')==m['key_id']]
            if len(match)!=1:raise ValueError('signer unknown')
            k=match[0]
            if set(k)!={'key_id','algorithm','public_key_hex','scope','revoked'} or k['algorithm']!='ed25519' or k['scope']!='NON_PRODUCTION_TEST_AUTHORITY' or k['revoked'] is not False or re.fullmatch('[0-9a-f]{64}',k['public_key_hex']) is None:raise ValueError('key')
            if not ed25519_ref.verify(bytes.fromhex(k['public_key_hex']),external,signature):raise ValueError('signature')
            status='NON_PRODUCTION_TEST_AUTHORITY_VERIFIED'
        found={}
        for folder in ['reference','schemas','src','tests']:
            for p in (ROOT/folder).rglob('*'):
                if p.is_symlink() or p.suffix in ('.pyc','.pyo'):raise ValueError('unsafe source')
                if p.is_file() and p.suffix in ('.md','.json','.py'):found[p.relative_to(ROOT).as_posix()]=blob(p.read_bytes())
        if found!=m['files']:raise ValueError('source map')
        names=['fractions.py','decimal.py','json/__init__.py','json/decoder.py','json/encoder.py','json/scanner.py','hashlib.py','pathlib.py','subprocess.py','selectors.py','tempfile.py']
        env={'python':sys.version,'implementation':sys.implementation.name,'platform':platform.platform(),'executable_realpath':str(Path(sys.executable).resolve()),'executable_sha256':blob(Path(sys.executable).read_bytes()),'flags':{'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode},'dependencies':{n:blob((Path('/usr/lib/python3.12')/n).read_bytes()) for n in names}}
        if m['environment_sha256']!=blob(encoded(env)) or m['input_sha256']!=blob(input_bytes) or m['resource_policy_sha256']!=blob((ROOT/'schemas/v0_9/p0a3g/resource_policy.json').read_bytes()):raise ValueError('runtime/input/policy')
        for name,module in list(sys.modules.items()):
            if not name.startswith('reference.'):continue
            filename=getattr(module,'__file__',None)
            if not filename or not filename.endswith('.py'):continue
            p=Path(filename)
            if ROOT not in p.resolve().parents:raise ValueError('module path')
            top=compile(p.read_bytes(),str(p),'exec',dont_inherit=True,optimize=0)
            funcs={c.co_name:c for c in top.co_consts if type(c)==types.CodeType}
            for n,value in vars(module).items():
                if type(value)==types.FunctionType and value.__module__==name and (n not in funcs or value.__code__!=funcs[n]):raise ValueError('loaded function')
        return {'authority_status':status,'loaded_code_identity':'LOADED_CODE_IDENTITY_UNVERIFIED'}
    except Exception as e:raise IdentityMismatch('EXTERNAL_IDENTITY_MISMATCH') from e
