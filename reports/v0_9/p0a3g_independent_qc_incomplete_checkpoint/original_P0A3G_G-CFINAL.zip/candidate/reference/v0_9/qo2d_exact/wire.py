"""Independent byte and certificate grammar. No production parser imports."""
import json,math,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
LIMITS=json.loads((ROOT/'schemas/v0_9/p0a3g/resource_policy.json').read_text())
class Rejected(Exception):pass
class Exhausted(Exception):pass
def read(raw,cap):
    if type(raw)!=bytes:raise Rejected('BYTES_REQUIRED')
    if len(raw)>cap:raise Exhausted('RAW_BYTE_CAP')
    try:s=raw.decode('ascii')
    except UnicodeError as e:raise Rejected('ASCII_REQUIRED') from e
    if '\\u' in s:raise Rejected('ESCAPED_UNICODE_FORBIDDEN')
    # Distinct lexical pass: strip complete JSON strings then count delimiters.
    chunks=re.split(r'("(?:[^"\\]|\\.)*")',s);depth=0;count=0
    for i,c in enumerate(chunks):
        if i%2:
            if len(c)-2>LIMITS['string_chars']:raise Exhausted('STRING_CAP')
            count+=1
        else:
            for ch in c:
                if ch in '[{':depth+=1
                elif ch in ']}':depth-=1
                if ch in '[{,:':count+=1
                if depth>LIMITS['depth']:raise Exhausted('DEPTH_CAP')
        if count>LIMITS['tokens']:raise Exhausted('TOKEN_CAP')
    def pairs(p):
        if len(p)>LIMITS['container_items']:raise Exhausted('CONTAINER_CAP')
        keys=[k for k,v in p]
        if len(keys)!=len(set(keys)):raise Rejected('DUPLICATE_KEY')
        return dict(p)
    def integer(x):
        if len(x.removeprefix('-'))>LIMITS['json_integer_digits']:raise Exhausted('INTEGER_TOKEN_CAP')
        return int(x)
    def no_number(x):raise Rejected('NONINTEGER_NUMBER')
    try:v=json.loads(s,object_pairs_hook=pairs,parse_int=integer,parse_float=no_number,parse_constant=no_number)
    except (ValueError,UnicodeError) as e:raise Rejected('JSON_SYNTAX') from e
    pending=[v]
    while pending:
        x=pending.pop()
        if type(x) in (dict,list):
            if len(x)>LIMITS['container_items']:raise Exhausted('CONTAINER_CAP')
            pending+=list(x.values()) if type(x) is dict else x
    if canonical(v)!=raw:raise Rejected("NONCANONICAL_JSON")
    return v
def keys(x,wanted):
    if type(x) is not dict or set(x)!=set(wanted):raise Rejected('OBJECT_FIELDS')
def seq(x,n=None):
    if type(x) is not list or (n is not None and len(x)!=n):raise Rejected('ARRAY_SHAPE')
def integer(x):
    if type(x) is not int or x<0:raise Rejected('NONNEGATIVE_INTEGER_REQUIRED')
def rational(w):
    seq(w,2)
    for s in w:
        if type(s) is not str:raise Rejected('RATIONAL_STRING')
        if len(s.removeprefix('-'))>min(LIMITS['integer_digits'],sys.get_int_max_str_digits() or LIMITS['integer_digits']):raise Exhausted('INTEGER_DIGIT_CAP')
    n,d=w
    if re.fullmatch(r'0|-?[1-9][0-9]*',n) is None or re.fullmatch(r'[1-9][0-9]*',d) is None:raise Rejected('RATIONAL_SYNTAX')
    a,b=int(n),int(d)
    if math.gcd(abs(a),b)!=1:raise Rejected('NONREDUCED_RATIONAL')
def request(r):
    keys(r,('schema','lane','authority','nuisance','paths','limits'))
    if r['schema']!='qo2d-request-1' or r['lane']!='P0A3D_QO_2D_OPEN_RATIONAL_VERTEX_SO2_EXACT' or r['authority']!='92de104cab58339df370acf96b8d849ecc2d888b' or r['nuisance']!='SO2_ONLY':raise Rejected('CONTRACT')
    names=('max_vertices','max_input_bits','max_operations','max_coefficient_bits','max_terms','max_formal_degree','reference_max_bits');keys(r['limits'],names)
    for k,v in r['limits'].items():
        if type(v) is not int or v<=0:raise Rejected('POSITIVE_LIMIT')
        if v>LIMITS[k]:raise Exhausted('REQUEST_POLICY_CAP')
    seq(r['paths'],2)
    for p in r['paths']:
        keys(p,('id','ordered','parameter_domain','endpoints','provenance','vertices'))
        if type(p['id']) is not str or not re.fullmatch(r'[A-Za-z0-9_.-]{1,64}',p['id']) or p['ordered'] is not True or p['parameter_domain']!='OPEN_INTERVAL' or p['provenance']!='INDEPENDENT_GENERIC':raise Rejected('PATH_METADATA')
        seq(p['vertices']);seq(p['endpoints'],2)
        for i in p['endpoints']:integer(i)
        if len(p['vertices'])<2 or p['endpoints']!=[0,len(p['vertices'])-1]:raise Rejected('ENDPOINTS')
        if len(p['vertices'])>r['limits']['max_vertices']:raise Exhausted('VERTEX_CAP')
        for pt in p['vertices']:
            seq(pt,2)
            for w in pt:
                rational(w)
                if max(abs(int(w[0])).bit_length(),int(w[1]).bit_length())>r['limits']['max_input_bits']:raise Exhausted('INPUT_BIT_CAP')
    if r['paths'][0]['id']==r['paths'][1]['id']:raise Rejected('DISTINCT_IDS')
def scalar(w,roots,lim):
    seq(w)
    if len(w)>lim['max_terms']:raise Exhausted('TERM_CAP')
    previous=-1
    for term in w:
        seq(term,2);m,q=term;integer(m);rational(q)
        if m<=previous or m>=2**roots or q[0]=='0':raise Rejected('MASK_ORDER_OR_FORWARD_REFERENCE')
        if max(abs(int(q[0])).bit_length(),int(q[1]).bit_length())>lim['max_coefficient_bits']:raise Exhausted('COEFFICIENT_BIT_CAP')
        previous=m
def certificate(c):
    keys(c,('schema','lane','machine_state','request','request_sha256','input_sha256','backend','roots','paths','union','alpha','beta','s','q_squared','q','rotation','direct_residual','roll_state','decisions'))
    request(c['request']);lim=c['request']['limits']
    if c['schema']!='qo2d-exact-1' or c['lane']!=c['request']['lane'] or c['backend']!='positive-radical-mask-v1' or c['machine_state']!='EXACT_THEOREM_CERTIFICATE_CANDIDATE_UNVALIDATED':raise Rejected('CERTIFICATE_ABI')
    for h in [c['request_sha256']]+(c['input_sha256'] if type(c['input_sha256']) is list else []):
        if type(h) is not str or re.fullmatch('[0-9a-f]{64}',h) is None:raise Rejected('DIGEST_GRAMMAR')
    seq(c['input_sha256'],2);seq(c['roots'])
    if len(c['roots'])>8 or 2**len(c['roots'])>lim['max_formal_degree']:raise Exhausted('TOWER_CAP')
    for i,r in enumerate(c['roots']):scalar(r,i,lim)
    count=len(c['roots']);seq(c['paths'],2)
    for p in c['paths']:
        keys(p,('zero_edges','surviving_edge_indices','lengths','total_length','knots','centroid','variance','rms'))
        seq(p['zero_edges']);seq(p['surviving_edge_indices'])
        for ev in p['zero_edges']:
            keys(ev,('edge_index','reason'));integer(ev['edge_index'])
            if ev['reason']!='EXACT_ZERO_CONSECUTIVE_EDGE':raise Rejected('ZERO_EVENT_REASON')
        for i in p['surviving_edge_indices']:integer(i)
        for k in ('lengths','knots','centroid'):
            seq(p[k]);[scalar(v,count,lim) for v in p[k]]
        seq(p['centroid'],2)
        for k in ('total_length','variance','rms'):scalar(p[k],count,lim)
    seq(c['union']);[scalar(v,count,lim) for v in c['union']]
    for k in ('alpha','beta','s','q_squared','q','direct_residual'):scalar(c[k],count,lim)
    seq(c['rotation'],2)
    for row in c['rotation']:
        seq(row,2);[scalar(v,count,lim) for v in row]
    if c['roll_state'] not in ('EXACT_WHOLE_ROLL_TIE','EXACT_UNIQUE_PROPER_ROTATION'):raise Rejected('ROLL_STATE')
    seq(c['decisions']);seen=set()
    for d in c['decisions']:
        keys(d,('label','expression','sign','method'))
        if type(d['label']) is not str or d['label'] in seen or type(d['sign']) is not int or d['sign'] not in (-1,0,1) or d['method']!='DESCENDING_SIGN_GUARDED_SQUARING':raise Rejected('DECISION')
        seen.add(d['label']);scalar(d['expression'],count,lim)
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
