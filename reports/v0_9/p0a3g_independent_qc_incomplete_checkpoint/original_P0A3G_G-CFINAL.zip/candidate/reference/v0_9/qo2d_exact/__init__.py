"""Independent candidate exact checker. Does not import production modules."""
