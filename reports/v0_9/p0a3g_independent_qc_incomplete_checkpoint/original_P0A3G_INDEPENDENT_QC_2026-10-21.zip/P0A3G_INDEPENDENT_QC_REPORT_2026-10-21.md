# P0A3G — Independent QC Report (21 October 2026)

**Project:** Meru Geometry Audit v0.9, `hebrew-projection-capacity-v0.9`  
**Reviewed signed protocol commit:** `adacfdbc6efcca4922c8d087d029b67e9b0c5dc5`  
**Signed direct parent:** `d95c50ea96744ce266058c51f85fff320d1a27df`  
**Signed protocol Git blob:** `00a4e6ac85403f2a6e4704963a858d43faef136b`  
**Expected human GPG fingerprint:** `D4EC014EEFCC90E619D2AA59A91239ABCF512130`  
**Review authority:** Independent read-only inspection and independent recomputation of user-supplied artifact bytes; no repository writes, commits, signing, retrospective DEV changes, or registered scientific execution.  
**Overall disposition:** **`P0A3G_INDEPENDENT_QC_NOT_QUALIFIED`** due to **QC-G01** (prospective-lock sequencing deviation). Successful bounded engineering evidence remains recorded and credited as such. This is not a finding that the P0A3D theorem is false.

## 1. Authentic inputs and integrity

Exact uploaded archives and independently recomputed SHA-256:

| Archive | Bytes | SHA-256 | Members / checked non-self hashes / inventory | Independent checks |
|---|---:|---|---|---|
| `P0A3G_G-C0.zip` | 66,925 | `7e2b1f593c2aba39c8db3565a20123d052c90d0b2dba81d7af5deaf0c73622fb` | 29/28/27 | SHA, CRC, safe paths, no duplicates, manifest/inventory PASS |
| `P0A3G_G-C1.zip` | 219,223 | `1209547e346fb1fe222b3abd387d63efb2d04aa5f34e3b84d9448ea26eadaaf0` | 83/82/81 | PASS |
| `P0A3G_G-C2_DEV_01.zip` | 1,025,638 | `34373559d37dfdd333e148f9100215a3f82eae8c5656f41dc6021469ab3c18c7` | 1002/1001/1000 | PASS |
| `P0A3G_G-CFINAL.zip` | 1,271,972 | `8b0ec808ddea05d31422ad30308d3a5bbe8aaadb860cd613adf51bdcc9f33a6a` | 1074/1073/1072 | PASS |

All member-by-member inventories match independently; no unsafe member path, duplicate path or symlink. The supplied G-C0 and G-C1 base64 copies decode byte-identically to the corresponding ZIPs. The private claude.ai artifact's access control and own historical version/retrieval logs are **not independently attested** by this QC; these four user-submitted bytes and the agent's persistence claims are distinct.

The G-C1 `SOURCE_LOCK.json` has 51 source/test/schema/etc. records. All 51 file byte lengths and SHA-256 hashes independently recompute correctly. Their copies in G-CFINAL match G-C1. The G-C2 attempt's actual source and DEV artifacts match those in G-CFINAL, after accounting for the two package layouts. The three frozen P0A3D/E mathematical kernels are byte-identical against the previously retrieved authentic P0A3E candidate.

## 2. QC-G01 — HIGH: full G01–G14 catalogue executed before required G-C1 prospective lock

**Direct original evidence:** G-C1 contains four immutable records named `prelock/PRELOCK_DRYRUN_01_evidence.json` through `04`, with `prelock/dry01.stdout`–`dry04.stdout` and stderr. They are preserved rather than hidden, which is good evidence discipline. However, each archived runner summary explicitly reports `methods_registered: 14` and `methods_run: 14`, with all G01–G14 test methods executed:

| Pre-lock full-catalogue execution | Method count | Result |
|---|---:|---|
| PRELOCK_DRYRUN_01 | 14 | FAIL (6 failures, 5 errors) |
| PRELOCK_DRYRUN_02 | 14 | PASS (0 failures/errors) |
| PRELOCK_DRYRUN_03 | 14 | PASS (0 failures/errors) |
| PRELOCK_DRYRUN_04 | 14 | PASS (0 failures/errors) |
| Post-lock `P0A3G_DEV_01` | 14 | PASS (0 failures/errors) |

**Signed requirement:** The P0A3G protocol G3 requires the complete prospective case/source/environment lock and independently persisted **G-C1 before G01 or any other DEV begins**. G4 permits at most three separately numbered prospective attempts under the same locked catalogue and envelope. These four pre-lock full-suite executions cannot be excluded from the prospective-lock test sequence merely by calling them `dry runs`. The substantive G01–G14 tests were performed **before** the required checkpoint gate. At least one prior full run failed and subsequent runs passed before the registered locked run.

**Decision:** `P0A3G_PROSPECTIVE_DEV_LOCK_SEQUENCE_NOT_QUALIFIED`; the recorded post-lock 14/14 is a faithful archived outcome, but its status **as a protocol-compliant, first prospectively locked execution** is not independently qualifiable. Do not relabel prior runs as post-lock DEV, redate G-C1, erase prior failures or claim a clean one-attempt scientific chronology. This finding concerns protocol compliance, not proof of mathematical or algorithmic error. The exact interpretation of the three-attempt ceiling can be considered in any future signed amendment; the clear G-C1-before-DEV ordering failure suffices for a negative overall QC decision.

## 3. QC-G02 — Positive bounded source and raw-stream evidence; no unexplained R1-type silent mismatch

Independently parsed **111 actual saved event JSON files**, each with stdout/stderr metadata, covering **222 stream records**. For each record, independently read the corresponding saved stream bytes from the ZIP and recomputed SHA-256 and byte length, comparing those with the event record and capture witness.

- Direct byte/capture witness agreement: **203/222**.
- Direct byte/capture mismatches: **19/222**. All 19 occurred in explicitly labelled simulated-fault cases; there were **zero unexplained raw-byte mismatches** under this classification.
- The retained candidate's richer reconciliation reports `MATCH=199`, `MISMATCH_DECLARED_SIMULATED_FAULT=21`, and 2 foreign-event-copy rows; the difference from the 203 direct byte matches is explained by tests that preserve stream bytes while deliberately corrupting *run/worker identities* or event ownership, which the candidate correctly treats as failures even when byte hashes happen to match. The reports also flag 5 orphan files and 2 pending writes inside declared failure-injection cases; those are separate artifacts, not additional successfully reconciled stream identities.
- The R1-type 108-byte-metadata/zero-byte-stdout condition is separately exercised as a rejection. Newly generated `forged_q` and `null_path_record` stdout are not substitutes for the original missing R1 bytes.

The source of `streamcapture.py`, `supervisor.py`, independent `stream_reconcile.py` and the G01–G14 harness was inspected. They implement bounded pipe capture, fsync/exclusive write, post-save re-reading and fail-closed reconciliation at the declared test boundary. This audit **did not establish** arbitrary-input correctness, hostile-filesystem durability, protection after controller death, or formal verification.

**Subdisposition:** `P0A3G_NEW_RAW_STREAM_ENGINEERING_DEV_SUPPORTED` (not historical R1 recovery, not global software qualification).

## 4. QC-G03 — Bounded Ed25519 authority exercise independently confirmed; production authority absent

A fresh independent verification using the installed cryptography Ed25519 implementation verified `G02_R/w0000.signature.bin` against the **actual saved** canonical envelope bytes and the caller test-trust-store public key (`test-key-A`). Envelope/signature/trust SHA-256 bindings in the caller receipt also match, and an independently tampered envelope fails signature verification. This positively supports at least one authentic `NON_PRODUCTION_TEST_AUTHORITY` witness without executing or importing the candidate's verification code.

The full agent record reports further positive and negative OpenSSL/pure-Python signature checks; those remain bounded recorded DEV evidence, not an independent complete cryptographic proof of the full signature handling route. The verified key is explicitly test-only, not the research-signing private key. `DEPLOYMENT` mode fails closed, actual human code-freeze authority is absent, and the source reports `LOADED_CODE_IDENTITY_UNVERIFIED`.

**Subdisposition:** `P0A3G_TEST_ONLY_SIGNATURE_INTERFACE_DEV_SUPPORTED`; external real-code authority **NOT QUALIFIED**.

## 5. QC-G04 — Remaining environment, durability and historical limitations

The agent prospectively declared CPython 3.12.3 (`/usr/bin/python3.12`) with a different executable build from R1, while retaining the eight-second worker/checker deadline. That difference was disclosed. This independent review host does not possess the declared executable binary and therefore has **not** replayed the full 14-method suite on the pinned host. No readiness is established for other environments. The private claude.ai base64 artifact route was reported as freshly retrieved; the presented checkpoint bytes verify, but the private artifact's historical retrieval events were not independently inspected. No comprehensive code-in-memory attestation or trusted code-only human signature exists. Real power loss, hostile filesystem, multiwriter, controller death and broader process containment are unqualified.

The old signed R1 independent negative status remains permanent. The original absent stdout streams have not been authentically recovered. Identical messages in different worker events are not a replacement.

## 6. Independent scientific and engineering decisions

| Area | Decision |
|---|---|
| Signed P0A3D exact theorem | Remains frozen and mathematically independently verified; no claim of new theorem proof here |
| Frozen three kernels | Byte-for-byte PASS against authentic P0A3E |
| G-C0/C1/C2/CFINAL archive integrity | PASS |
| G-C1 source lock vs actual source | 51/51 PASS |
| Executed source snapshot vs C1 / CFINAL | PASS |
| New raw-worker test outcomes | Positive bounded evidence; no unexplained saved-stream byte mismatch |
| Independent Ed25519 test witness | PASS for independently checked signed fixture |
| Prospectively locked DEV chronology | **NOT QUALIFIED: QC-G01 HIGH** |
| Actual human-signed production code authority | NOT ESTABLISHED |
| Complete loaded-code and hostile-host qualification | NOT ESTABLISHED |
| Full engineering/software readiness | **NOT QUALIFIED** |
| P0A4 scientific validation | NOT RUN / NOT AUTHORIZED |

**Overall:** `P0A3G_INDEPENDENT_QC_NOT_QUALIFIED`. No `GLOBAL_CERTIFIED`, positive code-only freeze or readiness status. The signed P0A3G protocol, original R1 negatives, four P0A3G archives and all pre-lock failures should be preserved unchanged. Do not request an agent to correct the existing archive retrospectively. A later, separately human-signed remediation/prospective protocol can decide whether to run a new strictly gated catalogue; if a full software readiness goal remains, the real code authority and host assumptions require separate qualification.

## 7. Reproducible independent verification materials

This report is accompanied by `P0A3G_QC_archive_integrity.json`, `P0A3G_INDEPENDENT_QC_EVIDENCE_RECHECK.json`, and the read-only Python scripts `p0a3g_independent_audit.py` and `p0a3g_qc_verify.py`. These scripts examine user-supplied archives and never alter signed material or execute the candidate as software. For signature check, see section 4; verification used an independent Ed25519 implementation against the actual ZIP member bytes.

**Authority:** unsigned independent research-chat QC; it becomes part of a signed preservation only after human review and human GPG signing. No Git commit/push was performed during this QC.
