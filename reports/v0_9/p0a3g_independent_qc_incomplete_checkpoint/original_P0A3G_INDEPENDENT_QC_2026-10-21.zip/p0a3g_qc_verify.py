from zipfile import ZipFile
from pathlib import Path
import hashlib,json,base64,collections,re
P=Path('/mnt/data');C0=ZipFile(P/'P0A3G_G-C0.zip'); C1=ZipFile(P/'P0A3G_G-C1.zip');C2=ZipFile(P/'P0A3G_G-C2_DEV_01.zip');F=ZipFile(P/'P0A3G_G-CFINAL.zip')
h=lambda b:hashlib.sha256(b).hexdigest()
res={};checkpoints={}
for key,z in [('C0',C0),('C1',C1),('C2',C2),('CFINAL',F)]:
 inv=json.loads(z.read('PACKAGE_INVENTORY.json'))
 checked=0;issues=[]
 for x in inv['payload_files']:
  b=z.read(x['path']);checked+=1
  if len(b)!=x['bytes'] or h(b)!=x['sha256']:issues.append(x['path'])
 checkpoints[key]={'inventory_checked':checked,'inventory_issues':issues}
# cross-check pure C1 and CF candidate contents
lock=json.loads(C1.read('lock/SOURCE_LOCK.json')); print('lock keys',lock.keys())
for n in C1.namelist():
 if n.startswith('candidate/'):
  a=C1.read(n);b=F.read(n)
  if a!=b:res.setdefault('candidate_diff',[]).append(n)
# compare lock structure
for name in ['gc1/lock/SOURCE_LOCK.json','gc1/P0A3G_DEV_CASES_PREDECLARED.md']:
 c1name=name[4:]
 res.setdefault('gc1_equal',{})[name]=F.read(name)==C1.read(c1name)
# source lock crosscheck
for k,v in lock.items():print('lock type',k,type(v).__name__,len(v) if hasattr(v,'__len__') else None)
# C2 final dev files
c2dev='P0A3G_DEV_01/'
for n in C2.namelist():
 if n.startswith(c2dev):
  b=C2.read(n)
  if n.startswith('P0A3G_DEV_01/candidate/'):
   dest=n[len('P0A3G_DEV_01/'):]
  else:dest='dev/'+n
  if dest not in F.namelist() or F.read(dest)!=b:res.setdefault('dev_diff',[]).append(n)
# archived b64
for key in ['C0','C1']:
 b64=P/f'P0A3G_G-{key}.zip.b64.txt';actual=P/f'P0A3G_G-{key}.zip'
 res[key+'_b64_matches']=base64.b64decode(re.sub(rb'\s+',b'',b64.read_bytes()),validate=True)==actual.read_bytes()
# independent all event/reports, do not rely on tool report
prefix='dev/P0A3G_DEV_01/attempt/P0A3G_DEV_01/raw_workers/'
ns=set(F.namelist());evpaths=sorted(n for n in ns if n.startswith(prefix) and n.endswith('.event.json')); byclass=collections.Counter();bycase=collections.defaultdict(collections.Counter);entries=[];faults=[];bad_undeclared=[]
for en in evpaths:
 ev=json.loads(F.read(en));d=en.rsplit('/',1)[0]+'/';case=en[len(prefix):].split('/')[0]
 for stream in ['stdout','stderr']:
  ent=ev[stream];p=d+ent['path']; b=F.read(p) if p in ns else None
  is_match=(b is not None and len(b)==ent['bytes'] and h(b)==ent['sha256'] and ent['capture_bytes']==ent['bytes'] and ent['capture_sha256']==ent['sha256'])
  diff=[]
  if b is None:diff.append('absent')
  elif len(b)!=ent['bytes'] or h(b)!=ent['sha256']:diff.append('recorded_saved_mismatch')
  if (ent['bytes'],ent['sha256'])!=(ent['capture_bytes'],ent['capture_sha256']):diff.append('recorded_capture_mismatch')
  category='MATCH' if is_match else 'MISMATCH'
  byclass[category]+=1; bycase[case][category]+=1
  if not is_match:
   item={'case':case,'stream':stream,'event':en,'error':diff,'fault':ev.get('evidence_fault'), 'fault_class':ev.get('evidence_fault_class'), 'save_bytes':len(b) if b is not None else None,'recorded_bytes':ent['bytes']}
   faults.append(item)
   if ev.get('evidence_fault_class')!='SIMULATED_EVIDENCE_FAULT' and case!='G06_foreign_event_copy':bad_undeclared.append(item)
  entries.append((case,stream,category))
# Check worker event identities
res.update({'archive_inventories':checkpoints,'stream_events':len(evpaths),'stream_rows':len(entries),'stream_match_summary':dict(byclass),'stream_unexpected':bad_undeclared,'stream_mismatch_by_case':{k:dict(v) for k,v in bycase.items() if v.get('MISMATCH')},'stream_mismatch_examples':faults[:10]})
# R1 predecessor kernel from same older signed P0A3E on local /mnt/data?
older=P/'p0a3f_qc_readonly/P0A3E_cumulative_implementation_candidate.zip'
if older.exists():
 z=ZipFile(older);oldn=z.namelist()
 for path in ['src/meru_geometry/v0_9/qo2d_exact/algebra.py','src/meru_geometry/v0_9/qo2d_exact/core.py','reference/v0_9/qo2d_exact/arithmetic.py']:
  match=[n for n in oldn if n.endswith(path)]
  res.setdefault('kernels',{})[path]={'found':match,'match_original':F.read('candidate/'+path)==z.read(match[0]) if len(match)==1 else None,'sha':h(F.read('candidate/'+path))}
# time and dryrun count
res['prelock_dryrun_14_case_summaries']={}
for i in range(1,5):
 n=f'prelock/dry0{i}.stdout';r=json.loads(C1.read(n));res['prelock_dryrun_14_case_summaries'][f'dryrun_{i}']={'registered':r.get('methods_registered'),'run':r.get('methods_run'),'passed':r.get('attempt_passed'),'failures':r.get('failures'),'errors':r.get('errors')}
q=P/'P0A3G_INDEPENDENT_QC_EVIDENCE_RECHECK.json';q.write_text(json.dumps(res,indent=2));print(json.dumps({k:v for k,v in res.items() if k not in ['stream_mismatch_examples']},indent=2));print('WROTE',q)
