from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import hashlib,json,collections,base64, re
p=Path('/mnt/data')
archives={k:p/f'P0A3G_G-{k}.zip' for k in ['C0','C1','CFINAL']}; archives['C2']=p/'P0A3G_G-C2_DEV_01.zip'
report={}
for key,file in archives.items():
 with ZipFile(file) as z:
  ns=z.namelist(); counts=collections.Counter(ns);badpaths=[x for x in ns if x.startswith('/') or '\\' in x or '..' in PurePosixPath(x).parts]; symlinks=[x for x in z.infolist() if (x.external_attr >> 16)&0o170000==0o120000]; nsymlinks=len(symlinks)
  m={x.split('  ',1)[1]:x.split('  ',1)[0] for x in z.read('SHA256SUMS').decode().strip().splitlines()}
  unlisted=set(ns)-set(m)-{'SHA256SUMS'}; missing=set(m)-set(ns)
  mismatches=[n for n,h in m.items() if n in ns and hashlib.sha256(z.read(n)).hexdigest()!=h]
  inv=json.loads(z.read('PACKAGE_INVENTORY.json')); report[key]={'size':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'members':len(ns),'manifest_count':len(m),'manifest_mismatches':mismatches,'missing':sorted(missing),'unlisted':sorted(unlisted),'badpaths':badpaths,'duplicate_paths':[n for n,c in counts.items() if c>1],'symlinks':nsymlinks,'inventory_type':type(inv).__name__, 'invkeys':list(inv)[:12] if isinstance(inv,dict) else None}
  if isinstance(inv,dict):
   for k,v in inv.items():
    if isinstance(v,list):
     report[key]['invlistkey']=k;report[key]['inv_count']=len(v);break
  if key=='CFINAL':
   for name in ['reports/FINAL_ENGINEERING_DISPOSITION.md','reports/DEV_ATTEMPT_SUMMARY.json','reports/STREAM_EVENT_RECONCILIATION.json','reports/CHECKPOINT_IDENTITY_LEDGER.json','reports/EXTERNAL_TEST_SIGNATURE_VERIFICATION_LEDGER.json']:
    print('\n',name,'\n',z.read(name).decode()[:7000])
  if key=='C1':
   print('\nC1 DECLARED TESTS:\n',z.read('P0A3G_DEV_CASES_PREDECLARED.md').decode()[:6500])
print('\nINTEGRITY:\n',json.dumps(report,indent=2))
(Path('/mnt/data/P0A3G_QC_archive_integrity.json')).write_text(json.dumps(report,indent=2))
