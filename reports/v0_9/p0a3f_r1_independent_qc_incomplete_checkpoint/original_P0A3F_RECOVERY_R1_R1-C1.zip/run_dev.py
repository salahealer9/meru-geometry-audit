"""R1 evidence controller; invokes only prospectively locked new DEV suite."""
from pathlib import Path
import sys,subprocess,os,signal,time,json,resource,hashlib,zipfile
W=Path(__file__).resolve().parent;R=W/'candidate';T=R/'reports/v0_9/p0a3f_runtime_external_trust_qualification';name=sys.argv[1]
assert name in ['P0A3F_R1_DEV_01','P0A3F_R1_DEV_02','P0A3F_R1_DEV_03']
A=T/'attempts';A.mkdir(exist_ok=True);attempt=A/name;assert not attempt.exists()
snapshot=A/(name+'_SOURCE.zip');assert not snapshot.exists()
with zipfile.ZipFile(snapshot,'w',zipfile.ZIP_DEFLATED) as z:
    for folder in ['src','reference','schemas','tests']:
        for p in sorted((R/folder).rglob('*')):
            if p.is_file():z.write(p,p.relative_to(R))
cmd=['/usr/bin/python3','-I','-S','-B',str(R/'tests/dev_v0_9/p0a3f/r1_checks.py'),str(attempt)]
def limits():
    resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));resource.setrlimit(resource.RLIMIT_CPU,(110,115));resource.setrlimit(resource.RLIMIT_FSIZE,(8388608,8388608));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
start=time.monotonic_ns();timed=False
with (A/(name+'.stdout')).open('xb') as out,(A/(name+'.stderr')).open('xb') as err:
    p=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True,preexec_fn=limits,env={'PATH':os.defpath,'LC_ALL':'C.UTF-8'})
    try:p.wait(timeout=120)
    except subprocess.TimeoutExpired:timed=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
result={'attempt':name,'command':cmd,'returncode':p.returncode,'outer_timeout':timed,'elapsed_ns':time.monotonic_ns()-start,'source_snapshot_sha256':hashlib.sha256(snapshot.read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256((A/(name+'.stdout')).read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((A/(name+'.stderr')).read_bytes()).hexdigest()}
(A/(name+'_execution.json')).write_text(json.dumps(result,indent=2)+'\n')
with (T/'DEV_EXECUTION_CHRONOLOGY.log').open('a') as f:f.write(json.dumps(result,sort_keys=True)+'\n')
print(json.dumps(result));sys.exit(p.returncode if p.returncode>=0 else 1)
