"""New R1 engineering edits from E; never imports candidate modules or runs tests."""
from pathlib import Path
import json
R=Path(__file__).resolve().parent/'candidate'
P=R/'src/meru_geometry/v0_9/qo2d_exact'; Q=R/'reference/v0_9/qo2d_exact'
# F1: new explicit caller receipt is separate from the manifest proposal.
(P/'identity.py').write_text('''"""R1 caller-supplied identity. Unsigned proposals never authorize deployment."""
import hashlib,json,platform,sys,types
from pathlib import Path
from .wire import ROOT,Boundary,decode,POLICY
PARENT='8ed3b988f716229bc9aee97d41ded0f524371193'
PROTOCOL='1d38ea6f53b9266d853df887a66331c59e4fc3ae'
AMENDMENT='83b9e6dcd53b100c5ac8b081832e81659cd1884a'
ARCHIVE='1e73c2685bd4eb8fba89e4e8ea609e97c7b4716805e83c64af374a4265522ea8'
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def environment():
    base=Path('/usr/lib/python3.12')
    deps=['fractions.py','decimal.py','json/__init__.py','json/decoder.py','json/encoder.py','json/scanner.py','hashlib.py','pathlib.py','subprocess.py']
    return {'python':sys.version,'implementation':sys.implementation.name,'platform':platform.platform(),'executable_realpath':str(Path(sys.executable).resolve()),'executable_sha256':sha(Path(sys.executable).read_bytes()),'flags':{'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode},'dependencies':{n:sha((base/n).read_bytes()) for n in deps}}
def files():
    out={}
    for folder in ('src','reference','schemas','tests'):
        for p in sorted((ROOT/folder).rglob('*')):
            if p.is_symlink() or p.suffix in ('.pyc','.pyo'):raise Boundary('CODE_IDENTITY_MISMATCH','SOURCE_SYMLINK_OR_BYTECODE')
            if p.is_file() and p.suffix in ('.py','.json','.md'):out[p.relative_to(ROOT).as_posix()]=sha(p.read_bytes())
    return out
def loaded_check():
    # Narrow accidental module-function mutation check, NOT runtime attestation.
    for name,mod in tuple(sys.modules.items()):
        if not (name.startswith('meru_geometry.') or name.startswith('reference.')):continue
        path=getattr(mod,'__file__',None)
        if not path or not str(path).endswith('.py'):continue
        p=Path(path)
        if ROOT not in p.resolve().parents:raise ValueError('loaded outside root')
        code=compile(p.read_bytes(),str(p),'exec',dont_inherit=True,optimize=0)
        funcs={c.co_name:c for c in code.co_consts if isinstance(c,types.CodeType)}
        for key,value in vars(mod).items():
            if isinstance(value,types.FunctionType) and value.__module__==name:
                if key not in funcs or value.__code__!=funcs[key]:raise ValueError('loaded function mismatch')
def verify(raw,input_hash=None,receipt=None,*,allow_dev=False):
    try:
        m=decode(raw,POLICY['document_bytes']);t=decode(receipt,POLICY['document_bytes'])
        fields={'schema','authority_mode','protocol_commit','recovery_commit','signed_parent','original_archive_sha256','files','environment_sha256','input_sha256'}
        if type(m) is not dict or set(m)!=fields:raise ValueError('manifest fields')
        if (m['schema'],m['authority_mode'],m['protocol_commit'],m['recovery_commit'],m['signed_parent'],m['original_archive_sha256'])!=('p0a3f-r1-expected-1','UNSIGNED_STAGING_PROPOSAL',PROTOCOL,AMENDMENT,PARENT,ARCHIVE):raise ValueError('manifest authority')
        if type(t) is not dict or set(t)!={'schema','trust_mode','expected_sha256','run_id','signer'}:raise ValueError('receipt fields')
        if not allow_dev or t['schema']!='p0a3f-r1-caller-receipt-1' or t['trust_mode']!='CALLER_OWNED_DEV_FIXTURE' or t['signer']!='NO_SIGNATURE_DEV_ONLY':raise ValueError('no real signed code authority')
        if t['expected_sha256']!=sha(raw) or type(t['run_id']) is not str or not __import__('re').fullmatch('[A-Za-z0-9_.-]{1,64}',t['run_id']):raise ValueError('caller binding')
        if m['files']!=files() or m['environment_sha256']!=sha(canonical(environment())):raise ValueError('source/runtime')
        h=m['input_sha256']
        if type(h) is not str or not __import__('re').fullmatch('[0-9a-f]{64}',h) or (input_hash is not None and input_hash!=h):raise ValueError('input')
        loaded_check()
        return m
    except Exception as e:raise Boundary('CODE_IDENTITY_MISMATCH','EXTERNAL_EXPECTATION_MISMATCH') from e
''')
(Q/'identity.py').write_text('''"""Separately written R1 checker trust gate; no production identity imports."""
import hashlib,json,platform,sys,types,re
from pathlib import Path
from .wire import ROOT,read,LIMITS
class IdentityMismatch(Exception):pass
def blob(b):return hashlib.sha256(b).hexdigest()
def encoded(x):return json.dumps(x,ensure_ascii=True,allow_nan=False,sort_keys=True,separators=(',',':')).encode('ascii')
def verify(external,input_bytes,receipt=None,*,allow_dev=False):
    try:
        m=read(external,LIMITS['document_bytes']);r=read(receipt,LIMITS['document_bytes'])
        if type(m)!=dict or set(m)!={'schema','authority_mode','protocol_commit','recovery_commit','signed_parent','original_archive_sha256','files','environment_sha256','input_sha256'}:raise ValueError('fields')
        pins={'schema':'p0a3f-r1-expected-1','authority_mode':'UNSIGNED_STAGING_PROPOSAL','protocol_commit':'1d38ea6f53b9266d853df887a66331c59e4fc3ae','recovery_commit':'83b9e6dcd53b100c5ac8b081832e81659cd1884a','signed_parent':'8ed3b988f716229bc9aee97d41ded0f524371193','original_archive_sha256':'1e73c2685bd4eb8fba89e4e8ea609e97c7b4716805e83c64af374a4265522ea8'}
        if any(m[k]!=v for k,v in pins.items()):raise ValueError('authority')
        if type(r)!=dict or set(r)!={'schema','trust_mode','expected_sha256','run_id','signer'}:raise ValueError('receipt fields')
        if allow_dev is not True or r['schema']!='p0a3f-r1-caller-receipt-1' or r['trust_mode']!='CALLER_OWNED_DEV_FIXTURE' or r['signer']!='NO_SIGNATURE_DEV_ONLY' or r['expected_sha256']!=blob(external):raise ValueError('not independently supplied DEV receipt')
        if type(r['run_id'])!=str or re.fullmatch('[A-Za-z0-9_.-]{1,64}',r['run_id']) is None:raise ValueError('run id')
        found={}
        for folder in ['reference','schemas','src','tests']:
            for p in (ROOT/folder).rglob('*'):
                if p.is_symlink() or p.suffix in ('.pyc','.pyo'):raise ValueError('unsafe source')
                if p.is_file() and p.suffix in ('.md','.json','.py'):found[p.relative_to(ROOT).as_posix()]=blob(p.read_bytes())
        if found!=m['files']:raise ValueError('source map')
        names=['fractions.py','decimal.py','json/__init__.py','json/decoder.py','json/encoder.py','json/scanner.py','hashlib.py','pathlib.py','subprocess.py']
        env={'python':sys.version,'implementation':sys.implementation.name,'platform':platform.platform(),'executable_realpath':str(Path(sys.executable).resolve()),'executable_sha256':blob(Path(sys.executable).read_bytes()),'flags':{'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode},'dependencies':{n:blob((Path('/usr/lib/python3.12')/n).read_bytes()) for n in names}}
        if m['environment_sha256']!=blob(encoded(env)) or m['input_sha256']!=blob(input_bytes):raise ValueError('runtime/input')
        for name,module in list(sys.modules.items()):
            if not name.startswith('reference.'):continue
            filename=getattr(module,'__file__',None)
            if not filename or not filename.endswith('.py'):continue
            p=Path(filename)
            if ROOT not in p.resolve().parents:raise ValueError('module path')
            top=compile(p.read_bytes(),str(p),'exec',dont_inherit=True,optimize=0)
            funcs={c.co_name:c for c in top.co_consts if type(c)==types.CodeType}
            for n,value in vars(module).items():
                if type(value)==types.FunctionType and value.__module__==name and (n not in funcs or value.__code__!=funcs[n]):raise ValueError('loaded function')
        return m
    except Exception as e:raise IdentityMismatch('EXTERNAL_IDENTITY_MISMATCH') from e
''')
# F4 canonical bytes enforced in both independent decoders; bounded streams.
p=P/'wire.py';s=p.read_text().replace('    return o\ndef request(raw):','    if canonical(o).encode("ascii")!=raw:raise Boundary("INVALID_INPUT","NONCANONICAL_JSON")\n    return o\ndef request(raw):')
s += '''\ndef request_stream(stream):
    """Read at most cap+1 bytes; a trusted blocking stream adapter is required."""
    try:
        raw=stream.read(POLICY['request_bytes']+1)
        return parse_request(raw)
    except Exception:return fail('INVALID_INPUT','BOUNDED_STREAM_READ_FAILED')
''';p.write_text(s)
p=Q/'wire.py';s=p.read_text().replace('    return v\ndef keys','    if canonical(v)!=raw:raise Rejected("NONCANONICAL_JSON")\n    return v\ndef keys');p.write_text(s)
p=Q/'service.py';s=p.read_text().replace('def verify(raw_request,raw_certificate,raw_expected):','def verify(raw_request,raw_certificate,raw_expected,receipt=None,*,allow_dev=False):').replace('identity.verify(raw_expected,canonical)','identity.verify(raw_expected,canonical,receipt,allow_dev=allow_dev)').replace('check(c,raw_expected)','check(c,raw_expected,receipt,allow_dev=allow_dev)');p.write_text(s)
p=Q/'checker.py';s=p.read_text().replace('def check(c,expected):','def check(c,expected,receipt=None,*,allow_dev=False):').replace("external_identity.verify(expected,strict_wire.canonical(c['request']))","external_identity.verify(expected,strict_wire.canonical(c['request']),receipt,allow_dev=allow_dev)");p.write_text(s)
# F2 operational policy additions retain all existing mathematical/numerical limits.
s=R/'schemas/v0_9/p0a3f';s.mkdir(parents=True,exist_ok=True)
policy=json.loads((R/'schemas/v0_9/p0a3e/resource_policy.json').read_bytes())
policy.update(schema='p0a3f-r1-resource-policy-1',interpreter='/usr/bin/python3',interpreter_sha256='a92f0f95e883390c7256b2e441484aac06b1002dbe1d924141a77c8d82f96223',calibration_memory_bytes=536870912,startup_margin_bytes=67108864)
(s/'resource_policy.json').write_text(json.dumps(policy,sort_keys=True,indent=2)+'\n')
# point only engineering parsers at new operational policy; never touch kernels.
for p in [P/'wire.py',Q/'wire.py']:
    p.write_text(p.read_text().replace('schemas/v0_9/p0a3e/resource_policy.json','schemas/v0_9/p0a3f/resource_policy.json'))
