# NEW R1 prospective catalogue — 2026-10-21, before first DEV
[IMPLEMENTED_UNVERIFIED] This catalogue is newly written from P0A3E, not the missing original26-method source. It has18 ordered unittest methods, fail-fast; subcase counts are not independent scientific experiments. Actual bytes/constructors are in r1_checks.py and caller-side build_prerun.py; all source/test/schema/config/runtime/fixture hashes locked in PRE_RUN_LOCK.json and C1_SOURCE_MANIFEST.json before execution.

|Method|Predeclared expected outcome|
|---|---|
|01|Missing/malformed manifest, missing receipt and unsigned deployment rejected by both identity validators; no numerical work|
|02|Wrong parent/protocol/amendment/archive/runtime/input/file hashes, signer/mode/run/digest rejected in both validators|
|03|Mutated loaded top-level function detected; reference AST contains no production imports; narrow check only|
|04|Noncanonical whitespace, duplicate, NaN/float/null/invalid UTF8/Unicode escapes, invalid rationals/boolean metadata rejected; no accepted hash; valid bytes admitted|
|05|Stream reads at most65537bytes; bytes/depth/string/numeric-token caps RESOURCE_INCOMPLETE|
|06|New dependent radical sqrt(4+2sqrt3)=1+sqrt3; exact equality, zero inversion rejection, nonzero zero-conjugate inverse in both frozen kernels|
|07|Fake incompatible/missing/bool startup traces rejected before exact work; no large actual allocation|
|08|Exactly four new comparisons R,Z,T,N below; preflight producer/checker then sequential exact producer/reference; original-input/direct residual recomputed|
|09|Proper identity matrix is nonoptimal forR; false q=1 and false whole-roll tie rejected|
|10|Omitted/duplicate knot and changed traversal rejected|
|11|Negative/forward/boolean radical references and null nested path rejected|
|12|Alternate exact zero represented by -1+sqrt1 accepted semantically, not by expression-string identity|
|13|Simulated before-write/after-flush/before-rename/after-rename-before-dir-fsync/post-rename-after-fsync faults preserve files; final exists only lasttwo|
|14|Valid R checkpoint with deliberately stale saved verdict completes only after fresh independent checker, within8seconds; mandatory functional recovery|
|15|Same persisted certificate plus actual8s checker sleep/parent SIGKILL returns RESOURCE_INCOMPLETE with -9, no certificate; separate from14|
|16|Actual selfSIGKILL and exit17 typed; injected MemoryError/RecursionError RESOURCE_INCOMPLETE; no score|
|17|Torn/absent/wrong-work/wrong-digest/wrong-caller checkpoint rejected before workers|
|18|All three frozen kernels match F0 hashes|

[FROZEN THEOREM] R:A=(1,2),(3,3),(4,6), B=(5,2),(4,4),(1,5)=JA+(7,1), q=0; irrational lengths sqrt5 and sqrt10. Z:A with an initial zero edge and exact mid-edge rational subdivision compared to originalA, q=0 with zero-edge provenance. T:line(-7,0)->(7,0) versus(2,0)->(-2,0)->(2,0), zero correlation/whole-roll tie. N:same but finalx=2+2^-16, strictly positive correlation/unique rotation. Four fixtures only; certificate tampering and recovery reuse those certificates, not fresh parameter searches.

[IMPLEMENTED_UNVERIFIED] Fixed interpreter /usr/bin/python3 -I -S -B, CPython3.12.3 and pinnedbinary. No alternate interpreter after results. ExistingF0 metadata VM recorded; calibration uses identical selected producer/checker import profiles at512MiB with64MiB margin below unchanged256MiB worker AS cap. CPU6/7s; wall8s bothnormal/timeout; output2MiB; FD32; core0; recursion256; integer5000; request65536; JSONdepth32/tokens100000/container4096; maxvertices8/inputbits128/operations2m/coefficientbits16384/terms1024/formaldegree256/referencebits256; disk16MiB perrun, application only. Outer DEV120seconds,512MiB,CPU110/115s,output8MiB. Single sequentialworker; no sweeps or optimizer.

[UNRESOLVED] Original F DEV01 22 reportedpasses/23rdmethod checker8stimeout remains transcript-only failure with unknown cause. This fresh catalogue does not explain it. No deadlineincrease authorized to obtain success.

[IMPLEMENTED_UNVERIFIED] Command: /usr/bin/python3 -I -S -B p0a3f_r1/run_dev.py P0A3F_R1_DEV_01 (subsequent attempts monotonic only after durable failure+repair). run_dev.py installs outer limits, preserves exact command/stdout/stderr/result/whole source snapshot. At most3 attempts under this catalogue; no expansions or outcome-based budget changes. At first ordinary failure stop attempt, persistC2+, then reason/repair with exactdiff and another checkpoint before retry. Genuine false exact-certificate acceptance, kernel defect, provenance mismatch or prohibited data => STOP_AND_QUARANTINE. No favorable readiness claims. Every attempt and repair durably verified before continuing.

[INDEPENDENT_QC_PENDING] Fixtures and caller receipts are unsigned DEV authorities only. Deployment remains closed pending separate human signed codefreeze; all broad host/arbitrary-input/loaded-code guarantees are unqualified.
