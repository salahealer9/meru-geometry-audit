"""Bytes-only independent certificate entry point; all failed states omit score."""
import hashlib
from . import wire,identity
from .arithmetic import Incomplete,InvalidProof
from .checker import check
SUCCESS='ENGINEERING_EXACT_CERTIFICATE_CANDIDATE_UNVALIDATED'
def verify(raw_request,raw_certificate,raw_expected,receipt=None,*,allow_dev=False):
    try:
        # Bound original bytes and validate their grammar before canonical hashing.
        r=wire.read(raw_request,wire.LIMITS['request_bytes']);wire.request(r);canonical=wire.canonical(r)
        identity.verify(raw_expected,canonical,receipt,allow_dev=allow_dev)
        c=wire.read(raw_certificate,wire.LIMITS['certificate_bytes']);wire.certificate(c)
        if wire.canonical(c['request'])!=canonical:raise wire.Rejected('ORIGINAL_INPUT_CHANGED')
        checked=check(c,raw_expected,receipt,allow_dev=allow_dev)
        return {'schema':'p0a3e-check-1','state':SUCCESS,'certificate_sha256':hashlib.sha256(wire.canonical(c)).hexdigest(),'input_sha256':hashlib.sha256(canonical).hexdigest(),'details':checked,'qualification':'INDEPENDENT_QC_PENDING'}
    except identity.IdentityMismatch:return {'schema':'p0a3e-failure-1','state':'CODE_IDENTITY_MISMATCH','reason':'EXTERNAL_IDENTITY_MISMATCH'}
    except (wire.Exhausted,Incomplete,MemoryError,RecursionError) as e:
        state='UNRESOLVED_EXACT_PREDICATE' if 'ISOLATION_CAP' in str(e) else 'RESOURCE_INCOMPLETE'
        return {'schema':'p0a3e-failure-1','state':state,'reason':type(e).__name__+':'+str(e)[:128]}
    except (wire.Rejected,InvalidProof):return {'schema':'p0a3e-failure-1','state':'CERTIFICATE_REJECTED','reason':'EXACT_CERTIFICATE_OR_GRAMMAR_REJECTED'}
    except Exception:return {'schema':'p0a3e-failure-1','state':'INTERNAL_ERROR_NO_CERTIFICATE','reason':'REFERENCE_INTERNAL'}
