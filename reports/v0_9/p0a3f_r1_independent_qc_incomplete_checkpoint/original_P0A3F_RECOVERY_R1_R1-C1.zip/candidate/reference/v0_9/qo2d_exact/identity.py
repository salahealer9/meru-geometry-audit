"""Separately written R1 checker trust gate; no production identity imports."""
import hashlib,json,platform,sys,types,re
from pathlib import Path
from .wire import ROOT,read,LIMITS
class IdentityMismatch(Exception):pass
def blob(b):return hashlib.sha256(b).hexdigest()
def encoded(x):return json.dumps(x,ensure_ascii=True,allow_nan=False,sort_keys=True,separators=(',',':')).encode('ascii')
def verify(external,input_bytes,receipt=None,*,allow_dev=False):
    try:
        m=read(external,LIMITS['document_bytes']);r=read(receipt,LIMITS['document_bytes'])
        if type(m)!=dict or set(m)!={'schema','authority_mode','protocol_commit','recovery_commit','signed_parent','original_archive_sha256','files','environment_sha256','input_sha256'}:raise ValueError('fields')
        pins={'schema':'p0a3f-r1-expected-1','authority_mode':'UNSIGNED_STAGING_PROPOSAL','protocol_commit':'1d38ea6f53b9266d853df887a66331c59e4fc3ae','recovery_commit':'83b9e6dcd53b100c5ac8b081832e81659cd1884a','signed_parent':'8ed3b988f716229bc9aee97d41ded0f524371193','original_archive_sha256':'1e73c2685bd4eb8fba89e4e8ea609e97c7b4716805e83c64af374a4265522ea8'}
        if any(m[k]!=v for k,v in pins.items()):raise ValueError('authority')
        if type(r)!=dict or set(r)!={'schema','trust_mode','expected_sha256','run_id','signer'}:raise ValueError('receipt fields')
        if allow_dev is not True or r['schema']!='p0a3f-r1-caller-receipt-1' or r['trust_mode']!='CALLER_OWNED_DEV_FIXTURE' or r['signer']!='NO_SIGNATURE_DEV_ONLY' or r['expected_sha256']!=blob(external):raise ValueError('not independently supplied DEV receipt')
        if type(r['run_id'])!=str or re.fullmatch('[A-Za-z0-9_.-]{1,64}',r['run_id']) is None:raise ValueError('run id')
        found={}
        for folder in ['reference','schemas','src','tests']:
            for p in (ROOT/folder).rglob('*'):
                if p.is_symlink() or p.suffix in ('.pyc','.pyo'):raise ValueError('unsafe source')
                if p.is_file() and p.suffix in ('.md','.json','.py'):found[p.relative_to(ROOT).as_posix()]=blob(p.read_bytes())
        if found!=m['files']:raise ValueError('source map')
        names=['fractions.py','decimal.py','json/__init__.py','json/decoder.py','json/encoder.py','json/scanner.py','hashlib.py','pathlib.py','subprocess.py']
        env={'python':sys.version,'implementation':sys.implementation.name,'platform':platform.platform(),'executable_realpath':str(Path(sys.executable).resolve()),'executable_sha256':blob(Path(sys.executable).read_bytes()),'flags':{'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode},'dependencies':{n:blob((Path('/usr/lib/python3.12')/n).read_bytes()) for n in names}}
        if m['environment_sha256']!=blob(encoded(env)) or m['input_sha256']!=blob(input_bytes):raise ValueError('runtime/input')
        for name,module in list(sys.modules.items()):
            if not name.startswith('reference.'):continue
            filename=getattr(module,'__file__',None)
            if not filename or not filename.endswith('.py'):continue
            p=Path(filename)
            if ROOT not in p.resolve().parents:raise ValueError('module path')
            top=compile(p.read_bytes(),str(p),'exec',dont_inherit=True,optimize=0)
            funcs={c.co_name:c for c in top.co_consts if type(c)==types.CodeType}
            for n,value in vars(module).items():
                if type(value)==types.FunctionType and value.__module__==name and (n not in funcs or value.__code__!=funcs[n]):raise ValueError('loaded function')
        return m
    except Exception as e:raise IdentityMismatch('EXTERNAL_IDENTITY_MISMATCH') from e
