"""R1 single-writer POSIX controller; caller receipts and fresh recovery checking."""
import os,signal,stat,subprocess,resource,tempfile,time
from pathlib import Path
from .wire import POLICY,ROOT,Boundary,request,decode,fail
from .identity import verify,canonical,sha
SUCCESS='ENGINEERING_EXACT_CERTIFICATE_CANDIDATE_UNVALIDATED'
FAILURES={'INVALID_INPUT','NOT_EVALUABLE','CERTIFICATE_REJECTED','CODE_IDENTITY_MISMATCH','ENVIRONMENT_UNQUALIFIED','RESOURCE_INCOMPLETE','UNRESOLVED_EXACT_PREDICATE','UNKNOWN_TERMINATION','INTERNAL_ERROR_NO_CERTIFICATE','CHECKPOINT_UNVERIFIED'}
def bounded_file(path,cap):
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as f:
        st=os.fstat(f.fileno())
        if not stat.S_ISREG(st.st_mode):raise Boundary('INVALID_INPUT','REGULAR_FILE_REQUIRED')
        if st.st_size>cap:raise Boundary('RESOURCE_INCOMPLETE','FILE_SIZE_CAP')
        b=f.read(cap+1)
    if len(b)>cap:raise Boundary('RESOURCE_INCOMPLETE','FILE_READ_CAP')
    return b
def disk(d):
    if d.is_symlink() or not d.is_dir():raise Boundary('CHECKPOINT_UNVERIFIED','RUN_DIRECTORY')
    total=0
    for p in d.iterdir():
        if p.is_symlink() or not p.is_file():raise Boundary('CHECKPOINT_UNVERIFIED','RUN_DIRECTORY_SHAPE')
        total+=p.stat().st_size
    if total>POLICY['run_disk_bytes']:raise Boundary('RESOURCE_INCOMPLETE','RUN_DISK_CAP')
def private_write(p,b):
    if type(b)!=bytes or len(b)>POLICY['document_bytes']:raise Boundary('RESOURCE_INCOMPLETE','WRITE_BYTE_CAP')
    with open(p,'xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def install_limits(calibration):
    # Supported only in a single-threaded trusted POSIX supervisor.
    mem=POLICY['calibration_memory_bytes'] if calibration else POLICY['worker_memory_bytes']
    for key,cap in [(resource.RLIMIT_AS,mem),(resource.RLIMIT_FSIZE,POLICY['worker_file_bytes']),(resource.RLIMIT_NOFILE,POLICY['worker_open_files']),(resource.RLIMIT_CORE,0)]:resource.setrlimit(key,(cap,cap))
    resource.setrlimit(resource.RLIMIT_CPU,(POLICY['worker_cpu_seconds'],POLICY['worker_cpu_seconds']+1))
def child(mode,d,raw,expected,receipt,certificate=None,*,fault='none',events=None,allow_dev=False):
    events=events if events is not None else [];disk(d)
    prefix=f'worker_{len(list(d.iterdir())):04}'
    paths={k:d/(prefix+'_'+k+suffix) for k,suffix in [('request','.json'),('expected','.json'),('certificate','.json'),('receipt','.json'),('stdout','.json'),('stderr','.log')]}
    for key,data in [('request',raw),('expected',expected),('receipt',receipt)]:private_write(paths[key],data)
    if certificate is not None:private_write(paths['certificate'],canonical(certificate))
    if sha(Path(POLICY['interpreter']).read_bytes())!=POLICY['interpreter_sha256']:return fail('ENVIRONMENT_UNQUALIFIED','INTERPRETER_IDENTITY')
    cmd=[POLICY['interpreter'],'-I','-S','-B',str(ROOT/'src/meru_geometry/v0_9/qo2d_exact/worker.py'),mode,*[str(paths[k]) for k in ('request','expected','certificate','receipt')],fault,'DEV_ONLY' if allow_dev else 'DEPLOYMENT']
    # Eight-second bound applies to BOTH normal and injected checker timeout.
    limit=POLICY['worker_wall_seconds'];start=time.monotonic_ns()
    event={'command':cmd,'wall_limit_seconds':limit,'mode':mode,'fault':fault,'controller_timeout':False};events.append(event)
    with open(paths['stdout'],'xb') as out,open(paths['stderr'],'xb') as err:
        proc=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True,preexec_fn=lambda:install_limits(mode.startswith('calibrate_')),env={'PATH':os.defpath,'LC_ALL':'C.UTF-8'})
        event['pid']=proc.pid
        try:proc.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL);proc.wait();event['controller_timeout']=True
    event.update(returncode=proc.returncode,elapsed_ns=time.monotonic_ns()-start)
    for name in ('stdout','stderr'):
        data=bounded_file(paths[name],POLICY['worker_file_bytes']);event[name+'_bytes']=len(data);event[name+'_sha256']=sha(data)
    if event['controller_timeout']:return fail('RESOURCE_INCOMPLETE','CONTROLLER_WALL_TIMEOUT')
    if proc.returncode<0:return fail('UNKNOWN_TERMINATION','WORKER_SIGNAL_'+str(-proc.returncode))
    if proc.returncode!=0:return fail('INTERNAL_ERROR_NO_CERTIFICATE','WORKER_NONZERO_'+str(proc.returncode))
    disk(d)
    try:return decode(bounded_file(paths['stdout'],POLICY['worker_file_bytes']),POLICY['worker_file_bytes'])
    except Boundary:return fail('INTERNAL_ERROR_NO_CERTIFICATE','MALFORMED_WORKER_OUTPUT')
def compatible(trace):
    try:
        v=trace['sizes']['VmSize'];rss=trace['sizes']['VmRSS']
        return trace['state']=='CALIBRATION_ONLY' and type(v) is int and type(rss) is int and 0<rss<=v and v+POLICY['startup_margin_bytes']<=POLICY['worker_memory_bytes']
    except Exception:return False
def preflight(d,raw,expected,receipt,events,allow_dev):
    for mode in ('produce','check'):
        t=child('calibrate_'+mode,d,raw,expected,receipt,events=events,allow_dev=allow_dev)
        events[-1]['calibration']=t
        if not compatible(t):raise Boundary('ENVIRONMENT_UNQUALIFIED','STARTUP_PREFLIGHT_FAILED')
def context(raw,expected,receipt,allow_dev):
    verify(expected,receipt=receipt,allow_dev=allow_dev)
    r,b=request(raw);verify(expected,sha(b),receipt,allow_dev=allow_dev)
    trust=decode(receipt,POLICY['document_bytes'])
    work=sha(canonical({'input_sha256':sha(b),'expected_sha256':sha(expected),'caller_receipt_sha256':sha(receipt),'run_id':trust['run_id'],'service':'p0a3f-r1-supervisor-1'}))
    return r,b,work
def atomic_save(d,record,fault='none'):
    if fault not in ('none','before_write','after_flush','before_rename','after_rename','post_rename'):raise Boundary('INVALID_INPUT','FAULT_ENUM')
    disk(d);b=canonical(record)
    if len(b)>POLICY['document_bytes']:raise Boundary('RESOURCE_INCOMPLETE','CHECKPOINT_BYTE_CAP')
    if fault=='before_write':raise Boundary('RESOURCE_INCOMPLETE','SIMULATED_BEFORE_WRITE')
    fd,tmp=tempfile.mkstemp(prefix='pending_',suffix='.json',dir=d)
    with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
    if fault in ('after_flush','before_rename'):raise Boundary('RESOURCE_INCOMPLETE','SIMULATED_'+fault.upper())
    os.replace(tmp,d/'checkpoint.json')
    if fault=='after_rename':raise Boundary('RESOURCE_INCOMPLETE','SIMULATED_AFTER_RENAME_BEFORE_DIRECTORY_FSYNC')
    fd=os.open(d,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
    if fault=='post_rename':raise Boundary('RESOURCE_INCOMPLETE','SIMULATED_POST_RENAME_AFTER_DIRECTORY_FSYNC')
    disk(d)
def checked_record(raw,expected,receipt,certificate,d,events,allow_dev,check_fault='none'):
    checked=child('check',d,raw,expected,receipt,certificate,events=events,allow_dev=allow_dev,fault=check_fault)
    if type(checked)!=dict or checked.get('state')!=SUCCESS:
        if type(checked)==dict and checked.get('state') in FAILURES:return fail(checked['state'],checked.get('reason','CHECKER_FAILURE'))
        return fail('INTERNAL_ERROR_NO_CERTIFICATE','UNEXPECTED_CHECKER_OUTPUT')
    if checked.get('certificate_sha256')!=sha(canonical(certificate)):return fail('INTERNAL_ERROR_NO_CERTIFICATE','CHECKED_BYTES_MISMATCH')
    return checked
def operation(raw,expected,receipt,directory,*,resume_mode=False,allow_dev=False,dev_fault='none',save_fault='none',check_fault='none'):
    events=[]
    try:
        if not allow_dev and any(x!='none' for x in (dev_fault,save_fault,check_fault)):raise Boundary('INVALID_INPUT','DEV_FAULT_DISABLED')
        r,b,work=context(raw,expected,receipt,allow_dev);d=Path(directory)
        if resume_mode:
            disk(d)
            try:record=decode(bounded_file(d/'checkpoint.json',POLICY['document_bytes']),POLICY['document_bytes'])
            except Exception as e:raise Boundary('CHECKPOINT_UNVERIFIED','ABSENT_OR_TORN_CHECKPOINT') from e
            fields={'schema','work_identity','certificate_sha256','certificate','verification'}
            if type(record)!=dict or set(record)!=fields or record['schema']!='p0a3f-r1-checkpoint-1' or record['work_identity']!=work or record['certificate_sha256']!=sha(canonical(record['certificate'])):raise Boundary('CHECKPOINT_UNVERIFIED','CHECKPOINT_BINDING')
            cert=record['certificate']
        else:
            if d.exists():raise Boundary('CHECKPOINT_UNVERIFIED','NEW_DIRECTORY_REQUIRED')
            d.mkdir(mode=0o700,parents=False)
        preflight(d,b,expected,receipt,events,allow_dev)
        if not resume_mode:
            cert=child('produce',d,b,expected,receipt,fault=dev_fault,events=events,allow_dev=allow_dev)
            if type(cert)!=dict:raise Boundary('INTERNAL_ERROR_NO_CERTIFICATE','WORKER_OBJECT')
            if cert.get('state') in FAILURES:raise Boundary(cert['state'],cert.get('reason','WORKER_FAILURE'))
        check=checked_record(b,expected,receipt,cert,d,events,allow_dev,check_fault)
        if check.get('state')!=SUCCESS:raise Boundary(check['state'],check.get('reason','CHECK_FAILURE'))
        if not resume_mode:
            record={'schema':'p0a3f-r1-checkpoint-1','work_identity':work,'certificate_sha256':sha(canonical(cert)),'certificate':cert,'verification':check};atomic_save(d,record,save_fault)
        return {'schema':'p0a3f-r1-result-1','state':SUCCESS,'work_identity':work,'certificate':cert,'verification':check,'worker_events':events,'recovery':'FRESH_REFERENCE_RECOMPUTED' if resume_mode else 'NEW_CHECKED_RECORD'}
    except Boundary as e:return {**fail(e.state,e.reason,raw),'worker_events':events}
    except (MemoryError,RecursionError):return {**fail('RESOURCE_INCOMPLETE','CONTROLLER_RUNTIME_LIMIT',raw),'worker_events':events}
    except Exception:return {**fail('INTERNAL_ERROR_NO_CERTIFICATE','CONTROLLER_IO_OR_INTERNAL',raw),'worker_events':events}
def run(raw,expected,receipt,directory,**options):return operation(raw,expected,receipt,directory,**options)
def resume(raw,expected,receipt,directory,**options):return operation(raw,expected,receipt,directory,resume_mode=True,**options)
