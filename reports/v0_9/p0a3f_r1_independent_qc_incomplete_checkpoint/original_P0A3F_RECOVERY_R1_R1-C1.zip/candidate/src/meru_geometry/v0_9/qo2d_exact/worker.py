"""R1 private bounded worker; limits already installed by parent before exec."""
import json,os,resource,signal,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
policy=json.loads((ROOT/'schemas/v0_9/p0a3f/resource_policy.json').read_bytes())
def output(obj):
    b=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
    if len(b)>policy['worker_file_bytes']:b=b'{"reason":"OUTPUT_BYTE_CAP","schema":"p0a3f-r1-failure-1","state":"RESOURCE_INCOMPLETE"}'
    sys.stdout.buffer.write(b);sys.stdout.buffer.flush()
def main():
    mode,request_file,expected_file,certificate_file,receipt_file,fault,dev=sys.argv[1:]
    calibration=mode.startswith('calibrate_');selected=mode.removeprefix('calibrate_')
    mem=policy['calibration_memory_bytes'] if calibration else policy['worker_memory_bytes']
    for kind,cap in [(resource.RLIMIT_AS,mem),(resource.RLIMIT_FSIZE,policy['worker_file_bytes']),(resource.RLIMIT_NOFILE,policy['worker_open_files']),(resource.RLIMIT_CORE,0)]:
        if resource.getrlimit(kind)!=(cap,cap):raise RuntimeError('PARENT_LIMITS_NOT_APPLIED')
    sys.setrecursionlimit(policy['recursion']);sys.set_int_max_str_digits(policy['integer_digits'])
    sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
    if selected=='produce':
        from meru_geometry.v0_9.qo2d_exact.wire import request,Boundary
        from meru_geometry.v0_9.qo2d_exact.identity import verify,sha
        from meru_geometry.v0_9.qo2d_exact.core import execute
    elif selected=='check':
        from reference.v0_9.qo2d_exact.service import verify as check
    else:raise RuntimeError('MODE')
    if calibration:
        status=Path('/proc/self/status').read_text();sizes={}
        for line in status.splitlines():
            if line.startswith(('VmSize:','VmRSS:')):
                k,v,u=line.split();sizes[k[:-1]]=int(v)*1024
        output({'schema':'p0a3f-r1-preflight-1','state':'CALIBRATION_ONLY','mode':selected,'sizes':sizes,'pid':os.getpid(),'recursion':sys.getrecursionlimit(),'limits':{name:list(resource.getrlimit(getattr(resource,name))) for name in ('RLIMIT_AS','RLIMIT_CPU','RLIMIT_FSIZE','RLIMIT_NOFILE','RLIMIT_CORE')}});return
    if fault=='timeout':time.sleep(30)
    elif fault=='kill':os.kill(os.getpid(),signal.SIGKILL)
    elif fault=='exit':os._exit(17)
    elif fault=='memory':raise MemoryError('INJECTED')
    elif fault=='recursion':raise RecursionError('INJECTED')
    elif fault!='none':raise RuntimeError('UNKNOWN_FAULT')
    def read(path,cap):
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
        with os.fdopen(fd,'rb') as f:b=f.read(cap+1)
        if len(b)>cap:raise MemoryError('RAW_CAP')
        return b
    raw=read(request_file,policy['request_bytes']);expected=read(expected_file,policy['document_bytes']);receipt=read(receipt_file,policy['document_bytes'])
    if selected=='produce':
        try:
            r,b=request(raw);verify(expected,sha(b),receipt,allow_dev=dev=='DEV_ONLY');output(execute(r))
        except Boundary as e:output({'schema':'p0a3f-r1-failure-1','state':e.state,'reason':e.reason})
    else:output(check(raw,read(certificate_file,policy['certificate_bytes']),expected,receipt,allow_dev=dev=='DEV_ONLY'))
if __name__=='__main__':
    try:main()
    except (MemoryError,RecursionError):output({'schema':'p0a3f-r1-failure-1','state':'RESOURCE_INCOMPLETE','reason':'WORKER_RUNTIME_LIMIT'})
    except Exception as e:output({'schema':'p0a3f-r1-failure-1','state':'INTERNAL_ERROR_NO_CERTIFICATE','reason':type(e).__name__})
