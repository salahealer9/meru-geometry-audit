"""R1 caller-supplied identity. Unsigned proposals never authorize deployment."""
import hashlib,json,platform,sys,types
from pathlib import Path
from .wire import ROOT,Boundary,decode,POLICY
PARENT='8ed3b988f716229bc9aee97d41ded0f524371193'
PROTOCOL='1d38ea6f53b9266d853df887a66331c59e4fc3ae'
AMENDMENT='83b9e6dcd53b100c5ac8b081832e81659cd1884a'
ARCHIVE='1e73c2685bd4eb8fba89e4e8ea609e97c7b4716805e83c64af374a4265522ea8'
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def environment():
    base=Path('/usr/lib/python3.12')
    deps=['fractions.py','decimal.py','json/__init__.py','json/decoder.py','json/encoder.py','json/scanner.py','hashlib.py','pathlib.py','subprocess.py']
    return {'python':sys.version,'implementation':sys.implementation.name,'platform':platform.platform(),'executable_realpath':str(Path(sys.executable).resolve()),'executable_sha256':sha(Path(sys.executable).read_bytes()),'flags':{'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode},'dependencies':{n:sha((base/n).read_bytes()) for n in deps}}
def files():
    out={}
    for folder in ('src','reference','schemas','tests'):
        for p in sorted((ROOT/folder).rglob('*')):
            if p.is_symlink() or p.suffix in ('.pyc','.pyo'):raise Boundary('CODE_IDENTITY_MISMATCH','SOURCE_SYMLINK_OR_BYTECODE')
            if p.is_file() and p.suffix in ('.py','.json','.md'):out[p.relative_to(ROOT).as_posix()]=sha(p.read_bytes())
    return out
def loaded_check():
    # Narrow accidental module-function mutation check, NOT runtime attestation.
    for name,mod in tuple(sys.modules.items()):
        if not (name.startswith('meru_geometry.') or name.startswith('reference.')):continue
        path=getattr(mod,'__file__',None)
        if not path or not str(path).endswith('.py'):continue
        p=Path(path)
        if ROOT not in p.resolve().parents:raise ValueError('loaded outside root')
        code=compile(p.read_bytes(),str(p),'exec',dont_inherit=True,optimize=0)
        funcs={c.co_name:c for c in code.co_consts if isinstance(c,types.CodeType)}
        for key,value in vars(mod).items():
            if isinstance(value,types.FunctionType) and value.__module__==name:
                if key not in funcs or value.__code__!=funcs[key]:raise ValueError('loaded function mismatch')
def verify(raw,input_hash=None,receipt=None,*,allow_dev=False):
    try:
        m=decode(raw,POLICY['document_bytes']);t=decode(receipt,POLICY['document_bytes'])
        fields={'schema','authority_mode','protocol_commit','recovery_commit','signed_parent','original_archive_sha256','files','environment_sha256','input_sha256'}
        if type(m) is not dict or set(m)!=fields:raise ValueError('manifest fields')
        if (m['schema'],m['authority_mode'],m['protocol_commit'],m['recovery_commit'],m['signed_parent'],m['original_archive_sha256'])!=('p0a3f-r1-expected-1','UNSIGNED_STAGING_PROPOSAL',PROTOCOL,AMENDMENT,PARENT,ARCHIVE):raise ValueError('manifest authority')
        if type(t) is not dict or set(t)!={'schema','trust_mode','expected_sha256','run_id','signer'}:raise ValueError('receipt fields')
        if not allow_dev or t['schema']!='p0a3f-r1-caller-receipt-1' or t['trust_mode']!='CALLER_OWNED_DEV_FIXTURE' or t['signer']!='NO_SIGNATURE_DEV_ONLY':raise ValueError('no real signed code authority')
        if t['expected_sha256']!=sha(raw) or type(t['run_id']) is not str or not __import__('re').fullmatch('[A-Za-z0-9_.-]{1,64}',t['run_id']):raise ValueError('caller binding')
        if m['files']!=files() or m['environment_sha256']!=sha(canonical(environment())):raise ValueError('source/runtime')
        h=m['input_sha256']
        if type(h) is not str or not __import__('re').fullmatch('[0-9a-f]{64}',h) or (input_hash is not None and input_hash!=h):raise ValueError('input')
        loaded_check()
        return m
    except Exception as e:raise Boundary('CODE_IDENTITY_MISMATCH','EXTERNAL_EXPECTATION_MISMATCH') from e
