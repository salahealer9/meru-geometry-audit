import os, json, hashlib, zipfile, pathlib, subprocess, tempfile, shutil, sys, datetime, math
from fractions import Fraction as F
B=pathlib.Path('/mnt/data/p0a3f_qc_readonly'); X=B/'extracted'; rpt=X/'candidate/reports/v0_9/p0a3f_runtime_external_trust_qualification'
sha=lambda b:hashlib.sha256(b).hexdigest()
assertions={}; details={}
expected_sizes={'R1-C0':1790515,'R1-C1':1858394,'R1-C2':2131186,'R1-CFINAL':2165809}
expected_final='6ec2b6e96234836d629398fb7fc781909de8b47b0bf80f5cae11202620ff2f15'
expected_E='1e73c2685bd4eb8fba89e4e8ea609e97c7b4716805e83c64af374a4265522ea8'
for name,size in expected_sizes.items():
 fn=B/f'P0A3F_RECOVERY_R1_{name}.zip';dat=fn.read_bytes();assert len(dat)==size
 with zipfile.ZipFile(fn) as z:
  names=z.namelist(); assert len(names)==len(set(names)); assert z.testzip() is None
  checks={}
  for line in z.read('SHA256SUMS').decode().splitlines():
   h,path=line.split('  ',1);checks[path]=h;assert path in names and sha(z.read(path))==h
  inv=json.loads(z.read('PACKAGE_INVENTORY.json' if name=='R1-CFINAL' else 'PAYLOAD_INVENTORY.json'))
  for v in inv:assert sha(z.read(v['path']))==v['sha256'] and len(z.read(v['path']))==v['bytes']
  assert len(checks)==len(names)-1 and len(inv)==len(names)-2
  assertions[name]={'bytes':len(dat),'sha256':sha(dat),'members':len(names),'sha256_items':len(checks),'inventory_items':len(inv),'crc_pass':True,'manifest_pass':True,'inventory_pass':True}
assertions['R1-CFINAL']['expected_sha256_match']=sha((B/'P0A3F_RECOVERY_R1_R1-CFINAL.zip').read_bytes())==expected_final
assert assertions['R1-CFINAL']['expected_sha256_match']
assertions['P0A3E_baseline']={'sha256':sha((B/'P0A3E_cumulative_implementation_candidate.zip').read_bytes()),'expected_match':sha((B/'P0A3E_cumulative_implementation_candidate.zip').read_bytes())==expected_E}
assert assertions['P0A3E_baseline']['expected_match']
with zipfile.ZipFile(B/'P0A3E_cumulative_implementation_candidate.zip') as z:
 kernels=['src/meru_geometry/v0_9/qo2d_exact/algebra.py','src/meru_geometry/v0_9/qo2d_exact/core.py','reference/v0_9/qo2d_exact/arithmetic.py']
 assertions['kernels']={k:{'baseline_sha256':sha(z.read(k)),'R1_sha256':sha((X/'candidate'/k).read_bytes()),'identical':z.read(k)==(X/'candidate'/k).read_bytes()} for k in kernels}
 assert all(x['identical'] for x in assertions['kernels'].values())
c1=json.load(open(rpt/'C1_SOURCE_MANIFEST.json'))
assertions['C1_source_lock']={'file_count':len(c1),'mismatches':[n for n,h in c1.items() if sha((X/'candidate'/n).read_bytes())!=h]}
assert not assertions['C1_source_lock']['mismatches']
with zipfile.ZipFile(rpt/'attempts/P0A3F_R1_DEV_01_SOURCE.zip') as z:
 assertions['DEV_source_snapshot']={'file_count':len(z.namelist()),'mismatches':[n for n in z.namelist() if n not in c1 or sha(z.read(n))!=c1[n]]};assert not assertions['DEV_source_snapshot']['mismatches']
lock=json.load(open(rpt/'PRE_RUN_LOCK.json'))
assertions['prospective_lock']={'catalogue_sha256_locked':sha((rpt/'DEV_CASES_PREDECLARED.md').read_bytes())==lock['catalogue_sha256'],'fixtures_hashes_locked':all(sha((rpt/'prerun_fixtures'/n).read_bytes())==h for n,h in lock['fixture_files'].items()),'locked_fixture_count':len(lock['fixture_files'])}
assert assertions['prospective_lock']['catalogue_sha256_locked'] and assertions['prospective_lock']['fixtures_hashes_locked']
logs=(rpt/'attempts/P0A3F_R1_DEV_01.stderr').read_text()
assertions['DEV_log']={'passed_lines':len([line for line in logs.splitlines() if line.endswith('... ok')]),'reported_18': 'Ran 18 tests' in logs and '\nOK' in logs,'exitcode':json.load(open(rpt/'attempts/P0A3F_R1_DEV_01_execution.json'))['returncode']}
assert assertions['DEV_log']=={'passed_lines':18,'reported_18':True,'exitcode':0}
ev=json.load(open(rpt/'attempts/P0A3F_R1_DEV_01/evidence.json'))
obs={v['name']:v['value'] for v in ev['observations']}
for n in ['stale_verdict_checked_completion','recovery_actual_controller_timeout']:
 assert n in obs
ok=obs['stale_verdict_checked_completion'];timeout=obs['recovery_actual_controller_timeout']
assertions['recovery_log']={'checked_recovery_state':ok['state'],'checked_recovery_tag':ok.get('recovery'),'checked_last_checker_exit':ok['worker_events'][-1]['returncode'],'checked_last_checker_elapsed_s':ok['worker_events'][-1]['elapsed_ns']/1e9,'timeout_state':timeout['state'],'timeout_last_killed':timeout['worker_events'][-1]['returncode'],'timeout_elapsed_s':timeout['worker_events'][-1]['elapsed_ns']/1e9,'no_timeout_certificate':'certificate' not in timeout}
assert assertions['recovery_log']['checked_last_checker_exit']==0 and assertions['recovery_log']['timeout_last_killed']==-9 and assertions['recovery_log']['no_timeout_certificate']
# Cryptographic re-verification of retained detached signatures, against expected fingerprint; separate key ownership/trust claim.
gnupg=tempfile.mkdtemp(prefix='meru_qc_gpg_');os.chmod(gnupg,0o700)
try:
 key=subprocess.run(['gpg','--batch','--homedir',gnupg,'--import',str(X/'intake/signer_public_key.asc')],capture_output=True,text=True)
 sigs=[]
 for f in sorted((X/'intake/commits').glob('*.asc')):
  payload=f.with_suffix('.payload')
  run=subprocess.run(['gpg','--batch','--homedir',gnupg,'--status-fd','1','--verify',str(f),str(payload)],capture_output=True,text=True)
  sigs.append({'commit':f.stem,'ok':run.returncode==0 and 'VALIDSIG D4EC014EEFCC90E619D2AA59A91239ABCF512130 ' in run.stdout})
 assertions['detached_GPG']={'public_key_imported':key.returncode==0,'commit_signatures_checked':len(sigs),'all_match_expected_fingerprint':all(s['ok'] for s in sigs),'failures':[s for s in sigs if not s['ok']],'local_ownertrust_established':False}
finally:shutil.rmtree(gnupg)
# Reconstruct all 17 Git signed commit object IDs from retained payload and detached signature.
commit_reconstruction=[]
for f in sorted((X/'intake/commits').glob('*.payload')):
    unsigned=f.read_bytes(); headers,body=unsigned.split(b'\n\n',1)
    signature=f.with_suffix('.asc').read_bytes().rstrip(b'\n').split(b'\n')
    signed=headers+b'\ngpgsig '+signature[0]+b''.join(b'\n '+line for line in signature[1:])+b'\n\n'+body
    got=hashlib.sha1(b'commit '+str(len(signed)).encode()+b'\0'+signed).hexdigest()
    commit_reconstruction.append({'commit':f.stem,'verified':got==f.stem})
assertions['commit_object_reconstruction']={'count':len(commit_reconstruction),'all_git_object_ids_match':all(v['verified'] for v in commit_reconstruction),'mismatches':[x for x in commit_reconstruction if not x['verified']]}
assert assertions['commit_object_reconstruction']['all_git_object_ids_match']
# Match 37 recorded worker-event file SHA-256 values against actual checkpoint bytes.
worker_events=[]
def collect_events(x):
    if isinstance(x,dict):
        if 'stdout_sha256' in x and 'stderr_sha256' in x and 'command' in x:
            req=next((v for v in x['command'] if isinstance(v,str) and v.endswith('_request.json')),None)
            if req:
                req=pathlib.Path(req)
                directory=rpt/'attempts/P0A3F_R1_DEV_01/raw_workers'/req.parent.name
                for typ,ext in [('stdout','json'),('stderr','log')]:
                    f=directory/req.name.replace('_request.json','_'+typ+'.'+ext)
                    worker_events.append({'case':req.parent.name,'worker':req.name,'mode':x['mode'],'stream':typ,'present':f.exists(),'recorded_bytes':x[typ+'_bytes'],'actual_bytes':f.stat().st_size if f.exists() else None,'recorded_sha256':x[typ+'_sha256'],'actual_sha256':sha(f.read_bytes()) if f.exists() else None})
        for v in x.values():collect_events(v)
    elif isinstance(x,list):
        for v in x:collect_events(v)
collect_events(ev)
discrepancies=[v for v in worker_events if not v['present'] or v['recorded_bytes']!=v['actual_bytes'] or v['recorded_sha256']!=v['actual_sha256']]
assertions['retained_raw_worker_event_audit']={'events':len(worker_events)//2,'stream_records':len(worker_events),'verified_stream_records':len(worker_events)-len(discrepancies),'discrepancies':discrepancies,'all_match':len(discrepancies)==0}
# Independent mathematical checks, first two are exact structural Euclidean invariances, second two exact rational integration.
def rat(x):return F(int(x[0]),int(x[1]))
def point(p):return tuple(map(rat,p))
def loadpaths(name):
 x=json.loads((rpt/'prerun_fixtures'/f'{name}.request.json').read_bytes())
 return [[point(v) for v in p['vertices']] for p in x['paths']]
R,S=loadpaths('R');assert all(S[i]==(F(7)-p[1],F(1)+p[0]) for i,p in enumerate(R))
Z1,Z2=loadpaths('Z');assert Z2==R and Z1[0]==Z1[1] and Z1[2]==tuple((a+b)/2 for a,b in zip(R[0],R[1])) and Z1[3:]==R[1:]
assertions['geometric_R_Z']={'R_exact_proper_rotation_translation':True,'Z_exact_zero_edge_and_arclength_subdivision':True}
# Independently integrate collinear T and N with Fraction, piecewise linear arclength x(u) and integral of products.
def poly(pts):
 ed=[(a[0],b[0],abs(b[0]-a[0])) for a,b in zip(pts,pts[1:]) if a!=b]
 tot=sum((v[2] for v in ed),F(0)); assert tot>0
 u=F(0);ans=[]
 for a,b,L in ed:
  end=u+L/tot; slope=(b-a)/(end-u);intercept=a-slope*u;ans.append((u,end,slope,intercept));u=end
 assert u==1;return ans
def integrate_product(p,q):
 knots=sorted(set([F(0),F(1)]+[x for u,v,m,c in p+q for x in (u,v)]));value=F(0)
 for lo,hi in zip(knots,knots[1:]):
  mid=(lo+hi)/2
  m,c=next((m,c) for u,v,m,c in p if u<=mid<=v)
  n,d=next((n,d) for u,v,n,d in q if u<=mid<=v)
  value+=m*n*(hi**3-lo**3)/3+(m*d+n*c)*(hi**2-lo**2)/2+c*d*(hi-lo)
 return value
def centered_stats(poly1,poly2):
 one=[(F(0),F(1),F(0),F(1))]
 ea,eb=integrate_product(poly1,one),integrate_product(poly2,one)
 va=integrate_product(poly1,poly1)-ea*ea;vb=integrate_product(poly2,poly2)-eb*eb
 covariance=integrate_product(poly1,poly2)-ea*eb
 return va,vb,covariance
mathcheck={}
for name in ('T','N'):
 a,b=loadpaths(name);assert all(y==0 for x,y in a+b)
 va,vb,cov=centered_stats(poly(a),poly(b))
 assert va>0 and vb>0
 mathcheck[name]={'variance_A':str(va),'variance_B':str(vb),'covariance':str(cov),'s_is_zero':cov==0,'s_is_positive':cov>0,'alpha_sign':0 if cov==0 else (1 if cov>0 else -1)}
assert mathcheck['T']['covariance']=='0' and mathcheck['N']['covariance']!='0'
assertions['geometric_T_N_independent_rational_integrals']=mathcheck
# Read-only differential boundary microchecks under this host's non-pinned interpreter; no qualification as 3.12 runtime replay.
sys.path[:0]=[str(X/'candidate/src'),str(X/'candidate')]
from meru_geometry.v0_9.qo2d_exact import wire
from reference.v0_9.qo2d_exact import wire as refwire
raw=(rpt/'prerun_fixtures/R.request.json').read_bytes()
malformed=[('leading_whitespace',b' '+raw),('trailing_newline',raw+b'\n'),('duplicate_key',b'{"x":0,"x":1}'),('NaN',b'{"x":NaN}'),('float',b'{"x":1.25}'),('unicode_escape',b'{"x":"\\u0030"}'),('UTF8_nonASCII',b'\xc3\xa9'),('large_integer',b'1234567890123'),('too_deep',b'['*33+b'0'+b']'*33)]
results=[]
for name,b in malformed:
 prod=wire.parse_request(b)['state'];ref='REJECTED'
 try:refwire.read(b,refwire.LIMITS['request_bytes']);ref='ACCEPTED'
 except (refwire.Rejected,refwire.Exhausted,Exception) as e:ref=type(e).__name__
 results.append({'case':name,'producer':prod,'reference':ref})
assert all(x['producer']!='VALIDATED_INPUT' and x['reference']!='ACCEPTED' for x in results)
assertions['independent_parser_negative_microchecks']={'python_version':sys.version.split()[0],'cases':results,'all_rejected':True,'not_pinned_runtime_replay':True}
result={'review_time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'package_sha256':expected_final,'qc_mode':'read_only_independent_static_evidence_crypto_parser_mathematics; NOT pinned-runtime full 18-case replay','checks':assertions}
out=B/'P0A3F_RECOVERY_R1_INDEPENDENT_QC_VERIFICATION.json';out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2)[:17000])
