# Independent QC — Meru Geometry Audit P0A3F_RECOVERY_R1

**Date:** 21 October 2026  
**Reviewer:** ChatGPT (independent read-only review in the current conversation; no original Work execution reused)  
**Material:** Library file `P0A3F_RECOVERY_R1_R1-CFINAL.zip`, SHA-256 `6ec2b6e96234836d629398fb7fc781909de8b47b0bf80f5cae11202620ff2f15`, 2,165,809 bytes; separately retrieved C0, C1, C2 and P0A3E baseline.  
**Authority:** Signed P0A3F preregistration `1d38ea6f53b9266d853df887a66331c59e4fc3ae`, signed amendment `83b9e6dcd53b100c5ac8b081832e81659cd1884a`, exact amendment Git blob `9fd9fba6ca509e3fcb72c2227d226847d218b354`.  
**Restrictions:** Read-only independent QC; **NO COMMIT, NO PUSH, NO edits to signed files or candidate, NO registered validation**.

## Decision

**INDEPENDENT_QC_NOT_QUALIFIED — EVIDENCE-PRESERVATION DISCREPANCY.**

The submitted R1 candidate is genuine and the bulk of the DEV evidence is coherent, but it **does not qualify for a positive engineering-code freeze**. Independent byte-level comparison identified **two material raw worker-evidence inconsistencies**. The correct near-term action is to **preserve the exact unmodified ZIP and this negative QC finding**, investigate the discrepancy without reconstructing missing bytes, then determine whether a separate controlled corrective attempt must be preregistered. No favorable readiness or code-only freeze is authorized by this QC.

This negative QC **does not invalidate the previously frozen P0A3D mathematical theorem**, nor does it establish a false exact certificate. It is an execution-evidence preservation finding.

## QCF01 — HIGH / blocking for complete R1 evidence — two retained worker stdout files disagree with immutable execution records

I parsed the retained `attempts/P0A3F_R1_DEV_01/evidence.json`, traversed its **37** worker event records, and independently recomputed the SHA-256 and length of each referenced stdout/stderr file (**74 stream records**). **72 match; 2 fail**:

| Adversarial case | Work-recorded stdout size | Work-recorded stdout SHA-256 | Actual stdout size in C2 and CFINAL | Actual stdout SHA-256 |
|---|---:|---|---:|---|
| `forged_q` | 108 | `23bcfd677effd3a3b5ff73bfce72328c0bd19148a79617be8b896a4e1d802807` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `null_path_record` | 108 | `23bcfd677effd3a3b5ff73bfce72328c0bd19148a79617be8b896a4e1d802807` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |

Both paths are inside `candidate/reports/v0_9/p0a3f_runtime_external_trust_qualification/attempts/P0A3F_R1_DEV_01/raw_workers/<case>/worker_0000_stdout.json`.

These are **not ZIP corruption errors**: the ZIP's CRC, inventory and self-consistent manifest all correctly certify the stored *zero-byte* files. The mismatch is between the stored files and the **DEV event's own contemporaneous stdout identity**. Both streams are already zero-length in **R1-C2**, not only CFINAL. Their associated stderr records match. The summary reports 18/18 and event JSON reports checker exit code zero; that is useful retained *reported* evidence, but the exact 108 output bytes are not preserved in either checkpoint. A success-log summary cannot replace missing raw worker evidence.

**Disposition:** `P0A3F_R1_DEV_01_RAW_WORKER_EVIDENCE_INCONSISTENT`; `R1_CFINAL_RAW_EVIDENCE_COMPLETENESS_NOT_QUALIFIED`. Cause **unknown**; no allegation of deception or source alteration. Do not fill files by inference, quietly recalculate the recorded hash, or overwrite C2/CFINAL. The test pass count may be cited as **recorded DEV**, not independently confirmed complete raw-evidence certification for these two cases.

## QCF02 — BLOCKING for software readiness — externally authoritative signed code is absent

- Production `candidate/src/meru_geometry/v0_9/qo2d_exact/identity.py` and reference `candidate/reference/v0_9/qo2d_exact/identity.py` accept only `UNSIGNED_STAGING_PROPOSAL` coupled to `CALLER_OWNED_DEV_FIXTURE`, and only with `allow_dev=True`.
- Normal deployment without `allow_dev` fails closed. This is the **correct conservative behavior** for unapproved engineering code, but the current candidate has **no implemented qualified real-signed-code authorization path**.
- `loaded_check()` inspects loaded top-level function code only; it does **not** attest globals, classes, the Python loader, native runtime, malicious substitutions or filesystem TOCTOU.

**Disposition:** F1 remains `P0A3F_EXTERNAL_TRUST_ANCHOR_UNQUALIFIED` and `P0A3F_LOADED_CODE_IDENTITY_UNVERIFIED`. A later signed code-only freeze is not automatically sufficient if the frozen executable still lacks an independently verified runtime trust interface.

## QCF03 — INCOMPLETE runtime, crash, and hostile-input qualification

- R1 DEV reports CPython **3.12.3** `/usr/bin/python3`, pinned binary identity and bounded preflight. The independent reviewer environment provides **Python 3.13.5**, not the registered binary; therefore I **did not claim a same-runtime replay of the 18 methods** or bypass the binary identity check.
- The supervisor launches a separate process group and performs eight-second wall-time termination when alive, but controller death, whole-process-tree containment, power failure, disk-full/global starvation, hostile filesystem, cross-host environments and multiwriter durability remain unqualified.
- The raw input and independent checker tests are finite; they do not establish arbitrary-input executable correctness, complete object API hardening, or independent loaded-code trust.

**Disposition:** F2 is bounded DEV-supported only; F3 retains `RESOURCE_CRASH_ENVELOPE_INCOMPLETE`; F4 retains `INPUT_FAILURE_ENVELOPE_INCOMPLETE` and broad checker qualification remains incomplete. These are retained limitations, not claims of newly discovered mathematical failure.

## Independent checks passed

1. **Archive identities and manifests:** C0 133 members/132 hashes/131 inventory; C1 169/168/167; C2 392/391/390; CFINAL 408/407/406. All CRC, all member hashes and inventories independently verified. CFINAL bytes and SHA match the Library receipt.
2. **Signed history:** independently verified **17/17** detached GPG signatures against supplied key fingerprint `D4EC014EEFCC90E619D2AA59A91239ABCF512130`, and separately reconstructed all **17/17** signed Git commit-object SHA-1 identities from signed payload plus signature. The QC keyring does not assign ownertrust; signature/known-fingerprint checks are distinguished from the human's own locally trusted key verification.
3. **Baseline and mathematical kernels:** original P0A3E archive SHA matches its signed identification; all **three frozen P0A3D/E arithmetic/core kernels** are byte-identical in R1.
4. **Prospective source lock:** all **29** C1-hashed source/test/schema files match CFINAL and the immutable DEV source ZIP; all **12** prospective fixture bytes match the C1 hashes; the prospective catalogue hash matches PRE_RUN_LOCK.
5. **DEV chronology:** one attempt `P0A3F_R1_DEV_01`; stderr contains 18 explicit `... ok` lines and `Ran 18 tests / OK`, return code 0. CFINAL preserves the source snapshot and original test catalogue. This is evidence of a recorded bounded run, **not sufficient to dismiss QCF01**.
6. **Recovery evidence:** recorded stale-verdict recovery invokes fresh checker with return code 0, about **0.317110196 s**; separately recorded timeout returns `RESOURCE_INCOMPLETE`, checker return code **−9** after about **8.017195188 s**, with no returned certificate. Relevant retained raw event streams match except the two distinct hostile certificate cases in QCF01.
7. **Independent mathematical fixtures:** R is exactly a proper quarter-turn followed by translation, giving the expected score zero; Z retains the same arclength traversal after one zero edge and exact subdivision, also zero. Exact rational piecewise integration of T independently gives variance `49/3` and `4/3` with covariance **0** (whole-roll tie); N gives covariance **`2886229032967/108086803374145536` > 0** (unique proper rotation). These are independently calculated, not based on the candidate solver's reported scores.
8. **Independent non-pinned Python parser checks:** nine additional negative byte cases (leading/trailing whitespace, duplicate keys, NaN, float, escaped Unicode, non-ASCII, large integer and excessive nesting) were rejected by both producer/reference parsers under Python 3.13.5. These are explicitly **not** a substitute for CPython 3.12.3 environment qualification.

## F0–F7 QC disposition

| Phase | Independent disposition |
|---|---|
| F0 | PASS for checked archive provenance, signed histories, kernel baseline identities. |
| F1 | INCOMPLETE — unsigned DEV receipt only, no verified signed-code operational authority or complete loaded-code attestation. |
| F2 | EVIDENCE SUPPORTED WITH LIMITS — original bounded 3.12.3 DEV recorded; independent pinned-host replay NOT PERFORMED. |
| F3 | EVIDENCE SUPPORTED WITH LIMITS — successful checked recovery + real timeout recorded; broader crash assumptions unresolved. |
| F4 | **INCOMPLETE, RAW EVIDENCE DISCREPANCY** — two hostile-case stdout files inconsistent with recorded events. |
| F5 | **18/18 REPORTED**, source/test prospective identities PASS, **complete raw DEV evidence FAIL** under QCF01. |
| F6 | ZIP packaging integrity PASS; claim of complete raw worker artifact preservation FAIL. |
| F7 | **INDEPENDENT_QC_NOT_QUALIFIED**; no readiness, code-only freeze or P0A4 approval. |

## Preservation and appropriate next action

1. **Retain the original C0, C1, C2, CFINAL ZIPs and receipts unchanged.** Preserve this report plus the independent verification JSON/script as distinct unsigned QC evidence. No Git writes.
2. Check only authentic source channels/backups for the two original stdout byte streams matching the retained 108-byte size and `23bcfd...` hash. If unavailable, classify the original streams as missing/inconsistent; do not generate replacements or rewrite chronology.
3. Review how the supervisor writes and reads stdout (`supervisor.py:43–56`) and how the Work checkpoint packager captured the live file tree, without asserting a root cause not demonstrated by new evidence.
4. Before any corrective DEV, separately preregister the evidence-gap disposition, new attempt policy, source/fixture lock and enhanced **raw-worker-stream consistency assertions before checkpoint storage**. Preserve `P0A3F_R1_DEV_01` and negative QC immutably; a new attempt cannot retrospectively verify the lost bytes.
5. If future engineering clears the evidence problem, independently qualify the real signed-code trust mechanism, loaded-code limitations and resource/crash envelope. Only then assess eligibility for a human GPG-signed **code-only freeze**. No P0A4 or historical target work here.

**Research boundary:** P0A3D exact mathematical theorem remains independently frozen; P0A3E incomplete finding unchanged; original lost P0A3F_DEV_01 remains transcript-only and quarantined, its timeout cause unknown. The present finding concerns a distinct R1 evidence discrepancy, not either historical event. The programme remains target-blind.

---

**Related independently generated QC artifacts:** `P0A3F_RECOVERY_R1_INDEPENDENT_QC_VERIFICATION.json` (machine-readable checks and discrepancies) and `qc_checks.py` (read-only reproducibility script). Neither alters the Work candidate. These artifacts are **unsigned** until separately reviewed and human-preserved.
