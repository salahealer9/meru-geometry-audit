"""Metadata-only R1 F0 inventory; imports no scientific implementation."""
import sys,os,json,platform,resource,hashlib,sysconfig,importlib.metadata,subprocess
from pathlib import Path
sha=lambda b:hashlib.sha256(b).hexdigest()
repo=subprocess.run(['git','rev-parse','--show-toplevel'],capture_output=True,text=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
pkgs=[{'name':d.metadata.get('Name'),'version':d.version} for d in importlib.metadata.distributions()]
pkgs.sort(key=lambda x:(str(x['name']),str(x['version'])))
out={'schema':'p0a3f-r1-environment-inventory-1','executable':sys.executable,'realpath':str(Path(sys.executable).resolve()),'executable_sha256':sha(Path(sys.executable).read_bytes()),'version':sys.version,'implementation':sys.implementation.name,'flags':{'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode},'platform':platform.platform(),'machine':platform.machine(),'stdlib':sysconfig.get_path('stdlib'),'visible_distributions':pkgs,'startup_status':Path('/proc/self/status').read_text(),'resource_limits':{n:resource.getrlimit(getattr(resource,n)) for n in dir(resource) if n.startswith('RLIMIT_')},'cgroup':Path('/proc/self/cgroup').read_text(),'cgroup_memory_max':Path('/sys/fs/cgroup/memory.max').read_text() if Path('/sys/fs/cgroup/memory.max').exists() else None,'locale':os.environ.get('LC_ALL'),'repository_read_only_observation':{'command':['git','rev-parse','--show-toplevel'],'returncode':repo.returncode,'stdout':repo.stdout,'stderr':repo.stderr,'interpretation':'No local checkout is assumed; no clean HEAD assertion. All work isolated; remote immutable objects read only.'},'selected_command':['/usr/bin/python3','-I','-S','-B'],'scientific_code_imported':False}
print(json.dumps(out,indent=2))
