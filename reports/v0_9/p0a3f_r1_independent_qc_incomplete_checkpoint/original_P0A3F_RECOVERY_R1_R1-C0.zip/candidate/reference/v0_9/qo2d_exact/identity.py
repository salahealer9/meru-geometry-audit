"""Independent expected-identity validation. No production hash calls."""
import hashlib,json,platform,sys
from pathlib import Path
from .wire import ROOT,read,LIMITS
class IdentityMismatch(Exception):pass
def blob(b):return hashlib.sha256(b).hexdigest()
def encoded(x):return json.dumps(x,ensure_ascii=True,allow_nan=False,sort_keys=True,separators=(',',':')).encode('ascii')
def verify(external,input_bytes):
    try:
        m=read(external,LIMITS['document_bytes'])
        fields=['schema','authority_mode','protocol_commit','signed_parent','original_archive_sha256','files','environment_sha256','input_sha256']
        if type(m) is not dict or sorted(m)!=sorted(fields):raise ValueError('fields')
        if (m['schema'],m['authority_mode'],m['protocol_commit'],m['signed_parent'],m['original_archive_sha256'])!=('p0a3e-expected-1','DEV_UNFROZEN_EXPECTATIONS','c48c7a60777200a172ae3c72f5b0402162370ec7','59eb47f7500d57866e4935822b78a555d3bcb515','c2f99b0e78849de16c8dc8167bdf5d584d4f64ab2c8a787d6a0ed507cfa9f378'):raise ValueError('anchor')
        names=set()
        for folder in ('src','reference','schemas/v0_9/p0a3e','tests/dev_v0_9/p0a3e'):
            for p in (ROOT/folder).rglob('*'):
                if p.is_symlink():raise ValueError('symlink')
                if p.is_file() and p.suffix in ('.py','.md','.json'):names.add(p.relative_to(ROOT).as_posix())
        if type(m['files']) is not dict or names!=set(m['files']):raise ValueError('manifest coverage')
        for n in sorted(names):
            if blob((ROOT/n).read_bytes())!=m['files'][n]:raise ValueError('source digest')
        runtime={'dependencies':'stdlib-only','executable_sha256':blob(Path(sys.executable).read_bytes()),'implementation':sys.implementation.name,'platform':platform.platform(),'python':sys.version}
        if blob(encoded(runtime))!=m['environment_sha256'] or blob(input_bytes)!=m['input_sha256']:raise ValueError('runtime/input')
        return m
    except Exception as e:raise IdentityMismatch('EXTERNAL_IDENTITY_MISMATCH') from e
