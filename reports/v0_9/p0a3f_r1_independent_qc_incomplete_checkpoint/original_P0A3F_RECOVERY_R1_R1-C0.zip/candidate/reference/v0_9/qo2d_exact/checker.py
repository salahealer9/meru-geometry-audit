"""Original-input exact verifier: global-u polynomial integrals and direct
rotated residual. No production arithmetic, path, parser or hashing imports.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,math
from .arithmetic import Algebra,Incomplete,InvalidProof
from . import wire as strict_wire,identity as external_identity

def wire(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)
def hash_object(x):return hashlib.sha256(wire(x).encode()).hexdigest()
def fraction(a):
    if type(a) is not list or len(a)!=2 or any(type(x) is not str for x in a):raise InvalidProof('rational encoding')
    n,d=a
    def integer(s,positive):
        if not s or (s.startswith('-') and positive):raise InvalidProof('integer syntax')
        digits=s[1:] if s.startswith('-') else s
        if not digits or any(c not in '0123456789' for c in digits) or (len(digits)>1 and digits[0]=='0') or s=='-0':raise InvalidProof('integer syntax')
        return int(s)
    x,y=integer(n,False),integer(d,True)
    if y<=0 or math.gcd(abs(x),y)!=1:raise InvalidProof('canonical reduced rational')
    return F(x,y)
def parse_request(r):
    if type(r) is not dict or set(r)!={'schema','lane','authority','nuisance','paths','limits'} or r['schema']!='qo2d-request-1':raise InvalidProof('request schema')
    if r['lane']!='P0A3D_QO_2D_OPEN_RATIONAL_VERTEX_SO2_EXACT' or r['authority']!='92de104cab58339df370acf96b8d849ecc2d888b' or r['nuisance']!='SO2_ONLY':raise InvalidProof('scope')
    lim=r['limits']
    if type(lim) is not dict or set(lim)!={'max_vertices','max_input_bits','max_operations','max_coefficient_bits','max_terms','max_formal_degree','reference_max_bits'} or any(type(v) is not int or v<=0 for v in lim.values()):raise InvalidProof('limits')
    if type(r['paths']) is not list or len(r['paths'])!=2:raise InvalidProof('two paths')
    result=[]
    for p in r['paths']:
        if type(p) is not dict or set(p)!={'id','ordered','parameter_domain','endpoints','provenance','vertices'}:raise InvalidProof('path keys')
        if type(p['id']) is not str or not p['id'] or p['ordered'] is not True or p['parameter_domain']!='OPEN_INTERVAL' or p['provenance']!='INDEPENDENT_GENERIC':raise InvalidProof('ordered open generic path')
        v=p['vertices']
        ep=p['endpoints']
        if type(v) is not list or len(v)<2 or type(ep) is not list or len(ep)!=2 or any(type(i) is not int for i in ep) or ep!=[0,len(v)-1]:raise InvalidProof('vertices/endpoints')
        if len(v)>lim['max_vertices']:raise Incomplete('reference vertex cap')
        pts=[]
        for point in v:
            if type(point) is not list or len(point)!=2:raise InvalidProof('2D only')
            pp=tuple(fraction(x) for x in point)
            if any(max(abs(x.numerator).bit_length(),x.denominator.bit_length())>lim['max_input_bits'] for x in pp):raise Incomplete('reference input bit cap')
            pts.append(pp)
        result.append(pts)
    if r['paths'][0]['id']==r['paths'][1]['id']:raise InvalidProof('independent IDs')
    return result
def code_hash(root,folder):
    p=Path(root);entries=[(f.relative_to(p).as_posix(),hashlib.sha256(f.read_bytes()).hexdigest()) for f in sorted((p/folder).rglob('*.py'))]
    return hash_object(entries)
def total(t,items):
    out=t.number(0)
    for a in items:out=t.plus(out,a)
    return out
def integrate_linear(t,m,c,lo,hi):return t.plus(t.scale(t.product(m,t.minus(t.power(hi,2),t.power(lo,2))),F(1,2)),t.product(c,t.minus(hi,lo)))
def integrate_product(t,m,c,n,d,lo,hi):
    return total(t,[t.scale(t.product(t.product(m,n),t.minus(t.power(hi,3),t.power(lo,3))),F(1,3)),t.scale(t.product(t.plus(t.product(m,d),t.product(n,c)),t.minus(t.power(hi,2),t.power(lo,2))),F(1,2)),t.product(t.product(c,d),t.minus(hi,lo))])
def path(t,points):
    edges=[];zero=[]
    for i in range(len(points)-1):
        p,q=points[i:i+2];d=(q[0]-p[0])**2+(q[1]-p[1])**2
        if d==0:zero.append({'edge_index':i,'reason':'EXACT_ZERO_CONSECUTIVE_EDGE'})
        else:edges.append((i,p,q,t.root(t.number(d))))
    if not edges:raise InvalidProof('constant path cannot certify')
    length=total(t,[e[3] for e in edges]);knots=[t.number(0)];running=t.number(0)
    for e in edges:running=t.plus(running,e[3]);knots.append(t.divide(running,length))
    coeff=[]
    for k,(i,p,q,l) in enumerate(edges):
        duration=t.divide(l,length);row=[]
        for j in range(2):
            m=t.divide(t.number(q[j]-p[j]),duration);c=t.minus(t.number(p[j]),t.product(m,knots[k]));row.append((m,c))
        coeff.append(row)
    center=[total(t,[integrate_linear(t,*row[j],knots[k],knots[k+1]) for k,row in enumerate(coeff)]) for j in range(2)]
    variance=t.minus(total(t,[integrate_product(t,*row[j],*row[j],knots[k],knots[k+1]) for k,row in enumerate(coeff) for j in range(2)]),total(t,[t.product(c,c) for c in center]))
    if t.sign(variance)!=1:raise InvalidProof('reference nonpositive variance contradiction')
    radius=t.root(variance);norm=[[(t.divide(m,radius),t.divide(t.minus(c,center[j]),radius)) for j,(m,c) in enumerate(row)] for row in coeff]
    return {'norm':norm,'knots':knots,'meta':{'zero_edges':zero,'surviving_edge_indices':[e[0] for e in edges],'lengths':[e[3] for e in edges],'total_length':length,'knots':knots,'centroid':center,'variance':variance,'rms':radius}}
def reconstruct(t,pts):
    a,b=[path(t,p) for p in pts];union=[]
    # Independent insertion merge with exact comparison; no production sort.
    for x in a['knots']+b['knots']:
        at=0
        while at<len(union) and t.sign(t.minus(union[at],x))<0:at+=1
        if at==len(union) or not t.zero(t.minus(union[at],x)):union.insert(at,x)
    cells=[];alpha=t.number(0);beta=t.number(0)
    for lo,hi in zip(union,union[1:]):
        mid=t.scale(t.plus(lo,hi),F(1,2));indices=[]
        for p in (a,b):
            indices.append(next(k for k in range(len(p['norm'])) if t.sign(t.minus(mid,p['knots'][k]))>0 and t.sign(t.minus(p['knots'][k+1],mid))>0))
        x,y=a['norm'][indices[0]],b['norm'][indices[1]]
        alpha=t.plus(alpha,total(t,[integrate_product(t,*x[j],*y[j],lo,hi) for j in range(2)]))
        beta=t.plus(beta,t.minus(integrate_product(t,*x[0],*y[1],lo,hi),integrate_product(t,*x[1],*y[0],lo,hi)))
        cells.append((lo,hi,x,y))
    s=t.root(t.plus(t.product(alpha,alpha),t.product(beta,beta)));q2=t.minus(t.number(2),t.scale(s,2));q=t.root(q2)
    return a,b,union,alpha,beta,s,q2,q,cells
def check(c,expected):
    strict_wire.certificate(c)
    external_identity.verify(expected,strict_wire.canonical(c['request']))
    keys={'schema','lane','machine_state','request','request_sha256','input_sha256','backend','roots','paths','union','alpha','beta','s','q_squared','q','rotation','direct_residual','roll_state','decisions'}
    if type(c) is not dict or set(c)!=keys or c['schema']!='qo2d-exact-1' or c['machine_state']!='EXACT_THEOREM_CERTIFICATE_CANDIDATE_UNVALIDATED' or c['backend']!='positive-radical-mask-v1':raise InvalidProof('certificate schema/backend/state')
    r=c['request'];pts=parse_request(r)
    if c['lane']!=r['lane'] or c['request_sha256']!=hash_object(r) or c['input_sha256']!=[hash_object(p) for p in r['paths']]:raise InvalidProof('external input/code/config pin mismatch')
    t=Algebra(r['limits']);a,b,union,alpha,beta,s,q2,q,cells=reconstruct(t,pts)
    mapping=[]
    def decode(w):
        if type(w) is not list:raise InvalidProof('scalar terms')
        out=t.number(0);previous=-1
        for term in w:
            if type(term) is not list or len(term)!=2:raise InvalidProof('term')
            mask,rat=term
            if type(mask) is not int or mask<=previous or mask<0 or mask>=2**len(mapping):raise InvalidProof('mask order/forward root')
            previous=mask;v=fraction(rat)
            if not v:raise InvalidProof('zero coefficient is noncanonical')
            value=t.number(v)
            for i,root in enumerate(mapping):
                if mask&(1<<i):value=t.product(value,root)
            out=t.plus(out,value)
        return out
    if type(c['roots']) is not list or 2**len(c['roots'])>r['limits']['max_formal_degree']:raise InvalidProof('root count')
    for rw in c['roots']:
        x=decode(rw)
        if t.sign(x)!=1:raise InvalidProof('root positive branch')
        mapping.append(t.root(x))
    def equal(w,value):
        if not t.zero(t.minus(decode(w),value)):raise InvalidProof('EXACT_VALUE_MISMATCH')
    if type(c['paths']) is not list or len(c['paths'])!=2:raise InvalidProof('path records')
    for record,p in zip(c['paths'],(a,b)):
        m=p['meta']
        if set(record)!=set(m):raise InvalidProof('path record keys')
        for key in ('zero_edges','surviving_edge_indices'):
            if record[key]!=m[key]:raise InvalidProof('edge provenance')
        for key in ('lengths','knots','centroid'):
            if type(record[key]) is not list or len(record[key])!=len(m[key]):raise InvalidProof('path scalar count')
            for w,v in zip(record[key],m[key]):equal(w,v)
        for key in ('total_length','variance','rms'):equal(record[key],m[key])
    if len(c['union'])!=len(union):raise InvalidProof('union partition count')
    for w,v in zip(c['union'],union):equal(w,v)
    for key,v in [('alpha',alpha),('beta',beta),('s',s),('q_squared',q2),('q',q)]:equal(c[key],v)
    if t.sign(s)<0 or t.sign(t.minus(t.number(1),s))<0 or t.sign(q)<0:raise InvalidProof('range')
    state='EXACT_WHOLE_ROLL_TIE' if t.zero(s) else 'EXACT_UNIQUE_PROPER_ROTATION'
    if c['roll_state']!=state:raise InvalidProof('tie classification')
    matrix=c['rotation']
    if type(matrix) is not list or len(matrix)!=2 or any(type(row) is not list or len(row)!=2 for row in matrix):raise InvalidProof('matrix shape')
    M=[[decode(w) for w in row] for row in matrix]
    co,si=(t.number(1),t.number(0)) if t.zero(s) else (t.divide(alpha,s),t.divide(beta,s))
    for row,wanted in zip(matrix,[[co,t.negative(si)],[si,co]]):
        for w,v in zip(row,wanted):equal(w,v)
    for i in range(2):
        for j in range(2):
            entry=total(t,[t.product(M[k][i],M[k][j]) for k in range(2)])
            if not t.zero(t.minus(entry,t.number(int(i==j)))):raise InvalidProof('orthogonality')
    determinant=t.minus(t.product(M[0][0],M[1][1]),t.product(M[0][1],M[1][0]))
    if not t.zero(t.minus(determinant,t.number(1))):raise InvalidProof('properness')
    residual=t.number(0)
    for lo,hi,x,y in cells:
        for j in range(2):
            slope=t.minus(total(t,[t.product(M[j][k],x[k][0]) for k in range(2)]),y[j][0]);intercept=t.minus(total(t,[t.product(M[j][k],x[k][1]) for k in range(2)]),y[j][1])
            residual=t.plus(residual,integrate_product(t,slope,intercept,slope,intercept,lo,hi))
    equal(c['direct_residual'],residual)
    if not t.zero(t.minus(residual,q2)):raise InvalidProof('ATTAINED_RESIDUAL_CONTRADICTION')
    if type(c['decisions']) is not list:raise InvalidProof('decisions')
    expected_values={f'{label}.length[{i}]':v for label,p in zip(('a','b'),(a,b)) for i,v in zip(p['meta']['surviving_edge_indices'],p['meta']['lengths'])}
    expected_values.update({'a.variance':a['meta']['variance'],'b.variance':b['meta']['variance'],'s':s,'one_minus_s':t.minus(t.number(1),s),'s_squared_identity':t.number(0),'unit_rotation':t.number(0),'direct_residual_minus_q2':t.number(0)})
    expected_values.update({f'union.width[{i}]':t.minus(union[i+1],union[i]) for i in range(len(union)-1)})
    expected_labels=list(expected_values)
    if len(c['decisions'])!=len(expected_labels) or set(d['label'] for d in c['decisions'])!=set(expected_labels):raise InvalidProof('decision completeness')
    for d in c['decisions']:
        if set(d)!={'label','expression','sign','method'} or type(d['sign']) is not int or d['sign'] not in (-1,0,1) or d['method']!='DESCENDING_SIGN_GUARDED_SQUARING':raise InvalidProof('decision schema')
        equal(d['expression'],expected_values[d['label']])
        if t.sign(decode(d['expression']))!=d['sign']:raise InvalidProof('exact sign decision')
    return {'state':'ENGINEERING_EXACT_CERTIFICATE_CANDIDATE_UNVALIDATED','check':'ORIGINAL_INPUT_EXACT_RECOMPUTATION_AND_DIRECT_RESIDUAL','roll_state':state,'reference_backend':'dense-radical-zero-plus-rational-isolation-v1','independent_QC':'PENDING','operations':t.ops}
