"""Isolated child entry point. Private production output is not a checked result."""
import json,os,resource,signal,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
policy=json.loads((ROOT/'schemas/v0_9/p0a3e/resource_policy.json').read_bytes())
def output(obj):
    b=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
    if len(b)>policy['worker_file_bytes']:b=b'{"schema":"p0a3e-failure-1","state":"RESOURCE_INCOMPLETE","reason":"OUTPUT_BYTE_CAP"}'
    sys.stdout.buffer.write(b);sys.stdout.buffer.flush()
def main():
    for key,cap in ((resource.RLIMIT_AS,policy['worker_memory_bytes']),(resource.RLIMIT_FSIZE,policy['worker_file_bytes']),(resource.RLIMIT_NOFILE,policy['worker_open_files']),(resource.RLIMIT_CORE,0)):
        resource.setrlimit(key,(cap,cap))
    resource.setrlimit(resource.RLIMIT_CPU,(policy['worker_cpu_seconds'],policy['worker_cpu_seconds']+1));sys.setrecursionlimit(policy['recursion']);sys.set_int_max_str_digits(policy['integer_digits'])
    for folder in ('src','reference'):
        if any(p.suffix in ('.pyc','.pyo') or p.is_symlink() for p in (ROOT/folder).rglob('*')):raise RuntimeError('BYTECODE_OR_SYMLINK')
    sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
    mode,request_file,expected_file,certificate_file,fault=sys.argv[1:]
    if fault=='timeout':time.sleep(30)
    elif fault=='exit':os._exit(17)
    elif fault=='kill':os.kill(os.getpid(),signal.SIGKILL)
    elif fault=='memory':raise MemoryError('DEV_INJECTED_ALLOCATION_FAILURE')
    elif fault=='recursion':raise RecursionError('DEV_INJECTED_RECURSION_FAILURE')
    elif fault!='none':raise RuntimeError('UNKNOWN_DEV_FAULT')
    def read(path,cap):
        with open(path,'rb') as f:b=f.read(cap+1)
        if len(b)>cap:raise MemoryError('WORKER_RAW_CAP')
        return b
    raw=read(request_file,policy['request_bytes']);expected=read(expected_file,policy['document_bytes'])
    if mode=='produce':
        from meru_geometry.v0_9.qo2d_exact.wire import request
        from meru_geometry.v0_9.qo2d_exact.identity import verify,sha
        from meru_geometry.v0_9.qo2d_exact.core import execute
        r,b=request(raw);verify(expected,sha(b));output(execute(r))
    elif mode=='check':
        from reference.v0_9.qo2d_exact.service import verify
        output(verify(raw,read(certificate_file,policy['certificate_bytes']),expected))
    elif mode=='limits':
        output({'schema':'p0a3e-worker-limits-1','state':'DEV_LIMIT_OBSERVATION','pid':os.getpid(),'recursion':sys.getrecursionlimit(),'limits':{name:list(resource.getrlimit(getattr(resource,name))) for name in ('RLIMIT_AS','RLIMIT_CPU','RLIMIT_FSIZE','RLIMIT_NOFILE','RLIMIT_CORE')}})
    else:raise RuntimeError('UNKNOWN_MODE')
if __name__=='__main__':
    try:main()
    except (MemoryError,RecursionError):output({'schema':'p0a3e-failure-1','state':'RESOURCE_INCOMPLETE','reason':'WORKER_RUNTIME_LIMIT'})
    except Exception as e:output({'schema':'p0a3e-failure-1','state':'INTERNAL_ERROR_NO_CERTIFICATE','reason':type(e).__name__})
