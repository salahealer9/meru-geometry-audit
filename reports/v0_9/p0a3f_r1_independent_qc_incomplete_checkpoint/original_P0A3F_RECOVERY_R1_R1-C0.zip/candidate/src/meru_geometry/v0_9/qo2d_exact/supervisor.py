"""Bounded sequential workers; independently rechecked, atomic complete records."""
import hashlib,json,os,signal,stat,subprocess,sys,tempfile,time
from pathlib import Path
from .wire import POLICY,ROOT,Boundary,request,decode,fail
from .identity import verify,canonical,sha
SUCCESS='ENGINEERING_EXACT_CERTIFICATE_CANDIDATE_UNVALIDATED'
FAILURES={'INVALID_INPUT','NOT_EVALUABLE','CERTIFICATE_REJECTED','RESOURCE_INCOMPLETE','UNRESOLVED_EXACT_PREDICATE','CODE_IDENTITY_MISMATCH','INTERNAL_ERROR_NO_CERTIFICATE','UNKNOWN_TERMINATION'}
def bounded_file(path,cap):
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as f:
        s=os.fstat(f.fileno())
        if not stat.S_ISREG(s.st_mode):raise Boundary('INVALID_INPUT','REGULAR_FILE_REQUIRED')
        if s.st_size>cap:raise Boundary('RESOURCE_INCOMPLETE','FILE_SIZE_CAP')
        b=f.read(cap+1)
    if len(b)>cap:raise Boundary('RESOURCE_INCOMPLETE','FILE_READ_CAP')
    return b
def disk(directory):
    total=0
    for p in directory.iterdir():
        if p.is_symlink() or not p.is_file():raise Boundary('INTERNAL_ERROR_NO_CERTIFICATE','RUN_DIRECTORY_SHAPE')
        total+=p.stat().st_size
    if total>POLICY['run_disk_bytes']:raise Boundary('RESOURCE_INCOMPLETE','RUN_DISK_CAP')
def private_write(p,b):
    if len(b)>POLICY['document_bytes']:raise Boundary('RESOURCE_INCOMPLETE','OUTPUT_BYTE_CAP')
    with open(p,'xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def child(mode,directory,raw,expected,certificate=None,fault='none',events=None):
    events=events if events is not None else []
    disk(directory);token=len(list(directory.iterdir()));prefix=f'worker_{token:03}'
    req=directory/(prefix+'_request.json');exp=directory/(prefix+'_expected.json');cert=directory/(prefix+'_certificate.json');out=directory/(prefix+'_stdout.json');err=directory/(prefix+'_stderr.log')
    private_write(req,raw);private_write(exp,expected)
    if certificate is not None:private_write(cert,canonical(certificate))
    cmd=[sys.executable,'-I','-B',str(ROOT/'src/meru_geometry/v0_9/qo2d_exact/worker.py'),mode,str(req),str(exp),str(cert),fault]
    limit=POLICY['diagnostic_timeout_ms']/1000 if fault=='timeout' else POLICY['worker_wall_seconds']
    with open(out,'xb') as fout,open(err,'xb') as ferr:
        proc=subprocess.Popen(cmd,stdout=fout,stderr=ferr,start_new_session=True,env={'PATH':os.defpath,'LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONHASHSEED':'0'})
        event={'command':cmd,'wall_limit_seconds':limit,'mode':mode,'fault':fault};events.append(event)
        try:proc.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL);proc.wait();event.update(returncode=proc.returncode,controller_timeout=True)
            return fail('RESOURCE_INCOMPLETE','CONTROLLER_WALL_TIMEOUT')
    event.update(returncode=proc.returncode,controller_timeout=False,stdout_bytes=out.stat().st_size,stderr_bytes=err.stat().st_size)
    event['stdout_sha256']=sha(bounded_file(out,POLICY['worker_file_bytes']));event['stderr_sha256']=sha(bounded_file(err,POLICY['worker_file_bytes']))
    if proc.returncode<0:return fail('UNKNOWN_TERMINATION','WORKER_SIGNAL_'+str(-proc.returncode))
    if proc.returncode!=0:return fail('INTERNAL_ERROR_NO_CERTIFICATE','WORKER_NONZERO_'+str(proc.returncode))
    disk(directory)
    try:return decode(bounded_file(out,POLICY['worker_file_bytes']),POLICY['worker_file_bytes'])
    except Boundary:return fail('INTERNAL_ERROR_NO_CERTIFICATE','MALFORMED_WORKER_OUTPUT')
def context(raw,expected):
    # Source/config identity before parsing any claimed certificate.
    verify(expected);r,b=request(raw);m=verify(expected,sha(b))
    return r,b,sha(canonical({'input_sha256':sha(b),'expected_sha256':sha(canonical(m)),'service':'p0a3e-supervised-1'}))
def atomic_save(directory,record,fault='none'):
    disk(directory);b=canonical(record)
    if len(b)>POLICY['document_bytes']:raise Boundary('RESOURCE_INCOMPLETE','CHECKPOINT_OUTPUT_CAP')
    if fault=='before_write':raise Boundary('RESOURCE_INCOMPLETE','DEV_INTERRUPTED_BEFORE_WRITE')
    fd,tmp=tempfile.mkstemp(prefix='pending_',suffix='.json',dir=directory)
    with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
    if fault=='after_flush':raise Boundary('RESOURCE_INCOMPLETE','DEV_INTERRUPTED_AFTER_FLUSH')
    os.replace(tmp,directory/'checkpoint.json')
    if fault=='after_rename':raise Boundary('RESOURCE_INCOMPLETE','DEV_INTERRUPTED_AFTER_RENAME')
    fd=os.open(directory,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
    disk(directory)
def checked_record(raw,expected,certificate,directory,events):
    checked=child('check',directory,raw,expected,certificate,events=events)
    if type(checked) is not dict or checked.get('state')!=SUCCESS:
        if type(checked) is dict and checked.get('state') in FAILURES:return checked
        return fail('INTERNAL_ERROR_NO_CERTIFICATE','UNEXPECTED_CHECKER_OUTPUT')
    if checked.get('certificate_sha256')!=sha(canonical(certificate)):return fail('INTERNAL_ERROR_NO_CERTIFICATE','CHECKED_BYTES_MISMATCH')
    return checked
def run(raw,expected,directory,*,dev_fault='none',save_fault='none'):
    events=[]
    try:
        r,b,work=context(raw,expected);d=Path(directory)
        if d.exists():raise Boundary('INTERNAL_ERROR_NO_CERTIFICATE','NEW_RUN_DIRECTORY_REQUIRED')
        d.mkdir(mode=0o700,parents=False)
        cert=child('produce',d,b,expected,fault=dev_fault,events=events)
        if type(cert) is not dict:raise Boundary('INTERNAL_ERROR_NO_CERTIFICATE','WORKER_OBJECT_REQUIRED')
        if cert.get('state') in FAILURES:return {**fail(cert['state'],cert.get('reason','WORKER_FAILURE')),'worker_events':events}
        check=checked_record(b,expected,cert,d,events)
        if check.get('state')!=SUCCESS:return {**check,'worker_events':events}
        record={'schema':'p0a3e-checkpoint-1','work_identity':work,'certificate':cert,'verification':check}
        atomic_save(d,record,save_fault)
        return {'schema':'p0a3e-result-1','state':SUCCESS,'work_identity':work,'certificate':cert,'verification':check,'worker_events':events,'durable_checkpoint':'checkpoint.json'}
    except Boundary as e:return {**fail(e.state,e.reason,raw),'worker_events':events}
    except (MemoryError,RecursionError):return {**fail('RESOURCE_INCOMPLETE','CONTROLLER_RUNTIME_LIMIT',raw),'worker_events':events}
    except Exception:return {**fail('INTERNAL_ERROR_NO_CERTIFICATE','CONTROLLER_IO_OR_INTERNAL',raw),'worker_events':events}
def resume(raw,expected,directory):
    events=[]
    try:
        r,b,work=context(raw,expected);d=Path(directory);disk(d)
        record=decode(bounded_file(d/'checkpoint.json',POLICY['document_bytes']),POLICY['document_bytes'])
        if type(record) is not dict or set(record)!={'schema','work_identity','certificate','verification'} or record['schema']!='p0a3e-checkpoint-1' or record['work_identity']!=work:raise Boundary('CERTIFICATE_REJECTED','CHECKPOINT_IDENTITY_OR_STRUCTURE')
        check=checked_record(b,expected,record['certificate'],d,events)
        if check.get('state')!=SUCCESS:return {**check,'worker_events':events}
        return {'schema':'p0a3e-result-1','state':SUCCESS,'work_identity':work,'certificate':record['certificate'],'verification':check,'worker_events':events,'recovery':'COMPLETE_RECORD_RECOMPUTED'}
    except Boundary as e:return {**fail(e.state,e.reason,raw),'worker_events':events}
    except (MemoryError,RecursionError):return {**fail('RESOURCE_INCOMPLETE','RECOVERY_RUNTIME_LIMIT',raw),'worker_events':events}
    except Exception:return {**fail('INTERNAL_ERROR_NO_CERTIFICATE','RECOVERY_IO_OR_INTERNAL',raw),'worker_events':events}
