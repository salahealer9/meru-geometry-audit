"""Caller-anchored expected manifest. Proposal generation grants NO trust."""
import hashlib,json,platform,sys
from pathlib import Path
from .wire import ROOT,Boundary,decode,POLICY
PARENT='59eb47f7500d57866e4935822b78a555d3bcb515'
ARCHIVE='c2f99b0e78849de16c8dc8167bdf5d584d4f64ab2c8a787d6a0ed507cfa9f378'
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def environment():return {'python':sys.version,'implementation':sys.implementation.name,'platform':platform.platform(),'executable_sha256':sha(Path(sys.executable).read_bytes()),'dependencies':'stdlib-only'}
def files():
    out={}
    for folder in ('src','reference','schemas/v0_9/p0a3e','tests/dev_v0_9/p0a3e'):
        for p in sorted((ROOT/folder).rglob('*')):
            if p.is_symlink():raise Boundary('CODE_IDENTITY_MISMATCH','SOURCE_SYMLINK')
            if p.is_file() and p.suffix in ('.py','.json','.md'):out[p.relative_to(ROOT).as_posix()]=sha(p.read_bytes())
    return out
def proposal(input_hash):
    """For review/DEV fixture preparation only. Never called by verify to trust itself."""
    return {'schema':'p0a3e-expected-1','authority_mode':'DEV_UNFROZEN_EXPECTATIONS','protocol_commit':'c48c7a60777200a172ae3c72f5b0402162370ec7','signed_parent':PARENT,'original_archive_sha256':ARCHIVE,'files':files(),'environment_sha256':sha(canonical(environment())),'input_sha256':input_hash}
def verify(raw,input_hash=None):
    try:
        x=decode(raw,POLICY['document_bytes'])
        fields={'schema','authority_mode','protocol_commit','signed_parent','original_archive_sha256','files','environment_sha256','input_sha256'}
        if type(x) is not dict or set(x)!=fields or x['schema']!='p0a3e-expected-1' or x['authority_mode']!='DEV_UNFROZEN_EXPECTATIONS' or x['protocol_commit']!='c48c7a60777200a172ae3c72f5b0402162370ec7' or x['signed_parent']!=PARENT or x['original_archive_sha256']!=ARCHIVE:raise ValueError('authority')
        if type(x['files']) is not dict or x['files']!=files() or x['environment_sha256']!=sha(canonical(environment())):raise ValueError('code/schema/config/checker/runtime')
        h=x['input_sha256']
        if type(h) is not str or len(h)!=64 or any(c not in '0123456789abcdef' for c in h) or (input_hash is not None and input_hash!=h):raise ValueError('input')
        return x
    except Exception as e:raise Boundary('CODE_IDENTITY_MISMATCH','EXTERNAL_EXPECTATION_MISMATCH') from e
