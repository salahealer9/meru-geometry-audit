"""R1 fresh read-only provenance intake. No archived code execution."""
from pathlib import Path,PurePosixPath
import urllib.request,concurrent.futures,json,hashlib,subprocess,zipfile,stat,ast,os,datetime
R=Path(__file__).resolve().parent;I=R/'intake';B='https://api.github.com/repos/salahealer9/meru-geometry-audit/'
CHAIN='83b9e6dcd53b100c5ac8b081832e81659cd1884a 1d38ea6f53b9266d853df887a66331c59e4fc3ae 8ed3b988f716229bc9aee97d41ded0f524371193 c48c7a60777200a172ae3c72f5b0402162370ec7 59eb47f7500d57866e4935822b78a555d3bcb515 92de104cab58339df370acf96b8d849ecc2d888b 923bab7855deaee6be49dd299bbdb0d6251844c1 01270ec3bff3c9a6352c5dadc90d5d9f12da0c0d 8adbc226b1ef7234a9bedab02ca515a6c11e5c4f 2425db592e80d5f688adc0facdea9e1042c05cdb 07b64003940072e00fb2ce969ebc3866a9a3dc4d e917fa2974997703d6ccb60b0b25d0c668d12bd5 090a1db6c95976bbb5f0d69a3cc4a4603d165505 5b0317f193c481d799e88b494ce370679fec43bc 5148712c07ac48742d3435dc14e01667280f94c3 24c00fc44e4d9d57adacd1e636e9e2d20d86a954 d15865167b4e3c454e398bd498d9d681103096f7'.split()
SIGNER='D4EC014EEFCC90E619D2AA59A91239ABCF512130'
def log(x):print(datetime.datetime.now(datetime.timezone.utc).isoformat(),x,flush=True)
def digest(b):return hashlib.sha256(b).hexdigest()
def git(b,t='blob'):return hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def fetch(url,name):
 p=I/name
 if p.exists():return p.read_bytes()
 b=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'P0A3F-R1-provenance'}),timeout=60).read();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return b
def api(path,name):return json.loads(fetch(B+path,name))
def many(f,items):
 with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:return list(ex.map(f,items))
log('fetch signed commit objects')
cs=many(lambda s:api('git/commits/'+s,'commits/'+s+'.json'),CHAIN)
for i,c in enumerate(cs):
 v=c['verification'];assert c['sha']==CHAIN[i] and v['verified'] and v['reason']=='valid'
 if i+1<len(cs):assert [x['sha'] for x in c['parents']]==[CHAIN[i+1]]
 head,body=v['payload'].split('\n\n',1);raw=(head+'\ngpgsig '+v['signature'].rstrip('\n').replace('\n','\n ')+'\n\n'+body).encode();assert git(raw,'commit')==CHAIN[i]
 (I/'commits'/f'{CHAIN[i]}.payload').write_text(v['payload']);(I/'commits'/f'{CHAIN[i]}.asc').write_text(v['signature'])
log('commit hashes and consecutive parents match; fetch scope and tree')
scopes=many(lambda s:api('commits/'+s,'scope_'+s+'.json'),CHAIN[:3])
amend='docs/v0_9/p0a3f_evidence_loss_recovery_amendment_2026_10_21.md'
original='docs/v0_9/p0a3f_exact_2d_qo_runtime_external_trust_and_fail_closed_recovery_qualification_protocol.md'
incident='reports/v0_9/p0a3f_evidence_loss_incident/'
assert {x['filename'] for x in scopes[0]['files']}=={amend,incident+'original_P0A3F_EVIDENCE_LOSS_INCIDENT_2026-10-21.zip',incident+'INCIDENT_AND_AMENDMENT_MANIFEST.sha256'}
assert all(x['status']=='added' for x in scopes[0]['files'])
assert len(scopes[1]['files'])==1 and scopes[1]['files'][0]['filename']==original and scopes[1]['files'][0]['status']=='added'
assert len(scopes[2]['files'])==7 and all(x['status']=='added' and x['filename'].startswith('reports/v0_9/p0a3e_incomplete_checkpoint/') for x in scopes[2]['files'])
tree=api('git/trees/'+cs[0]['tree']['sha']+'?recursive=1','tree.json');assert not tree['truncated'];entries={x['path']:x for x in tree['tree']}
pins={original:'9530a75d2346752a093367aeac24e13c5d2d6fac',amend:'9fd9fba6ca509e3fcb72c2227d226847d218b354','reports/v0_9/p0a3e_incomplete_checkpoint/P0A3E_INCOMPLETE_SOFTWARE_PRESERVATION_CLOSEOUT.md':'2084ae570ef487a06b4fdf339a19c39456bf4a57','reports/v0_9/p0a3e_incomplete_checkpoint/P0A3E_NEXT_P0A3F_SOFTWARE_QUALIFICATION_PLAN.md':'c23d0a6ed40bb964fbb3ac553754b2a62a8f9cd0','reports/v0_9/p0a3e_incomplete_checkpoint/P0A3E_independent_software_QC_report_2026-10-20.md':'5cacc87e6ea320598fc79ece3607588d91734a4c','reports/v0_9/p0a3d_theorem_result_freeze/P0A3D_ORIGINAL_THEOREM_PROOF.md':'88c3b1158e34b60aab948e4e0f3b5cd0899f3173','reports/v0_9/p0a2_target_blind_design/score_normalization_candidates.md':'c848a6bf28471184efb9bf61ae1bd5a0e35933aa','reports/v0_9/p0a2_target_blind_design/numerical_error_failure_ledger.md':'21c4a6dfec35b90a35c36e35ceac508561f552a9'}
for p,h in pins.items():assert entries[p]['sha']==h
prefixes=['reports/v0_9/p0a3e_incomplete_checkpoint/','reports/v0_9/p0a3d_theorem_result_freeze/',incident]
paths=sorted(set(pins)|{p for p,x in entries.items() if x['type']=='blob' and any(p.startswith(s) for s in prefixes)})
def raw(p):
 b=fetch('https://raw.githubusercontent.com/salahealer9/meru-geometry-audit/'+CHAIN[0]+'/'+p,'files/'+p);assert git(b)==entries[p]['sha'];return {'path':p,'git_blob':git(b),'sha256':digest(b),'bytes':len(b)}
records=many(raw,paths);(I/'retrieved_files.json').write_text(json.dumps(records,indent=2))
for p in (I/'files').rglob('*.sha256'):
 for line in p.read_text().splitlines():
  if not line.strip():continue
  h,n=line.split(None,1);assert digest((I/'files'/n.lstrip('* ')).read_bytes())==h
log('pinned source blobs and preservation manifests match; verify GPG')
fetch('https://github.com/salahealer9.gpg','signer_public_key.asc');gh=R/'verification_keyring';gh.mkdir(mode=0o700,exist_ok=True)
def gpg(args):
 cmd=['gpg','--homedir',str(gh),'--batch',*args];p=subprocess.run(cmd,capture_output=True,text=True);return {'command':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
imp=gpg(['--import',str(I/'signer_public_key.asc')]);(I/'gpg_import.json').write_text(json.dumps(imp,indent=2))
checks=[]
for s in CHAIN:
 r=gpg(['--status-fd','1','--verify',str(I/'commits'/f'{s}.asc'),str(I/'commits'/f'{s}.payload')]);checks.append({'commit':s,**r});assert r['returncode']==0 and 'VALIDSIG '+SIGNER+' ' in r['stdout']
ref=api('git/ref/tags/v0.8.0','v08_ref.json');tag=api('git/tags/'+ref['object']['sha'],'v08_tag.json');v=tag['verification'];assert v['verified'] and git((v['payload']+v['signature']).encode(),'tag')==ref['object']['sha']
(I/'tag.payload').write_text(v['payload']);(I/'tag.asc').write_text(v['signature']);r=gpg(['--status-fd','1','--verify',str(I/'tag.asc'),str(I/'tag.payload')]);checks.append({'tag':'v0.8.0',**r});assert r['returncode']==0 and 'VALIDSIG '+SIGNER+' ' in r['stdout']
(I/'gpg_verifications.json').write_text(json.dumps(checks,indent=2))
comp=api('compare/'+tag['object']['sha']+'...'+CHAIN[-1],'v08_p0a0_ancestry.json');assert comp['merge_base_commit']['sha']==tag['object']['sha']
log('17 commit signatures and v0.8 tag verified; inspect archives')
expected={'original_P0A3E_cumulative_implementation_candidate.zip':('1e73c2685bd4eb8fba89e4e8ea609e97c7b4716805e83c64af374a4265522ea8',968965),'original_P0A3E_independent_QC_review_2026-10-20.zip':('6fd796d3eb99eb78191b7a3219ad557627012871d5c20c2ee504981160da3961',21497),'original_P0A3D_cumulative_proof_and_implementation_candidate.zip':('c2f99b0e78849de16c8dc8167bdf5d584d4f64ab2c8a787d6a0ed507cfa9f378',642047),'original_P0A3D_independent_QC_review_2026-10-20.zip':('4da72ab4a3347cad19e746f42ae9799f6e410a97ceb8972ad74530e6723c1e20',7893),'original_P0A3F_EVIDENCE_LOSS_INCIDENT_2026-10-21.zip':('8048fdf7c56d82b8f560f98cd7b40bea99eb66837ef1e7be49934a4d1303f88d',6842)}
archives={};verified=[]
for p in (I/'files').rglob('*.zip'):
 b=p.read_bytes();assert (digest(b),len(b))==expected[p.name];z=zipfile.ZipFile(p);names=z.namelist();assert len(names)==len(set(names))
 for x in z.infolist():
  n=PurePosixPath(x.filename);assert not n.is_absolute() and '..' not in n.parts and '\\' not in x.filename and not stat.S_ISLNK(x.external_attr>>16)
 assert z.testzip() is None
 row={'file':p.relative_to(I).as_posix(),'sha256':digest(b),'bytes':len(b),'entries':len(names),'CRC':'PASS','safe':True}
 if 'SHA256SUMS' in names:
  seen=[]
  for line in z.read('SHA256SUMS').decode().splitlines():
   h,n=line.split(None,1);n=n.lstrip('* ');assert digest(z.read(n))==h;seen.append(n)
  assert set(seen)==set(names)-{'SHA256SUMS'};row['manifest_verified']=len(seen)
 if 'PACKAGE_INVENTORY.json' in names:
  inv=json.loads(z.read('PACKAGE_INVENTORY.json'));payload=inv['payload_files'];assert {x['path'] for x in payload}==set(names)-{'SHA256SUMS','PACKAGE_INVENTORY.json'}
  for x in payload:
   b=z.read(x['path']);assert len(b)==x['bytes'] and digest(b)==x['sha256']
  row['inventory_verified']=len(payload)
 archives[p.name]=z;verified.append(row)
e=archives['original_P0A3E_cumulative_implementation_candidate.zip'];d=archives['original_P0A3D_cumulative_proof_and_implementation_candidate.zip']
kernels=['src/meru_geometry/v0_9/qo2d_exact/algebra.py','src/meru_geometry/v0_9/qo2d_exact/core.py','reference/v0_9/qo2d_exact/arithmetic.py']
for n in kernels:assert e.read(n)==d.read(n)
assert d.read('reports/v0_9/p0a3d_exact_qo_core/THEOREM_PROOF.md')==(I/'files/reports/v0_9/p0a3d_theorem_result_freeze/P0A3D_ORIGINAL_THEOREM_PROOF.md').read_bytes()
history=[]
for phase,z,count in [('D',d,4),('E',e,2)]:
 for i in range(1,count+1):
  stem=f'P0A3{phase}_DEV_{i:02d}';n=next(n for n in z.namelist() if n.endswith(stem+'_result.json'));result=json.loads(z.read(n))
  for suffix,key in [('_stdout.log','stdout_sha256'),('_stderr.log','stderr_sha256'),('_evidence.json','evidence_sha256')]:
   match=next(n for n in z.namelist() if n.endswith(stem+suffix));assert digest(z.read(match))==result[key]
  history.append({'attempt':stem,'result':result})
q=archives['original_P0A3E_independent_QC_review_2026-10-20.zip']
for n in q.namelist():
 p=I/'qc_transcripts'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(q.read(n))
for n in e.namelist():
 if n.startswith(('src/','reference/','schemas/','tests/')):
  p=R/'candidate'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(e.read(n))
inventory=[];imports=[]
for p in sorted((R/'candidate').rglob('*')):
 if not p.is_file():continue
 n=p.relative_to(R/'candidate').as_posix();inventory.append({'path':n,'sha256':digest(p.read_bytes()),'bytes':p.stat().st_size,'frozen_math':n in kernels})
 if p.suffix=='.py':
  for node in ast.walk(ast.parse(p.read_bytes())):
   if isinstance(node,ast.Import):imports.extend({'file':n,'import':x.name} for x in node.names)
   elif isinstance(node,ast.ImportFrom):imports.append({'file':n,'import':'.'*node.level+(node.module or '')})
for n,obj in [('archive_verification.json',verified),('baseline_inventory.json',inventory),('baseline_import_graph.json',imports),('historical_dev_verified.json',history)]: (I/n).write_text(json.dumps(obj,indent=2))
state={'lane':'P0A3F_RECOVERY_R1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commits':CHAIN,'tree':cs[0]['tree']['sha'],'tag':ref['object']['sha'],'tag_target':tag['object']['sha'],'local_GPG':'17 detached commit signatures and tag verified with public key matched to user-pinned fingerprint; no ownertrust assignment or private keys','older_ancestry':'v0.8 ancestor confirmed through GitHub merge-base, not a signature walk of every intermediate pre-P0A0 commit','kernels':{n:digest(e.read(n)) for n in kernels},'incident':'INCIDENT_REPORT_FROM_TRANSCRIPT; not recovered DEV','source':'untouched verified P0A3E archive','DEV':'NOT_RUN','durable_C0':'PENDING'}
(I/'F0_VERIFIED.json').write_text(json.dumps(state,indent=2));log('F0 integrity verification complete; C0 not yet persisted')
