# P0A3F_RECOVERY_R1 — Signed-Amendment Work Execution Handoff

**Project:** Meru Geometry Audit — v0.9 Hebrew Projection Capacity  
**Repository:** `salahealer9/meru-geometry-audit`  
**Branch:** `hebrew-projection-capacity-v0.9`  
**Prepared:** 2026-10-21  
**Purpose:** Execute the *already authorized* narrow P0A3F recovery amendment in a **new ChatGPT Work conversation**. This handoff is not a scientific protocol, signature, code-freeze decision, or independent qualification report.

## Immediate instruction to the Work agent

Execute **`P0A3F_RECOVERY_R1 — Exact 2D QO Runtime, External Trust and Fail-Closed Recovery Qualification`** as a **fresh, prospectively locked engineering execution** from the byte-verified, human-signed **P0A3E** cumulative implementation baseline. Follow original P0A3F stages **F0–F7 in registered order**, with every additional restriction and durable evidence checkpoint mandated by the later signed P0A3F evidence-loss amendment. **Do not resume, reconstruct, or relabel the lost original P0A3F development source or test evidence.**

**NO COMMIT. NO PUSH. NO WRITES TO THE EXISTING GIT CHECKOUT. NO P0A4. NO HISTORICAL HEBREW TARGETS. NO SELF-CERTIFICATION.**

If any required provenance or durable preservation step cannot be independently completed, **STOP and report incomplete**, retaining the most recent verified checkpoint. Never continue a DEV sequence solely in an ephemeral environment.

## A. Exact immutable authority pins

1. **Newest signed recovery amendment commit:** `83b9e6dcd53b100c5ac8b081832e81659cd1884a` — *Preserve P0A3F evidence loss and preregister recovery amendment*.
2. **Required direct parent:** `1d38ea6f53b9266d853df887a66331c59e4fc3ae` — the human-signed original P0A3F, one-file preregistration.
3. **Recovery amendment path:** `docs/v0_9/p0a3f_evidence_loss_recovery_amendment_2026_10_21.md`.
4. **Exact recovery amendment Git blob:** `9fd9fba6ca509e3fcb72c2227d226847d218b354`.
5. **Original P0A3F protocol path:** `docs/v0_9/p0a3f_exact_2d_qo_runtime_external_trust_and_fail_closed_recovery_qualification_protocol.md`.
6. **Exact original protocol Git blob:** `9530a75d2346752a093367aeac24e13c5d2d6fac`.
7. **Original P0A3F protocol direct parent / signed P0A3E incomplete preservation:** `8ed3b988f716229bc9aee97d41ded0f524371193`.
8. **Signed P0A3D positive exact-theorem result freeze:** `59eb47f7500d57866e4935822b78a555d3bcb515`.
9. **Expected human signing-key fingerprint:** `D4EC014EEFCC90E619D2AA59A91239ABCF512130`.

Retrieve the **complete original protocol and complete recovery amendment directly from GitHub**, at the pinned commits, **before doing any engineering**. Independently verify the true commit, parent, Git blobs, exact three-file *additive* scope of the new recovery commit, GPG signature identity, P0A0–P0A3F predecessor chain, applicable signed v0.8 tag, and signed P0A3D/E records. Distinguish (1) GitHub signature-attestation metadata, (2) trusted local `git verify-commit --raw` evidence, and (3) an unsigned working ZIP checksum. Do not infer that one substitutes for another. **No branch reset, forced update, historical file edits or signing is authorized.**

The signed amendment file may still bear the historical words **“HUMAN-SIGNING CANDIDATE”** in its heading. This was candidate text before signing and is not permission to edit the now-signed blob.

GitHub paths to inspect:

- `https://github.com/salahealer9/meru-geometry-audit/commit/83b9e6dcd53b100c5ac8b081832e81659cd1884a`
- `https://github.com/salahealer9/meru-geometry-audit/blob/83b9e6dcd53b100c5ac8b081832e81659cd1884a/docs/v0_9/p0a3f_evidence_loss_recovery_amendment_2026_10_21.md`
- `https://github.com/salahealer9/meru-geometry-audit/blob/1d38ea6f53b9266d853df887a66331c59e4fc3ae/docs/v0_9/p0a3f_exact_2d_qo_runtime_external_trust_and_fail_closed_recovery_qualification_protocol.md`

## B. Preserve the original incident as historical *transcript-derived* evidence only

**Signed incident path:** `reports/v0_9/p0a3f_evidence_loss_incident/original_P0A3F_EVIDENCE_LOSS_INCIDENT_2026-10-21.zip`.

**Original incident ZIP size:** 6,842 bytes.  
**Expected SHA-256:** `8048fdf7c56d82b8f560f98cd7b40bea99eb66837ef1e7be49934a4d1303f88d`.  
**Signed outer manifest:** `reports/v0_9/p0a3f_evidence_loss_incident/INCIDENT_AND_AMENDMENT_MANIFEST.sha256`.  
**Expected manifest entries:** amendment SHA-256 `3c1cbe3e2b1c3b7a35abd722e426351220e4eb0e36a30d9dd78a78f9074140c1`; incident ZIP SHA-256 above.

Verify size/hash, ZIP path safety and CRC, internal self-exception manifest rules, and the five internal non-self identities. Preserve the exact original ZIP, not a re-created approximation. The earlier account was **not independently reexecuted or authenticated from retained DEV bytes**:

- Lost original attempt: `P0A3F_DEV_01`, reportedly a **26-method** prospective catalogue.
- Reported: methods 1–22 passed; method 23, `test_23_torn_stale`, subcase `saved_verdict_ignored`, failed.
- Reported checker: `RESOURCE_INCOMPLETE` / `CONTROLLER_WALL_TIMEOUT`, return code `-9` after the recorded **eight-second** deadline; no required independently checked complete certificate.
- Missing: original P0A3F source snapshot, complete raw original DEV logs, exact original catalogue/test bytes, and original worker failure artifact. The root cause of the checker stall remains **unknown**.
- No valid retrospective pass is permitted. Do not promote the 22 reported passes into verified DEV acceptance evidence; do not claim exhaustive backup searches.

Maintain permanent, separate historical statuses:

- `P0A3F_DEV_01_EVIDENCE_UNAVAILABLE`
- `P0A3F_DEV_01_RECORDED_FAIL_NOT_QUALIFIED`
- `P0A3F_EVIDENCE_LOSS_STOP_AND_QUARANTINE`

Label the incident account **`INCIDENT_REPORT_FROM_TRANSCRIPT`**, not an original recovered or rerun test log. The signed amendment creates only a **new execution lane** named `P0A3F_RECOVERY_R1`. New attempts must be `P0A3F_R1_DEV_01`, `P0A3F_R1_DEV_02`, etc., and must be explicitly described as new independently recreated engineering work.

## C. Immutable positive and incomplete predecessor baselines

**P0A3D theorem status:** `P0A3D_EXACT_2D_QO_THEOREM_INDEPENDENTLY_VERIFIED` (the signed abstract theorem), not executable-software qualification and not historical Hebrew specificity.

Its precise domain: two independently supplied, genuinely ordered, finite, **open 2D polygonal paths** with rational-coordinate vertices; **true planar arclength** parameterization; independent centroid/RMS normalization; nuisance group **proper rotations `SO(2)` only**. For normalized paths `A,B`, `J(x,y)=(-y,x)`:

- `alpha = integral_0^1 B · A du`;
- `beta = integral_0^1 B · J(A) du`;
- `s = +sqrt(alpha^2 + beta^2)`;
- `qO = +sqrt(2 - 2s)`;
- for exact `s>0`, unique optimal proper rotation `[[alpha/s, -beta/s], [beta/s, alpha/s]]`;
- for exact `s=0`, all rotations tie and the canonical witness is the identity.

The theorem permits irrational arclength segment lengths from rational coordinates and concerns *unlimited exact arithmetic*, not finite-time completion on every input.

**P0A3D original candidate:** size **642,047 bytes**, SHA-256 `c2f99b0e78849de16c8dc8167bdf5d584d4f64ab2c8a787d6a0ed507cfa9f378`; verify original theorem, QC and historical DEV records as required by the original protocol.

**P0A3E original cumulative candidate:** `reports/v0_9/p0a3e_incomplete_checkpoint/original_P0A3E_cumulative_implementation_candidate.zip`, size **968,965 bytes**, SHA-256 `1e73c2685bd4eb8fba89e4e8ea609e97c7b4716805e83c64af374a4265522ea8`, **303 entries**, ZIP CRC PASS, 302/302 `SHA256SUMS` and 301/301 inventory entries. Independently recheck all identities before extraction.

**P0A3E original independent QC archive:** `reports/v0_9/p0a3e_incomplete_checkpoint/original_P0A3E_independent_QC_review_2026-10-20.zip`, SHA-256 `6fd796d3eb99eb78191b7a3219ad557627012871d5c20c2ee504981160da3961`.

P0A3E status remains `P0A3E_SOFTWARE_IMPLEMENTATION_INCOMPLETE`. Its historical failed DEV_01 and successful DEV_02 (32/32 on `/usr/bin/python3`), and **both** independent QC transcripts (including incompatible `/opt/pyvenv/bin/python`, 5-pass/1-fail, versus successful `/usr/bin/python3`) are immutable. They do not qualify the candidate for production use.

**Mathematical kernels that MUST remain byte-identical** to signed P0A3D throughout the isolated R1 work:

- `src/meru_geometry/v0_9/qo2d_exact/algebra.py`
- `src/meru_geometry/v0_9/qo2d_exact/core.py`
- `reference/v0_9/qo2d_exact/arithmetic.py`

If a *mathematically false exact certificate* is accepted, a kernel defect is found, or a mathematical contradiction is encountered, preserve a minimal counterexample and STOP/QUARANTINE. Do not silently repair a frozen kernel. The valid exact theorem remains distinct from any implementation defect.

Historical v0.8 outcome also remains: `NO_REPRODUCIBLE_PUBLISHED_FIRST_HAND_CONSTRUCTION_RECOVERED`. Historical source/rights/observation/order and fair candidate/null gates remain open.

## D. New non-negotiable **durable** checkpoints

A Work temporary directory **must never be the only surviving copy** of newly developed source or DEV evidence. Use a user-accessible persistent Library or equivalent independent durable storage; after each upload or saved checkpoint, **independently verify destination existence, exact byte size and SHA-256, preferably by retrieval or a verified destination metadata record**. The appearance of a link, chat filename, pending upload or locally produced ZIP is insufficient.

**R1-C0 — Before proceeding beyond F0, and before development/DEV:** preserve a dated checked baseline: signed lineage, frozen source/archive verification, incident ZIP verification, read-only Git-worktree state, vetted extracted P0A3E starting files and hash manifest, interpreter environment, F0/requirements/scope matrix, prohibition list and chosen persistence destination. Verify durable identity and retrieval *before* proceeding.

**R1-C1 — After isolated development but before *any* DEV:** preserve the *actual* source/reference/worker/checker/parser/schema/config code bytes and full diffs, code/test hashes, exact prospective catalogue/fixtures/expected results, selected interpreter and complete registered resource, checker/worker and timeout budget envelope, caller-owned expected trust interface and hard-stop rules. Verify durability *before* first new DEV attempt.

**R1-C2+ — After every DEV attempt OR distinct code repair:** preserve complete original stdout, stderr, exit/return codes, test inputs, raw worker/supervisor/checker artifacts, timeouts/crashes, failure records, snapshots, test/source/config hashes and exact repairs/diffs. Create a new non-overwriting, monotonically identified checkpoint and verify persistence *before* modifying code again or starting another attempt. Negative evidence must survive alongside repaired versions.

**R1-CFINAL — Cumulative release:** include all actual new source, checker, tests, chronological DEV snapshots, incident reference, requirements/disposition ledgers and all the original F6-required artifacts in one consistent candidate ZIP with a verified member inventory, SHA-256 manifest and exact byte sizes. Independently retrieve and verify its delivered copy *before* making any candidate-delivered claim.

**If durable saving or identity confirmation fails: STOP and report `P0A3F_R1_SOFTWARE_QUALIFICATION_INCOMPLETE`.** Return the identity and location of the **last confirmed** checkpoint, with a precise incomplete ledger; do not continue an extended ephemeral work session or promise delivery later. Favor early C0/C1 over optional broad DEV work.

All R1 checkpoints are **unsigned engineering evidence**, not a substitute for human code signing or independent QC. Neither this handoff nor an unsigned Work deliverable can authenticate itself as external code authority.

## E. Exact F0–F7 execution order and acceptance obligations

### F0 — Provenance, safe isolation and prospective acceptance lock

Read complete signed inputs. Verify actual Git identities/GPG evidence; P0A3D/E archives, CRC, manifest and inventory; original DEV and both QC histories; signed theorem/source definitions. Safely inspect and extract only vetted paths into a new isolated workspace **outside the live repository**, without executing archive contents during inspection. Inventory baseline-to-revised hashes, source import graph, OS/architecture/kernel/Python/stdlib/dependencies/resolved interpreter/limits and startup memory footprint. Establish F1–F4 requirements, transform exclusions, typed statuses, trust assumptions and stop conditions. **Create, persist and verify R1-C0 before engineering.** The original F0 prospective lock must be complete before DEV.

### F1 — Externally anchored source and loaded-runtime trust

Define a versioned, strict canonical, caller-owned **expected identity** manifest, pinned to the human-signed source/code parent and individual SHA-256 identities for producer, reference checker, parser, schemas, configuration, policy and deterministic dependencies; separately anchor canonical input and output/certificate identities. No certificate may be accepted unless the **external** expected manifest is validated first. Prospectively test missing/wrong parent/version/source/checker/schema/config/input, unsigned/untrusted manifests, forged signers, and loaded-code versus disk mismatches; no score or completed certificate on failures. Preserve the difference between DEV injected *trusted fixtures* and a future genuinely human-signed code-freeze manifest. Explicitly disclose time-of-check/time-of-use, in-memory code, symlink/filesystem and runtime attestation limitations. Unproven loaded-byte identity is `P0A3F_LOADED_CODE_IDENTITY_UNVERIFIED` or the scoped trust failure; never self-certify.

### F2 — Reproducible interpreter and bounded resource envelope

Measure and pin the **same actual Python interpreter/import profile** used in DEV: executable realpath/hash when accessible, version, implementation, platform, kernel, dependency/environment identities and startup `VmSize`/`VmRSS` or supported equivalents; record unknown observations honestly. Preflight compatible startup address-space with declared safety margin and unmodified operational thresholds. Enforce independently supplied input-byte, digit, recursion, process, wall/CPU/memory, output/checkpoint/disk and checker budgets as early as feasible; disclose which enforcement is OS/cgroup/supervisor versus best effort. Prospectively test both compatible execution and fail-closed incompatible footprint. Never substitute interpreters or inflate caps after seeing outcomes. `ENVIRONMENT_UNQUALIFIED` / `RESOURCE_INCOMPLETE` carry **no score**.

### F3 — Producer/checker supervision, interrupted-write and recovery

Bind immutable run identity to input, external expected source/checker identities, schema/config, selected interpreter and resource limits. Supervise producer and **independent checker** processes, distinguish actual versus simulated faults, and preserve termination observations. Implement bounded **single-writer atomic completion**: temporary file on same filesystem; flush/fsync; atomic rename; directory fsync where available; new process independently rechecks final bytes, caller expectation, request identity and exact witness after recovery. Reject stale/partial/torn/temp files, cached check-verdict authority and mismatched identities. Prospectively test before-write, after-flush, before-rename, after-rename/before-directory-fsync, post-rename, worker kill/timeout and restart boundaries where supported. Disclose power-loss, kernel, filesystem and multi-writer exclusions. Never promote a timed-out checker to checked completion.

**Mandatory incident-responsive prospective case:** a genuine **valid persisted certificate with a stale/saved verification verdict**, which must undergo *fresh independent checker verification before completion*. Test both (1) successful independently checked completion inside a **prospectively declared supported operational envelope**, and (2) real timeout/interruption correctly failing closed. **A correct timeout status does not substitute for case (1).** Preserve original eight-second failure prominently; if the *new* checker wall bound differs, justify and freeze it **before** any R1 DEV run. Do not infer the root cause of the original failure.

### F4 — Strict raw-input grammar and independent reference checker

Require bounded raw bytes/streams before full materialization, strict UTF-8/canonical JSON, duplicate-key and NaN/Infinity rejection, correct Python `bool` versus `int` handling, deterministic canonical rational grammar, positive roots/order, finite schema/depth/digit/vertex bounds, no hidden traversal changes, and no hashing of rejected inputs as canonical accepted data. Bound worker outputs and nested certificate processing. Independently reconstruct original ordered paths, zero-edge provenance, true-arclength union knots, centroid/RMS, correlations, proper-rotation witness and **direct integrated residual**. Reject wrong knots, dependent radical representation tricks, forged ties, malformed tower refs, nonoptimal but valid proper rotations, unknown/duplicate fields and certificate/source identity forgery. The reference checker may not use production numerical modules it purports to verify. Disclose shared runtime/Fraction assumptions and unprotected internal APIs; errors/resource exhaustion must never emit success.

### F5 — Frozen generic DEV catalogue and chronological attempts

**Before first DEV**, save the actual `P0A3F_R1_DEV_CASES_PREDECLARED.md`: exact list and count of NEW generic cases/fixtures, constructors, identities and expected exact or typed-negative outcomes; interpreter/startup preflight; relevant source/test/schema/config hashes; wall, CPU, memory, output, digit, recursion, disk and worker/checker budgets; fault-injection status; commands, expected status taxonomy and stop rules. This is **not** a reconstruction of the lost historical 26-case catalogue. It is not P0A4 or historical target selection. After durable R1-C1 verification, execute bounded generic DEV, numbered `P0A3F_R1_DEV_01` onward. Preserve all failures, entire stdout/stderr, inputs, process observations, source snapshots and complete diffs. Each repair produces a new numbered attempt under the *already predeclared* cases and limits; changed acceptance envelopes require explicit prospective authorization, not post hoc passing. Persist each R1-C2+ before any further changes/tests.

### F6 — Cumulative candidate for **independent QC**, not self-approval

Package a portable unsigned R1 candidate with at least the full original P0A3F F6 output set, including:

- Four design/contract documents: exact 2D QO runtime/resource; external trust/code manifest; atomic recovery/host failure; **future registered target-free validation DESIGN ONLY**.
- Full `src/meru_geometry/v0_9/qo2d_exact/` and `reference/v0_9/qo2d_exact/`, with three P0A3D kernels demonstrably byte-identical.
- Proposed versioned `schemas/v0_9/p0a3f/` and `tests/dev_v0_9/p0a3f/`.
- F0–F7 requirements/decisions matrix; `BASELINE_TO_REVISED_HASH_AND_DIFF.csv` and unified diffs.
- Exact preregistered R1 DEV catalogue and fixture identities, all numbered attempts/logs/source snapshots and `DEV_EXECUTION_CHRONOLOGY.log`.
- Interpreter/preflight report, external trust ledger, process fault/recovery evidence, raw boundary/adversarial checker audit, production/reference dependency and trust matrix, information-barrier/source-provenance ledger.
- **Unfilled** independent QC checklist and honest final engineering disposition.
- R1-C0/C1/C2+ evidence and verified checkpoint references; reference to the original incident ZIP explicitly labelled transcript-derived.
- ZIP-root `README.md`, `PACKAGE_INVENTORY.json`, `SHA256SUMS` with normal self-hash exception, exact byte sizes and full member identities.

No private keys, unwanted binaries, symlinks, ZIP traversal/duplicate paths, Hebrew content, nonfinite JSON values, or selectively discarded failures. Identify claims as `[FROZEN THEOREM]`, `[IMPLEMENTED_UNVERIFIED]`, `[DEV_CHECKED_ONLY]`, `[REFERENCE_RECOMPUTED_DEV]`, `[INDEPENDENT_QC_PENDING]`, `[UNRESOLVED]`, or `[DEFERRED]`. **Independently retrieve and verify R1-CFINAL** before claiming the candidate is delivered.

### F7 — Independent-evidence-limited disposition

State **separate explicit decisions for F1, F2, F3, F4**, plus scoped evaluation of (i) abstract theorem, (ii) software arithmetic, (iii) independent reference checker, (iv) external expected trust and loaded-byte attestation, (v) interpreter compatibility, (vi) crash/recovery, (vii) input/certificate security, (viii) bounded R1 DEV, (ix) registered numerical validation. Document host restrictions and all remaining unqualified conditions. A DEV pass count is not formal software proof, source authenticity, or real filesystem power-loss qualification.

Allowed overall outputs, as supported by evidence:

- `P0A3F_R1_ENGINEERING_CANDIDATE_SUBMITTED_FOR_QC` **only** after full independently verified R1-CFINAL delivery, otherwise
- `P0A3F_R1_SOFTWARE_QUALIFICATION_INCOMPLETE` with last durable checkpoint and blockers.
- Retain `P0A3F_DEV_01_EVIDENCE_UNAVAILABLE` permanently.
- Retain `P0A3F_REGISTERED_VALIDATION_NOT_RUN`.
- Use scoped original P0A3F negative findings where warranted, e.g. `P0A3F_EXTERNAL_TRUST_ANCHOR_UNQUALIFIED`, `P0A3F_LOADED_CODE_IDENTITY_UNVERIFIED`, `P0A3F_INTERPRETER_ENVIRONMENT_UNQUALIFIED`, `P0A3F_RESOURCE_CRASH_ENVELOPE_INCOMPLETE`, `P0A3F_INPUT_FAILURE_ENVELOPE_INCOMPLETE`, `P0A3F_REFERENCE_INDEPENDENCE_UNQUALIFIED`.

**Never grant** `P0A3F_EXACT_2D_QO_SOFTWARE_CANDIDATE_READY_FOR_REGISTERED_TARGET_FREE_VALIDATION` or `GLOBAL_CERTIFIED` in Work. They are not authorized outcomes. The former requires later **separate substantive independent QC, then a separate human GPG-signed code-only freeze** of the actual code/checker/schema/config/environment and externally expected source identity.

## F. Fail-closed hard stops and information barrier

Immediate STOP/QUARANTINE for wrong signed source/parent/blob/GPG identity, missing/corrupt original archives or required historical evidence, forbidden target data, wrong mathematical kernel identities, exact false certificate accepted as valid, unauthorized validation, or incompatible external trust authority. Preserve precise observations and no claimed exact success. Ordinary isolated engineering defects can be repaired **only** under the prospective DEV/history/checkpoint rules.

Excluded from this execution: P0A0 S00–S12 replays; P0A4; historical Hebrew images, glyph vectors, fonts as proxies, digitization, candidate/null experiments or shape matching; optimizer/performance threshold tuning; reversal, reflection, phase shift, non-prescribed reparametrization, free scale, QH, G0/A/B/3D cameras, physical shadow; publication or deployment; private-key/credential collection. No code signing by the agent. All research inference boundaries and earlier incomplete statuses remain intact.

## G. Handoff completion and next authorized stage

Return the **actual independently verifiable, user-accessible** C0/C1/C2+/CFINAL artifact identities as achieved, each with size/SHA-256, plus exact DEV chronology and negative events. If the run stops, report what survived and why, not a promised later continuation. The human operator has **already signed and pushed** the amendment; do not request a duplicate signature.

After full R1 candidate delivery: separate **independent QC** on original bytes, immutable math kernels, trust, runtime, worker/checker crash/recovery, hostile input and all DEV evidence. Only if independently qualified may the human separately review/sign a **CODE-ONLY freeze**. Only later may a distinct registered target-free numerical protocol and P0A4 validation be considered. Historical first-hand, Hebrew observation, source rights, QH, G0/A/B cameras and N0–N3 fairness remain deferred under separate future protocols.

**Start now with read-only GitHub retrieval, full F0 lineage/archive verification and verified durable R1-C0. Do not start source modification or DEV until the corresponding gates are satisfied.**
