"""Evidence packaging only; never imports or executes scientific candidate code."""
from pathlib import Path
import hashlib,json,zipfile,sys,datetime
ROOT=Path(__file__).resolve().parent
EXCLUDE={'checkpoints','readback','library_helpers','verification_keyring','__pycache__'}
def sha(b): return hashlib.sha256(b).hexdigest()
def build(name):
    out=ROOT/'checkpoints'/f'P0A3F_RECOVERY_R1_{name}.zip'; out.parent.mkdir(exist_ok=True)
    if out.exists(): raise RuntimeError('immutable checkpoint already exists')
    files={p.relative_to(ROOT).as_posix():p.read_bytes() for p in ROOT.rglob('*') if p.is_file() and not any(x in EXCLUDE for x in p.relative_to(ROOT).parts)}
    inventory=[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())]
    files['PAYLOAD_INVENTORY.json']=(json.dumps(inventory,indent=2)+'\n').encode()
    files['SHA256SUMS']=(''.join(f'{sha(b)}  {n}\n' for n,b in sorted(files.items()))).encode()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,b in sorted(files.items()):
            i=zipfile.ZipInfo(n,(2026,10,21,0,0,0)); i.external_attr=0o100644<<16; i.compress_type=zipfile.ZIP_DEFLATED; z.writestr(i,b)
    print(json.dumps(verify(out)))
def verify(path):
    p=Path(path); b=p.read_bytes()
    with zipfile.ZipFile(p) as z:
        names=z.namelist(); assert len(names)==len(set(names)); assert z.testzip() is None
        assert all(not n.startswith('/') and '..' not in Path(n).parts for n in names)
        pairs=[line.split('  ',1) for line in z.read('SHA256SUMS').decode().splitlines()]
        assert {n for h,n in pairs}==set(names)-{'SHA256SUMS'}
        for h,n in pairs: assert sha(z.read(n))==h,n
        inv=json.loads(z.read('PAYLOAD_INVENTORY.json'))
        assert {r['path'] for r in inv}==set(names)-{'SHA256SUMS','PAYLOAD_INVENTORY.json'}
        for r in inv:
            data=z.read(r['path']); assert len(data)==r['bytes'] and sha(data)==r['sha256'],r['path']
    return {'path':str(p.resolve()),'bytes':len(b),'sha256':sha(b),'entries':len(names),'manifest_verified':len(pairs),'inventory_verified':len(inv),'crc':'PASS'}
if __name__=='__main__':
    if sys.argv[1]=='build': build(sys.argv[2])
    elif sys.argv[1]=='verify': print(json.dumps(verify(sys.argv[2])))
