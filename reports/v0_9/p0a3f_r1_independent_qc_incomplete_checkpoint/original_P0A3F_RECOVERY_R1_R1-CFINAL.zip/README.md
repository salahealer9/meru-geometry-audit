# P0A3F_RECOVERY_R1 cumulative engineering candidate

[INDEPENDENT_QC_PENDING] Unsigned candidate for independent mathematical, software and provenance review. Qualification remains incomplete. No readiness, approval or freeze is asserted.

[DEV_CHECKED_ONLY] One new attempt, P0A3F_R1_DEV_01, passed all 18 prospective methods, including four new generic QO comparisons. Mandatory recovery from a stale saved verdict completed through a fresh independent checker under the eight-second limit. A separate actual eight-second timeout failed closed. No source repairs or second attempt were needed. This evidence does not authorize replay or registered validation.

[IMPLEMENTED_UNVERIFIED] The package preserves the executed directory layout:

- candidate/src and candidate/reference: complete cumulative production and independent checker code.
- candidate/schemas and candidate/docs: proposed contracts and resource policy.
- candidate/tests: new R1 tests plus unchanged historical E test source. Historical tests were not executed.
- candidate/reports/v0_9/p0a3f_runtime_external_trust_qualification: final dispositions, full diffs, prospective lock, source snapshots and complete attempt evidence.
- intake: exact GitHub protocols, signed commit payloads/signatures, public verification key, lineage, original archives, QC, theorem and environment records.
- receipts: verified durable R1-C0, R1-C1 and R1-C2 identities.

[INDEPENDENT_QC_PENDING] Read FINAL_ENGINEERING_DISPOSITION.md and the updated phase matrix in candidate/reports first. Earlier F0/C0/C1 documents intentionally retain their prospective state. CFINAL's own receipt is external to this ZIP, avoiding self-reference. PACKAGE_INVENTORY.json covers every payload except itself and SHA256SUMS; SHA256SUMS covers every member except itself.

[FROZEN THEOREM] The exact 2D ordered-open rational-path theorem and all three mathematical kernels remain unchanged. Original D/E archives, historical DEV failures, both QC environments and the incident archive remain byte-identical. The lost original F DEV01 remains a transcript-only failure with unknown timeout cause. R1 evidence does not replace it.

[UNRESOLVED] Real human-signed code authority, comprehensive loaded-code attestation, arbitrary-input correctness and hostile-host crash guarantees remain unqualified. Missing crop, historical construction, source rights, order, observation and fairness limitations remain. No repository modification, commit, push, P0A0 replay, P0A4, Hebrew/proxy, camera, QH or candidate/null execution occurred.
