"""Summarize preserved evidence, without executing candidate or new tests."""
from pathlib import Path
import json,hashlib,csv,ast,datetime
W=Path(__file__).resolve().parent;R=W/'candidate';T=R/'reports/v0_9/p0a3f_runtime_external_trust_qualification';A=T/'attempts';H=json.loads((A/'P0A3F_R1_DEV_01/evidence.json').read_bytes());obs={o['name']:o['value'] for o in H['observations']}
def write(name,x): (T/name).write_text(json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((T/'C1_SOURCE_MANIFEST.json').read_bytes())
for n,h in source.items():assert sha(R/n)==h,n
f0=json.loads((W/'intake/F0_VERIFIED.json').read_bytes())
for n,h in f0['kernels'].items():assert sha(R/n)==h,n
write('FINAL_SOURCE_IDENTITY_CHECK.json',{'label':'DEV_CHECKED_ONLY','all_C1_manifest_files_unchanged':True,'source_files':len(source),'frozen_kernels':f0['kernels'],'DEV_attempts':1,'source_repairs':0,'test_catalogue_unchanged':True,'catalogue_sha256':sha(T/'DEV_CASES_PREDECLARED.md')})
traces=[]
for o in H['observations']:
    v=o['value']
    if isinstance(v,dict):
        for e in v.get('worker_events',v.get('events',[])):
            if 'calibration' in e:traces.append({'case':o['name'],**e})
write('INTERPRETER_ENVIRONMENT_AND_PREFLIGHT.json',{'label':'DEV_CHECKED_ONLY','inventory':json.loads((W/'intake/environment.json').read_bytes()),'declared':json.loads((T/'DECLARED_RUNTIME.json').read_bytes()),'policy':json.loads((R/'schemas/v0_9/p0a3f/resource_policy.json').read_bytes()),'calibrations':traces,'qualification':'DECLARED_HOST_BOUNDED_DEV_ONLY','limitations':['startup VmSize heuristic, not peak proof','no alternate interpreter tested','native libraries/OS/CPU trusted','no cgroup or total process tree quota','incompatible example is fake trace, not real allocation']})
write('EXTERNAL_EXPECTED_IDENTITY_TRUST_LEDGER.json',{'label':'INDEPENDENT_QC_PENDING','signed_protocol':f0['commits'][1],'signed_amendment':f0['commits'][0],'E_preservation':f0['commits'][2],'source_manifest_sha256':sha(T/'C1_SOURCE_MANIFEST.json'),'caller':'independent metadata fixture constructor build_prerun.py; Work-generated unsigned DEV receipt, not outside-human signature','expected_manifest_mode':'UNSIGNED_STAGING_PROPOSAL','real_human_code_freeze':'ABSENT; DEPLOYMENT_FAILS_CLOSED','loaded_runtime':'TOP_LEVEL_FUNCTION_COMPARISON_ONLY; P0A3F_LOADED_CODE_IDENTITY_UNVERIFIED','trust_assumptions':['user-pinned GPG fingerprint; public key acquired GitHub; no ownertrust assigned','GitHub valid attestation distinct from local detached signature verification','selected Python/stdlib files hashed; native/OS dependency trust not exhaustive','CPython arbitrary precision int/Fraction common to both arithmetic implementations','trusted supervisor, single writer, trusted local POSIX filesystem','no malicious in-process monkeypatch/global/class/loader or TOCTOU protection'],'DEV_evidence':['methods01-03: missing/mismatched receipts/identities and top-level mutation','source file tamper subcases reject receipt mismatch; separate actual source-substitution hostile-host testing NOT_PERFORMED','reference AST has no production imports']})
write('INFORMATION_BARRIER_AND_SOURCE_PROVENANCE.json',{'label':'INDEPENDENT_QC_PENDING','F0':f0,'new_source_origin':'untouched signed E archive, not reconstruction of lost F source','C0_C1_C2_receipts':{p.stem:json.loads(p.read_bytes()) for p in sorted((W/'receipts').glob('*.json'))},'forbidden_execution':'NOT_RUN','repository_modifications':'NONE; only isolated workspace writes; no local checkout cleanliness claimed','old_registered_tests':'NOT_REPLAYED','target_access':'NONE','historical_limitations':['missing inherited crop','NO_REPRODUCIBLE_PUBLISHED_FIRST_HAND_CONSTRUCTION_RECOVERED','unresolved source rights/order/observation/fairness','no Hebrew score selection or historical inference'],'original_incident':'INCIDENT_REPORT_FROM_TRANSCRIPT; P0A3F_DEV_01_EVIDENCE_UNAVAILABLE; recorded failure not qualified; timeout cause UNKNOWN'})
rows=[['F0','DEV_CHECKED_ONLY','Pinned protocol/amendment blobs,17commit signatures/parents,tag,archives and retained history verified; R1-C0 durable retrieval checked','Older v0.8 ancestry via GitHub merge-base; no complete pre-P0A0 signature walk'],['F1','DEV_CHECKED_ONLY / UNQUALIFIED_FOR_DEPLOYMENT','Separate caller receipt; distinct producer/reference validation; canonical source/runtime/input/run identity; default reject','No human-signed new-code freeze; loaded code attestation incomplete; TOCTOU/host attacks excluded'],['F2','DEV_CHECKED_ONLY / DECLARED_HOST_ONLY','Pinned3.12.3 interpreter; preexec limits; measured selected imports fit256MiB with64MiBmargin; fake incompatible trace rejected','Startup heuristic; native/runtime/OS trust; no total-host quotas; no alternate host proof'],['F3','DEV_CHECKED_ONLY / PARTIAL','Mandatory fresh-check recovery passed; real8stimeout fail-closed; kill/exit and5simulated writewindows retained','No power-loss, kernel/multiwriter/hostilefilesystem/true disk-full guarantee'],['F4','DEV_CHECKED_ONLY / PARTIAL','Canonical raw bytes/stream limits; independent exact residual/nonoptimal witness and hostile grammar checks','Arbitrary Python object/stream abuse, class/global mutation, exhaustive bounded adversarial inputs not qualified'],['F5','DEV_CHECKED_ONLY','One prospective R1 attempt;18methods passed;4new genericcomparisons; allraw/source evidence retainedC2','No numerical certification; oldFfailedattempt unavailable transcriptonly'],['F6','INDEPENDENT_QC_PENDING','Complete cumulative candidate assembled with originals/diffs/raw evidence/provenance/checksums','CFINAL retrieval verification external receipt follows; unsigned'],['F7','INDEPENDENT_QC_PENDING','Separate negative/partial findings preserved; submitted only for QC','No readiness/approval/freeze; P0A4 NOT_RUN']]
with (T/'F0_F7_REQUIREMENT_AND_DECISION_MATRIX.csv').open('w') as f:w=csv.writer(f);w.writerow(['phase','disposition','evidence','remaining_limits']);w.writerows(rows)
# Keep initial F0 matrix untouched; updated authoritative matrix is this report.
with (T/'PRODUCTION_REFERENCE_DEPENDENCY_AND_TRUST.csv').open('w') as f:
    w=csv.writer(f);w.writerow(['path','imports','route','trust'])
    for folder in ['src/meru_geometry/v0_9/qo2d_exact','reference/v0_9/qo2d_exact']:
        for p in sorted((R/folder).glob('*.py')):
            imports=[]
            for n in ast.walk(ast.parse(p.read_text())):
                if isinstance(n,ast.Import):imports.extend(a.name for a in n.names)
                elif isinstance(n,ast.ImportFrom):imports.append('.'*n.level+(n.module or ''))
            w.writerow([p.relative_to(R).as_posix(),';'.join(imports),'global-u polynomial residual' if folder.startswith('reference') else 'production endpoint integral core','CPython/int/Fraction common; independent arithmetic routes; source QC pending'])
(T/'PROCESS_FAULT_RECOVERY_EVIDENCE.md').write_text('''# R1 fault and recovery evidence
[DEV_CHECKED_ONLY] P0A3F_R1_DEV_01 passed18/18methods, exit0; outer17.554817949s, no outertimeout. Four new exact comparisons only. All worker commands, PID/returncode/wall limit/elapsed time, stdout/stderr length+SHA and actual raw input/output files are preserved under attempts/P0A3F_R1_DEV_01/raw_workers. Empty stdout/stderr files remain actual zero-byte evidence. No source repairs or later attempts.
[REFERENCE_RECOMPUTED_DEV] Mandatory stale-verdict case: validR persisted certificate with saved UNTRUSTED_STALE_SAVED_VERDICT. Recovery reran bothpreflights and the checker, returned FRESH_REFERENCE_RECOMPUTED, checkerexit0 in0.317110196s under8s. This is a successful functional microcheck within this declared envelope, not general recovery certification.
[DEV_CHECKED_ONLY] Separate forcedchecker sleep: parent actually killed child at8.017195188s after8sdeadline, returncode-9, RESOURCE_INCOMPLETE/CONTROLLER_WALL_TIMEOUT, no resultcertificate. NormalOS scheduling overhead beyond deadline is recorded, not a changed budget. Actual selfSIGKILL and exit17 also observed. MemoryError/RecursionError were explicit Python injections, not exhausted host memory/stack.
[DEV_CHECKED_ONLY] Five simulated atomicwrite interruptions retained actual pending/final files: beforewrite, afterflush, beforerename, afterrename-before-directoryfsync, postrename-afterfsync. These are controlled exceptions, not powercut experiments. Torn, absent, work/digest/caller mismatch failed beforeworkerlaunch. No saved verdict was trusted.
[UNRESOLVED] Original lost P0A3F_DEV_01 reportedly22passes then method23 timeout8s remains quarantined, unavailable original telemetry/source, causeUNKNOWN. New success is not evidence of old cause or restoration. Truepowerloss/kernelcrash/hostilefilesystem/multiwriter races/diskfull/global starvation unsupported. All negative states and raw artifacts kept; no global certification.
''')
(T/'RAW_BOUNDARY_AND_CHECKER_ADVERSARIAL_AUDIT.md').write_text('''# R1 boundary and reference audit
[IMPLEMENTED_UNVERIFIED] Production parser compares canonical byte encoding before returning any validated input hash. Raw diagnostic prefix digests are explicitly distinct. ASCII subset ofUTF8, no escapedUnicode, duplicates/floats/NaN/nonfinite/noncanonical rationals; strictbool checks. Byte caps precede materialization through boundedread(n) for trustedstreams and boundedregular files. Both parsers independently enforce canonical bytes. JSONSchema documents shape but does not alone prove exact/tower/budget properties.
[DEV_CHECKED_ONLY] Methods04/05 exercised canonical/hostile tokens, rational grammar, booleans, bytes/string/depth/integer bounds. Method03 mutated a production top-level function and observed rejection. Reference loaded-class/global mutation was not exhaustively tested. Streamread(n) assumes a trusted object obeyingn; blocked/malicious Python stream objects are outsidepublicprocess threat model.
[REFERENCE_RECOMPUTED_DEV] Reference code uses independent dense radical arithmetic/global-u polynomial integrals, reconstructing originalpaths, zeroedgeindices, arclength/centroid/RMS, unionknots, correlations, properoptimalrotation and directly integratedresidual. Separate syntax/hash/identity implementations share CPython/Fraction but no production imports. Four fixturecertificates checked; falseq/tie/nonoptimalproperrotation, omitted/duplicateknots, changedtraversal, malformedroots/masks/nullpath rejected. Equivalentconstruction -1+sqrt1 accepted as exactzero. Dependent sqrt(4+2sqrt3) equality/inversion checked in both frozen kernels.
[UNRESOLVED] These are finiteDEV evidence, not proof of full hostileinput envelope or executable correctness on all finiteinputs. Object-level helpers, imports, monkeypatching, globals/classes and native/runtime integrity remain trusted/unqualified. No new theorem or kernel edits. A future false exact-certificate acceptance must trigger quarantine, never silent kernelrepair.
''')
(T/'PROOF_STATUS_LEDGER.md').write_text('''# Proof and implementation dispositions
[FROZEN THEOREM] Signed P0A3D abstract exact2D ordered-open rational-vertex true-arclength SO(2) theorem independentlyverified in59eb47f7500d57866e4935822b78a555d3bcb515. Original proof andQC retained byte-identically; no new mathematical claim or extension.
[DEV_CHECKED_ONLY] Frozen algebra/core/reference arithmetic hashes remain442065847937252db00d3f63b02184c15d57989f958f764c5c731cb385de6d2d /37701d034d98725673240a881420892893906c70387f68432b5993f8557dd420 /72b3c37f02be65b2df7616a94e84601d66cf4af5b7a50e878724de647e5bf0ba. New dependent equality/nonzero inversion/zero inversion andfourgeneric fixture checks do not constitute software proof.
[UNRESOLVED] Exact arithmetic software arbitrary-input qualification; reference arbitrary-input independence/correctness; host/runtime/loadedbytesattestation; complete hostile-parser/resource/crash guarantees remain unqualified. Common arithmetic/runtime assumptions disclosed. Existing finite budget exhaustion remains incomplete calculation, not invalidtheorem domain.
[DEFERRED] P0A4,3D/camera/G0/A/B,QH,sourcehistoricalmodel/rights/order,candidate-null andHebrew inference notexecuted/notauthorized.
''')
(T/'INDEPENDENT_QC_CHECKLIST.md').write_text('''# Independent QC — UNFILLED
[INDEPENDENT_QC_PENDING] Only an independent reviewer may complete these items.
- [ ] Retrieve CFINAL independently; recompute size/SHA/CRC/manifest/inventory.
- [ ] Reverify original/amendment commit/blob/parents/signer and preserved baseline/QC/history.
- [ ] Confirm C0,C1,C2 durable receipts and chronological gates.
- [ ] Confirm original lostDEV01 remains transcript-only failure with unknowncause.
- [ ] Compare all source/diffs to immutable E and three frozen kernels.
- [ ] Review callerreceipt threatmodel, defaultdeploymentdenial and unsignedproposal labels.
- [ ] Review pinnedruntime/preflight andOS versusapplicationcaps.
- [ ] Review independent checker residual/nonoptimal witness and sharedarithmetictrust.
- [ ] Review both mandatory recovery outcomes and retainedraw artifacts.
- [ ] Decide whether stated unsupported host/parser/recovery conditions are acceptable for any later gate.
- [ ] Review separate F1–F4 and nineoverall dispositions without inferring readiness.
- [ ] Human separately decides whether any code-only freeze is justified; no agent authorization.
''')
(T/'FINAL_ENGINEERING_DISPOSITION.md').write_text('''# P0A3F_RECOVERY_R1 — submitted candidate, qualification incomplete
[INDEPENDENT_QC_PENDING] Complete engineering evidence candidate prepared for independent mathematical/software/provenance QC. Delivery status becomes P0A3F_R1_ENGINEERING_CANDIDATE_SUBMITTED_FOR_QC only after independently retrieved CFINAL verification; this is not positive readiness. Overall qualification remains P0A3F_R1_SOFTWARE_QUALIFICATION_INCOMPLETE pending independent QC and external trust gate.

|Area|Disposition|
|---|---|
|F1 externaltrust|DEV_CHECKED_ONLY; realhuman signedcodeauthority absent; loadedcodeidentity UNVERIFIED; deploymentclosed|
|F2 runtime|DEV_CHECKED_ONLY within pinnedCPython3.12.3/Linux envelope; startupheuristic and host/native trust limitations|
|F3 recovery|Mandatory normalfreshcheck andactual8stimeout both observed; boundedcrash envelopePARTIAL; unsupportedhostfailures remain|
|F4 boundary/checker|Bounded hostilebytes and exactwitness microchecks passed; arbitraryinput/security/referencequalification remainsPARTIAL|

|Overall gate|Disposition|
|---|---|
|Abstract theorem|FROZEN THEOREM unchanged; no new independent mathematical approval|
|Exactsoftwarearithmetic|DEV_CHECKED_ONLY, not full-domain certified|
|Independentreference|REFERENCE_RECOMPUTED_DEV; sharedCPython/Fraction; fullsoftwarequalificationpending|
|Externaltrust/loadedbytes|UNRESOLVED; realhuman codefreeze absent, onlycallerDEVfixture|
|Runtimecompatibility|DEV_CHECKED_ONLY declaredhost, no crosshostguarantee|
|Crash/recovery|DEV_CHECKED_ONLY boundedfaults, broaderenvelopeincomplete|
|Parser/certificatesecurity|DEV_CHECKED_ONLY finitecases; inputfailureenvelopeincomplete|
|BoundedDEV|One newR1attempt,18/18methods, fourfreshcomparisons, alloutputs preserved; no repairs|
|Registeredvalidation|P0A3F_REGISTERED_VALIDATION_NOT_RUN|

[UNRESOLVED] Original F DEV01 remains P0A3F_DEV_01_EVIDENCE_UNAVAILABLE and P0A3F_DEV_01_RECORDED_FAIL_NOT_QUALIFIED. It reported22passes thenmethod23checker8stimeout; rawbyteslost, causeunknown. R1 does not restore/relabel it. Historical D01–04,E01–02, bothE independentQC environments, theorem/QC andincident archives unchanged. Missingcrop, missingfirsthandconstruction, observation/rights/order/fairness remain.
[DEFERRED] No commit/push/repositorymodification, P0A0replay, P0A4,3D/QH/cameras,Hebrew/proxy,candidate-null orscientificoptimizer work. No finalscore/hierarchy selected. No readiness/selfapproval/freeze. Only independentQC and separatehuman signedcodefreeze can authorize consideration of later registeredvalidation.
''')
(W/'README.md').write_text('''# P0A3F_RECOVERY_R1 cumulative engineering candidate
[INDEPENDENT_QC_PENDING] Unsigned candidate for independent review. No readiness, self-certification or freeze. Qualification remains incomplete as detailed in candidate/reports/v0_9/p0a3f_runtime_external_trust_qualification/FINAL_ENGINEERING_DISPOSITION.md.

[DEV_CHECKED_ONLY] One new attempt P0A3F_R1_DEV_01 passed18/18prospective methods (fournewgenericQO comparisons). Mandatory stale-verdict freshchecker recovery succeeded under8s; separate actual8stimeout failedclosed. No source repairs or secondattempt. Do not rerun without appropriate review/authorization; these files are evidence, not execution instructions to replay tests.

[IMPLEMENTED_UNVERIFIED] Layout preserves the executed workspace: candidate/src, candidate/reference, candidate/schemas, candidate/tests, candidate/docs and candidate/reports contain complete cumulativeimplementation and newreports. intake contains exact GitHub protocols, raw signedcommit payloads/signatures/publickey, lineage/scope/archives/QC/proof/history verification and environment. OriginalD/E/incidentZIPs remain byteidentical under intake/files/reports/v0_9/. Historical tests in candidate/tests/dev_v0_9/p0a3e are unchanged archivedsource; never run inR1. Attempts include exactsourcesnapshotZIP, allraw worker artifacts andstdout/stderr. Rootengineering scripts and fullunifieddiff are retained for provenance.

[INDEPENDENT_QC_PENDING] receipts/ records durableC0/C1/C2 identities andfreshretrievalchecks. CFINAL's own external receipt follows finalupload/retrieval, avoiding selfreferentialhashes. PACKAGE_INVENTORY.json covers everypayload member except itself/SHA256SUMS; SHA256SUMS covers everymember exceptitself. Bothoriginal protocols andnewhandoff are included. InitialF0/C0/C1 files preserve prospective state; updatedauthoritative decisionmatrix is under candidate/reports, not theinitialF0matrix.

[FROZEN THEOREM] Exact2D orderedopen rationalpath truearclength SO(2) theorem andthree kernels unchanged. Shared arithmetic/runtime assumptions and source-rights/order/missingcrop/history barriers retained. Originallost FDEV01 remains transcript-only failure, not replaced by R1passes.
''')
write('HISTORICAL_AND_R1_CHRONOLOGY.json',{'label':'INDEPENDENT_QC_PENDING','old_D_E':json.loads((W/'intake/historical_dev_verified.json').read_bytes()),'old_F':'DEV01 evidence unavailable transcript-only22reportedpass+method23timeout8s; causeunknown; no originalF02','R1':[json.loads((A/'P0A3F_R1_DEV_01_execution.json').read_bytes())],'source_repairs':[],'C0_C1_C2':'fresh retrieval verified; receipts included','registered_validation':'NOT_RUN'})
print('F6/F7 reports generated. No new DEV. Source manifest and frozen kernels unchanged.')
