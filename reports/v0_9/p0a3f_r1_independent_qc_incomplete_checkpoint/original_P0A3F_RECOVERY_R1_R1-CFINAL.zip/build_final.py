"""Cumulative evidence release packaging, no candidate imports or execution."""
from pathlib import Path
import hashlib,json,zipfile,sys
W=Path(__file__).resolve().parent
EXCLUDE={'checkpoints','readback','library_helpers','verification_keyring','__pycache__'}
def sha(b):return hashlib.sha256(b).hexdigest()
def verify(path):
    p=Path(path);data=p.read_bytes()
    with zipfile.ZipFile(p) as z:
        names=z.namelist();assert len(names)==len(set(names));assert z.testzip() is None
        assert all(not n.startswith('/') and '..' not in Path(n).parts for n in names)
        assert all((i.external_attr>>16)&0o170000!=0o120000 for i in z.infolist())
        rows=json.loads(z.read('PACKAGE_INVENTORY.json'))
        assert {r['path'] for r in rows}==set(names)-{'PACKAGE_INVENTORY.json','SHA256SUMS'}
        for r in rows:
            b=z.read(r['path']);assert len(b)==r['bytes'] and sha(b)==r['sha256'],r['path']
        hashes=[line.split('  ',1) for line in z.read('SHA256SUMS').decode().splitlines()]
        assert {n for h,n in hashes}==set(names)-{'SHA256SUMS'}
        for h,n in hashes:assert sha(z.read(n))==h,n
    return {'path':str(p.resolve()),'bytes':len(data),'sha256':sha(data),'entries':len(names),'inventory_verified':len(rows),'manifest_verified':len(hashes),'crc':'PASS','safe_unique_paths':True}
if sys.argv[1]=='build':
    out=W/'checkpoints/P0A3F_RECOVERY_R1_R1-CFINAL.zip';assert not out.exists()
    files={p.relative_to(W).as_posix():p.read_bytes() for p in W.rglob('*') if p.is_file() and not any(x in EXCLUDE for x in p.relative_to(W).parts)}
    assert 'PACKAGE_INVENTORY.json' not in files and 'SHA256SUMS' not in files
    files['PACKAGE_INVENTORY.json']=(json.dumps([{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())],indent=2)+'\n').encode()
    files['SHA256SUMS']=''.join(f'{sha(b)}  {n}\n' for n,b in sorted(files.items())).encode()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,b in sorted(files.items()):
            i=zipfile.ZipInfo(n,(2026,10,21,0,0,0));i.external_attr=0o100644<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,b)
    print(json.dumps(verify(out)))
elif sys.argv[1]=='verify':print(json.dumps(verify(sys.argv[2])))
