# Meru 3D-V5 — Independent historical/mathematical scoping review (read-only)

**Date:** 22 October 2026 · **Protocol commit:** `2073a5618719230c6ec4d5aad7a2941825c7fd77` · **Direct parent:** `aa79d6509b95b302bd6c8092464aed7717f71554`  
**Exact signed protocol blob:** `9bc215654470785f625c799371168b36e88e1a2b`. GitHub reports the V5 commit as validly signed; the user-supplied terminal output independently documents local `GOODSIG`/`VALIDSIG`/`TRUST_ULTIMATE`. The V5 protocol's frozen DRAFT text is archival.  
**Activity:** documentary comparison and symbolic forward-model design only. **NO** scientific candidate projection, match score, glyph, target, dataset, experimental run, Git write or push performed here.

## Executive assessment

The V5 inherited **source and model contracts are sufficiently recoverable to prepare a scoped V5B protocol**, with an important restriction: source-inspired candidate geometry remains *mathematically explicit but historically underdetermined*. In particular, only A-DIAGRAM supports the already preregistered finite Archimedean/logarithmic/Golden Mean controls on one shared parameter interval without changing endpoint rules. Variant B supports separately matched same-carrier logarithmic controls but carries an entire surface-parameter family; the original 400-cell endpoint study supplies no projection-class outcomes. PROSE comparisons are not licensed by moving its limiting endpoint. N3, finite-width ribbon optics and full analytic curve-set equality remain open.

**Current QC status:** static provenance/parity checks performed; a genuinely separate **second read-only reviewer** is still required by signed V5 §8 before a *final independently reviewed* qualification may be frozen. Therefore the appropriate administrative state of **this delivered package** is `QUALIFICATION_READY_FOR_SECOND_READ_ONLY_REVIEW`, not a falsely completed independent sign-off. Proposed scientific outcome, conditional on that independent check: `MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_QUALIFIED`. The package does **not** presently certify V5B numerical readiness.

## 1. Signed identity, source selection and preservation

- Remote V5 HEAD is `2073a5618719230c6ec4d5aad7a2941825c7fd77`, direct child of signed V4 freeze `aa79d6509b95b302bd6c8092464aed7717f71554`; GitHub signature verification `valid`.
- The uploaded approved V5 protocol has SHA-256 `91cdd78c77290444845e0876e2984ea2d1930f91c726d1c12384cbea484b94cb` and Git blob `9bc215654470785f625c799371168b36e88e1a2b`. Its bytes match the signed remote blob.
- Historical `v0.8.0` tag is a signed annotated tag, GitHub verification `valid`, object `12afd9f9d1cb4a9d000c0fd9555419f0383978e9`; key A/B preregistration and source-recovery-closeout blobs checked under that tag match their corresponding signed-V5-HEAD blobs. A full all-source historical tag-identity survey is recommended before final external review.
- The 20 authoritative file paths and exact Git blob identities are enumerated in `V5_SOURCE_TO_MODEL_REGISTER.md`. Later v0.9 methodological and P0A3 files are **boundaries**, not permission to unlock P0A4 certification or actual Hebrew-target evaluation. No P0A4 protocol file was found in the signed V5 checkout tree.

## 2. High-confidence scoped findings

**Variant A.** A-PROSE outer limit is $\theta\to0^+$, inner $3\pi$, with finite spherical image limit $(1,0,0)$. A-DIAGRAM is the *different* finite interval $\theta\in[1,1+3\pi]$. Both use the audit's isotropic inverse-gnomonic map and separate G30/GHALF scales. The old S1 failure remains unaffected. N1 A comparator formulas have inherited authority **only** on DIAGRAM; no source-valid PROSE-to-Archimedean cutoff is defined.

**Variant B.** Explicit unchanged surface $X_{w,e}$ with 25 positive $(w,e)$ cells, eight radial laws, two scales, $u_k(\theta)=\pi[1-\arctan(kr(\theta))/\arctan(k)]$ and $v=\theta-1$ on the finite 3π interval. Both radius and carrier geometry are source-constrained **audit choices**. Previously none of 400 endpoint-analysis cells reached the exact source endpoint-parallelism target. Their results may not be relabelled as a new projection study.

**Control fairness.** A's endpoint-matched log is exactly the m=1 grid member; double-counting it is false independence. The generic six-rate log family and Golden Mean do not all have the reciprocal candidate's inner endpoint radius; any comparative outcome must state that nuisance. In B, comparator/candidate match the exact same $(w,e,k)$ and mapping. A pair from distinct carrier cells would not qualify as matched. Control tiers N0, N1, N2 and N3 are not exchangeable samples; N3 is currently uninstantiated.

**V1–V4 inheritance.** Cameras are A G0/G1/G2 = 6/14/26 and B = 6/18/42 in signed primitive-triple ordering; O2 antipodal quotient gives 3/7/13 and 3/9/21 axes. These are independent candidate grids, not historical frame measurements. V4 only establishes finite PL traces and convex solids; no result is copied to source-inspired analytic vortex curves.

**K and R.** Canonical (3,10) knot remains a different object from the 1.5-turn FIRST HAND, and a ring-torus knot asset is not a dimpled-carrier metric surface. Historical opaque ribbon/wire and material/light shadow optics have no reproducible source-derived width, geometry or renderer. Their empirical or physical shadow claims are deferred.

## 3. Mathematical completeness and unresolved obligations

A projected analytic curve is an infinite object; finite polygonal samples cannot certify its entire equivalence class. Congruence up to arbitrary monotone reparametrisation cannot be refuted simply by comparing raw-parameter Gram kernels. V5B must either canonicalise by *certified projected arclength* and compare full kernels (with orientation for SO2), or use a separately proved complete substitute. For inequivalence it may use rigorous endpoint-chord / projected-length witness inequalities. Exact equalities (including antipodal O2 identity) need symbolic theorems; numerically small error is not enough. Regularity, zero-speed positions and singular branches must fail closed. The certification plan records this in detail.

No V5B run source, precision, interval backend, stopping budget or exact continuous-pair oracle has been selected or executed. It would be scientifically premature to label V5B executable now. The correct next gate is **an independently reviewed V5 qualification report, signed separately**, followed by a **distinct, tightly scoped V5B preregistration** (possibly an exact-theorem-first pilot) with human approval.

## 4. Independent review checklist / reviewer actions

A second read-only reviewer should: (i) fetch each of the 20 source blobs at the registered signed commits and independently verify the crucial v0.8.0 tag identities; (ii) independently transcribe all A/B endpoint-map and eight-branch definitions without importing this register; (iii) compare every matrix row's scale/domain/carrier/permission against V5 §§3–7; (iv) challenge the projected-arclength completeness argument and singularity policy; (v) verify that V5B work does not depend on any unseen Hebrew source/pixels or silently instantiate N3; (vi) publish an additive QC document with its own identity, conflicts, status and signed closeout gate. A checker script and JSON in this package are **static document-level QC**, not a substitute for a second scientist.

## 5. Decision and allowed next step

**Current:** `QUALIFICATION_READY_FOR_SECOND_READ_ONLY_REVIEW` (scientifically coherent proposal; separate reviewer outstanding).  
**Proposed after independent corroboration:** `MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_QUALIFIED`.  
**Not established:** recovered historical FIRST HAND; endpoint parallelism; source-specific Hebrew image generation; analytic projection census; physical-optical silhouettes; target access; an exact continuous equality implementation; V5B authorisation.

Do not modify signed V1–V4 evidence. No user-facing RUN instruction accompanies this V5 report. The right next action is independent read-only review and a separate human-controlled V5 freeze, not candidate experimentation.
