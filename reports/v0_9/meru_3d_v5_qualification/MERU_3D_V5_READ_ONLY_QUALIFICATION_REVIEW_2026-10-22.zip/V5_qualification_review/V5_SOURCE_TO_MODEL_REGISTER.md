# V5 Source-to-Model Register — target-blind read-only qualification

**Date:** 2026-10-22 · **Scientific phase:** Meru v0.9 3D-V5 · **No new geometric projections evaluated**  
**Signed protocol:** `2073a5618719230c6ec4d5aad7a2941825c7fd77` (parent `aa79d6509b95b302bd6c8092464aed7717f71554`, protocol Git blob `9bc215654470785f625c799371168b36e88e1a2b`)  
**Signature evidence:** GitHub reports `verified=true`, reason `valid`; user supplied local `GOODSIG`/`VALIDSIG`/`TRUST_ULTIMATE` for fingerprint `D4EC014EEFCC90E619D2AA59A91239ABCF512130`. These are separate attestations.  
**v0.8 archival control:** signed annotated tag `v0.8.0` (Git tag object `12afd9f9d1cb4a9d000c0fd9555419f0383978e9`, target commit `85748bff0bfae383afcc0d885f4aec505a2885dd`); the four independently cross-checked A, B and source-recovery prereg/closeout blobs match the signed tag. The remaining listed source blobs were retrieved as files at signed V5 commit `2073a5618719230c6ec4d5aad7a2941825c7fd77`; a full historical blob-for-blob tag comparison remains a separate audit step.

## 1. Authority and exact source objects

Each path below was retrieved read-only from GitHub at the signed V5 commit. Git *blob* identity is distinct from a commit signature. These records are not new historical sources.

| Role | Read-only path at signed HEAD | Git blob SHA-1 | What it supports |
|---|---|---|---|
| V5 signed preregistration | [`docs/v0_9/meru_3d_v5_target_blind_source_model_and_matched_null_qualification_protocol_2026_10_22.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/v0_9/meru_3d_v5_target_blind_source_model_and_matched_null_qualification_protocol_2026_10_22.md) | `9bc215654470785f625c799371168b36e88e1a2b` | Governing qualification scope, gates and outputs |
| v0.8 source recovery | [`docs/first_hand_construction_source_recovery_closeout_v0.8.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/first_hand_construction_source_recovery_closeout_v0.8.md) | `76a342c3d5d84687b181d410deec7fdd3ba05502` | Published-corpus construction is underdetermined |
| v0.8 A preregistration | [`docs/first_hand_analytic_s1_preregistration_v0.8.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/first_hand_analytic_s1_preregistration_v0.8.md) | `027d193abaab4ab3e35451161175fbbebd6dcc0f` | Reciprocal law, A PROSE/DIAGRAM intervals, spherical map/scales |
| v0.8 A result | [`docs/first_hand_s1_analytic_closeout_v0.8.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/first_hand_s1_analytic_closeout_v0.8.md) | `7fd635528e596815e2b097aa89d440b15fe989f3` | S1 endpoint failure and scope |
| v0.8 A comparator prereg | [`docs/first_hand_s1_comparator_preregistration_v0.8.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/first_hand_s1_comparator_preregistration_v0.8.md) | `965539f60c6a340005911d43d951043562c85ef1` | Exact A Archimedean/logarithmic/Golden Mean radial laws |
| v0.8 A comparator result | [`docs/first_hand_s1_comparator_closeout_v0.8.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/first_hand_s1_comparator_closeout_v0.8.md) | `b91d3d46e2af4b96b3c6fb993e7afbf0701b1d78` | A comparison restricted to DIAGRAM |
| v0.8 B source specification | [`docs/first_hand_variant_b_source_geometry_specification_v0.8.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/first_hand_variant_b_source_geometry_specification_v0.8.md) | `501be812592bce1c5a672e278f4f59a98a775443` | Metric underdetermination and physical meaning limits |
| v0.8 B preregistration | [`docs/first_hand_variant_b_swept_family_preregistration_v0.8.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/first_hand_variant_b_swept_family_preregistration_v0.8.md) | `bfd0ac70597987f47644b3895a37b6dc026d3d86` | Exact 25-carrier, 8-radial-law, 2-scale construction |
| v0.8 B result | [`docs/first_hand_variant_b_swept_family_closeout_v0.8.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/first_hand_variant_b_swept_family_closeout_v0.8.md) | `37d0a54dd8228156f8a02801fa9693b48a762a86` | Absolute endpoint-alignment failure, relative semantic reversal |
| v0.6 reconstruction constraints | [`docs/source_audit/reconstruction_constraints_v0_6.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/source_audit/reconstruction_constraints_v0_6.md) | `0c05bbef4acb770816eb14667ecf6cf037290d24` | Ribbon vs centreline; view/projection; knot distinction |
| C0 reference model | [`docs/geometry/torus_embedding_baseline.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/geometry/torus_embedding_baseline.md) | `6fff14949e348d0bbef4490c3130be5d3c1612a8` | Canonical torus and independent C0 hypothesis |
| v0.5 projection orbits | [`docs/geometry/projection_orbit_results_v0_5.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/geometry/projection_orbit_results_v0_5.md) | `e1e9285550922d4ec6adfec3a25c90d38bb5714b` | Earlier object-specific quotient examples |
| P0A2 direction designs | [`reports/v0_9/p0a2_target_blind_design/direction_family_candidates.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/reports/v0_9/p0a2_target_blind_design/direction_family_candidates.md) | `2328af16794329fdc14b41d8ffb5a128765580c8` | A/B camera tier ordering and axial quotient |
| V1 result freeze | [`docs/v0_9/meru_3d_v1_finite_direction_result_freeze_2026_10_22.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/v0_9/meru_3d_v1_finite_direction_result_freeze_2026_10_22.md) | `b71ad50b6532e8b680f14e21fc0c9bfcb56549ac` | Signed camera direction census/separation |
| V2 result freeze | [`docs/v0_9/meru_3d_v2_exact_covering_result_freeze_2026_10_22.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/v0_9/meru_3d_v2_exact_covering_result_freeze_2026_10_22.md) | `e9503be9d75947a313ec8372136bfc91ba5d496a` | Exact spherical covering radii |
| V3 result freeze | [`docs/v0_9/meru_3d_v3_labelled_projection_equivalence_result_freeze_2026_10_22.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/v0_9/meru_3d_v3_labelled_projection_equivalence_result_freeze_2026_10_22.md) | `6cdcd0e6c2ab2b64bcb0e67c8d1f7c4ca711a110` | Label-preserving finite projection result |
| V4 result freeze | [`docs/v0_9/meru_3d_v4_trace_convex_silhouette_result_freeze_2026_10_22.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/v0_9/meru_3d_v4_trace_convex_silhouette_result_freeze_2026_10_22.md) | `16b3243acf1f300e643df1dc331eed2fcd5b3e9a` | Exact finite PL traces and convex silhouettes, not analytic curves |
| P0A1 methodological limits | [`docs/v0_9/p0a1_post_synthetic_methodology_qualification_protocol.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/v0_9/p0a1_post_synthetic_methodology_qualification_protocol.md) | `d0a20485e8a2793fae6ede040fc266e461c8f23f` | Representation, target and null control restrictions |
| P0A2 methods design | [`docs/v0_9/p0a2_target_blind_numerical_methods_capacity_solver_design_protocol.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/v0_9/p0a2_target_blind_numerical_methods_capacity_solver_design_protocol.md) | `61585fb47cdb3ff2a3cfef07d3548fbd08084d0b` | Capacity, parity, solver bounds |
| P0A3 implementation gate | [`docs/v0_9/p0a3_target_blind_numerical_implementation_and_certification_architecture_protocol.md`](https://github.com/salahealer9/meru-geometry-audit/blob/2073a5618719230c6ec4d5aad7a2941825c7fd77/docs/v0_9/p0a3_target_blind_numerical_implementation_and_certification_architecture_protocol.md) | `38106180f7b2855992b70c925d64169dee0213ca` | No premature target access or N0–N3 fitting |

## 2. Atomic source-to-model classification

Each row has exactly **one** V5 provenance class. A historical statement and its mathematically chosen realization receive *separate* rows.

| ID | One atomic claim / assumption | Provenance class | Source |
|---|---|---|---|
| F01 | The published reconstruction includes the reciprocal planar seed law \(r(\theta)=1/\theta\). | `SOURCE_ATTESTED` | v0.8 source recovery §2 |
| F02 | The later FIRST HAND half-vortex uses a \(1.5\)-turn / \(3\pi\) counting convention; an earlier counting convention is historically documented. | `SOURCE_ATTESTED` | v0.8 source recovery §§2,8 |
| F03 | A source describes three projected copies separated by 120°. | `SOURCE_ATTESTED` | v0.8 source recovery §2 |
| F04 | A craft route bends the construction until the endpoint-parallelism criterion is imposed. | `SOURCE_ATTESTED` | v0.8 source recovery §§2–4 |
| F05 | The public corpus lacks a reproducible *unique* deterministic metric rule for the finished FIRST HAND. | `UNRESOLVED` | v0.8 source recovery §§3,12; state `NO_REPRODUCIBLE_PUBLISHED_FIRST_HAND_CONSTRUCTION_RECOVERED` |
| A01 | The isotropic inverse-gnomonic sphere mapping \(M_k\) is a specific audit reconstruction, not the uniquely sourced historical mapping. | `SOURCE_CONSTRAINED_INTERPRETATION` | A preregistration §§4–5 |
| A02 | The spherical end-limit at \(\theta\to0^+\) is handled analytically rather than by arbitrary epsilon cutoff. | `SOURCE_CONSTRAINED_INTERPRETATION` | A preregistration §§3,6 |
| A03 | PROSE and DIAGRAM are separate registered endpoint interpretations, not mergeable geometric branches. | `SOURCE_CONSTRAINED_INTERPRETATION` | A preregistration §3 |
| A04 | The G30/GHALF isotropic scales are fixed audit choices and not evidence of unique historical metric scale. | `SOURCE_CONSTRAINED_INTERPRETATION` | A preregistration §5 |
| A05 | The registered four-cell S1 spherical endpoint-tangent test did not achieve directed endpoint compatibility. | `INDEPENDENT_DIAGNOSTIC` | A closeout §§3–4 |
| B01 | The elliptic-fat-torus carrier is a genus-one, source-motivated but nonunique audit surface family. | `SOURCE_CONSTRAINED_INTERPRETATION` | B source specification §9 and B preregistration §§3–4 |
| B02 | The arctangent radial-to-meridian mapping and azimuth \(v=\theta-1\) are audit choices, frozen before B execution. | `SOURCE_CONSTRAINED_INTERPRETATION` | B preregistration §11 |
| B03 | The 400-cell registered B endpoint study found no exactly compatible reciprocal or logarithmic case under either endpoint semantic branch. | `INDEPENDENT_DIAGNOSTIC` | B closeout §§1–3 |
| K01 | A historical 3,10 torus-knot framework appears in the source accounts. | `SOURCE_ATTESTED` | v0.8 source recovery §2; reconstruction constraints C07 |
| K02 | A canonical ring-torus knot \(T(3t,10t)\) is an independently fixed **reference**, not the finished FIRST HAND. | `INDEPENDENT_DIAGNOSTIC` | torus embedding baseline §§1–2 |
| K03 | A unique transformation from the canonical ring knot to a source dimpled-sphere carrier is unavailable. | `UNRESOLVED` | reconstruction constraints C07 and torus baseline |
| R01 | Source material describes a toroidal ribbon, with width, orientation/twist and supporting surface conceptually distinct from its centreline. | `SOURCE_ATTESTED` | reconstruction constraints C02–C03 |
| R02 | A unique metric ribbon width, normal field, material, occlusion and physical illumination model is not available. | `UNRESOLVED` | v0.8 source recovery; reconstruction constraints C02–C03 |
| N01 | The fixed A-domain Archimedean/logarithmic/Golden Mean curves are fair *registered comparator candidates*, not independent random null samples. | `NULL_CONTROL` | A comparator preregistration §§5–9 |
| N02 | The six log-rate branches plus separately named Golden Mean share B carrier/map cells and are matched-domain controls. | `NULL_CONTROL` | B preregistration §§9–11 |
| N03 | A generic complexity-matched three-dimensional \(N3\) ensemble is not yet defined. | `UNRESOLVED` | V5 signed protocol §4 and P0A3 limits |
| V01 | Fixed V1–V4 grids and quotient rules are diagnostic camera designs, not reconstructed historical camera directions. | `INDEPENDENT_DIAGNOSTIC` | V1–V4 results and P0A2 direction design |
| O01 | A finite-width nonconvex opaque physical FIRST HAND silhouette model is not presently qualified. | `UNRESOLVED` | v0.6 constraints; V5 §5 |

## 3. Exact inherited Variant-A mathematical contract

**Radial source law (attested):** \(r_R(\theta)=1/\theta\), \(\theta>0\).  
**Chosen analytic embedding (audit reconstruction):**

\[
M_k(x,y)=\frac{(kx,ky,1)}{\sqrt{1+k^2(x^2+y^2)}},\quad
\Gamma_k(\theta)=\frac{(k\cos\theta,k\sin\theta,\theta)}{\sqrt{k^2+\theta^2}}.
\]

- `A-PROSE`: \(\theta\in(0,3\pi]\), outer limit \(\theta\to0^+\), inner endpoint \(3\pi\), limiting spherical point \((1,0,0)\). No numerical epsilon replacement. **Ineligible** for the frozen ordinary A comparator curves that begin at finite radius without a new cutoff/pole.
- `A-DIAGRAM`: \(\theta\in[1,1+3\pi]\). Let \(L=3\pi\), \(u=\theta-1\in[0,L]\), and \(q_R=1/(1+L)\). Outer-to-inner is increasing \(u\); the registered *directed endpoint test* describes inner-to-outer, i.e. **decreasing \(u\)**. That direction must not be quietly changed in a future orientation-sensitive objective.
- Frozen `G30`: \(k=\tan(\pi/6)=1/\sqrt3\); `GHALF`: \(k=\tan(1/2)\). These are two alternative fixed scales, **not** a fit or complete uncertainty range.

The signed A comparator preregistration fixes the following **radial laws on DIAGRAM's identical domain**:

\[
\begin{aligned}
r_R(u)&=\frac1{1+u},\\
r_{Arch}(u)&=1-\frac{1-q_R}{L}u,\\
b_*&=\frac{\log(1+L)}{L},\\
r_{log,m}(u)&=\exp(-mb_*u),\quad m\in\{0.50,0.75,1,1.25,1.5,2\},\\
\phi&=\frac{1+\sqrt5}2,\quad b_\phi=\frac{2\log\phi}\pi,\\
r_\phi(u)&=\exp(-b_\phi u).
\end{aligned}
\]

**Critical deduplication:** the endpoint-matched logarithmic curve \(r_{LM}(u)=e^{-b_*u}\) is precisely the `m=1` sensitivity-grid member, not an additional seventh log-rate instance. The Golden Mean curve is separately named even if its numerical rate is inside the grid. Only the Archimedean and `m=1` log controls share **both** candidate endpoint radii; the others remain registered radial controls but do not share the candidate inner radius. No smoothing, fitting or rescaling fixes that difference.

For each such radial law, the common *chosen* sphere projection is \(M_k(r(\theta)\cos\theta,r(\theta)\sin\theta)\). The A reciprocal closed form above should not be substituted mechanically for different radial laws.

## 4. Exact inherited Variant-B mathematical contract

**Common domain and orientation:** \(\theta\in[1,1+3\pi]\), endpoint-test direction inner to outer (decreasing \(\theta\)); no PROSE-pole comparison.  
**Surface:**

\[
\begin{aligned}
R&=(1+w)/2,&a&=(1-w)/2,\\
X_{w,e}(u,v)&=((R+a\cos u)\cos v,\,(R+a\cos u)\sin v,\,ea\sin u),\\
w&\in\{0.02,0.05,0.10,0.20,0.30\},&e&\in\{1.4,1.6,1.8,2.0,2.2\}.
\end{aligned}
\]

All 25 frozen cells have \(0<w<1\), \(e>0\), so each is an embedded ring-type genus-one audit carrier with outer radius \(1\) and throat radius \(w\); **not** a uniquely established source metric.

**Frozen radial laws:** reciprocal \(r_R(\theta)=1/\theta\), \(r_{L},m}(\theta)=\exp[-mb_*(\theta-1)]\) for the same six multipliers, and separately \(r_\phi(\theta)=\exp[-b_\phi(\theta-1)]\). \(b_*\), \(b_\phi\) as above; eight **distinct named branches** total (1 reciprocal + 6 generic log + 1 Golden Mean), even if some rates might coincide numerically (no such identity assumed).

**Frozen meridian/azimuth/space map (no substitution):**

\[
\begin{aligned}
s_k(r)&=\frac{\arctan(kr)}{\arctan k},\\
u_k(\theta)&=\pi[1-s_k(r(\theta))],\\
v(\theta)&=\theta-1,\\
C_{w,e,k,r}(\theta)&=X_{w,e}\bigl(u_k(\theta),v(\theta)\bigr).
\end{aligned}
\]

Each radial law shares the identical carrier, mapping and two scale choices (`G30`, `GHALF`). The published endpoint **400 cells** equal \(25\) carriers × \(8\) branches × \(2\) scales; they are **not** 400 measured projection geometries. B is **not** an endpoint-parallel historical reconstruction under the inherited audit. No recalculation of v0.8 endpoint statistics or geometric projection pairs occurs in V5.

## 5. K and ribbon scopes

`K`: the canonical ring-torus reference uses \(T(u,v)=((R+r\cos v)\cos u,(R+r\cos v)\sin u,r\sin v)\) with \(R>r>0\); \(\gamma_{3,10}(t)=T(3t,10t)\), \(0\le t\le2\pi\). Exact **metric** parameters and orientation to the fixed camera grid are **not chosen by this V5 gate**. The source's unspecified dimple transformation is not filled in. K is not an N1/N2 replacement and needs a separate reference-lane preregistration.

`R`: a centreline trace cannot be relabelled an opaque ribbon/surface silhouette without a width law, ribbon normal/twist, self-occlusion and forward-optics choice. Source data do not supply these uniquely. Status `UNRESOLVED` for finite-width/historical-shadow claims.

## 6. Boundary determination

Only A-DIAGRAM and the inherited B carrier/radial grids have documented, shared mathematical domains suitable for proposing matched-control **designs**. N0 is a geometric diagnostic only; N3 is `NULL_NOT_YET_INSTANTIATED`. `TR-ANALYTIC` is a proposed observation lane; `SET-IMAGE` requires a new whole-image equivalence proof and `CS-NONCONVEX` is deferred. The historical first-hand reconstruction and Hebrew target-use gates remain closed. No new projected counts or candidate-favouring shape choice is reported.
