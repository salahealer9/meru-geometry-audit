# V5 Continuous-Projection Certification Plan — prospective V5B only

**Scope:** implements the *design* required by signed V5; no execution, geometry evaluation, parameter search, camera-pair classification or new measured class count. **Priority** is `A-DIAGRAM` at two frozen scales and the common six signed G0 cameras. Neither candidate nor any control is authorised to run until a separate signed V5B protocol freezes the detailed proof algorithm, arithmetics and budgets.

## 1. Proposed exact forward-map contract

For a radial law $r(u)>0$ on $u\in[0,L]$, $L=3\pi$, put $\theta=1+u$ and

\[
P_{k,r}(u)=\frac{\big(k r(u)\cos(1+u),\,k r(u)\sin(1+u),\,1\big)}{\sqrt{1+k^2r(u)^2}}, \quad u\in[0,L].
\]

This is precisely $M_k$ applied to the planar source spiral; for $r(u)=1/(1+u)$ it equals the inherited spherical reciprocal expression. Use *identical* formula for every N1 radial-law substitution. Each curve is **open**, not allowed a cyclic shift. Preserve the registered inward/outward endpoint direction, and separately declare if the geometric trace equivalence also permits reversal. The default future geometric observation `TR-ANALYTIC` is path-order-aware and admits monotone reparametrisation, not reordering or deleting visits. Do not assume that analytic projection of a closed trace is a convex hull or an opaque solid silhouette.

For a camera primitive triple $t$ with $q=t\cdot t$, its *exact* projection metric is

\[
B_t(v,w)=v\cdot w-\frac{(t\cdot v)(t\cdot w)}q;
\qquad D_t(v,w)=\frac{t\cdot(v\times w)}{\sqrt q}.
\]

These identities hold pointwise for smooth and nonsmooth input curves and eliminate camera-roll choices. The G0 normal triples are $\pm e_x,\pm e_y,\pm e_z$ in signed lexicographic order. Do not add roll as a separate capacity dimension. No scale fitting or morphology-dependent normalization; translation is quotiented as a common rigid planar shift only. `SO2` and `O2` must be separately reported.

## 2. Proof obligations for complete continuous equivalence

For cameras $t,t'$ and one fixed model curve, $**equal**$ means existence of one planar orthogonal $Q$ of allowed determinant, one translation $b$, and a continuous monotone bijection $h$ (in the allowed traversal orientation) such that $\Pi_{t'}P(h(u))=Q\Pi_tP(u)+b$ for **every** parameter value. Inequality means rigorous nonexistence of such a relation. A finite sample is not a proof of either.

**Common-domain analytic strategy — optional but incomplete on its own:** equal all-point Gram *kernels* under the same parametrisation $B_t(P(u)-P(u_0),P(v)-P(u_0))$ and, for SO2, all oriented determinant kernels. Such identities are sufficient for congruence with the *same* parameter, but nonidentity of these kernels under the identity map does **not** prove inequivalence under an arbitrary monotone reparametrisation. Never misuse that shortcut.

**Correct unparameterised-trace strategy:** first establish projected regularity and strictly positive total arclength; then use a certified arclength coordinate $s\in[0,\ell_t]$ with projected speed $v_t(u)=\sqrt{B_t(P'(u),P'(u))}$. For a proper open curve, arc length supplies a canonical continuous traversal coordinate; reversal is the separate involution $s\mapsto\ell_t-s$. Equality requires $\ell_t=\ell_{t'}$ and equality of centred all-point Gram kernels indexed by common arclength, with all oriented determinant kernels additionally for SO2. Under the agreed rank and regularity hypotheses these equalities are complete for rigid congruence up to monotone reparametrisation/reversal. If projected speed has zeros or an arclength inverse fails its required regularity, provide a separate proof that handles those isolated segments/singularities or report `UNRESOLVED_PAIR`.

**Independent inequivalence witnesses:** a single *rigid invariant* rigorously different proves noncongruence, e.g. endpoints' chord squared, total arclength, or pairwise squared distance between **uniquely specified arclength locations** (such as half-arc-length), provided the chosen witness is invariant under allowed reversal. When endpoint reversal is permitted, the chord length remains invariant automatically. Other witness functionals must be symmetrized over reversal. A disjoint interval enclosure gives `UNEQUAL`. An overlap proves nothing. Distances at matching raw parameter $u$ alone are not valid inequivalence witnesses for unparameterised traces.

**Equality certificates** need full analytic functional identity or a rigorous theorem for the entire continuum, not a finite grid or an interval width below an arbitrary tolerance. Camera antipodes are **always O2-equal** for the same equivariant orthographic map, by the exact identity of all $B_{t}$ kernels under $t\mapsto-t$. For SO2 the determinant changes sign; no automatic equality is implied. Additional equalities from object symmetry must be separately certified, not assumed. Reflexivity, O2-antipodal pairing, O2-coarsening of SO2 and equivalence transitivity are mandatory structural checks.

## 3. Rigorous enclosure implementation design (to freeze in V5B)

1. **Domains:** two $k$ branches separately, open DIAGRAM interval $u\in[0,3\pi]$, the 1 reciprocal plus the already frozen Archimedean, six generic logarithmic and separately named Golden Mean controls. Deduplicate the endpoint-matched log `m=1` rather than counting it twice.
2. **Arithmetic:** interval-enclose $\pi,\tan(1/2),\sin,\cos,\exp,\log$, square roots and derivatives with a verified directed-rounding implementation. A future V5B signature must freeze software version/backend, precision start/ceiling, rational range reduction, domain subdivision strategy, error margins, resource limits and admissible interval widths before calculation.
3. **Preflight:** certify positive/finite positions, analytic endpoint limits, derivative regularity, projected rank/extent for each camera/control, and absence or treatment of curvature/tangent singularities. Distinguish mathematical cusp, numerical enclosure uncertainty and exact collapse. No prospective score is silently assigned to an invalid camera.
4. **Pairs:** enumerate ordered $6\times6$ camera comparisons for both groups with `EQUAL`, `UNEQUAL`, `UNRESOLVED_PAIR`; no guessing from small residuals. Symbolic equalities first; rigorous invariant separation when possible; full arclength-kernel equality only with a demonstrated completeness method. If the invariant enclosure overlaps zero at the resource ceiling, stop and report unresolved.
5. **Outputs:** per-camera model/scale/domain/rank/evaluability, pair certificates with witness identities or interval intervals, matrix symmetry/diagonal, computed *bounds* on class counts if any pair unresolved, and full provenance. For undecided equivalence graph edges, report safe lower/upper distinct-class bounds (possible completions of an equivalence relation respecting proved equalities and inequalities), not a forced partition. Calculating the optimum number of distinct classes among completions may require exhaustive graph-colouring/partition bounds and must itself be independently certified.
6. **Parity:** same precision ceiling, hierarchy, camera family, allowable reparametrisations, SO2/O2 options, stop rules, valid-camera thresholds and pairwise numerical work budget for reciprocal and each control. Do not selectively refine the candidate more than nulls. Distinguish explicitly *shape-law complexity* (fixed previously) and *search freedom* (none permitted in this first trial).
7. **Output labels:** `EXACT_CERTIFIED`, `INTERVAL_CERTIFIED`, `APPROXIMATE_ONLY`, `DEFERRED`, `FAILED`, and `UNRESOLVED_PAIR` at the appropriate granularity. `APPROXIMATE_ONLY` cannot support an exact class census.

## 4. Prospectively fixed validation oracles — no scientific outcomes assumed

- **Universal analytic identities:** $B_t=B_{-t}$ as forms and $D_t=-D_{-t}$; rank/extent consistency; all-pairs reflexivity; SO2→O2 containment.
- **Elementary independent fixtures:** exact straight-line finite-open curve, simple circle in a known fixed plane, and a known symmetric figure with analytic projected relations. These are new generic mathematical sanity cases, not replayed V4 scientific results, and their exact equations and expected pair labels must be signed in V5B before execution.
- **Failure-control fixtures:** exact collapse, near-collapse without tolerance shortcuts, an analytic cusp, an isolated zero-speed projection, genuine reversed traversal, and a self-overlapping trace retaining traversal multiplicity. No fixture may be selected after viewing its measured outcome.
- **Second independent method:** distinct symbolic proof/interval library or a separately developed proof checker, with source/package/import independence documented; no mere copy of the registered implementation. It must compare full matrices, every unresolved entry and the proof assumptions.

## 5. Eligibility decision

This document does not select a numerical precision, tolerance, seed, metric or implicit exactness threshold for execution: those choices belong to the *separately human-signed* V5B preregistration and implementation freeze. Until then **no candidate-vs-null projection classification is authorised**. `SET-IMAGE`, the general opaque nonconvex physical silhouette `CS-NONCONVEX`, the PROSE pole, the toroidal B full parameter grid and canonical knot reference belong to distinct later studies with independent scope control. The historical source ambiguity is not cured by formal projection certificates.
