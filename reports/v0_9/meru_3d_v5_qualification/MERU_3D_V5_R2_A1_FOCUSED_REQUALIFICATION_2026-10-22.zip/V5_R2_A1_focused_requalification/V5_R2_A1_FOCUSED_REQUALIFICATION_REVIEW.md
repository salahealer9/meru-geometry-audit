# Meru 3D-V5-R2-A1 — Focused Independent Read-Only Requalification

**Prospective post-amendment status:** `MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_QUALIFIED`.
- This is a new review decision made after the amendment.
- It does **not** revise the historical second-review verdict `MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_INCOMPLETE`, which stands as recorded (ZIP `567e2017…c13c`, unchanged).
- It licenses only the drafting of a separately signed V5B preregistration. It authorises **no** V5B computation.
- A process caveat on reviewer independence is in §6.

| Field | Value |
|---|---|
| Reviewer | Claude (Anthropic AI model; session configured `claude-opus-5-5`), isolated cloud workspace |
| Window | 2026-10-22, 13:31–14:00 UTC |
| Handoff | `MERU_3D_V5_R2_A1_CLAUDE_FOCUSED_REQUALIFICATION_HANDOFF_2026-10-22.zip`, SHA-256 `587dd6fd…81ff`; 8/8 internal sums OK |
| Labels | PASS / FAIL / DEFERRED / UNVERIFIABLE |

## 1. Signed identities (R01–R05)

**Repository and signatures:**
- **Branch head.** A fresh read-only clone and `git ls-remote` agree: the branch tip is **`9daaf5a706e9097aa98f0e27740a72f9f99b7126`**.
- **Lineage.** Its parent is `2073a5618719230c6ec4d5aad7a2941825c7fd77`. That commit's parent is `aa79d6509b95b302bd6c8092464aed7717f71554`.
- **Scope.** The commit is a one-file addition: `A docs/v0_9/meru_3d_v5_r2_a1_namespace_orientation_and_parity_qualification_amendment_2026_10_22.md`, blob **`a1ed423f9ff2f42b030a47afb2fe9df8f79e2c64`**, SHA-256 `36fb4215…82ad`, 19,893 B. The V5 protocol blob at HEAD is unchanged: `9bc215654470785f625c799371168b36e88e1a2b`.
- **Local GPG.** Run in an isolated keyring, with the public key taken from the repository's own provenance JSON (SHA-256 `af66fcd2…63b8`). Result: `GOODSIG` and `VALIDSIG D4EC014EEFCC90E619D2AA59A91239ABCF512130` on all three commits, with **`TRUST_UNDEFINED`**.
- **GitHub API.** `verified=true`, `reason=valid`, `verified_at 2026-10-22T13:23:36Z`; one added file, blob `a1ed423f`.
- **Trust basis.** Neither local GPG nor the GitHub attestation is your local `TRUST_ULTIMATE`, which was not reproduced here. The trust basis is: the signature was made by the key published in the repository, and the platform attests it.

**Handoff copies:** the protocol and amendment Markdown supplied in the handoff are byte-identical to the Git blobs.

**Review archives:**
- First review ZIP `42fa29c8…f7`: 6 members, 5/5 manifest OK.
- Second review ZIP `567e2017…c13c`: 16 members, 15/15 manifest OK. It is byte-identical to the archive this reviewer delivered. Its recorded outcome is still `…INCOMPLETE`, with B35 FAIL and B41 UNVERIFIABLE.
- The historic first-review matrix still has 38 rows (30 / 2 PROSE / 6 deferred), all `NOT_AUTHORIZED`. These were recounted from the archive, not recomputed.

R01–R05: **PASS**.

## 2. D01 — namespace (R06–R08)

**Original wording.** Re-extracted from the Git blobs:
- P0A0 §9 (`0f8b663b…`): N0 arbitrary smooth 3-D curves; N1 length/curvature/complexity-matched; N2 generic 1.5-turn vortices with non-fixed radial laws; N3 same-carrier, same-span, non-reciprocal spiral controls.
- The P0A1 ledger (`79c99f82…`) marks each of these NULL_CONTROL, with generator, distribution, size and seed UNRESOLVED.
- Amendment §1.1 restates these meanings faithfully.

**What amendment §1.2 does:**
- It introduces `V5-N0`…`V5-N3` and states that a V5-labelled control "is **not evidence** that any original P0A0/P0A1 N0–N3 null tier or later Gate-6 requirement has been satisfied".
- It says there is no one-to-one equivalence, that V5 rows are fixed design pairings rather than null draws, that the original files are not to be renamed, and that the prefixed names must cite the amendment.
- It confirms `V5-N3` is `NULL_NOT_YET_INSTANTIATED`.

**Verdict.** The collision is resolved without satisfying any original obligation by stealth. R06–R08: **PASS**. `SOURCE_CONTRACT_UNRESOLVED` for D01 is cleared prospectively.

**Editorial caveat (E1).** The "relation" column compares `V5-N1`, the radial-law substitutions, with original **N1**. The nearest original *type* is in fact **N2** (non-fixed radial laws). The blanket non-satisfaction clause prevents any harm, but an additive erratum is recommended.

## 3. D02 / B35 — orientation-sensitive certificates (R09–R17)

I re-derived each claim independently and checked it with new code (`supporting_evidence/a1_orientation_proofs.py`, 23/23). It used fully general symbolic frames and invented exact-rational polylines only.

- **R09 — formulas.** For *every* proper orthonormal frame with third row n = t/|t| (quaternion-parametrised, so all of SO(3)):
  - image Gram = `a·b − (n·a)(n·b)` = `B_t`;
  - image determinant = `n·(a×b)` = `D_t` (Binet–Cauchy identity);
  - `B_{−t} = B_t` and `D_{−t} = −D_t`, which needs only t ≠ 0.
  - For *any* two proper lifts at n and −n, the 2×2 image map has determinant −1 (P2b). The antipodal views are mirror images whatever lift is chosen. **PASS.**
- **R10 — antipodal lemma without reversal.**
  - Same-length arclength representatives force the alignment to be the identity, so Q v(s) = F v(s) for every s.
  - Determinants are preserved by Q and negated by F, so all of them vanish and the trace has affine rank ≤ 1.
  - Converse: rotating by −2θ maps u to Fu (P3b), so a collinear trace is SO(2)-congruent to its mirror.
  - A constant trace is `NOT_EVALUABLE`.
  - One certified non-zero three-point determinant therefore proves `UNEQUAL`. **PASS.**
  - Editorial (E2): raw parameters are admissible for this witness simply because affine rank does not depend on parametrisation. The amendment's stated reason, "same intrinsic arclength labelling", is true but not needed.
- **R11 — W under reflection.** W(Fg) = −W(g) symbolically (P4c); on an invented polyline, W = 1/2 for g and −1/2 for its mirror (P5c). **PASS.**
- **R12 — W under reversal.**
  - The determinant factor flips (P4d) and the displacement factor flips (P4e), so W is invariant (P4f).
  - This was confirmed by recomputing the arclength points from the *reversed vertex list*, i.e. genuinely re-anchored at the old end: W stayed at 1/2 (P5b).
  - The V-shape example (P5e/P5f) is non-collinear yet SO(2)+reversal-congruent to its mirror, and has W = 0. This shows the no-reversal lemma cannot be extended. **PASS.**
- **R13 — W is sufficient only.** A certified W ≠ 0, or disjoint W enclosures for two curves, proves SO(2) inequivalence with or without reversal: W is invariant under translation, SO(2), reparametrisation and reversal.
  - W = 0 is inconclusive. A concrete invented polyline (P5g) has W = 0 but is *not* SO(2)(+reversal)-congruent to its mirror (compare its length/turn sequences). W also vanishes whenever the first-quarter and last-quarter chords are equal.
  - The amendment states this correctly. **PASS.**
  - Note (E4): V5B should expect some W-based results to be UNRESOLVED, and may predeclare further witnesses (as §2.3 allows).
- **R14 — future obligations.** Arclength enclosure, certified inversion of s ↦ θ(s) at ℓ/4, ℓ/2 and 3ℓ/4, and the degeneracy policy are explicitly V5B obligations that fail closed to `UNRESOLVED_PAIR`; raw-θ sampling is forbidden. **PASS** as a deferral.
- **R15 — kernels.**
  - Gram-kernel equality ⇔ O(2) congruence for equal lengths. Adding the oriented kernel ⇔ SO(2) congruence, with a proper extension in the rank-1 case.
  - Reversal must re-anchor at h(ℓ). P5h shows the naive index-reversed kernel differs from the true one.
  - Distance kernels may replace Gram kernels for O(2) only. Amendment §2.4 matches this. **PASS.**
- **R16 — EQUAL needs proof.** EQUAL requires a symbolic identity, a complete kernel proof or a proved symmetry; samples and intervals cannot prove it. **PASS.**
- **R17 — matrix rules.** SO(2) and O(2) matrices are kept separate; an EQUAL component containing an UNEQUAL pair gives `FAILED`; unresolved pairs give rigorous class-count bounds. **PASS.**

**B35** is satisfied prospectively: orientation-sensitive witnesses now exist for both reversal branches.

## 4. D03 — parity supplement (R18–R19)

**What amendment §3.1 records** (it agrees with the v0.8 sources):
- Every A/B object has zero free fitted parameters.
- Fixed grid labels are distinguished from fitted parameters.
- The DIAGRAM interval is the only matched A domain.
- Inner endpoints differ for the B logarithmic controls with m ≠ 1 (`(1+3π)^(−m)`) and for the B Golden Mean (`φ^(−6)`). The outer endpoint (u=0, v=0) is common to all B objects.
- The A Golden Mean and A log m ≠ 1 controls do not match the reciprocal inner radius.
- Cameras, quotient, SO(2)/O(2), reversal, roll, chirality and precision parity are made common contracts.

**Against signed V5 §8 ("parameter counts, branch/rank validity, reason for any defer"):**
- Parameter counts are supplied.
- Rank/degeneracy validity cannot be obtained without evaluating projections, which V5 forbids at this stage. It is honestly deferred as "NOT YET CERTIFIED" to the V5B preflight, with no rank invented.
- Precision, stop, budget and interval contracts are deferred to the signed V5B protocol.

These deferrals are legitimate. R18–R19: **PASS**.

## 5. D04–D11 and preserved limitations (R20–R23)

**Discrepancies.** Every item has an adequate written disposition (ledger CSV):
- D04: mandatory B endpoint caveat.
- D05: V5-N0 comparator still not instantiated; V4 polylines usable as predeclared diagnostics.
- D06: K/C0 deferred; code defaults are not authority.
- D07: register split required in the eventual archive.
- D08: erratum for `r_{L,m}`; the checker-script claim acknowledged as inaccurate; kernel basepoint, re-anchoring, contradiction rule, open-trace wording and zero-speed handling all made explicit.
- D09: V5B subset chosen prospectively.
- D10: closed.
- D11: six-choice multiplicity acknowledged.

**Preserved limitations:**
- B41 remains a bounded `UNVERIFIABLE`: no proof of the first review's non-execution is asserted.
- This review accessed no chart, font, glyph, Hebrew target or source image; ran no V5B, candidate or control projection; and ran no V1–V4 experiment.
- No commit, push or freeze took place.

R20–R23: **PASS**.

## 6. Decision, caveats and limits

**Decision.** The material items D01 and D02 are cured by the signed amendment. D03 is adequate for qualification with legitimate V5B deferrals. D04–D11 are disposed. No identity failure or leakage was found. On the evidence, the prospective status is **`MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_QUALIFIED`**.

**Process caveat on independence (for the owner to weigh):**
- This reviewer is the same AI reviewer, in the same session, that produced the second review.
- That review *proposed* the D02 lemmas and the W witness, which the amendment adopts almost verbatim.
- The D02 checks here were re-derived with new, more general code: all proper frames, an explicit re-anchored reversal, and counterexamples showing the limits. Even so, this is not reviewer-independent confirmation of D02.
- If amendment §4.2's "genuinely independent" requirement is meant to exclude the reviewer who proposed the remedy, a short third-party check of §2 should come before the freeze.

**Editorial (non-blocking; additive erratum optional):**
- E1: the V5-N1 cross-reference should point to original N2.
- E2: the raw-parameter rationale (see R10).
- E3: the amendment's archival "DRAFT/UNSIGNED" header follows the V5 §9 practice; its authority comes from the signed commit.
- E4: W is incomplete (see R13).

**Not authorised:** any V5B calculation, precision, tolerance or execution.

The human-controlled freeze note was not prepared, completed or signed.
