"""V5-R2-A1: identity re-check of the two immutable review ZIPs and the historic 38-row matrix inventory,
plus extraction of the original P0A0 sec.9 / P0A1 ledger N0-N3 wording from Git blobs. New code; reads
archives in memory as untrusted data; recomputes no experimental result."""
import csv
import hashlib
import io
import json
import subprocess
import sys
import zipfile
from collections import Counter

first, second, repo, out = sys.argv[1:5]
res = {}


def sha(b):
    return hashlib.sha256(b).hexdigest()


for label, path, exp in [('first', first, '42fa29c800d58a4df7f8230e48db4e4271b9521fb0d6e9fa1adfb603dedbc7f7'),
                         ('second', second, '567e2017f4b6ef2717800ecd44ebedde100c6f5e84027180eee744c42f1ac13c')]:
    b = open(path, 'rb').read()
    z = zipfile.ZipFile(io.BytesIO(b))
    names = [n for n in z.namelist() if not n.endswith('/')]
    sums_name = [n for n in names if n.endswith('SHA256SUMS.txt')][0]
    base = sums_name.rsplit('/', 1)[0] + '/' if '/' in sums_name else ''
    lines = [l for l in z.read(sums_name).decode().splitlines() if l.strip()]
    ok = all(sha(z.read(base + l.split(None, 1)[1].strip())) == l.split(None, 1)[0] for l in lines)
    listed = {base + l.split(None, 1)[1].strip() for l in lines}
    res[label] = {'sha256': sha(b), 'expected': exp, 'match': sha(b) == exp, 'bytes': len(b), 'members': len(names),
                  'testzip_ok': z.testzip() is None, 'manifest_entries': len(lines), 'manifest_all_ok': ok,
                  'unlisted_members': sorted(set(names) - listed - {sums_name})}
    if label == 'first':
        csvname = [n for n in names if n.endswith('V5_CANDIDATE_NULL_PARITY_MATRIX.csv')][0]
        rows = list(csv.DictReader(io.StringIO(z.read(csvname).decode('utf-8'))))
        res['first_matrix'] = {'rows': len(rows), 'design_status': dict(Counter(r['design_status'] for r in rows)),
                               'execution_status': dict(Counter(r['execution_status'] for r in rows)),
                               'prose_ineligible': sum(1 for r in rows if r['design_status'] == 'INELIGIBLE' and 'PROSE' in r['candidate_id']),
                               'unique_ids': len({r['pair_id'] for r in rows}) == len(rows)}
    if label == 'second':
        q = json.loads(z.read([n for n in names if n.endswith('V5_SECOND_INDEPENDENT_QC.json')][0]))
        res['second_recorded'] = {'outcome': q['outcome'], 'checklist_counts': q['checklist_counts'],
                                  'B35': [c for c in q['checklist_results'] if c['id'] == 'B35'][0]['result'],
                                  'B41': [c for c in q['checklist_results'] if c['id'] == 'B41'][0]['result']}


def blob(path):
    bid = subprocess.run(['git', '-C', repo, 'rev-parse', 'HEAD:' + path], capture_output=True, text=True).stdout.strip()
    txt = subprocess.run(['git', '-C', repo, 'cat-file', 'blob', bid], capture_output=True, text=True).stdout
    return bid, txt


b0, t0 = blob('docs/p0a0_hebrew_projection_source_identity_and_synthetic_pilot_protocol_v0.9.md')
b1, t1 = blob('reports/v0_9/p0a1_methodology/source_constraint_ledger.md')
res['p0a0'] = {'blob': b0, 'expected': '0f8b663bfe2432685c9320a00c80fd6bcf436e38',
               'n_lines': [l for l in t0.splitlines() if l.strip().startswith(('- `N0`', '- `N1`', '- `N2`', '- `N3`'))]}
res['p0a1'] = {'blob': b1, 'expected': '79c99f826db184fcf95679b886abdee9644274d5',
               'n_rows': [l for l in t1.splitlines() if l.startswith(('| N0 ', '| N1 ', '| N2 ', '| N3 '))]}
json.dump(res, open(out, 'w'), indent=1)
print(json.dumps(res, indent=1))
