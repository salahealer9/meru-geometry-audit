# Command log (read-only; all exit 0 unless stated)
1. Handoff ZIP sha256 + extraction with python3 -I into empty dir; `sha256sum -c SHA256SUMS.txt` → 8/8 OK.
2. `git clone --branch hebrew-projection-capacity-v0.9` (anonymous read) into empty dir; `git rev-parse HEAD`; `git ls-remote origin refs/heads/hebrew-projection-capacity-v0.9` → 9daaf5a6…
3. `git cat-file -p HEAD`; `git show --stat`; `git diff-tree --name-status HEAD` → one A file; `git rev-parse HEAD:<amendment>` → a1ed423f…; `HEAD:<V5>` → 9bc21565…; `2073a561^` → aa79d650…; `git status --porcelain` → empty.
4. Key extracted from reports/v0_9/p0a2_target_blind_design/provenance_and_information_barrier.json (sha256 af66fcd2…); `GNUPGHOME=<empty> gpg --import`; `git verify-commit --raw` on 9daaf5a6, 2073a561, aa79d650 → GOODSIG/VALIDSIG D4EC…, TRUST_UNDEFINED, rc 0.
5. GitHub REST GET /repos/salahealer9/meru-geometry-audit/commits/9daaf5a6… (web fetch) → verified=true, reason=valid.
6. `git show HEAD:<amendment>` and `HEAD:<V5>` compared with `cmp` to handoff copies → identical.
7. `python3 -I a1_orientation_proofs.py` → 23/23, exit 0.
8. `python3 -I a1_archive_and_registry_checks.py` → archives match, manifests OK, matrix 38 (30/2/6), P0A0/P0A1 blobs match, exit 0.
9. `python3 -I build_a1_outputs.py` → CSVs, QC JSON.
No commit, push, staging, tag or reset. No V5B/candidate/control projection, class count, V1–V4 rerun, or chart/font/glyph/image access. Earlier-review scripts not imported or run.
