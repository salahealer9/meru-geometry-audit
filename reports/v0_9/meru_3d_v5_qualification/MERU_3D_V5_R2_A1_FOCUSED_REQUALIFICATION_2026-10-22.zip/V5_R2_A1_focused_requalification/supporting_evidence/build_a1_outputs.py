import csv, hashlib, json, os, sys
O, SE = sys.argv[1], os.path.join(sys.argv[1], 'supporting_evidence')
h = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()

led = [
 ('D01', 'MATERIAL_NONBLOCKING', 'Amendment §1.1-1.2', 'RESOLVED_PROSPECTIVELY', 'V5-N0..N3 namespace; explicit non-satisfaction of P0A0 §9 / P0A1 N0-N3 and Gate 6; checked against blobs 0f8b663b / 79c99f82', 'review §2; a1_archive_and_registry_checks.json; editorial E1'),
 ('D02', 'MATERIAL_NONBLOCKING', 'Amendment §2.1-2.5', 'RESOLVED_PROSPECTIVELY', 'antipodal no-reversal lemma and reversal-invariant oriented witness W valid; W sufficient only; obligations fail closed', 'review §3; a1_orientation_proofs.json P1-P5'),
 ('D03', 'EDITORIAL', 'Amendment §3.1', 'RESOLVED', 'parameter counts, endpoint mismatches, common contracts supplied; ranks/precision/stop legitimately deferred to V5B', 'review §4'),
 ('D04', 'EDITORIAL', 'Amendment §3.1, §3.2 D04', 'RESOLVED', 'B inner-endpoint non-parity stated and mandatory for later matrices', 'review §5'),
 ('D05', 'EDITORIAL', 'Amendment §3.2 D05', 'RESOLVED_AS_DEFERRAL', 'V5-N0 deterministic comparator NULL_NOT_YET_INSTANTIATED; V4 polylines usable as predeclared diagnostics', 'review §5'),
 ('D06', 'EDITORIAL', 'Amendment §3.2 D06', 'RESOLVED_AS_DEFERRAL', 'K/C0 deferred; code defaults not authority', 'review §5'),
 ('D07', 'EDITORIAL', 'Amendment §3.2 D07', 'RESOLVED_AS_FUTURE_ARCHIVE_OBLIGATION', 'split mixed provenance rows additively in eventual archive', 'review §5'),
 ('D08', 'EDITORIAL', 'Amendment §3.2 D08, §2.4-2.5', 'RESOLVED', 'erratum r_{L,m}; checker-script claim acknowledged inaccurate; basepoint/re-anchor/contradiction/open-trace/zero-speed made explicit', 'review §5'),
 ('D09', 'NOTE', 'Amendment §3.2 D09', 'RESOLVED_AS_FUTURE_OBLIGATION', 'V5B subset chosen prospectively before implementation/data', 'review §5'),
 ('D10', 'RESOLVED', 'Amendment §3.2 D10', 'CLOSED', '14/14 pre-tag objects identical', 'second review CSV'),
 ('D11', 'EDITORIAL', 'Amendment §3.2 D11', 'RESOLVED', 'six-choice multiplicity acknowledged', 'review §5'),
 ('E1', 'EDITORIAL (new)', 'Amendment §1.2 table', 'OPEN_NONBLOCKING', 'V5-N1 relation column cites original N1; nearest type is original N2; blanket clause prevents harm', 'review §2'),
 ('E2', 'EDITORIAL (new)', 'Amendment §2.2', 'OPEN_NONBLOCKING', 'raw-parameter rationale: affine rank is parametrisation-free', 'review §3 R10'),
 ('E3', 'NOTE (new)', 'Amendment header', 'OPEN_NONBLOCKING', 'archival DRAFT/UNSIGNED header; authority from signed commit per V5 §9 practice', 'review §6'),
 ('E4', 'NOTE (new)', 'Amendment §2.3', 'OPEN_NONBLOCKING', 'W incomplete; vanishes when first/last quarter chords equal; expect UNRESOLVED', 'a1_orientation_proofs P5g'),
]
with open(os.path.join(O, 'V5_R2_A1_DISCREPANCY_RESOLUTION_LEDGER.csv'), 'w', newline='') as f:
    w = csv.writer(f, lineterminator='\n'); w.writerow(['id', 'original_severity', 'referenced_clause', 'result', 'basis', 'proof_or_source_pointer']); w.writerows(led)

ids = [
 ('git_commit', 'signed amendment (branch HEAD)', '9daaf5a706e9097aa98f0e27740a72f9f99b7126', 'VALIDSIG D4EC014EEFCC90E619D2AA59A91239ABCF512130 TRUST_UNDEFINED; GitHub verified=true valid 2026-10-22T13:23:36Z'),
 ('git_commit', 'signed V5 protocol (direct parent)', '2073a5618719230c6ec4d5aad7a2941825c7fd77', 'VALIDSIG D4EC… TRUST_UNDEFINED'),
 ('git_commit', 'signed V4 freeze (grandparent)', 'aa79d6509b95b302bd6c8092464aed7717f71554', 'VALIDSIG D4EC… TRUST_UNDEFINED'),
 ('git_blob', 'amendment docs/v0_9/meru_3d_v5_r2_a1_namespace_orientation_and_parity_qualification_amendment_2026_10_22.md', 'a1ed423f9ff2f42b030a47afb2fe9df8f79e2c64', 'sha256 36fb421576d742e96c18aa84f0b8600da5bd268d106f7a96917cd427198d82ad; 19893 B; only file added'),
 ('git_blob', 'V5 protocol', '9bc215654470785f625c799371168b36e88e1a2b', 'sha256 91cdd78c77290444845e0876e2984ea2d1930f91c726d1c12384cbea484b94cb; unchanged at HEAD'),
 ('git_blob', 'P0A0 protocol (§9 N0-N3)', '0f8b663bfe2432685c9320a00c80fd6bcf436e38', 'at HEAD'),
 ('git_blob', 'P0A1 source-constraint ledger', '79c99f826db184fcf95679b886abdee9644274d5', 'at HEAD'),
 ('file', 'first review ZIP (immutable)', '42fa29c800d58a4df7f8230e48db4e4271b9521fb0d6e9fa1adfb603dedbc7f7', '19443 B; 6 members; 5/5 manifest; 38-row matrix 30/2/6 all NOT_AUTHORIZED'),
 ('file', 'second review ZIP (immutable)', '567e2017f4b6ef2717800ecd44ebedde100c6f5e84027180eee744c42f1ac13c', '61126 B; 16 members; 15/15 manifest; outcome INCOMPLETE preserved'),
 ('file', 'handoff ZIP', '587dd6fde364216ae17659df349ebf676830be3698166f94fbe3fb726d2381ff', '109650 B; 8/8 sums'),
 ('file', 'signer public key extracted from repo provenance JSON', 'af66fcd281d760d195aab4d1889215b5f4b09983fb718455a27c7cf7c58363b8', 'basis of local GPG check'),
]
with open(os.path.join(O, 'V5_R2_A1_SOURCE_AND_EVIDENCE_IDENTITIES.csv'), 'w', newline='') as f:
    w = csv.writer(f, lineterminator='\n'); w.writerow(['object_type', 'role', 'identity', 'verification']); w.writerows(ids)

R = {k: 'PASS' for k in ['R%02d' % i for i in range(1, 24)]}
ev = {'R01': 'review §1', 'R02': 'review §1', 'R03': 'review §1', 'R04': 'review §1', 'R05': 'archive checks', 'R06': 'registry extract', 'R07': 'registry extract',
      'R08': 'review §2', 'R09': 'P1a-P1d,P2a-P2b', 'R10': 'P3a-P3b,P5i', 'R11': 'P4c,P5c', 'R12': 'P4d-P4f,P5b,P5e-P5f', 'R13': 'P5f-P5g', 'R14': 'amendment §2.3 deferral',
      'R15': 'P5h; review §3', 'R16': 'amendment §2.4', 'R17': 'amendment §2.5', 'R18': 'review §4', 'R19': 'review §4', 'R20': 'ledger', 'R21': 'amendment §3.3', 'R22': 'review §5', 'R23': 'review §6'}
p = json.load(open(os.path.join(SE, 'a1_orientation_proofs.json')))
a = json.load(open(os.path.join(SE, 'a1_archive_and_registry_checks.json')))
qc = {
 'schema': 'MERU_3D_V5_R2_A1_FOCUSED_REQUALIFICATION_QC_V1', 'date': '2026-10-22', 'window_utc': '13:31-14:00',
 'reviewer': 'Claude (Anthropic AI model; session configured claude-opus-5-5)',
 'identities': {'head': '9daaf5a706e9097aa98f0e27740a72f9f99b7126', 'parent': '2073a5618719230c6ec4d5aad7a2941825c7fd77', 'grandparent': 'aa79d6509b95b302bd6c8092464aed7717f71554',
                'amendment_blob': 'a1ed423f9ff2f42b030a47afb2fe9df8f79e2c64', 'v5_blob': '9bc215654470785f625c799371168b36e88e1a2b', 'one_file_addition': True,
                'local_gpg': 'GOODSIG/VALIDSIG D4EC014EEFCC90E619D2AA59A91239ABCF512130, TRUST_UNDEFINED (isolated keyring, repo-published key)',
                'github': {'verified': True, 'reason': 'valid', 'verified_at': '2026-10-22T13:23:36Z'}, 'human_trust_ultimate_reproduced': False},
 'preservation': {'first_review': a['first'], 'first_matrix': a['first_matrix'], 'second_review': a['second'], 'second_recorded': a['second_recorded'],
                  'historical_second_review_verdict_preserved': 'MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_INCOMPLETE', 'B41_preserved_as': 'UNVERIFIABLE'},
 'namespacing': {'p0a0_blob_ok': a['p0a0']['blob'] == a['p0a0']['expected'], 'p0a1_blob_ok': a['p0a1']['blob'] == a['p0a1']['expected'],
                 'original_meanings_restated_faithfully': True, 'explicit_non_satisfaction_clause': True, 'V5_N3': 'NULL_NOT_YET_INSTANTIATED',
                 'editorial': 'E1: V5-N1 relation column cites original N1; nearest type original N2'},
 'math_orientation': {'proof_checks': '%d/%d' % (p['n_pass'], p['n_total']), 'antipodal_no_reversal_lemma': 'VALID', 'W_witness': 'VALID_SUFFICIENT_NOT_COMPLETE',
                      'reversal_reanchoring': 'VERIFIED', 'kernel_characterisation': 'VALID'},
 'checklist': [{'id': k, 'result': R[k], 'evidence': ev[k]} for k in sorted(R)],
 'discrepancies': [{'id': r[0], 'result': r[3]} for r in led],
 'blocking_items': [], 'material_open_items': [],
 'process_caveats': ['Reviewer is the same AI reviewer/session that authored the second review and proposed the D02 lemmas/W adopted by the amendment; D02 re-derived with new code but not reviewer-independent; owner may require third-party check of amendment §2 before freeze.'],
 'scope_attestation': {'v5b_execution': False, 'candidate_or_control_projection': False, 'class_counts': False, 'v1_v4_rerun': False, 'hebrew_chart_font_glyph_image_access': False,
                       'git_write': False, 'freeze_prepared_or_signed': False, 'prior_review_scripts_reused': False},
 'outcome': 'MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_QUALIFIED', 'outcome_nature': 'prospective post-amendment qualification; not a revision of the historical INCOMPLETE verdict',
 'v5b_permission': 'drafting a separately signed V5B preregistration only; no computation',
 'supporting_evidence_sha256': {os.path.relpath(os.path.join(r_, f_), O): h(os.path.join(r_, f_)) for r_, _, fs in os.walk(SE) for f_ in sorted(fs)},
}
json.dump(qc, open(os.path.join(O, 'V5_R2_A1_FOCUSED_REQUALIFICATION_QC.json'), 'w'), indent=1)
print('ok', p['n_pass'], p['n_total'])
