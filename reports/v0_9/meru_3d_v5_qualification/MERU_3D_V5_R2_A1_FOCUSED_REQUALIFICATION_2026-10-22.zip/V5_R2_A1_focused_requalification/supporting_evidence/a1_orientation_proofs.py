"""V5-R2-A1 focused requalification — fresh symbolic/exact proof checks for amendment §2.

Written new for this review (no code reused from the first or second review).
Objects: fully generic symbolic vectors/frames and small exact-rational planar polylines invented here.
No Meru candidate, control, camera class, projection count or target is evaluated.
"""
import json
import sys
from fractions import Fraction as Fr

import sympy as sp

R = []


def rec(cid, claim, ok, note=""):
    R.append({"id": cid, "claim": claim, "result": "PASS" if ok else "FAIL", "note": str(note)})


# ---------- P1: B_t and D_t equal image Gram/determinant for ANY proper orthonormal frame with third row n ----------
qa, qb, qc, qd = sp.symbols('qa qb qc qd', real=True)
N2 = qa**2 + qb**2 + qc**2 + qd**2
# rotation matrix from (unnormalised) quaternion, divided by N2 -> orthonormal, det +1
Rq = sp.Matrix([
    [qa**2 + qb**2 - qc**2 - qd**2, 2*(qb*qc - qa*qd), 2*(qb*qd + qa*qc)],
    [2*(qb*qc + qa*qd), qa**2 - qb**2 + qc**2 - qd**2, 2*(qc*qd - qa*qb)],
    [2*(qb*qd - qa*qc), 2*(qc*qd + qa*qb), qa**2 - qb**2 - qc**2 + qd**2]]) / N2
rec('P1a', 'quaternion frame is orthonormal with det +1', sp.simplify(Rq * Rq.T - sp.eye(3)) == sp.zeros(3) and sp.simplify(Rq.det() - 1) == 0)
u, v, n = Rq.row(0).T, Rq.row(1).T, Rq.row(2).T
a = sp.Matrix(sp.symbols('a1:4', real=True)); b = sp.Matrix(sp.symbols('b1:4', real=True))
img = lambda X: sp.Matrix([(u.T * X)[0], (v.T * X)[0]])
gram = (img(a).T * img(b))[0]
det = sp.Matrix.hstack(img(a), img(b)).det()
rec('P1b', 'image Gram = a.b - (n.a)(n.b) for every proper frame (all quaternions)', sp.simplify(gram - ((a.T * b)[0] - (n.T * a)[0] * (n.T * b)[0])) == 0)
rec('P1c', 'image det = n.(a x b) for every proper frame (Binet-Cauchy with u x v = n)', sp.simplify(det - (n.T * a.cross(b))[0]) == 0)
t = sp.Matrix(sp.symbols('t1:4', real=True)); q = (t.T * t)[0]
Bt = (a.T * b)[0] - (t.T * a)[0] * (t.T * b)[0] / q
Dt = (t.T * a.cross(b))[0] / sp.sqrt(q)
rec('P1d', 'with n = t/|t| (t nonzero), B_t and D_t are the amendment formulas; B_{-t}=B_t, D_{-t}=-D_t',
    sp.simplify(Bt.subs({t[0]: -t[0], t[1]: -t[1], t[2]: -t[2]}) - Bt) == 0 and
    sp.simplify(Dt.subs({t[0]: -t[0], t[1]: -t[1], t[2]: -t[2]}) + Dt) == 0,
    'requires q = t.t > 0; any nonzero primitive integer triple qualifies')

# ---------- P2: +n and -n images differ by an IMPROPER planar map for ANY pair of proper lifts ----------
phi = sp.symbols('phi', real=True)
Qroll = sp.Matrix([[sp.cos(phi), -sp.sin(phi), 0], [sp.sin(phi), sp.cos(phi), 0], [0, 0, 1]])
Flip = sp.diag(1, -1, -1)  # rotation by pi about image x-axis: proper, sends third row n -> -n
R_minus = Qroll * Flip * Rq  # general proper frame with third row -n (all such frames have this form)
rec('P2a', 'R_minus is proper and has third row -n', sp.simplify(R_minus.det() - 1) == 0 and sp.simplify(R_minus.row(2).T + n) == sp.zeros(3, 1))
M = sp.simplify(R_minus * Rq.T)
Bblk = M[:2, :2]
rec('P2b', 'image map between +n and -n views is a 2x2 block of det -1 (reflection up to rotation), third component -1',
    sp.simplify(Bblk.det() + 1) == 0 and sp.simplify(M[2, 2] + 1) == 0 and sp.simplify(M[2, 0]) == 0 and sp.simplify(M[2, 1]) == 0)

# ---------- P3: no-reversal antipodal lemma, algebra and converse ----------
g1, g2, h1, h2, al = sp.symbols('g1 g2 h1 h2 alpha', real=True)
F = sp.diag(1, -1)
Q2 = sp.Matrix([[sp.cos(al), -sp.sin(al)], [sp.sin(al), sp.cos(al)]])
G = sp.Matrix([g1, g2]); H = sp.Matrix([h1, h2])
d = lambda X, Y: sp.Matrix.hstack(X, Y).det()
rec('P3a', 'det(FX,FY) = -det(X,Y); det(QX,QY) = det(X,Y)', sp.simplify(d(F * G, F * H) + d(G, H)) == 0 and sp.simplify(d(Q2 * G, Q2 * H) - d(G, H)) == 0)
th = sp.symbols('theta', real=True)
uu = sp.Matrix([sp.cos(th), sp.sin(th)])
rec('P3b', 'converse: for a collinear curve along unit u, rotation by -2*theta maps u to Fu, so Q lambda u = F lambda u for all lambda',
    sp.simplify(Q2.subs(al, -2 * th) * uu - F * uu) == sp.zeros(2, 1))

# ---------- P4: W invariance algebra (generic points) ----------
P = {k: sp.Matrix(sp.symbols(k + 'x ' + k + 'y', real=True)) for k in ['o', 'e', 'm', 'p', 'r']}  # p = p1, r = p3
def W(o, e, m, p1, p3):
    return d(m - o, e - o) * (((p1 - o).T * (p1 - o))[0] - ((p3 - e).T * (p3 - e))[0])
W0 = W(P['o'], P['e'], P['m'], P['p'], P['r'])
c = sp.Matrix(sp.symbols('c1 c2', real=True))
rec('P4a', 'W translation invariant', sp.simplify(W(*[P[k] + c for k in 'oemp'], P['r'] + c) - W0) == 0)
rec('P4b', 'W SO(2) invariant', sp.simplify(W(*[Q2 * P[k] for k in 'oemp'], Q2 * P['r']) - W0) == 0)
rec('P4c', 'W odd under reflection', sp.simplify(W(*[F * P[k] for k in 'oemp'], F * P['r']) + W0) == 0)
detf = d(P['m'] - P['o'], P['e'] - P['o']); detr = d(P['m'] - P['e'], P['o'] - P['e'])
fac = ((P['p'] - P['o']).T * (P['p'] - P['o']))[0] - ((P['r'] - P['e']).T * (P['r'] - P['e']))[0]
facr = ((P['r'] - P['e']).T * (P['r'] - P['e']))[0] - ((P['p'] - P['o']).T * (P['p'] - P['o']))[0]
rec('P4d', 'reversal (o<->e, p1<->p3, m fixed): determinant factor changes sign', sp.simplify(detr + detf) == 0)
rec('P4e', 'reversal: displacement factor changes sign', sp.simplify(facr + fac) == 0)
rec('P4f', 'reversal: W invariant (product of two sign changes)', sp.simplify(W(P['e'], P['o'], P['m'], P['r'], P['p']) - W0) == 0)


# ---------- P5: exact polylines (invented generic objects), arclength points computed from vertices ----------
def length(seg):
    (x0, y0), (x1, y1) = seg
    L2 = (x1 - x0) ** 2 + (y1 - y0) ** 2
    s = sp.sqrt(L2)
    return sp.nsimplify(s)


def point_at(verts, frac):
    segs = list(zip(verts[:-1], verts[1:]))
    Ls = [length(sg) for sg in segs]
    tot = sum(Ls); target = frac * tot; acc = 0
    for (A, B), L in zip(segs, Ls):
        if acc + L >= target:
            lam = (target - acc) / L
            return sp.Matrix([A[0] + lam * (B[0] - A[0]), A[1] + lam * (B[1] - A[1])])
        acc += L
    return sp.Matrix(verts[-1])


def Wpoly(verts):
    o, p1, m, p3, e = [point_at(verts, sp.Rational(k, 4)) for k in range(5)]
    return sp.nsimplify(sp.simplify(W(o, e, m, p1, p3)))


gen = [(0, 0), (1, 0), (1, 2), (sp.Rational(3, 2), 2), (sp.Rational(3, 2), sp.Rational(5, 2))]
rev = list(reversed(gen))
mir = [(x, -y) for x, y in gen]
rot = [(sp.Rational(3, 5) * x - sp.Rational(4, 5) * y + 7, sp.Rational(4, 5) * x + sp.Rational(3, 5) * y - 2) for x, y in gen]
wg, wr, wm, wo = Wpoly(gen), Wpoly(rev), Wpoly(mir), Wpoly(rot)
rec('P5a', 'generic polyline: W(g)=1/2 computed from vertices', wg == sp.Rational(1, 2), wg)
rec('P5b', 'reversed vertex list (re-anchored at old end): W unchanged', wr == wg, wr)
rec('P5c', 'mirrored polyline: W = -W(g)', wm == -wg, wm)
rec('P5d', 'rotated+translated polyline (exact 3-4-5 rotation): W unchanged', wo == wg, wo)
# V-shape: non-collinear, congruent to its mirror via rotation by pi + reversal -> lemma 2.2 cannot extend; W must vanish
V = [(0, 0), (1, 1), (2, 0)]
Vm = [(x, -y) for x, y in V]
Vm_rot_rev = list(reversed([(2 - x, -y) for x, y in Vm]))  # rotate mirror by pi about (1,0), then reverse
rec('P5e', 'V-shape: mirror equals rotation(pi)+reversal of itself (SO2+rev congruent though non-collinear)',
    [tuple(p) for p in Vm_rot_rev] == [tuple(p) for p in V])
rec('P5f', 'V-shape: W = 0 (as required for any curve SO2+rev-congruent to its mirror)', Wpoly(V) == 0)
# W=0 inconclusive: straight first and last quarters
S = [(0, 0), (1, 0), (1, 1), (3, 1)]  # segment lengths 1,1,2; turns +90,-90
rec('P5g', 'straight-quarter polyline: W = 0 although (by length/turn sequences 1,1,2 vs 2,1,1 and turn signs) it is NOT SO2(+rev)-congruent to its mirror -> W=0 inconclusive, W is not complete',
    Wpoly(S) == 0, 'g: lengths (1,1,2) turns (+,-); Fg: (1,1,2),(-,+); (Fg)rev: (2,1,1)')
# re-anchoring necessity: A_rev(s,t) != A(l-s,l-t) in general
def disp(verts, frac, anchor_frac):
    return point_at(verts, frac) - point_at(verts, anchor_frac)
s1, s2 = sp.Rational(1, 4), sp.Rational(1, 2)
A_naive = d(disp(gen, 1 - s1, 0), disp(gen, 1 - s2, 0))
A_rev = d(disp(rev, s1, 0), disp(rev, s2, 0))  # true reversed curve, anchored at its own start (= old end)
rec('P5h', 'reversal requires re-anchoring: oriented kernel of reversed curve differs from naively index-reversed kernel',
    sp.simplify(A_naive - A_rev) != 0, (sp.nsimplify(A_naive), sp.nsimplify(A_rev)))
# no-reversal lemma witness: three points non-collinear => rank 2 => antipodal SO2 UNEQUAL
rec('P5i', 'three-point determinant on generic polyline nonzero (rank 2), on collinear polyline zero',
    d(point_at(gen, sp.Rational(1, 4)) - point_at(gen, 0), point_at(gen, 1) - point_at(gen, 0)) != 0 and
    d(point_at([(0, 0), (1, 1), (3, 3)], sp.Rational(1, 3)) - sp.Matrix([0, 0]), sp.Matrix([3, 3])) == 0)

out = {"schema": "meru-v5-r2-a1-orientation-proofs-1", "sympy": sp.__version__, "results": R,
       "n_pass": sum(r["result"] == "PASS" for r in R), "n_total": len(R),
       "scope": "generic symbolic objects and invented rational polylines only; no Meru candidate/control/projection/target"}
json.dump(out, open(sys.argv[1], "w"), indent=1)
print(out["n_pass"], "/", out["n_total"])
for r in R:
    if r["result"] != "PASS":
        print("FAIL", r)
