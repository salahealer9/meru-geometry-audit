# V5-R2-A1 focused requalification — CP0 identities (2026-10-22 ~13:35 UTC)
- Handoff ZIP sha256 587dd6fde364216ae17659df349ebf676830be3698166f94fbe3fb726d2381ff (109,650 B); 8/8 internal sums OK.
- Fresh clone: branch tip = ls-remote = 9daaf5a706e9097aa98f0e27740a72f9f99b7126; parent 2073a5618719230c6ec4d5aad7a2941825c7fd77; grandparent aa79d6509b95b302bd6c8092464aed7717f71554.
- Amendment commit adds exactly one file (A docs/v0_9/meru_3d_v5_r2_a1_namespace_orientation_and_parity_qualification_amendment_2026_10_22.md), blob a1ed423f9ff2f42b030a47afb2fe9df8f79e2c64, sha256 36fb421576d742e96c18aa84f0b8600da5bd268d106f7a96917cd427198d82ad (19,893 B). V5 blob 9bc21565… unchanged at HEAD (sha256 91cdd78c…).
- Isolated GNUPGHOME, key from repo provenance JSON (sha256 af66fcd2…63b8): GOODSIG+VALIDSIG D4EC014EEFCC90E619D2AA59A91239ABCF512130, TRUST_UNDEFINED, on 9daaf5a6, 2073a561, aa79d650.
- GitHub API: 9daaf5a6 verified=true reason=valid verified_at 2026-10-22T13:23:36Z; one added file, blob a1ed423f.
- Handoff signed_reference copies byte-identical to Git blobs.
- Review ZIPs: first 42fa29c8…f7 (19,443 B), second 567e2017…c13c (61,126 B), second identical to the reviewer's own delivered original.
- P0A0 blob 0f8b663b…, P0A1 ledger blob 79c99f82… at HEAD.
