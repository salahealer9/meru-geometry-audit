# Meru 3D-V5 — Second Independent Read-Only Qualification Review

**Final recommendation:** `MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_INCOMPLETE`. The reasons are in §9. No item is BLOCKING.

| Field | Value |
|---|---|
| Repository / branch | `salahealer9/meru-geometry-audit` / `hebrew-projection-capacity-v0.9` |
| Signed V5 protocol | commit `2073a5618719230c6ec4d5aad7a2941825c7fd77`; parent `aa79d6509b95b302bd6c8092464aed7717f71554`; blob `9bc215654470785f625c799371168b36e88e1a2b`; content SHA-256 `91cdd78c77290444845e0876e2984ea2d1930f91c726d1c12384cbea484b94cb` (24,459 B) |
| First review under challenge | `MERU_3D_V5_READ_ONLY_QUALIFICATION_REVIEW_2026-10-22.zip`, SHA-256 `42fa29c800d58a4df7f8230e48db4e4271b9521fb0d6e9fa1adfb603dedbc7f7` (19,443 B, 6 members) |
| Review instrument | `MERU_3D_V5_SECOND_INDEPENDENT_READ_ONLY_REVIEW_CHECKLIST_2026-10-22.md`, applied here without modifying it |
| Reviewer | Claude, an Anthropic AI model. Session configured as `claude-opus-5-5`; the serving model may differ. Ran in an isolated cloud Linux workspace on request of the repository owner. |
| Review window | 2026-10-22, 12:48–13:20 UTC |
| Status labels used | `PASS` / `FAIL` / `DEFERRED` / `UNVERIFIABLE` (user's labels) |

The other deliverables are:
- `V5_SECOND_INDEPENDENT_QC.json`
- `V5_SOURCE_AND_BLOB_VERIFICATION.csv`
- `V5_DISCREPANCY_AND_DEFERRAL_LEDGER.md`
- `SHA256SUMS.txt`
- `supporting_evidence/`: the scripts and outputs written for this review, plus timestamped checkpoints.

---

## 0. Independence declaration and limits

**What was done:**
1. **Read-only.** No Git commit, push, tag, staging or file change in the repository. The clone was used only through `rev-parse`, `cat-file`, `show`, `log`, `merge-base`, `verify-commit` and `verify-tag`.
2. **No experiment.**
   - No V5B or other projection experiment.
   - No candidate/null simulation, camera-pair decision or class count.
   - No V1–V4 rerun.
   - No historical Hebrew chart, A09 source image, glyph, font or alphabet proxy was opened or accessed.
   - No target-dependent choice was made.
3. **Order of work.**
   - The original sources were read and transcribed **before** the first-review register, matrix and plan were opened.
   - The reconstruction is timestamped in `supporting_evidence/checkpoints/CP1_…md` (mtime 12:55:24 UTC).
   - The first-review files were opened for reading only after CP1 was written (after 12:55:24 UTC).
   - Their bytes were read earlier, at 12:49 UTC, by `sha256sum -c` only, to verify checksums. Their content was not displayed then.
4. **No shared code.** The first review shipped no checker code; its review §4 says otherwise, see D08(b). No code from the first review was imported or run. All scripts in `supporting_evidence/` were written from scratch for this review.

**Limits:**
5. **The reconstruction was not formula-blind.** The checklist (B12–B17) and the handoff summary state the expected formulas. The reconstruction was therefore *verified against* the original signed texts, not produced blind. Agreement with the first review was not used as evidence. Each formula was checked against the original source (§3), and the routine identities were proved symbolically (`v5_symbolic_identity_checks`, 35/35).
6. **Institutional independence is unknown.** The authorship of the first review is not stated. If it was also produced by an AI system of the same family, this review is *procedurally* independent (separate session, separate method, no shared code) but not *institutionally* independent. The human signer should weigh this.
7. **Local GPG verification is distinct from GitHub's.**
   - The public key was extracted from the repository's own signed `reports/v0_9/p0a2_target_blind_design/provenance_and_information_barrier.json` (`public_key_armored`; key file SHA-256 `af66fcd2…63b8`) into an isolated empty `GNUPGHOME`.
   - The result, `VALIDSIG D4EC014EEFCC90E619D2AA59A91239ABCF512130`, proves the signatures were made with that key. `TRUST_UNDEFINED` means no ownertrust was asserted.
   - This is **not** the human's local trusted-key verification, and the reported `GOODSIG/VALIDSIG/TRUST_ULTIMATE` was not reproduced here.
   - GitHub's `verified: true, reason: valid` (fetched from the public API, `verified_at 2026-10-22T11:59:17Z`) is a third, separate attestation.

---

## 1. Authority and identity verification (B01–B06)

| Check | Result | Evidence |
|---|---|---|
| **B01** | **PASS** | Fresh clone; HEAD = branch tip = `2073a561…`, 0 commits ahead. Parent is exactly `aa79d650…`. The commit adds exactly one file (`git show --stat`), the V5 protocol, blob `9bc21565…`; the content SHA-256 matches. Local `verify-commit --raw`: VALIDSIG D4EC… on V5 and on the parent. GitHub API: verified/valid, same parent and blob. The signed V1–V4 protocol and freeze commits (`0e5c1ea4`, `db007d74`, `67ccaa1f`, `d7b5359f`, `aa79d650`) are all ancestors of V5 with VALIDSIG D4EC. No contradictory ancestry. |
| **B02** | **PASS** | Tag `v0.8.0` = tag object `12afd9f9d1cb4a9d000c0fd9555419f0383978e9` → commit `85748bff0bfae383afcc0d885f4aec505a2885dd`; `verify-tag`: VALIDSIG D4EC. All **14** pre-tag objects used for material A/B/K/C0 claims (12 documents and 2 code files) are blob-identical at the tag and at V5 (CSV, `IDENTICAL_AT_TAG`). The tag-target merge commit and the pre-signing-era commits that last touched the v0.5/v0.6/torus files are unsigned. Their contents are authenticated by the signed tag object, which names that tree. |
| **B03** | **PASS** | All 20 first-review path/blob pairs were parsed from the register and re-derived at V5: **20/20 MATCH**. 9 of those 20 post-date `v0.8.0`. They are v0.9 files (V5 protocol, P0A1/P0A2/P0A3, P0A2 direction design, V1–V4 freezes), each last touched by a VALIDSIG-D4EC commit that is an ancestor of V5, so the tag cannot contain them. This review also consulted 9 further objects the first review did not list: the V1–V4 protocols, P0A0, the P0A1 ledger, the truncation-parity preregistration and two code files (CSV). |
| **B04** | **PASS** | ZIP SHA-256 `42fa29c8…f7` and size match. 6 members. `SHA256SUMS.txt` lists 5 and does not list itself: 5/5 OK. The original ZIP is preserved unchanged. |
| **B05** | **PASS** | V1–V4 freezes limit themselves to finite grids, labelled projections, and PL traces/convex solids of target-blind controls. V5 §§0, 1, 2(7), 5, 8 and 9 forbid amending them, releasing optics, overriding the P0A3/P0A4 gates or exposing targets. Nothing in either review attempts any of these. |
| **B06** | **PASS** | The three attestations are distinguished in §0 item 7. Trust is not inferred from GitHub. |

---

## 2. Source-recovery boundary (B11)

**B11 — PASS.** From the v0.8 source-recovery closeout (blob `76a342c3…`, §§2–4, 12, 15):
- **Recovered:** the reciprocal seed `rθ=1`; the later `1.5 turns = 3π` convention (§8; the earlier 3.5/1.75 convention is resolved as a counting change); three projected copies at 120°; the craft route "bend until endpoint direction is parallel".
- **Missing:** the deterministic continuous shaping rule between scaffold and finished endpoint-parallel FIRST HAND. The three algebraic function sets, the unique dimpled-sphere metric and the reciprocal-to-dimpled-sphere transform were not recovered.
- **Final state, preserved unchanged:** `NO_REPRODUCIBLE_PUBLISHED_FIRST_HAND_CONSTRUCTION_RECOVERED`.

## 3. Independently reconstructed equations (B12–B18)

### 3.1 Variant A (B12, B13, B14, B15) — **PASS** for all four

**Sources:** S1 preregistration (blob `027d193a…`, §§2–6, 11), S1 closeout (`7fd63552…`), comparator preregistration (`965539f6…`, §§3–11) and comparator closeout (`b91d3d46…`).

**Model:**
- Planar law `r=1/θ` (θ>0).
- Audit map `M_k(x,y)=(kx,ky,1)/√(k²x²+k²y²+1)`, declared in prereg §4 as "a registered analytic model convention … not asserted to be the uniquely recoverable historical projection".
- Composite `Γ_k(θ)=(k cosθ, k sinθ, θ)/√(k²+θ²)`, with `‖Γ_k‖=1`.

**Domains and orientation:**
- `A-PROSE`: θ_outer→0⁺ (exact limit `(1,0,0)`, no epsilon), θ_inner=3π.
- `A-DIAGRAM`: θ∈[1,1+3π].
- Directed endpoint semantics: inner→outer, i.e. decreasing θ.
- The two domains must not be averaged, merged or selected between (prereg §3).

**Scales:** G30 `k=tan(π/6)=1/√3` and GHALF `k=tan(1/2)`, two fixed branches. `k=tan(1)` is explicitly excluded, and the asymmetry with the θ_outer=1 marker is recorded in prereg §5.

**Finding beyond the first review.** Γ_k is real-analytic at θ=0, with `Γ_k'(0)=(0,1,1/k)` (checks A03–A05).
- On S², the reciprocal PROSE curve is therefore a *regular closed arc* θ∈[0,3π]. The "pole" exists only in the planar curve.
- PROSE is ineligible for comparators for a structural reason: any comparator with a finite outer radius has `z>0` at its outer endpoint, so it can never reach the equatorial PROSE endpoint (A19). This matches the comparator prereg §4/§24.
- A later *reciprocal-only* PROSE lane would therefore be mathematically well defined. It remains outside V5B.

**DIAGRAM comparators** (comparator prereg §§5–9; u=θ−1∈[0,3π], phase θ₀=1, q_R=1/(1+3π)):
- `r_R=1/(1+u)`.
- `r_A=1−(1−q_R)u/(3π)`.
- `r_{L,m}=e^{−m b* u}`, with `b*=ln(1+3π)/(3π)≈0.248725803248475` and `m∈{0.5,0.75,1,1.25,1.5,2}`.
- `r_φ=e^{−b_φ u}`, with `b_φ=2 ln φ/π≈0.306348962530033` and `r_φ(3π)=φ^{−6}`.

**What the checks confirm (A08–A18):**
- The endpoint-matched log *is* `m=1` (A12).
- Only the Archimedean and `m=1` curves share both endpoint radii.
- The Archimedean comparator shares both *spherical* endpoints with the reciprocal (A17).
- The Golden Mean comparator matches the outer radius only (A11).

### 3.2 Variant B (B16, B17) — **PASS** for both

**Sources:** B specification (`501be812…`), B preregistration (`bfd0ac70…`, §§3–17) and B closeout (`37d0a54d…`).

**Carrier:**
- `X_{w,e}(u,v)=((R+a cos u)cos v, (R+a cos u)sin v, e a sin u)`, with `R=(1+w)/2` and `a=(1−w)/2`, so `R+a=1` and `R−a=w`.
- Grid: `w∈{.02,.05,.10,.20,.30}`, `e∈{1.4,1.6,1.8,2.0,2.2}`; 25 embedded genus-1 tori (prereg §4 proof).
- Status: a source-constrained but **non-unique** audit carrier. The source attests a dimpled-sphere torus but gives no metric (specification §9).

**Domain, laws and map:**
- θ∈[1,1+3π]; inner→outer orientation = decreasing θ.
- Radial laws are written *in θ*: `1/θ`, `exp(−m b*(θ−1))` for the six m, and `exp(−b_φ(θ−1))`. That is 8 branches.
- There is **no Archimedean branch** and **no PROSE** in B: prereg §30 prohibits "adding AOG-PROSE".
- Map: `s_k(r)=arctan(kr)/arctan k`, `u_k(θ)=π[1−s_k(r(θ))]`, `v(θ)=θ−1`, `C=X_{w,e}(u_k,v)`. The same map is used for every branch, and k appears only inside it.

**Properties checked:**
- Symbolic checks B01–B12: `X_u⊥X_v` and `|X_v|=ρ≥w>0`, so `C'≠0` everywhere. `u_k` is strictly increasing, so C is an embedded arc.
- The 400 cells (25×8×2) are endpoint-analysis cells, **not** projection observations.

### 3.3 K, C0, ribbon and optics (B18) — **PASS**, with D06

- **K.** Canonical ring torus `T(u,v)` with `R>r>0`, and `γ_{p,q}(t)=T(pt+φ_u, qt+φ_v)`, (3,10), with p counting turns around the axis (baseline blob `6fff1494…`).
  - The document fixes no numeric R, r or phases. Only code defaults exist (`R=2.0`, `r=0.75`). The v0.5 object counts were approximate (relative RMS `1e-08`).
  - Constraint C07: the source transforms the ring knot to a dimpled-sphere torus by an unknown `F_Meru`.
  - K is a reference only. The first review keeps it separate. **Correct.**
- **C0** (`theta_start=0.5`, 1.5 toroidal and 1.0 poloidal turns in code defaults) is a distinct hypothesis generator. The first review lists its document but gives it no provenance or exclusion row (D06).
- **Ribbon and optics** (constraints C02/C03/C08): width, twist, surface, material and illumination are unspecified, so the status is `UNRESOLVED`. Nothing was invented by either review.

---

## 4. Provenance register — independent, split per V5 §1 (B19)

**B19 — PASS.** The classification below was done by this reviewer. Rows of the first review that mix classes are reported as D07 (EDITORIAL).

| ID | Atomic claim | Class | Source |
|---|---|---|---|
| S01 | Reciprocal seed law rθ=1 | SOURCE_ATTESTED | recovery closeout §2 |
| S02 | Later FIRST HAND half-vortex = 1.5 turns = 3π | SOURCE_ATTESTED | recovery §§2, 8 |
| S03 | Earlier 3.5/1.75-turn convention is the same vortex, recounted | SOURCE_ATTESTED | recovery §8; v0.6 C01 |
| S04 | Three projected copies at 120° | SOURCE_ATTESTED | recovery §2 |
| S05 | Craft route: bend until endpoint direction is parallel | SOURCE_ATTESTED | recovery §§2, 4 |
| S06 | Endpoint parallelism is Tenen's self-embedment criterion; self-embedment ≠ self-similarity | SOURCE_ATTESTED | B specification §§2.1, 3 |
| S07 | Source contrasts reciprocal with Archimedean, logarithmic and Golden Mean spirals | SOURCE_ATTESTED | comparator prereg §2; B specification §2 |
| S08 | FIRST HAND associated with a dimpled-sphere torus; 3,10 ring knot "transformed to fit" it | SOURCE_ATTESTED | B specification §§2.5, 2.7; v0.6 C07 |
| S09 | Ribbon on a toroidal surface, distinct from its centreline | SOURCE_ATTESTED | v0.6 C02/C03 |
| U01 | Unique deterministic shaping rule / finished FIRST HAND coordinates | UNRESOLVED | recovery §§3, 12, 15 |
| U02 | Unique dimpled-sphere metric; ring→dimpled transform F_Meru | UNRESOLVED | B specification §9; v0.6 C07 |
| U03 | Ribbon width/normal field; material; occlusion; illumination | UNRESOLVED | v0.6 C02; V5 §3R |
| U04 | Numeric K/C0 metric and pose | UNRESOLVED (code defaults are not authority) | baseline document; D06 |
| I01 | Isotropic inverse-gnomonic map M_k | SOURCE_CONSTRAINED_INTERPRETATION | S1 prereg §4 |
| I02 | Scales G30 and GHALF | SOURCE_CONSTRAINED_INTERPRETATION | S1 prereg §5 |
| I03 | PROSE and DIAGRAM as two retained truncation interpretations | SOURCE_CONSTRAINED_INTERPRETATION | S1 prereg §3 |
| I04 | Elliptic fat torus family X_{w,e} with its 5×5 grid | SOURCE_CONSTRAINED_INTERPRETATION | B prereg §§3–6 |
| I05 | B arctan meridian map and v=θ−1 | SOURCE_CONSTRAINED_INTERPRETATION | B prereg §§11–12 |
| D01p | Exact analytic PROSE limit instead of an epsilon | INDEPENDENT_DIAGNOSTIC (method rule) | S1 prereg §6 |
| D02p | v0.8 S1/comparator/B endpoint results | INDEPENDENT_DIAGNOSTIC | closeouts |
| D03p | Canonical (3,10) ring knot K as a reference | INDEPENDENT_DIAGNOSTIC | baseline document |
| D04p | C0 reciprocal-to-torus candidate | INDEPENDENT_DIAGNOSTIC (hypothesis generator) | baseline document |
| D05p | V1–V4 camera grids and quotient rules | INDEPENDENT_DIAGNOSTIC | P0A2 D3; V1–V4 |
| N01 | Endpoint normalisation (Archimedean, log m=1) and the log m-grid on DIAGRAM | NULL_CONTROL | comparator prereg §§6–9 |
| N02 | Golden Mean rate 2 ln φ/π as a separately named comparator | NULL_CONTROL | comparator prereg §8 |
| N03 | B six-log and Golden Mean branches on identical (w,e,k) and map | NULL_CONTROL | B prereg §9 |
| N04 | V5-N0 diagnostics; V5-N3 equal-complexity generic curves | NULL_CONTROL (N3: NULL_NOT_YET_INSTANTIATED) | V5 §4 |
| X01 | V5-N0…N3 versus P0A0/P0A1 N0…N3 naming | SOURCE_CONTRACT_UNRESOLVED (V5 §2 rule) | D01 |

---

## 5. Parity matrix audit (B21–B25)

**Method:** an independent parser (`supporting_evidence/audit_parity_matrix.py`, run with `python3 -I`) read the CSV as untrusted data and compared it with control sets reconstructed from the sources.

| Check | Result | Evidence |
|---|---|---|
| **B21** | **PASS** | 38 rows with unique IDs: 30 `DESIGN_ELIGIBLE`, 2 `INELIGIBLE` (PROSE, one per scale), 6 `DEFERRED`. 38/38 are `NOT_AUTHORIZED`. Totals match the first-review QC JSON. Coverage per scale matches the sources exactly: A-DIAGRAM has 8 controls (Archimedean, 6 log, Golden Mean) × 2 scales = 16 rows; B has 7 × 2 = 14 rows. There are no invented members (no B-Archimedean, no PROSE comparator) and no duplicated m=1 row. Design eligibility is distinguished from execution permission. |
| **B22** | **PASS**, with exceptions D03 and D04 | All 30 eligible rows pair the candidate and control on the same θ-domain, k, map, (w,e) cell (B), cameras (G0), SO2/O2 branch policy, reversal policy, translation and no-scale budget, and zero fitted parameters. Precision/stop parity is asserted in plan §3.6 rather than per row. The A rows correctly disclose inner-radius non-parity; the 12 B rows other than m=1 do not (D04). The numeric parameter counts, rank-validity, degeneracy and chirality fields required by V5 §4/§8 are missing (D03; supplement in ledger §3). |
| **B23** | **PASS** within V5's own namespace; **D01 open** | N0 is diagnostic and deferred. N1 is A radial substitution. N2 is B same-carrier. N3 is `NULL_NOT_YET_INSTANTIATED` (register §6; the matrix says DEFERRED). No row supports a p-value or a pooled sample. **But** the labels conflict with the signed P0A0 §9 / P0A1 ladder (D01), which V5 §2 requires to be labelled `SOURCE_CONTRACT_UNRESOLVED`. |
| **B24** | **PASS** | P0A2 D3 and the V1 freeze give: A0 then C then E (A), A0 then E then T (B), lexicographic integer-triple order within each stratum. Counts 6/14/26 and 6/18/42; axes 3/7/13 and 3/9/21; shared G0; antipodal closure. Antipodal lift identity: P01 and L03. Roll is absorbed by the SO(2) quotient; no fitted pose. |
| **B25** | **PASS** | (i) S1/comparator values are endpoint-tangent angles of the curve at two points, not images. (ii) V4 counts are exact classes of five integer polylines and solids under a PL algorithm; V5 §§5–6 forbid applying the TR class test to analytic curves or as a set test. (iii) The 400 B cells are endpoint statistics with no camera. None of these is a projection-class observation of an analytic curve. |

---

## 6. Continuous-equivalence certification review (B31–B38)

| Check | Result | Comment |
|---|---|---|
| **B31** | **PASS** | Plan §1–2 and V5 §5 define TR-ANALYTIC correctly: ordered trace under increasing reparametrisation, with reversal as a separate branch. They do not claim set-image, occlusion or PL-sample equality. |
| **B32** | **PASS** | Theorem and proof below. The first-review statement is correct but leaves the centring undefined (D08c). |
| **B33** | **PASS** | Plan §2 and §3.3 flag zero speed, cusps, collapse, self-overlap and endpoint limits, and fail closed to UNRESOLVED. Note (D08f): isolated speed zeros do not break completeness, only enclosure. |
| **B34** | **PASS** | Chord², projected length and reversal-symmetrised arclength-located distances are valid O(2) witnesses. Raw-θ kernel differences are correctly excluded. |
| **B35** | **FAIL** (package) | The plan explains *why* SO(2) antipodal equality is not automatic, but provides **no orientation-sensitive witness**. All its witnesses are unchanged by reflection, so the 3 antipodal SO(2) pairs at G0 are structurally UNRESOLVED (D02). The proposed correction, the antipodal SO(2) lemma and a reversal-symmetric oriented witness, was checked symbolically (L04–L09). |
| **B36** | **PASS** | EQUAL only by full-domain identity or theorem; UNEQUAL by directed-rounding disjoint enclosures; exhaustion → UNRESOLVED; tools and precision frozen in V5B before execution (plan §§2, 3.2, 5). |
| **B37** | **PASS** | Trivalent pairs, transitivity, SO2⊂O2 refinement, antipodal O2 identities, rigorous class-count bounds and certified optimisation over completions (plan §§2, 3.5). Contradiction→FAILED is only implicit (D08d). |
| **B38** | **PASS** | The plan's priority is A-DIAGRAM at G0; B rows are eligible but not scheduled; SET-IMAGE, CS-NONCONVEX, PROSE, the B grid and K all go to later studies (plan §5). Scope divergence noted (D09). |

**Orthographic formulas.** The first review's projection formulas, `B_t(v,w) = v·w − (t·v)(t·w)/q` and `D_t(v,w) = t·(v×w)/√q`, equal the image-plane inner product and determinant under the signed P0A2 proper frame lift. This was checked symbolically on generic vectors (L01, L02), along with `B_{−t}=B_t` and `D_{−t}=−D_t` (L03).

### 6.1 B32 — Conditional completeness of projected-arclength kernels

**Setting.** Let γ, δ be continuous, rectifiable, non-constant open planar traces.
- Each has projected length ℓ>0 and an arclength representative γ̃ on [0,ℓ], with γ = γ̃∘σ_γ, where σ_γ is continuous, non-decreasing and onto.
- This holds for every rectifiable curve. γ is constant wherever σ_γ is constant.
- Analytic curves on compact intervals are rectifiable. This includes the PROSE arc, by A04.

**Equivalence.** γ ~ δ (TR, no reversal) means there exist non-decreasing continuous onto maps φ, ψ, a matrix Q∈O(2) (or SO(2)) and a vector c with γ∘φ = Qδ∘ψ + c.

**Step 1.** Length is unchanged by monotone reparametrisation and by rigid motions. The arclength representative of `Qδ∘ψ + c` is therefore `Qδ̃ + c`. Hence γ ~ δ ⇔ (ℓ_γ = ℓ_δ and γ̃ = Qδ̃ + c on [0,ℓ]).

**Step 2 (Gram).** Put g(s) = γ̃(s) − γ̃(0) and h(s) = δ̃(s) − δ̃(0), and suppose ⟨g(s),g(t)⟩ = ⟨h(s),h(t)⟩ for all s, t.
- Choose s_i so that the h(s_i) span W = span h, with dim d ∈ {1,2}.
- Equal Gram determinants mean the g(s_i) are independent too. Define Q on W by Q h(s_i) = g(s_i).
- Write h(s) = Σ a_i h(s_i). Then |g(s) − Qh(s)|² = |g|² − 2Σa_i⟨g(s),g(s_i)⟩ + |h|² = |g|² − 2Σa_i⟨h(s),h(s_i)⟩ + |h|² = |g|² − |h|² = 0.
- Extend Q to O(2). Then γ̃ = Qδ̃ + c. The base-point-free kernel |γ̃(s)−γ̃(t)|² is equivalent by polarisation.

**Step 3 (SO(2)).**
- If d = 2 and det(g(s),g(t)) = det(h(s),h(t)) for all s, t, then det(g(s₁),g(s₂)) = det Q·det(h(s₁),h(s₂)) with a non-zero factor, so det Q = +1.
- If d = 1, compose Q with the reflection that fixes span g pointwise; this gives det Q = +1 without changing the curve.
- Conversely, an O(2)-equivalence with det Q = −1 and d = 2 negates every determinant. The SO(2) test then fails unless D ≡ 0, i.e. d ≤ 1.

**Reversal.** Use γ̃_rev(s) = γ̃(ℓ−s). The anchored kernels must be **re-anchored** at γ̃(ℓ): g_rev(s) = γ̃(ℓ−s) − γ̃(ℓ). The determinant kernel is *not* D(ℓ−s, ℓ−t). The base-free distance kernel avoids anchoring for the Gram part. ∎

**Scope of the theorem.** This is a *characterisation*, not an algorithm. Certifying EQUAL by kernel identity in arclength coordinates requires symbolic identity of transcendental functions after a non-closed-form reparametrisation. In practice, EQUAL certificates in V5B will come from structural theorems: identical camera, antipodal O(2), and proven object symmetries. Interval arithmetic can certify only UNEQUAL.

### 6.2 B35 — Antipodal lemma (proposed correction for V5B)

**Setting.** The views +t and −t of one open curve are γ and Fγ, with F = diag(1,−1) (P01, L03), and they share one arclength parametrisation.

**Case 1: reversal not permitted.**
- An SO(2) alignment must preserve arclength from the start, so it is the identity.
- Then det(Fg(s),Fg(t)) = −det(g(s),g(t)) must equal det(Qg(s),Qg(t)) = det(g(s),g(t)) (L04). So the views are SO(2)-equal ⇔ the projected trace is collinear.
- One certified non-zero D_t(P(u₁)−P(u₀), P(u₂)−P(u₀)), at **raw** parameters, therefore certifies UNEQUAL.
- Raw parameters are legitimate *only here*, because the alignment is forced to be the identity.

**Case 2: reversal permitted.** The lemma does not apply. Use the witness W = det(m−o, e−o)·(|p₁−o|² − |p₃−e|²), with o and e the endpoints and m, p₁, p₃ the points at arclength ℓ/2, ℓ/4 and 3ℓ/4.
- W is unchanged by translation, SO(2) and reversal, and changes sign under reflection (L06–L09).
- W requires certified arclength inversion.

---

## 7. Boundaries and deliverables (B41–B44)

| Check | Result | Evidence |
|---|---|---|
| **B41** | **PASS** for this review; **UNVERIFIABLE** for the first review | **This review:** command log in §8; checks restricted to identities and generic lemmas, with scope attestations in each JSON; no image or font files opened; no Git write. **First review:** its six files contain no projection outputs, scores or target material. A keyword and number scan found only its own non-access statements, with no long decimals in the Markdown. Non-execution, however, cannot be proved from documents. There is no evidence of leakage, so no basis for BLOCKED. |
| **B42** | **PASS** | `V5_DISCREPANCY_AND_DEFERRAL_LEDGER.md`: D01–D11 with severity, correction and amendment need. The first-review archive is untouched. |
| **B43** | **PASS** | This document, the CSV, the JSON, the ledger, the supporting evidence and SHA256SUMS. |
| **B44** | **Selected** | `MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_INCOMPLETE` (§9). |

---

## 8. Command and provenance log (abridged; all read-only)

- `git clone` (anonymous read) of the repository.
- `git -C git_v5 rev-parse HEAD` → `2073a561…`.
- `git show --stat`; `git rev-parse <commit>:<path>` for every source at V5 and `v0.8.0`.
- `git cat-file -p` on the tag and commits.
- `git merge-base --is-ancestor` for lineage.
- `GNUPGHOME=<isolated> git verify-commit --raw` and `verify-tag --raw`. The key was imported from the repository provenance JSON.
- `git rev-list 85748bff..2073a561`: 46 commits, all VALIDSIG D4EC.
- GitHub REST `GET /repos/salahealer9/meru-geometry-audit/commits/2073a561…`: `verification.verified=true`, `reason=valid`. Fetched through the web tool, because `gh api` was refused for this repository (403).
- The first-review ZIP was extracted with `python3 -I` into a new empty directory; `sha256sum -c SHA256SUMS.txt`.
- `python3 -I supporting_evidence/v5_symbolic_identity_checks.py` → 35/35.
- `python3 -I supporting_evidence/v5_projection_lemma_checks.py` → 9/9.
- `python3 -I supporting_evidence/audit_parity_matrix.py` → 38 rows, coverage equal to the sources.
- `python3 -I supporting_evidence/build_source_csv.py` → CSV with 40 rows: 29 Git blobs, 3 commits, 1 tag and 7 file rows; 20/20 first-review blobs MATCH.
- Tools: sympy 1.13.3 (PyPI) on the workspace Python.
- Checkpoints were written to `supporting_evidence/checkpoints/` with SHA-256, and copied to the attached Project. The time labels written *inside* CP1/CP2 are approximate; the file mtimes (UTC) are authoritative: CP0 12:49:48, CP1 12:55:24, CP2 13:01:18.

---

## 9. Decision and reasoning

**Outcome:** `MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_INCOMPLETE`.

**What passes independently:**
- Every identity: V5 commit, parent, blob, signatures, tag, 20/20 first-review blobs, the 14-object tag census and the first-review archive.
- Every source transcription: A domains, map and scales; the A comparators and m=1 deduplication; the B carrier, grid, laws and map; the K/C0/ribbon separation.
- The design-level parity of all 30 eligible pairings, and the PROSE ineligibility.
- The first review is accurate on all of these. No source content needed to be invented.

**Why not QUALIFIED:**
1. **D01: unresolved conflict between signed documents.** V5 redefines N0–N3 against the signed P0A0 §9 / P0A1 ladder without acknowledging it. Under V5 §2, a conflict with an authoritative source must be labelled `SOURCE_CONTRACT_UNRESOLVED`. Under V5 §2(7), V5 may not supersede the earlier gates. While this stands, the null design is not "adequately specified" with respect to its governing records.
2. **D02: essential check B35 fails against the accepted plan.** The plan has no orientation-sensitive witness and no antipodal SO(2) rule. Its SO(2) branch therefore cannot resolve mirror-image pairs, as designed. The checklist names B35 an essential check, and its stop rule forbids a positive freeze with an uncorrected essential proof item.
3. **Correction route.** Both are *material corrections*. The freeze-note draft (§4) says these require "a separately signed amendment rather than an unqualified PASS". This reviewer cannot create or sign that amendment. That is reserved to the human.

**Alternative reading considered.** Read literally, the signed V5 text defines INCOMPLETE as a gap "not supportable without inventing source content", and allows QUALIFIED "with explicitly deferred continuous-geometry proof".
- Under that reading, D02 could be treated as a permitted V5B deferral and D01 as nomenclature.
- This review does not adopt that reading, for three reasons: (a) the checklist the human supplied makes B35 essential; (b) V5 §2 itself requires the `SOURCE_CONTRACT_UNRESOLVED` label for D01; (c) the freeze-note draft requires a signed amendment for material corrections.
- The human may weigh this. Neither defect is BLOCKING. Both are curable without new source content.

**Path to a QUALIFIED determination.** This is a prospective suggestion, not authorisation:
- **(i)** A narrow, human-signed additive amendment that:
  - namespaces the V5 tiers and states the mapping to, and non-discharge of, P0A0/P0A1 N0–N3 (D01);
  - adds the antipodal SO(2) lemma and an oriented, reversal-aware witness class to the certification plan, together with the D08(c)/(d) clarifications (D02);
  - optionally adopts the D03 supplement and the D04–D07 notes.
- **(ii)** A short read-only confirmation that the amendment matches this ledger.

No V5B protocol, calculator, precision, tolerance or execution is authorised by this review.

**Retained under any outcome:**
- `NO_REPRODUCIBLE_PUBLISHED_FIRST_HAND_CONSTRUCTION_RECOVERED`.
- A and B are audit reconstructions only.
- V1–V4 remain unchanged.
- TR-ANALYTIC, SET-IMAGE, CS-NONCONVEX, optics, N3 and Hebrew specificity are all uncertified.
- The target barrier is closed.

---

## 10. Reviewer receipt (checklist §C values, supplied here; the checklist file itself was not edited)

| Receipt field | Value |
|---|---|
| Reviewer identity, time, method | Claude (Anthropic AI model; configured `claude-opus-5-5`), 2026-10-22 12:48–13:20 UTC. Independent source-first transcription, symbolic identity and lemma checks, and an independent matrix parser. See §0 for limits. |
| Signed protocol and first-review bytes verified | Yes: blob `9bc21565…`, SHA-256 `91cdd78c…`; ZIP `42fa29c8…`, 5/5 internal sums. |
| Historical source-tag identity comparison | 14/14 pre-tag objects identical at `v0.8.0` (tag VALIDSIG D4EC); 15 post-tag v0.9 objects explained. |
| Essential checks | 32 checks, B01–B44: **30 PASS** (B44 = outcome selected), **1 FAIL (B35)**, **1 UNVERIFIABLE** (B41; PASS for this review's own conduct, UNVERIFIABLE for the first review's non-execution), **0 DEFERRED**. |
| Material discrepancy ledger | D01 and D02 MATERIAL_NONBLOCKING; D03–D08 and D11 EDITORIAL; D09 NOTE; D10 RESOLVED; no BLOCKING. |
| Final outcome and caveats | `MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_INCOMPLETE` (§9). |
| Report path and SHA-256 | `V5_second_independent_review/V5_SECOND_INDEPENDENT_REVIEW.md`; the hash is in `SHA256SUMS.txt`. |
| Separately signed reviewer attestation | None. An AI reviewer holds no signing key. |

The human-controlled freeze note was read but **not** completed, signed, staged or pushed.
