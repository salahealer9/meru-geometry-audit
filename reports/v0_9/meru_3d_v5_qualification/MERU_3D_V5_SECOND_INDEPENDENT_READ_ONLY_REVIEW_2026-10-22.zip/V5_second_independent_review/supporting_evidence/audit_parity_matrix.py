"""Second independent V5 review: row-by-row audit of the first review's parity matrix.

Written from scratch; reads the CSV as untrusted data (python3 -I). Applies rules reconstructed by the
second reviewer from the signed sources (see CP1). Evaluates no geometry, projection, or score.
"""
import csv
import collections
import json
import sys

path, out = sys.argv[1], sys.argv[2]
raw = open(path, 'rb').read()
rows = list(csv.DictReader(open(path, newline='', encoding='utf-8')))

# ---- rules reconstructed from signed sources ----
A_LOG_M = ['0.50', '0.75', '1.00', '1.25', '1.50', '2.00']
expected_A_controls = ['A_ARCH'] + ['A_LOG_m' + m for m in A_LOG_M] + ['A_GOLDEN']  # v0.8 comparator prereg sec 6-9
expected_B_controls = ['B_LOG_m' + m for m in A_LOG_M] + ['B_GOLDEN']  # v0.8 B prereg sec 9 (no Archimedean)
ENDPOINT_MATCHED = {'A_ARCH', 'A_LOG_m1.00', 'B_LOG_m1.00'}

findings = []
per_row = []
for r in rows:
    pid, cand, ctl, tier = r['pair_id'], r['candidate_id'], r['control_id'], r['control_tier']
    st, ex = r['design_status'], r['execution_status']
    notes = []
    verdict = 'CONSISTENT'
    if ex != 'NOT_AUTHORIZED':
        verdict = 'DISCREPANCY'; notes.append('execution_status not NOT_AUTHORIZED')
    dom = r['model_domain']
    if cand.startswith('A_DIAGRAM'):
        if '[1,1+3pi]' not in dom.replace(' ', ''):
            verdict = 'DISCREPANCY'; notes.append('A-DIAGRAM domain text mismatch')
        if ctl in ENDPOINT_MATCHED and 'Both endpoint radii' not in r['matching_constraints']:
            verdict = 'DISCREPANCY'; notes.append('endpoint-matched control not labelled as such')
        if ctl not in ENDPOINT_MATCHED and ctl.startswith('A_') and 'Both endpoint radii fixed' in r['matching_constraints']:
            verdict = 'DISCREPANCY'; notes.append('non-matched control wrongly labelled endpoint-matched')
        if ctl == 'A_LOG_m1.00':
            notes.append('same mathematical object as v0.8 "endpoint-matched logarithmic" comparator; must not be counted twice')
        if ctl == 'A_GOLDEN':
            notes.append('Golden Mean inner radius phi^-6 != q_R (named comparator, not endpoint matched)')
    if cand.startswith('A_PROSE'):
        if st == 'DESIGN_ELIGIBLE':
            verdict = 'DISCREPANCY'; notes.append('PROSE comparison marked eligible; v0.8 comparator prereg sec 4 forbids')
    if cand.startswith('B_'):
        if ctl.startswith('B_ARCH'):
            verdict = 'DISCREPANCY'; notes.append('Variant-B has no registered Archimedean branch (invented member)')
        if '[1,1+3pi]' not in dom.replace(' ', ''):
            notes.append('check B domain text: ' + dom)
        if ctl == 'B_LOG_m1.00':
            notes.append('only B log branch sharing reciprocal inner radius')
    # tier label namespace check vs P0A0 sec 9 / P0A1 ledger
    p0a0_meaning = {'N0': 'arbitrary smooth 3-D curves', 'N1': 'length/curvature/complexity matched',
                    'N2': 'generic 1.5-turn non-fixed radial law', 'N3': 'same-carrier same-span non-reciprocal'}
    if tier in p0a0_meaning:
        notes.append('tier label %s here (V5 meaning) differs from signed P0A0/P0A1 meaning "%s"' % (tier, p0a0_meaning[tier]))
    per_row.append({'pair_id': pid, 'candidate': cand, 'control': ctl, 'tier': tier, 'scale': r['scale'],
                    'design_status': st, 'execution_status': ex, 'camera_count': r['camera_count'],
                    'observation_lane': r['observation_lane'], 'defer_reason': r['defer_reason'],
                    'second_review_verdict': verdict, 'notes': notes})

c = collections.Counter(r['design_status'] for r in rows)
pairs = collections.Counter((r['candidate_id'], r['scale']) for r in rows)
ctl_by_cand = collections.defaultdict(set)
for r in rows:
    ctl_by_cand[(r['candidate_id'], r['scale'])].add(r['control_id'])
coverage = {}
for (cand, sc), ctls in sorted(ctl_by_cand.items()):
    if cand.startswith('A_DIAGRAM'):
        missing = sorted(set(expected_A_controls) - ctls); extra = sorted(ctls - set(expected_A_controls))
    elif cand.startswith('B_'):
        missing = sorted(set(expected_B_controls) - ctls); extra = sorted(ctls - set(expected_B_controls))
    else:
        missing, extra = [], []
    coverage['%s|%s' % (cand, sc)] = {'controls': sorted(ctls), 'missing_vs_sources': missing, 'extra_vs_sources': extra}

summary = {
    'schema': 'meru-v5-second-review-matrix-audit-1',
    'input_sha256': __import__('hashlib').sha256(raw).hexdigest(),
    'n_rows': len(rows),
    'design_status_counts': dict(c),
    'execution_status_counts': dict(collections.Counter(r['execution_status'] for r in rows)),
    'tier_counts': dict(collections.Counter(r['control_tier'] for r in rows)),
    'candidate_scale_counts': {'%s|%s' % k: v for k, v in sorted(pairs.items())},
    'coverage_vs_reconstructed_sources': coverage,
    'unique_pair_ids': len(set(r['pair_id'] for r in rows)) == len(rows),
    'rows_with_discrepancy': [p['pair_id'] for p in per_row if p['second_review_verdict'] != 'CONSISTENT'],
    'per_row': per_row,
}
json.dump(summary, open(out, 'w'), indent=1)
print(json.dumps({k: v for k, v in summary.items() if k not in ('per_row', 'coverage_vs_reconstructed_sources')}, indent=1))
for k, v in coverage.items():
    print(k, 'n=%d' % len(v['controls']), 'missing', v['missing_vs_sources'], 'extra', v['extra_vs_sources'])
for p in per_row:
    print(p['pair_id'], '|', p['tier'], '|', p['design_status'], '|', p['camera_count'], '|', p['defer_reason'][:110])
