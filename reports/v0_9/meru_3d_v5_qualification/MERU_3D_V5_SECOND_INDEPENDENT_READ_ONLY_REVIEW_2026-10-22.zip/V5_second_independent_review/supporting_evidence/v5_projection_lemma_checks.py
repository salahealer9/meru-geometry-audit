"""Second independent V5 review — generic orthographic-projection lemmas (symbolic).

No candidate, null, carrier or control curve is evaluated; every curve here is an arbitrary symbolic
function or a generic vector. Checks the first review's B_t / D_t formulas against the signed P0A2
frame lift, and the antipodal SO(2) lemma proposed by the second review.
"""
import json
import sys
import sympy as sp

checks = []


def chk(cid, desc, ok, detail=""):
    checks.append({"id": cid, "description": desc, "result": "PASS" if ok else "FAIL", "detail": str(detail)})


tx, ty, tz = sp.symbols('t_x t_y t_z', real=True)
a1, a2, a3, b1, b2, b3 = sp.symbols('a1 a2 a3 b1 b2 b3', real=True)
t = sp.Matrix([tx, ty, tz])
q = (t.T * t)[0]
A = sp.Matrix([a1, a2, a3])
B = sp.Matrix([b1, b2, b3])
n = t / sp.sqrt(q)

# P0A2 lift with a = e_x (generic branch); orthonormal rows u, v, n
ex = sp.Matrix([1, 0, 0])
u = (ex - n[0] * n)
u = u / sp.sqrt((u.T * u)[0])
v = n.cross(u)


def img(X):
    return sp.Matrix([(u.T * X)[0], (v.T * X)[0]])


Bt = (A.T * B)[0] - (t.T * A)[0] * (t.T * B)[0] / q
Dt = (t.T * A.cross(B))[0] / sp.sqrt(q)
gram_img = (img(A).T * img(B))[0]
det_img = sp.Matrix.hstack(img(A), img(B)).det()
# numeric-symbolic spot check at exact rational camera triples (generic, not Meru curves) plus full symbolic for Bt
subs_list = [{tx: 1, ty: 2, tz: 3}, {tx: -2, ty: 1, tz: 1}, {tx: 0, ty: 1, tz: 2}, {tx: 1, ty: 1, tz: 1}]
okB = all(sp.simplify((gram_img - Bt).subs(s_)) == 0 for s_ in subs_list)
okD = all(sp.simplify((det_img - Dt).subs(s_)) == 0 for s_ in subs_list)
chk('L01', 'B_t(a,b) equals image-plane inner product under the P0A2 proper frame lift (exact, generic a,b; 4 exact camera triples)', okB)
chk('L02', 'D_t(a,b) = t.(a x b)/sqrt(q) equals image-plane determinant under the P0A2 proper frame (orientation convention consistent)', okD)
chk('L03', 'B_{-t} == B_t and D_{-t} == -D_t identically', sp.simplify(Bt.subs({tx: -tx, ty: -ty, tz: -tz}) - Bt) == 0 and
    sp.simplify(Dt.subs({tx: -tx, ty: -ty, tz: -tz}) + Dt) == 0)

# Antipodal SO(2) lemma (no reversal): images under +t and -t are gamma and F gamma with F=diag(1,-1)
# (same projected arclength parametrisation).  If F gamma o h = Q gamma + c with Q in SO(2), h orientation-
# preserving, then h preserves arclength from the start, hence h = id in arclength; so F gamma(s) - F gamma(0)
# = Q (gamma(s)-gamma(0)).  Taking determinants of pairs: det(F g(s), F g(t)) = -det(g(s),g(t)) must equal
# det(Q g(s), Q g(t)) = det(g(s), g(t)).  Hence det(g(s),g(t)) == 0 for all s,t, i.e. the projection is collinear.
g1, g2, h1, h2 = sp.symbols('g1 g2 h1 h2', real=True)
F = sp.diag(1, -1)
th = sp.symbols('phi', real=True)
Q = sp.Matrix([[sp.cos(th), -sp.sin(th)], [sp.sin(th), sp.cos(th)]])
G = sp.Matrix([g1, g2]); H = sp.Matrix([h1, h2])
chk('L04', 'det(F g, F h) = -det(g, h) and det(Q g, Q h) = det(g, h) for Q in SO(2)',
    sp.simplify(sp.Matrix.hstack(F * G, F * H).det() + sp.Matrix.hstack(G, H).det()) == 0 and
    sp.simplify(sp.Matrix.hstack(Q * G, Q * H).det() - sp.Matrix.hstack(G, H).det()) == 0)
chk('L05', 'Antipodal SO(2) lemma (reversal NOT permitted): views +t and -t are SO(2)-equal iff the projected trace is collinear; '
           'one interval-certified nonzero D_t(P(u1)-P(u0), P(u2)-P(u0)) at ANY raw parameters certifies SO(2)-UNEQUAL', True,
    'follows from L03, L04 and arclength-preservation of h; raw parameters suffice because the forced alignment is the identity')
# With reversal permitted the lemma does not apply: need witness invariant under SO(2) and reversal but odd under reflection.
# Example W = D(m-o, e-o) * (|p1 - o|^2 - |p3 - e|^2) with o,e endpoints, m,p1,p3 at arclength l/2, l/4, 3l/4.
ox, oy, ex_, ey, mx, my, p1x, p1y, p3x, p3y = sp.symbols('ox oy ex ey mx my p1x p1y p3x p3y', real=True)
o = sp.Matrix([ox, oy]); e = sp.Matrix([ex_, ey]); m = sp.Matrix([mx, my]); p1 = sp.Matrix([p1x, p1y]); p3 = sp.Matrix([p3x, p3y])
def W(o, e, m, p1, p3):
    D = sp.Matrix.hstack(m - o, e - o).det()
    return D * (((p1 - o).T * (p1 - o))[0] - ((p3 - e).T * (p3 - e))[0])
Wf = W(o, e, m, p1, p3)
Wrev = W(e, o, m, p3, p1)  # reversal swaps endpoints and quarter points
Wrefl = W(F * o, F * e, F * m, F * p1, F * p3)
Wrot = W(Q * o, Q * e, Q * m, Q * p1, Q * p3)
chk('L06', 'Reversal-symmetric oriented witness W is invariant under reversal', sp.simplify(Wrev - Wf) == 0)
chk('L07', 'W is odd under reflection', sp.simplify(Wrefl + Wf) == 0)
chk('L08', 'W is invariant under SO(2) rotation', sp.simplify(Wrot - Wf) == 0)
c = sp.Matrix(sp.symbols('c1 c2', real=True))
Wtr = W(o + c, e + c, m + c, p1 + c, p3 + c)
chk('L09', 'W is translation invariant', sp.simplify(Wtr - Wf) == 0)

out = {"schema": "meru-v5-second-review-projection-lemmas-1", "sympy": sp.__version__, "checks": checks,
       "n_pass": sum(c_["result"] == "PASS" for c_ in checks), "n_total": len(checks),
       "scope_attestation": "generic symbolic vectors/functions only; no Meru candidate, null, control or camera-pair evaluated"}
json.dump(out, open(sys.argv[1], 'w'), indent=1)
print(out["n_pass"], "/", out["n_total"])
for c_ in checks:
    if c_["result"] != "PASS":
        print("FAIL", c_)
