import hashlib
import json
import os
import sys

D = sys.argv[1]
SE = os.path.join(D, 'supporting_evidence')


def h(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


checks = [
    ('B01', 'PASS', 'review §1; CSV git_commit rows; GitHub API verified=true/valid'),
    ('B02', 'PASS', 'CSV tag_comparison: 14/14 IDENTICAL_AT_TAG; verify-tag VALIDSIG D4EC'),
    ('B03', 'PASS', 'CSV first_review_blob_match 20/20 MATCH; 9 post-tag explained; 9 extra objects'),
    ('B04', 'PASS', 'ZIP sha256 42fa29c8…; 5/5 internal sums; 6 members'),
    ('B05', 'PASS', 'review §1 B05'),
    ('B06', 'PASS', 'review §0 item 7'),
    ('B11', 'PASS', 'review §2'),
    ('B12', 'PASS', 'review §3.1; symbolic A01-A02'),
    ('B13', 'PASS', 'review §3.1; symbolic A03-A07, A18'),
    ('B14', 'PASS', 'review §3.1; symbolic A08-A16'),
    ('B15', 'PASS', 'review §3.1; symbolic A11, A12, A17, A19'),
    ('B16', 'PASS', 'review §3.2; symbolic B01-B06'),
    ('B17', 'PASS', 'review §3.2; symbolic B07-B12'),
    ('B18', 'PASS', 'review §3.3; ledger D06'),
    ('B19', 'PASS', 'review §4 split register; ledger D07'),
    ('B21', 'PASS', 'matrix_audit.json'),
    ('B22', 'PASS', 'review §5; exceptions ledger D03, D04'),
    ('B23', 'PASS', 'within V5 namespace; ledger D01 SOURCE_CONTRACT_UNRESOLVED'),
    ('B24', 'PASS', 'review §5; symbolic P01, L03'),
    ('B25', 'PASS', 'review §5'),
    ('B31', 'PASS', 'review §6'),
    ('B32', 'PASS', 'review §6.1 proof'),
    ('B33', 'PASS', 'review §6; ledger D08f'),
    ('B34', 'PASS', 'review §6'),
    ('B35', 'FAIL', 'plan lacks orientation-sensitive witnesses; ledger D02; correction lemmas L04-L09'),
    ('B36', 'PASS', 'review §6'),
    ('B37', 'PASS', 'review §6; ledger D08d'),
    ('B38', 'PASS', 'review §6; ledger D09'),
    ('B41', 'UNVERIFIABLE', 'PASS for this review; first-review non-execution not provable from documents; no leakage evidence'),
    ('B42', 'PASS', 'V5_DISCREPANCY_AND_DEFERRAL_LEDGER.md'),
    ('B43', 'PASS', 'this package'),
    ('B44', 'PASS', 'outcome selected: MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_INCOMPLETE'),
]
from collections import Counter
cnt = Counter(c[1] for c in checks)
disc = [
    ('D01', 'MATERIAL_NONBLOCKING', 'V5 N0-N3 labels conflict with signed P0A0 §9 / P0A1 ledger ladder; SOURCE_CONTRACT_UNRESOLVED', 'human-signed additive namespace clarification'),
    ('D02', 'MATERIAL_NONBLOCKING', 'certification plan has no orientation-sensitive witness; SO2 antipodal pairs structurally unresolved (B35)', 'signed amendment to plan / V5B protocol'),
    ('D03', 'EDITORIAL', 'matrix lacks numeric parameter counts, rank validity, degeneracy, chirality, precision fields', 'additive supplement (ledger §3)'),
    ('D04', 'EDITORIAL', 'B rows omit inner-endpoint non-parity for 6/7 controls', 'additive note'),
    ('D05', 'EDITORIAL', 'N0 composition not enumerated; deterministic 3D comparator undefined', 'V5B decision'),
    ('D06', 'EDITORIAL', 'K/C0 metric only code defaults; C0 lacks provenance/exclusion row', 'additive note'),
    ('D07', 'EDITORIAL', 'mixed-class register rows B01, N01; F02 double claim', 'split register (review §4)'),
    ('D08', 'EDITORIAL', 'typo; absent checker script claim; centring; contradiction rule; wording; regularity precondition', 'additive record'),
    ('D09', 'NOTE', 'V5B scope divergence (8 controls vs 3-curve pilot)', 'human decision in V5B'),
    ('D10', 'RESOLVED', 'full v0.8.0 tag census completed: 14/14 identical', 'none'),
    ('D11', 'EDITORIAL', 'log-grid multiplicity bookkeeping', 'V5B rule'),
]
out = {
    'schema': 'MERU_3D_V5_SECOND_INDEPENDENT_QC_V1',
    'date': '2026-10-22',
    'review_window_utc': '12:48-13:20',
    'reviewer': 'Claude (Anthropic AI model; session configured claude-opus-5-5; serving model may differ)',
    'independence': {
        'source_first_reconstruction_before_reading_first_review': True,
        'cp1_checkpoint_mtime_utc': '2026-10-22T12:55:24Z',
        'first_review_code_imported': False,
        'first_review_shipped_code': False,
        'formula_blind': False,
        'formula_blind_note': 'checklist B12-B17 states expected formulas; reconstruction verified against original sources',
        'institutional_independence': 'UNKNOWN (first-review authorship not stated)',
    },
    'identities': {
        'v5_commit': '2073a5618719230c6ec4d5aad7a2941825c7fd77',
        'parent': 'aa79d6509b95b302bd6c8092464aed7717f71554',
        'protocol_blob': '9bc215654470785f625c799371168b36e88e1a2b',
        'protocol_sha256': '91cdd78c77290444845e0876e2984ea2d1930f91c726d1c12384cbea484b94cb',
        'one_file_scope': True,
        'local_gpg': 'VALIDSIG D4EC014EEFCC90E619D2AA59A91239ABCF512130; TRUST_UNDEFINED; isolated GNUPGHOME; key from repo provenance JSON',
        'local_trusted_key_verification_by_human_reproduced': False,
        'github_verification': {'verified': True, 'reason': 'valid', 'verified_at': '2026-10-22T11:59:17Z'},
        'v0_8_0_tag_object': '12afd9f9d1cb4a9d000c0fd9555419f0383978e9',
        'v0_8_0_target': '85748bff0bfae383afcc0d885f4aec505a2885dd',
        'v0_8_0_tag_signature': 'VALIDSIG D4EC014EEFCC90E619D2AA59A91239ABCF512130',
        'pre_tag_objects_identical_at_tag': '14/14',
        'post_tag_objects_explained': 15,
        'first_review_register_blobs_match': '20/20',
        'commits_after_tag_target_validsig': '46/46',
        'first_review_zip_sha256': '42fa29c800d58a4df7f8230e48db4e4271b9521fb0d6e9fa1adfb603dedbc7f7',
        'first_review_internal_sums': '5/5 OK; 6 members',
    },
    'independent_matrix_audit': {'rows': 38, 'design_eligible': 30, 'ineligible_prose': 2, 'deferred': 6,
                                 'execution_authorized': 0, 'A_controls_per_scale': 8, 'B_controls_per_scale': 7,
                                 'invented_members': 0, 'm1_duplicated': False},
    'symbolic_checks': {'identities': '35/35', 'projection_lemmas': '9/9'},
    'checklist_results': [{'id': i, 'result': r, 'evidence': e} for i, r, e in checks],
    'checklist_counts': dict(cnt),
    'discrepancies': [{'id': i, 'severity': s, 'summary': t, 'correction': c} for i, s, t, c in disc],
    'blocking_items': [],
    'scope_attestation': {
        'v5b_or_other_projection_executed': False, 'candidate_null_simulation': False,
        'camera_pair_decision_or_class_count': False, 'v1_v4_rerun': False,
        'hebrew_chart_source_image_glyph_font_proxy_accessed': False, 'git_write': False,
        'freeze_note_completed_or_signed': False, 'first_review_archive_modified': False,
    },
    'outcome': 'MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_INCOMPLETE',
    'outcome_basis': ['D01 SOURCE_CONTRACT_UNRESOLVED (V5 §2)', 'B35 FAIL against accepted certification plan (D02)',
                      'material corrections require separately signed amendment (freeze-note draft §4)'],
    'v5b_permission': 'NONE',
    'supporting_evidence_sha256': {os.path.relpath(os.path.join(r, f), D): h(os.path.join(r, f))
                                   for r, _, fs in os.walk(SE) for f in sorted(fs)},
}
json.dump(out, open(os.path.join(D, 'V5_SECOND_INDEPENDENT_QC.json'), 'w'), indent=1, sort_keys=False)
print(dict(cnt))
