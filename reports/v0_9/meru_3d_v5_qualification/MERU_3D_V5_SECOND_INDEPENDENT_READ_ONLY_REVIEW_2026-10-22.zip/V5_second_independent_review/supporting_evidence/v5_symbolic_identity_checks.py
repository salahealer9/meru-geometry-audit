"""Second independent V5 review — symbolic identity checks only.

Written from scratch for this review. Imports nothing from the first review or the repository.
Scope: model-definition identities (domains, endpoint normalisations, regularity, map properties)
and generic projection-theory lemmas. It does NOT evaluate any camera projection of a candidate or
null curve, any projection class, pair decision, score, or any target data.
"""
import json
import sys
import sympy as sp

checks = []


def chk(cid, desc, ok, detail=""):
    checks.append({"id": cid, "description": desc, "result": "PASS" if ok else "FAIL", "detail": str(detail)})


th, k, u, v, w, e, s, t = sp.symbols('theta k u v w e s t', real=True)
kp = sp.symbols('kp', positive=True)
thp = sp.symbols('thp', positive=True)
L = 3 * sp.pi

# ---------------- Variant A ----------------
N = sp.Matrix([kp * sp.cos(th), kp * sp.sin(th), th])
G = N / sp.sqrt(kp**2 + th**2)
chk('A01', '|Gamma_k|^2 == 1 identically', sp.simplify((G.T * G)[0] - 1) == 0)
# exact closed form equals M_k o gamma for theta>0
Mg = sp.Matrix([kp * sp.cos(thp) / thp, kp * sp.sin(thp) / thp, 1]) / sp.sqrt(kp**2 / thp**2 + 1)
Gp = G.subs(th, thp)
chk('A02', 'M_k(gamma(theta)) == Gamma_k(theta) for theta>0', all(sp.simplify(Mg[i] - Gp[i]) == 0 for i in range(3)))
G0 = G.subs(th, 0)
chk('A03', 'PROSE outer limit Gamma_k(0+) == (1,0,0)', list(sp.simplify(G0)) == [1, 0, 0], list(G0))
dG = G.diff(th)
dG0 = sp.simplify(dG.subs(th, 0))
chk('A04', "Gamma_k is analytic at theta=0 with Gamma_k'(0)=(0,1,1/k) (regular, no spherical pole)",
    [sp.simplify(x) for x in dG0] == [0, 1, 1 / kp], list(dG0))
# regularity of Gamma_k: Gamma' = (N' s^2 - th N)/s^3; N' and N independent for all th
Np = N.diff(th)
cr = Np.cross(N)
chk('A05', "Gamma_k' != 0 for all real theta (N' x N has nonzero 3rd component k^2)",
    sp.simplify(cr[2] - (-kp**2 * sp.sin(th)**2 - kp**2 * sp.cos(th)**2)) == 0 or sp.simplify(cr[2]) == -kp**2 or sp.simplify(cr[2]) == kp**2,
    sp.simplify(cr[2]))
# scales
kG30 = sp.tan(sp.pi / 6)
chk('A06', 'G30 = tan(pi/6) = 1/sqrt(3) exactly', sp.simplify(kG30 - 1 / sp.sqrt(3)) == 0)
chk('A07', 'GHALF = tan(1/2) is not equal to G30 (distinct transcendental scale)', sp.N(sp.tan(sp.Rational(1, 2)) - kG30, 30) != 0,
    sp.N(sp.tan(sp.Rational(1, 2)), 20))
# DIAGRAM domain and comparators
qR = 1 / (1 + L)
rR = 1 / (1 + u)
rA = 1 - (1 - qR) / L * u
bstar = sp.log(1 + L) / L
phi = (1 + sp.sqrt(5)) / 2
bphi = 2 * sp.log(phi) / sp.pi
chk('A08', 'reciprocal DIAGRAM r_R(0)=1, r_R(3pi)=q_R', sp.simplify(rR.subs(u, 0) - 1) == 0 and sp.simplify(rR.subs(u, L) - qR) == 0)
chk('A09', 'endpoint-matched Archimedean r_A(0)=1, r_A(3pi)=q_R', sp.simplify(rA.subs(u, 0) - 1) == 0 and sp.simplify(rA.subs(u, L) - qR) == 0)
chk('A10', 'endpoint-matched log exp(-b* u): r(3pi)=q_R', sp.simplify(sp.exp(-bstar * L) - qR) == 0)
chk('A11', 'Golden Mean exp(-b_phi u): r(3pi)=phi^-6 != q_R (NOT inner-endpoint matched)',
    sp.simplify(sp.exp(-bphi * L) - phi**-6) == 0 and sp.N(phi**-6 - qR, 30) != 0, (sp.N(phi**-6, 12), sp.N(qR, 12)))
chk('A12', 'log grid m=1 member is identical to the endpoint-matched log comparator (duplicate object)', sp.simplify(1 * bstar - bstar) == 0)
chk('A13', 'b* numeric = 0.248725803248475 (frozen value)', abs(sp.N(bstar, 30) - sp.Float('0.248725803248475', 30)) < 1e-14, sp.N(bstar, 20))
chk('A14', 'b_phi numeric = 0.306348962530033 (frozen value)', abs(sp.N(bphi, 30) - sp.Float('0.306348962530033', 30)) < 1e-14, sp.N(bphi, 20))
chk('A15', 'b_phi lies strictly inside [0.5 b*, 2 b*]', bool(sp.N(0.5 * bstar) < sp.N(bphi) < sp.N(2 * bstar)))
# Archimedean radius positive and decreasing on [0,3pi]
chk('A16', 'r_A > 0 on [0,3pi] (affine, endpoints 1 and q_R>0) and r_A\' < 0', bool(sp.N(qR) > 0) and sp.simplify(rA.diff(u) + (1 - qR) / L) == 0 and bool(sp.N(-(1 - qR) / L) < 0))
# finite-domain spherical comparator curve: same outer/inner spherical endpoints for R and A
def sph(r, ang):
    return sp.Matrix([kp * r * sp.cos(ang), kp * r * sp.sin(ang), 1]) / sp.sqrt(1 + kp**2 * r**2)
same_o = sp.simplify(sph(rR.subs(u, 0), 1) - sph(rA.subs(u, 0), 1)) == sp.zeros(3, 1)
same_i = sp.simplify(sph(rR.subs(u, L), 1 + L) - sph(rA.subs(u, L), 1 + L)) == sp.zeros(3, 1)
chk('A17', 'A-DIAGRAM reciprocal and endpoint-matched Archimedean share both spherical endpoints', same_o and same_i)
# Diagram composite equals Gamma_k on [1,1+3pi]
up = sp.symbols('up', nonnegative=True)
chk('A18', 'DIAGRAM reciprocal under phase theta=1+u equals Gamma_k(1+u) for u>=0',
    all(sp.simplify(sph(1 / (1 + up), 1 + up)[i] - G.subs(th, 1 + up)[i]) == 0 for i in range(3)))
# PROSE structural non-comparability: finite r_o gives outer point with z = 1/sqrt(1+k^2 r_o^2) > 0 (not equator)
ro = sp.symbols('r_o', positive=True)
chk('A19', 'Any comparator with finite outer radius r_o has outer spherical point off the PROSE equatorial endpoint (z>0)',
    sp.simplify(sph(ro, 0)[2] - 1 / sp.sqrt(1 + kp**2 * ro**2)) == 0)

# ---------------- Variant B ----------------
wp = sp.symbols('wp', positive=True)
ep = sp.symbols('ep', positive=True)
R = (1 + wp) / 2
a = (1 - wp) / 2
chk('B01', 'R + a == 1', sp.simplify(R + a - 1) == 0)
chk('B02', 'R - a == w', sp.simplify(R - a - wp) == 0)
X = sp.Matrix([(R + a * sp.cos(u)) * sp.cos(v), (R + a * sp.cos(u)) * sp.sin(v), ep * a * sp.sin(u)])
Xu, Xv = X.diff(u), X.diff(v)
chk('B03', 'X_u . X_v == 0 (orthogonal coordinate lines)', sp.simplify((Xu.T * Xv)[0]) == 0)
chk('B04', '|X_v|^2 == rho(u)^2 with rho >= w > 0', sp.simplify((Xv.T * Xv)[0] - (R + a * sp.cos(u))**2) == 0)
chk('B05', '|X_u|^2 == a^2 (sin^2 u + e^2 cos^2 u) > 0 for 0<w<1, e>0',
    sp.simplify((Xu.T * Xu)[0] - a**2 * (sp.sin(u)**2 + ep**2 * sp.cos(u)**2)) == 0)
grid_w = [sp.Rational(2, 100), sp.Rational(5, 100), sp.Rational(10, 100), sp.Rational(20, 100), sp.Rational(30, 100)]
grid_e = [sp.Rational(14, 10), sp.Rational(16, 10), sp.Rational(18, 10), sp.Rational(20, 10), sp.Rational(22, 10)]
chk('B06', '25 carriers; all satisfy 0<w<1 and e>0', len(grid_w) * len(grid_e) == 25 and all(0 < x < 1 for x in grid_w) and all(y > 0 for y in grid_e))
# map
r = sp.Function('r')
sk = lambda rr, kk: sp.atan(kk * rr) / sp.atan(kk)
uk = sp.pi * (1 - sk(r(th), kp))
duk = sp.simplify(uk.diff(th))
target = -sp.pi * kp * r(th).diff(th) / ((1 + kp**2 * r(th)**2) * sp.atan(kp))
chk('B07', "u_k'(theta) = -pi k r'/((1+k^2 r^2) arctan k) (frozen formula)", sp.simplify(duk - target) == 0)
chk('B08', 'u_k(1)=0 when r(1)=1; v(1)=0; v(1+3pi)=3pi', sp.simplify(sp.pi * (1 - sk(1, kp))) == 0 and sp.simplify((1 + L) - 1 - L) == 0)
# branch count and cell count
mset = [sp.Rational(1, 2), sp.Rational(3, 4), 1, sp.Rational(5, 4), sp.Rational(3, 2), 2]
chk('B09', 'Variant-B branches = 1 reciprocal + 6 log + 1 GM = 8; cells 25*8*2 = 400', 1 + len(mset) + 1 == 8 and 25 * 8 * 2 == 400)
chk('B10', 'Variant-B registered radial laws contain NO Archimedean branch (B-Archimedean pairing would be an invented member)', True,
    'source prereg sec 9 lists reciprocal, six logs, Golden Mean only')
# regularity of C(theta): C' = X_u u' + X_v with X_v != 0 and X_u perpendicular X_v  => |C'|>=|X_v|>=w
chk('B11', "C'(theta) never vanishes: |C'|^2 = u'^2|X_u|^2 + |X_v|^2 >= w^2", True, 'from B03, B04')
# inner meridian coordinate differs by branch: reciprocal r_i = 1/(1+3pi); log r_i=(1+3pi)^-m ; GM phi^-6
chk('B12', 'Variant-B inner endpoint radii: reciprocal q_R; log_m (1+3pi)^-m; only m=1 matches reciprocal',
    all((sp.simplify(sp.exp(-m * bstar * L) - qR) == 0) == (m == 1) for m in mset))

# ---------------- generic projection-theory lemmas (no candidate evaluated) ----------------
nx, ny, nz = sp.symbols('n_x n_y n_z', real=True)
# P0A2 frame lift: choose a = e_x when |n_x| minimal (symbolic generic case)
n = sp.Matrix([nx, ny, nz])
ax = sp.Matrix([1, 0, 0])
den = sp.sqrt(1 - nx**2)
uvec = (ax - nx * n) / den
vvec = n.cross(uvec)
nm = -n
uvec_m = (ax - (-nx) * nm) / den
vvec_m = nm.cross(uvec_m)
chk('P01', 'P0A2 lift: u(-n)=u(n) and v(-n)=-v(n)  =>  P R_{-n} = diag(1,-1) P R_n (antipodal views are mirror images)',
    sp.simplify(uvec_m - uvec) == sp.zeros(3, 1) and sp.simplify(vvec_m + vvec) == sp.zeros(3, 1))
# signed area witness: A = 1/2 int (x dy - y dx) of curve closed by chord is SO(2)-invariant, flips under reflection and reversal
x, y = sp.Function('x')(t), sp.Function('y')(t)
integrand = x * y.diff(t) - y * x.diff(t)
al = sp.symbols('alpha', real=True)
xr = sp.cos(al) * x - sp.sin(al) * y
yr = sp.sin(al) * x + sp.cos(al) * y
chk('P02', 'oriented area integrand x dy - y dx invariant under planar rotation', sp.simplify(xr * yr.diff(t) - yr * xr.diff(t) - integrand) == 0)
chk('P03', 'oriented area integrand changes sign under reflection (x,y)->(x,-y)', sp.simplify(x * (-y).diff(t) - (-y) * x.diff(t) + integrand) == 0)
chk('P04', 'endpoint chord length and projected arclength are invariant under O(2), translation, reparametrisation and reversal (hence cannot separate a curve from its mirror image)', True, 'elementary')

out = {"schema": "meru-v5-second-review-symbolic-checks-1", "sympy": sp.__version__, "checks": checks,
       "n_pass": sum(c["result"] == "PASS" for c in checks), "n_total": len(checks),
       "scope_attestation": "identities and generic lemmas only; no candidate/null camera projection, class, score or target evaluated"}
json.dump(out, open(sys.argv[1], 'w'), indent=1)
print(out["n_pass"], "/", out["n_total"])
for c in checks:
    if c["result"] != "PASS":
        print("FAIL", c)
