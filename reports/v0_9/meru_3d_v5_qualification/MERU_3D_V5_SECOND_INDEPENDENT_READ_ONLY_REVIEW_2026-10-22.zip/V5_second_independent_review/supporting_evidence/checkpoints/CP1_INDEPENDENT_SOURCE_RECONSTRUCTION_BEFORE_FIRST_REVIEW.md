# CP1 — Independent source reconstruction (written BEFORE reading first-review register/matrix/plan)

Time: 2026-10-22 ~14:05 BST. All sources read from the clone at V5 2073a561; v0.8 docs blob-identical at signed tag v0.8.0.

## Variant A (sources: S1 prereg 027d193a, S1 closeout 7fd63552, comparator prereg 965539f6, comparator closeout b91d3d46)
- Planar r=1/θ, θ>0; M_k(x,y)=(kx,ky,1)/sqrt(k²x²+k²y²+1); Γ_k(θ)=(k cosθ,k sinθ,θ)/sqrt(k²+θ²). Orientation inner→outer = decreasing θ.
- PROSE: θ_outer→0⁺ (analytic limit (1,0,0); no epsilon), θ_inner=3π. DIAGRAM: θ∈[1,1+3π].
- NOTE (own finding): Γ_k extends analytically through θ=0 with Γ_k'(0)=(0,1,1/k); on S² the PROSE curve is a regular closed arc [0,3π]. The "pole" exists only in the planar curve. PROSE is therefore not a spherical singularity for the reciprocal candidate; its non-comparability is structural (finite-r comparators cannot reach the equatorial endpoint), as v0.8 comparator prereg §4/§24 states.
- Scales: G30 k=tan(π/6)=1/√3; GHALF k=tan(1/2). k=tan(1) explicitly excluded (scoping asymmetry recorded in v0.8).
- Comparators (DIAGRAM only, u=θ−1∈[0,3π], phase θ0=1): Archimedean r_A=1−(1−q_R)u/(3π), q_R=1/(1+3π) (shares both spherical endpoints with reciprocal); endpoint-matched log r=e^{−b*u}, b*=ln(1+3π)/(3π)≈0.248725803248475; Golden Mean b_φ=2lnφ/π≈0.306348962530033, r(3π)=φ^−6 (NOT inner matched); log grid b_m=m b*, m∈{0.5,0.75,1,1.25,1.5,2} — m=1 IS the endpoint-matched log (duplicate object, two labels). No AOG-PROSE comparator cells (structural non-comparability).
- Provenance: reciprocal law + 3π span SOURCE_ATTESTED; inverse-gnomonic M_k and scales SOURCE_CONSTRAINED_INTERPRETATION (declared audit convention); comparator families named by source (SOURCE_ATTESTED names), endpoint-matching normalisation and log grid INDEPENDENT_DIAGNOSTIC/NULL_CONTROL choices.

## Variant B (spec 501be812, prereg bfd0ac70, closeout 37d0a54d)
- X_{w,e}(u,v)=((R+a cos u)cos v,(R+a cos u)sin v, e a sin u), R=(1+w)/2, a=(1−w)/2; w∈{.02,.05,.10,.20,.30}, e∈{1.4,…,2.2}; 25 embedded genus-1 carriers.
- θ∈[1,1+3π]; radial laws IN θ: r_R=1/θ; r_{L,m}=exp(−b_m(θ−1)); r_φ=exp(−b_φ(θ−1)). 8 branches (1+6+1). NO Archimedean branch in B. NO PROSE in B (explicitly prohibited).
- Map: s_k(r)=arctan(kr)/arctan(k); u_k(θ)=π[1−s_k(r(θ))]; v(θ)=θ−1. Same map for all 8 branches. k∈{G30,GHALF} only inside the map.
- Regularity: X_u⊥X_v, |X_v|=ρ≥w>0 ⇒ C'(θ)≠0; u_k strictly increasing ⇒ C injective (embedded arc).
- 400 = endpoint-analysis cells, not projection observations.
- Inner endpoints differ by branch (only log m=1 shares reciprocal inner radius).

## K / C0 / ribbons
- Canonical ring torus T(u,v) with R>r>0; γ_{p,q}(t)=T(pt+φ_u,qt+φ_v), (3,10); convention p=around axis, q=around tube "must be verified against Meru". The baseline DOCUMENT fixes no R, r or phases; numeric values exist only as code defaults (torus.py e520556c / embeddings.py 938e64cb: R=2.0, r=0.75, phases 0). C0 code default theta_start=0.5, toroidal 1.5, poloidal 1.0 turns — distinct from Variant A/B conventions. ⇒ K and C0 metric parameters are not document-specified; K lane must be DEFERRED with its own registered metric.
- v0.6 constraints C02/C03/C07/C08: ribbon width/twist/surface distinct; canonical knot is reference; transformation F_Meru unknown.

## Nulls — label collision (own finding, to be compared with first review)
- Signed P0A0 §9 (blob 0f8b663b) and P0A1 source_constraint_ledger (79c99f82) define N0 arbitrary smooth 3-D curves; N1 length/curvature/complexity matched; N2 generic 1.5-turn non-fixed radial law; N3 same-carrier same-span non-reciprocal.
- V5 §4 reuses N0–N3 with different meanings: N0 sanity; N1 radial-law substitution; N2 same-carrier; N3 equal-complexity generic. V5 does not acknowledge the permutation. V5 §2(7) says it must not supersede P0A gates. ⇒ discrepancy needing additive namespacing.

## Cameras
- P0A2 D3 + V1 freeze: A 6/14/26, B 6/18/42; axes 3/7/13, 3/9/21; lexicographic integer-triple stratum order; antipodal: P R_{−n}=diag(1,−1) P R_n (symbolically re-verified P01).

## Certification-theory points to test against first-review plan
- Interval arithmetic can certify UNEQUAL only; EQUAL needs symbolic identity/theorem.
- Chord and length witnesses are O(2)+reversal invariants: cannot separate SO(2) antipodal (mirror) pairs; need an oriented witness (e.g. chord-closed signed area) — and that flips under reversal too.
- O(2) kernel test needs a GLOBAL sign of the determinant kernel, not pointwise |D|.
- Arclength representative requires rectifiability, quotient by weakly monotone reparametrisation, isolated projected-speed zeros (cusps) handled; θ(s) inversion needs certified enclosure.
- Unresolved-pair class bounds need trivalent transitive closure with contradiction detection; lower bound is a minimum clique-cover style problem.

Symbolic checks: indep_checks/v5_symbolic_identity_checks.py (sha256 70bf08dc…a5) → 35/35 PASS (JSON c5a8829f…2e).
