# CP2 — Second independent V5 review: findings before writing deliverables (2026-10-22 ~14:30 BST)
Identity: V5 2073a561… parent aa79d650… blob 9bc21565…; local GPG VALIDSIG D4EC… (TRUST_UNDEFINED, isolated keyring, key from repo provenance JSON); GitHub verified=true/valid. v0.8.0 tag 12afd9f9…→85748bff… VALIDSIG; all 9 consulted v0.8-era docs blob-identical at tag and V5; v0.9 docs postdate tag (signed commits, ancestors of V5).
First review ZIP 42fa29c8… 6 files, 5/5 internal sums OK.
Checks: symbolic identities 35/35 (script 70bf08dc…, json c5a8829f…); projection lemmas 9/9 (script ada7394b…, json 0fc17318…); matrix audit (script 11a4521b…, json f7e4de6e…): 38 rows 30/2/6, 38 NOT_AUTHORIZED, coverage A 8 controls/scale, B 7/scale = sources.
Discrepancies (draft severities):
- D01 MATERIAL_NONBLOCKING: V5 N0–N3 labels collide with signed P0A0 §9 (blob 0f8b663b) / P0A1 ledger (79c99f82) N0–N3 ladder; unacknowledged by V5 and first review → SOURCE_CONTRACT_UNRESOLVED (V5 §2) until human-signed namespace mapping.
- D02 MATERIAL_NONBLOCKING: certification plan witnesses are all reflection-invariant; no orientation-odd witness → SO2 antipodal (mirror) pairs structurally UNRESOLVED; checklist B35 unmet. Remedy: antipodal SO2 lemma (L05) + reversal-symmetric oriented witness (L06–L09).
- D03 MATERIAL_NONBLOCKING: matrix lacks V5 §8/§4 fields (numeric parameter counts, branch/rank validity, degeneracy, chirality, precision/stop).
- D04 EDITORIAL: B rows omit inner-endpoint non-parity for 6/7 controls.
- D05 EDITORIAL: N0 composition (V3/V4 curves + undefined deterministic 3D comparator) not enumerated; plan substitutes new fixtures without rationale.
- D06 EDITORIAL: K metric only code defaults (R=2,r=0.75); C0 lacks provenance row/exclusion.
- D07 EDITORIAL: register blends (B01, N01) need splitting; F02 double claim.
- D08 EDITORIAL: register LaTeX typo r_{L},m}; review claims a checker script not in package; plan "centred" kernel ambiguous; contradiction detection implicit; plan "open DIAGRAM interval" wording; plan regularity precondition stronger than needed.
- D09 NOTE: plan V5B scope (8 A controls) vs freeze-note draft minimal pilot (3).
- D10 RESOLVED: full v0.8 tag census (deferred by first review) completed: all match.
Provisional outcome reasoning: no identity failure, no leakage → not BLOCKED. Source/domain/map attribution all PASS. Essential B35 unmet by package + D01 unresolved signed-doc conflict + D03 → INCOMPLETE pending narrow human-signed additive amendment.
