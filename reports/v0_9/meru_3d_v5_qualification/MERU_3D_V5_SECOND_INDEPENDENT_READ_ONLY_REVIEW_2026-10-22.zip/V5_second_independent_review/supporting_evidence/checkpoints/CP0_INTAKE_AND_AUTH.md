# CP0 — Intake and authentication (2026-10-22 ~13:50 BST)
- Handoff ZIP sha256 6da9dd0e…bb80 (31,620 B); internal sums OK.
- V5 commit 2073a5618719230c6ec4d5aad7a2941825c7fd77; parent aa79d6509b95b302bd6c8092464aed7717f71554; single added file
  docs/v0_9/meru_3d_v5_target_blind_source_model_and_matched_null_qualification_protocol_2026_10_22.md
  blob 9bc215654470785f625c799371168b36e88e1a2b; content sha256 91cdd78c77290444845e0876e2984ea2d1930f91c726d1c12384cbea484b94cb; 24,459 B.
- Local isolated-GNUPGHOME GPG (key from repo provenance JSON, key file sha256 af66fcd2…63b8): VALIDSIG D4EC014EEFCC90E619D2AA59A91239ABCF512130 on V5 and parent; TRUST_UNDEFINED (ownertrust not asserted).
- All 46 commits v0.8.0-target..HEAD VALIDSIG D4EC. Tag v0.8.0 object 12afd9f9…, target 85748bff…, VALIDSIG D4EC; ancestor of V5.
- GitHub API (WebFetch): verification.verified=true, reason=valid, verified_at 2026-10-22T11:59:17Z.
- Branch tip == V5 at clone time.
- First-review ZIP sha256 42fa29c800d58a4df7f8230e48db4e4271b9521fb0d6e9fa1adfb603dedbc7f7 (19,443 B); 6 members; 5/5 internal sums OK.
  SHA256SUMS.txt e1358721…4bf44.
- Freeze-note draft read; NOT filled, NOT signed.
- Independence discipline: first-review register/matrix/plan NOT yet read in detail; sources reconstructed first.
