"""Build V5_SOURCE_AND_BLOB_VERIFICATION.csv from the read-only clone (second independent review).
Runs only read-only git plumbing/porcelain (rev-parse, cat-file, log, verify-commit, merge-base)."""
import csv
import hashlib
import os
import re
import subprocess
import sys

REPO, GNUPG, FR_DIR, FR_ZIP, OUT = sys.argv[1:6]
V5 = '2073a5618719230c6ec4d5aad7a2941825c7fd77'
TAG = 'v0.8.0'


def git(*a, env=None):
    return subprocess.run(['git', '-C', REPO] + list(a), capture_output=True, text=True, env=env)


def sig(commit):
    env = dict(os.environ, GNUPGHOME=GNUPG)
    r = git('verify-commit', '--raw', commit, env=env)
    m = re.search(r'VALIDSIG ([0-9A-F]{40})', r.stderr)
    trust = re.search(r'TRUST_([A-Z]+)', r.stderr)
    return ('VALIDSIG ' + m.group(1) if m else 'NO_VALIDSIG') + (' TRUST_' + trust.group(1) if trust else ' TRUST_NOT_REPORTED')


fr_register = open(os.path.join(FR_DIR, 'V5_SOURCE_TO_MODEL_REGISTER.md'), encoding='utf-8').read()
fr_pairs = dict(re.findall(r'blob/2073a561[0-9a-f]+/([^)\s]+)\)\s*\|\s*`([0-9a-f]{40})`', fr_register))

sources = [
    ('V5 signed protocol (governing)', 'docs/v0_9/meru_3d_v5_target_blind_source_model_and_matched_null_qualification_protocol_2026_10_22.md', 'Governing V5 scope, provenance classes, tiers, gates'),
    ('v0.8 source recovery closeout', 'docs/first_hand_construction_source_recovery_closeout_v0.8.md', 'r*theta=1; 3pi later convention; 120 deg copies; craft bend; NO_REPRODUCIBLE_PUBLISHED_FIRST_HAND_CONSTRUCTION_RECOVERED'),
    ('v0.8 A S1 preregistration (primary domain source)', 'docs/first_hand_analytic_s1_preregistration_v0.8.md', 'Gamma_k; M_k; PROSE theta->0+..3pi; DIAGRAM [1,1+3pi]; G30/GHALF; tan(1) excluded'),
    ('v0.8 A S1 closeout', 'docs/first_hand_s1_analytic_closeout_v0.8.md', 'S1 four-cell endpoint failure; PROSE handled by exact limit (1,0,0)'),
    ('v0.8 A comparator preregistration', 'docs/first_hand_s1_comparator_preregistration_v0.8.md', 'DIAGRAM-only Arch/log/GM laws; log grid; PROSE structural non-comparability'),
    ('v0.8 A comparator closeout', 'docs/first_hand_s1_comparator_closeout_v0.8.md', 'Comparator endpoint results; Arch shares both spherical endpoints'),
    ('v0.8 A truncation-parity prereg (context)', 'docs/first_hand_s1_truncation_parity_preregistration_v0.8.md', 'Log tangent parity under n*pi spans (context only; V5 keeps 3pi)'),
    ('v0.8 B source specification', 'docs/first_hand_variant_b_source_geometry_specification_v0.8.md', 'Dimpled-sphere torus attested; metric underdetermined; knot vs carrier distinct'),
    ('v0.8 B swept-family preregistration (primary map source)', 'docs/first_hand_variant_b_swept_family_preregistration_v0.8.md', 'X_{w,e}; 5x5 grid; 8 radial laws in theta; s_k,u_k,v map; 400 cells; no PROSE; no Archimedean'),
    ('v0.8 B swept-family closeout', 'docs/first_hand_variant_b_swept_family_closeout_v0.8.md', '400 cells executed; 0 technical failures; no parallel cell'),
    ('v0.6 reconstruction constraints', 'docs/source_audit/reconstruction_constraints_v0_6.md', 'C02 ribbon vs centreline; C03 axle singularity; C07 ring knot transformed; C08 model families separate'),
    ('canonical torus / K / C0 baseline', 'docs/geometry/torus_embedding_baseline.md', 'Ring torus R>r>0; (3,10) knot convention; C0 candidate; NO numeric R,r,phases in document'),
    ('K/C0 code defaults (repository convention, not a registered metric)', 'src/meru_geometry/torus.py', 'Defaults R=2.0, r=0.75'),
    ('C0 code defaults (repository convention, not a registered metric)', 'src/meru_geometry/embeddings.py', 'C0 defaults theta_start=0.5, 1.5 toroidal, 1.0 poloidal turns, R=2, r=0.75'),
    ('v0.5 projection orbit results', 'docs/geometry/projection_orbit_results_v0_5.md', '12 tetrahedral frames -> 6 signed / 3 axes; object counts used approximate relative-RMS 1e-8'),
    ('P0A2 direction-family design', 'reports/v0_9/p0a2_target_blind_design/direction_family_candidates.md', 'A0,C,E,T strata; 6/14/26, 6/18/42; lexicographic order; antipodal lift P R_-n = diag(1,-1) P R_n'),
    ('V1 protocol', 'docs/v0_9/meru_3d_v1_target_blind_viewing_direction_separation_protocol_2026_10_22.md', 'Frozen grids (blob cited by V1 freeze)'),
    ('V1 result freeze', 'docs/v0_9/meru_3d_v1_finite_direction_result_freeze_2026_10_22.md', 'Grid census/separation PASS'),
    ('V2 protocol', 'docs/v0_9/meru_3d_v2_target_blind_spherical_covering_radius_protocol_2026_10_22.md', 'Covering-radius protocol (blob cited by V2 freeze)'),
    ('V2 result freeze', 'docs/v0_9/meru_3d_v2_exact_covering_result_freeze_2026_10_22.md', 'Exact covering radii PASS'),
    ('V3 protocol', 'docs/v0_9/meru_3d_v3_target_blind_labelled_projection_equivalence_protocol_2026_10_22.md', 'F/L/P labelled controls'),
    ('V3 result freeze', 'docs/v0_9/meru_3d_v3_labelled_projection_equivalence_result_freeze_2026_10_22.md', 'Labelled projection PASS'),
    ('V4 protocol', 'docs/v0_9/meru_3d_v4_target_blind_trace_and_convex_silhouette_equivalence_protocol_2026_10_22.md', 'TR-L/TR-S/TR-C/CS-T/CS-B controls (candidate N0 curves)'),
    ('V4 result freeze', 'docs/v0_9/meru_3d_v4_trace_convex_silhouette_result_freeze_2026_10_22.md', '6,090/6,090 checks; 30,320 entries; PL traces/convex solids only'),
    ('P0A0 protocol (signed N0-N3 ladder)', 'docs/p0a0_hebrew_projection_source_identity_and_synthetic_pilot_protocol_v0.9.md', 'Sec 9 N0 arbitrary smooth; N1 length/curvature/complexity; N2 generic 1.5-turn; N3 same-carrier non-reciprocal'),
    ('P0A1 protocol', 'docs/v0_9/p0a1_post_synthetic_methodology_qualification_protocol.md', 'N0-N3 prospective fairness; no candidate/null scoring'),
    ('P0A1 source-constraint ledger', 'reports/v0_9/p0a1_methodology/source_constraint_ledger.md', 'Five provenance classes; N0-N3 ladder prerequisites'),
    ('P0A2 protocol', 'docs/v0_9/p0a2_target_blind_numerical_methods_capacity_solver_design_protocol.md', 'Capacity/nuisance parity; infimum monotonicity'),
    ('P0A3 protocol', 'docs/v0_9/p0a3_target_blind_numerical_implementation_and_certification_architecture_protocol.md', 'No premature target; N0-N3 laws unchosen'),
]

rows = []
for role, path, supports in sources:
    bV = git('rev-parse', '%s:%s' % (V5, path)).stdout.strip() or 'MISSING_AT_V5'
    r8 = git('rev-parse', '--verify', '-q', '%s:%s' % (TAG, path))
    b8 = r8.stdout.strip() if r8.returncode == 0 else 'ABSENT_AT_TAG'
    data = subprocess.run(['git', '-C', REPO, 'cat-file', 'blob', bV], capture_output=True).stdout
    lc = git('log', '-1', '--format=%H', V5, '--', path).stdout.strip()
    anc_tag = git('merge-base', '--is-ancestor', TAG, lc).returncode == 0
    anc_v5 = git('merge-base', '--is-ancestor', lc, V5).returncode == 0
    if b8 == 'ABSENT_AT_TAG':
        tag_status = 'POSTDATES_TAG_EXPECTED' if anc_tag else 'ABSENT_AT_TAG_UNEXPLAINED'
    else:
        tag_status = 'IDENTICAL_AT_TAG' if b8 == bV else 'DIFFERS_FROM_TAG'
    fr = fr_pairs.get(path)
    rows.append({
        'object_type': 'git_blob', 'role': role, 'path': path, 'blob_at_V5': bV, 'blob_at_v0.8.0': b8,
        'tag_comparison': tag_status, 'last_touch_commit_at_V5': lc, 'last_touch_commit_signature_local': sig(lc) if lc else '',
        'last_touch_ancestor_of_V5': anc_v5, 'content_sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
        'in_first_review_register': fr is not None,
        'first_review_blob_match': ('MATCH' if fr == bV else 'MISMATCH') if fr else 'NOT_LISTED_BY_FIRST_REVIEW',
        'supports_claim': supports})

# commits / tag
for label, obj in [('V5 signed preregistration commit', V5), ('required parent (signed V4 freeze)', 'aa79d6509b95b302bd6c8092464aed7717f71554'),
                   ('v0.8.0 tag target commit', '85748bff0bfae383afcc0d885f4aec505a2885dd')]:
    rows.append({'object_type': 'git_commit', 'role': label, 'path': '', 'blob_at_V5': '', 'blob_at_v0.8.0': '',
                 'tag_comparison': '', 'last_touch_commit_at_V5': obj, 'last_touch_commit_signature_local': sig(obj),
                 'last_touch_ancestor_of_V5': git('merge-base', '--is-ancestor', obj, V5).returncode == 0,
                 'content_sha256': '', 'bytes': '', 'in_first_review_register': '', 'first_review_blob_match': '', 'supports_claim': ''})
tagobj = git('rev-parse', TAG).stdout.strip()
env = dict(os.environ, GNUPGHOME=GNUPG)
vt = git('verify-tag', '--raw', TAG, env=env).stderr
m = re.search(r'VALIDSIG ([0-9A-F]{40})', vt)
rows.append({'object_type': 'git_tag', 'role': 'signed annotated tag v0.8.0', 'path': '', 'blob_at_V5': '', 'blob_at_v0.8.0': '',
             'tag_comparison': 'tag object ' + tagobj, 'last_touch_commit_at_V5': git('rev-parse', TAG + '^{commit}').stdout.strip(),
             'last_touch_commit_signature_local': ('VALIDSIG ' + m.group(1)) if m else 'NO_VALIDSIG', 'last_touch_ancestor_of_V5': True,
             'content_sha256': '', 'bytes': '', 'in_first_review_register': '', 'first_review_blob_match': '', 'supports_claim': ''})
# first review archive
zb = open(FR_ZIP, 'rb').read()
rows.append({'object_type': 'file', 'role': 'first-review ZIP (accepted, unchanged)', 'path': os.path.basename(FR_ZIP), 'blob_at_V5': '', 'blob_at_v0.8.0': '',
             'tag_comparison': '', 'last_touch_commit_at_V5': '', 'last_touch_commit_signature_local': '', 'last_touch_ancestor_of_V5': '',
             'content_sha256': hashlib.sha256(zb).hexdigest(), 'bytes': len(zb), 'in_first_review_register': '', 'first_review_blob_match': '',
             'supports_claim': 'expected 42fa29c800d58a4df7f8230e48db4e4271b9521fb0d6e9fa1adfb603dedbc7f7'})
for fn in sorted(os.listdir(FR_DIR)):
    b = open(os.path.join(FR_DIR, fn), 'rb').read()
    rows.append({'object_type': 'file', 'role': 'first-review member', 'path': 'V5_qualification_review/' + fn, 'blob_at_V5': '', 'blob_at_v0.8.0': '',
                 'tag_comparison': '', 'last_touch_commit_at_V5': '', 'last_touch_commit_signature_local': '', 'last_touch_ancestor_of_V5': '',
                 'content_sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b), 'in_first_review_register': '', 'first_review_blob_match': '',
                 'supports_claim': ''})
# first-review register paths not in my list
mine = {s[1] for s in sources}
for p, b in fr_pairs.items():
    if p not in mine:
        rows.append({'object_type': 'git_blob', 'role': 'first-review listed path not in second-review list', 'path': p, 'blob_at_V5': b,
                     'blob_at_v0.8.0': '', 'tag_comparison': 'CHECK', 'last_touch_commit_at_V5': '', 'last_touch_commit_signature_local': '',
                     'last_touch_ancestor_of_V5': '', 'content_sha256': '', 'bytes': '', 'in_first_review_register': True,
                     'first_review_blob_match': '', 'supports_claim': ''})

with open(OUT, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()), lineterminator='\n')
    w.writeheader()
    w.writerows(rows)
print('rows', len(rows), 'first-review register paths parsed', len(fr_pairs))
print('mismatch', [r['path'] for r in rows if r['first_review_blob_match'] == 'MISMATCH'])
print('tag differs', [r['path'] for r in rows if r['tag_comparison'] in ('DIFFERS_FROM_TAG', 'ABSENT_AT_TAG_UNEXPLAINED')])
print('not VALIDSIG', [r['role'] for r in rows if r['last_touch_commit_signature_local'] and 'VALIDSIG D4EC014EEFCC90E619D2AA59A91239ABCF512130' not in r['last_touch_commit_signature_local']])
print('fr listed', sum(1 for r in rows if r['in_first_review_register'] is True))
