# Meru 3D-V5 — Second Independent Review: Discrepancy and Deferral Ledger

**Review date:** 22 October 2026, 12:48–13:20 UTC.
**Reviewed objects:**
- Signed V5 protocol: commit `2073a5618719230c6ec4d5aad7a2941825c7fd77`, blob `9bc215654470785f625c799371168b36e88e1a2b`.
- First review ZIP: `MERU_3D_V5_READ_ONLY_QUALIFICATION_REVIEW_2026-10-22.zip`, SHA-256 `42fa29c800d58a4df7f8230e48db4e4271b9521fb0d6e9fa1adfb603dedbc7f7`.

**Rule:** the accepted first-review archive is **not modified**. Every correction below is a prospective, additive proposal for the human. Nothing here is enacted, signed or committed.

**Severity scale** (from checklist B42):
- `BLOCKING`: an identity or integrity failure, or forbidden leakage.
- `MATERIAL_NONBLOCKING`: a positive qualification is prevented until the human signs an additive correction.
- `EDITORIAL`: wording or completeness. It can be recorded additively without changing scientific content.

## 1. Summary

| ID | Severity | One-line summary | Amendment needed |
|---|---|---|---|
| D01 | MATERIAL_NONBLOCKING | V5 reuses the names N0–N3 with meanings that differ from the signed P0A0 §9 / P0A1 N0–N3 ladder. Neither V5 nor the first review acknowledges this. | Human-signed additive namespace clarification. No new protocol. |
| D02 | MATERIAL_NONBLOCKING | Every inequivalence witness in the certification plan is unchanged by reflection. The plan has no orientation-sensitive witness and no antipodal SO(2) rule. As a result, SO(2) antipodal pairs could never be resolved, and checklist B35 is unmet. | Additive signed amendment to the certification plan, carried into the V5B protocol. |
| D03 | EDITORIAL | The parity matrix records some fields required by V5 §4/§8 only as prose: numeric parameter counts, branch/rank validity, degeneracy policy, chirality, precision/stop parity. | Additive supplement (draft in §3). |
| D04 | EDITORIAL | The B (N2) rows do not disclose inner-endpoint non-parity. Six of the seven B controls end at a different inner radius, and therefore a different meridian coordinate, from the reciprocal. The A rows do disclose this. | Additive note. |
| D05 | EDITORIAL | The N0 tier is not enumerated. V5 §4 requires V3/V4 curves plus "a deterministic 3D nondegenerate comparator", and the second is not defined anywhere. The plan substitutes new fixtures without saying why. | Additive note. The V5B protocol must decide. |
| D06 | EDITORIAL | The numeric metric for K and C0 exists only as code defaults: `R=2.0`, `r=0.75`, phases 0, C0 `theta_start=0.5`. These are not registered in any document. C0 has no provenance row and no exclusion row. | Additive note. |
| D07 | EDITORIAL | Some first-review register rows mix provenance classes (B01, N01), and F02 combines two claims. V5 §1 requires such rows to be split. | Split register supplied in the review §4. |
| D08 | EDITORIAL | Assorted wording issues: a LaTeX typo; a "checker script" that is cited but absent; an ambiguous "centred" kernel; contradiction detection that is only implicit; an "open interval" wording; an over-strong regularity precondition. | Record additively. |
| D09 | NOTE | The first review's plan proposes eight A controls for the first V5B. The unsigned freeze-note draft recommends a three-curve minimal pilot. | Human scope decision in V5B. |
| D10 | RESOLVED | The first review deferred the full v0.8.0 tag census to this review. It is now complete: all 14 pre-tag objects consulted (12 documents and 2 code files) are blob-identical at the tag and at V5. | None. |
| D11 | EDITORIAL | Log-grid multiplicity: six log members compared with one reciprocal must never be summarised as "best of grid" without family-level bookkeeping. | Prospective V5B rule. |

**No BLOCKING item was found:**
- All commit, tag, blob and archive identities verified.
- No target, glyph, font, chart or source-image content was found in either review.
- No execution artefact was found.

## 2. Detailed entries

### D01 — Null-tier namespace collision with signed P0A0/P0A1 (MATERIAL_NONBLOCKING)

**The two definitions:**

| Label | Signed P0A0 §9 (blob `0f8b663b…`, commit `d1586516…`, VALIDSIG D4EC) and P0A1 source-constraint ledger (blob `79c99f82…`, commit `090a1db6…`, VALIDSIG D4EC) | Signed V5 §4 |
|---|---|---|
| N0 | arbitrary smooth 3-D curves | geometric sanity controls (V3/V4) |
| N1 | length/curvature/complexity-matched curves | Variant-A radial-law substitutions |
| N2 | generic 1.5-turn vortices with non-fixed radial laws | Variant-B same-carrier substitutions |
| N3 | same-carrier, same-span, non-reciprocal controls | equal-complexity generic curves (not instantiated) |

**How V5 handles it:** V5 does not cite P0A0 §9 or acknowledge the remapping. V5 §2 item 7 says the V5 line "must not supersede the stricter P0A3/P0A4 gates". V5 §2 also directs that a conflict with an authoritative source be labelled `SOURCE_CONTRACT_UNRESOLVED`.

**How the first review handles it:** it adopts the V5 labels and does not detect the conflict (register N01–N03; matrix `control_tier`).

**Why it matters:**
- The P0A1 ledger and next-gate map treat N0–N3 as future *distributions/generators with sizes and seeds* (Gate 6).
- The V5 "N1/N2" tiers are fixed finite lists. V5 itself says they are not exchangeable random samples.
- Without namespacing, a later document could cite "N1/N2 controls completed in V5" as progress on P0A0/P0A1 Gate 6. It is not.
- In substance, V5-N2 is a fixed-member instance of the *kind* of control described by P0A0-N3. V5-N1 is a fixed-member instance of the kind described by P0A0-N2, restricted to the sphere. V5-N3 resembles P0A0-N0/N1.

**Proposed correction (additive, human-signed):** in the V5 qualification freeze, or in a short signed corrigendum:
- prefix every V5 tier, e.g. `V5-N0` … `V5-N3`;
- state the mapping above;
- state that no V5 tier discharges any P0A0/P0A1 N-tier or Gate-6 requirement.

No source content has to be invented, and no new protocol is required.

### D02 — The certification plan cannot separate mirror images (MATERIAL_NONBLOCKING)

**What the first-review plan (§2) proposes:** inequivalence witnesses based on endpoint chord, total projected arclength, and distances between arclength-located points.

**The gap:**
- All of these are unchanged by planar reflection.
- Signed antipodal G0 views (`+t`, `−t`) are mirror images (lemma L03; the P0A2 lift `P R_{−n} = diag(1,−1) P R_n`, check P01).
- So every proposed witness takes **exactly equal** values on an antipodal pair, and the pair is never separated.
- Under plan §3.4 ("If the invariant enclosure overlaps zero … report unresolved"), all three antipodal SO(2) pairs at G0 would therefore be `UNRESOLVED_PAIR` for every curve.
- The plan says correctly that SO(2) antipodal equality is not automatic, but it gives no rule for deciding it.
- Checklist B35 requires "orientation-sign/handedness witnesses … where scalar witnesses coincide". The plan has none.

**Proposed correction:** two prospective lemmas, both proved symbolically for generic inputs (checks L04–L09). No Meru curve was evaluated.

1. **Antipodal SO(2) lemma (reversal not permitted).**
   - Statement: views `+t` and `−t` of the same open curve are SO(2)-equal if and only if the projected trace is collinear.
   - Consequence: one interval-certified nonzero `D_t(P(u₁)−P(u₀), P(u₂)−P(u₀))`, at any raw parameter values, certifies `UNEQUAL`.
   - Proof outline: any admissible alignment between the two views must preserve arclength measured from the start, so it is the identity. A rotation preserves determinants, while reflection negates them. Every determinant must therefore vanish.
   - This lemma covers only the antipodal case. It does not license raw-parameter witnesses for general pairs.
2. **Reversal-symmetric oriented witness (when reversal is permitted).**
   - Definition: let `o` and `e` be the endpoints, and `m`, `p₁`, `p₃` the points at arclength ℓ/2, ℓ/4 and 3ℓ/4. Then `W = det(m−o, e−o)·(|p₁−o|² − |p₃−e|²)`.
   - Properties: W is unchanged by translation, SO(2) rotation and reversal, and changes sign under reflection.
   - Use: a certified nonzero W separates a curve from its mirror image under SO(2) with reversal. This needs certified arclength inversion.
   - A chord-closed signed area is a simpler oriented witness when reversal is *not* permitted, because it changes sign under reversal.

Both should be written into the V5B protocol before any execution. Until then, the fail-closed behaviour of the plan (UNRESOLVED) is safe but incomplete.

### D03 — Matrix fields required by V5 §4/§8 (EDITORIAL)

**Requirements:**
- V5 §8 requires each matrix row to carry "parameter counts, branch/rank validity and reason for any defer".
- V5 §4 requires "valid/degenerated cases, projection observable, normalisation, chirality, common camera tiers and same number of nuisance choices" for every pairwise comparison.

**What the first-review matrix has:** prose columns `transform_budget` and `shape_parameter_comparison`. It has no numeric parameter count, rank/evaluability column, degeneracy column or chirality column. Precision/stop parity appears only in the plan (§3.6).

Rank validity cannot be established without evaluating projections, which is prohibited in V5. The correct entry is therefore "to be certified in V5B preflight; invalid views retained and reported". The supplement in §3 supplies the missing fields from the sources without new geometry.

### D04 — Inner-endpoint non-parity not disclosed in B rows (EDITORIAL)

**Facts** (from the B preregistration §9, verified by checks B12/A11):
- The B reciprocal ends at `r = 1/(1+3π)`.
- `B_LOG_m` ends at `(1+3π)^(−m)`, so only `m = 1` matches.
- `B_GOLDEN_MEAN` ends at `φ^(−6)`.

So the inner meridian coordinate `u_k(θ_i)` differs for 6 of the 7 B controls. The B rows' `matching_constraints` text ("Same surface X_w,e, azimuth v, meridian u_k, theta interval and k") is true of the *map formula*, but silent on the endpoint image. The corresponding A rows correctly say "inner radius may differ".

### D05 — N0 composition (EDITORIAL)

**What V5 §4 requires:** "Fixed simple curves from V3/V4 and a deterministic 3D nondegenerate comparator".

**What the first review provides:** the matrix row `N0_FINITE_DIAGNOSTIC` defers N0 without listing members. The V3 F/L/P controls are labelled point sets, not curves. The V4 TR-L/TR-S/TR-C are polylines. CS-T/CS-B are solids and are irrelevant to TR-ANALYTIC. The "deterministic 3D nondegenerate comparator" is not defined in any signed document, so it is `NULL_NOT_YET_INSTANTIATED`.

**The plan's choice:** plan §4 proposes new line/circle/symmetric fixtures and explicitly avoids "replayed V4 scientific results".

**Recommendation:** the V5B protocol should decide explicitly. V4 TR-S/TR-C are natural positive-control oracles for TR-ANALYTIC on piecewise-smooth curves, because their exact SO(2)/O(2) classes are independently certified. Using them requires matching the V4 TR equivalence definition (reversal for TR-S, cyclic shift plus reversal for TR-C). It does not replay the V4 run.

### D06 — K/C0 metric only in code defaults (EDITORIAL)

- `docs/geometry/torus_embedding_baseline.md` (blob `6fff1494…`) fixes no numeric `R`, `r`, phases or pose.
- `src/meru_geometry/torus.py` (blob `e520556c…`) and `embeddings.py` (blob `938e64cb…`) default to `R=2.0`, `r=0.75`, phases 0. C0 additionally uses `theta_start=0.5`, 1.5 toroidal turns and 1.0 poloidal turns.
- The v0.5 object counts used an *approximate* relative-RMS threshold of `1e-08`.

None of these is a registered metric. The first review's "no fixed metric R/r and pose" is right, but should say that code defaults exist and are not authority. C0, a distinct candidate from A and B with its own conventions, needs an explicit provenance row and a `DEFERRED/EXCLUDED` matrix row so that it cannot be adopted silently later.

### D07 — Provenance rows that mix classes (EDITORIAL)

- First-review **B01** combines two claims: the source associates the FIRST HAND with a genus-1 dimpled-sphere torus (`SOURCE_ATTESTED`, B specification §2.5/§2.7), and the elliptic fat torus family is an audit choice (`SOURCE_CONSTRAINED_INTERPRETATION`).
- **N01** combines two claims: the source contrasts the reciprocal with the Archimedean, logarithmic and Golden Mean spirals (`SOURCE_ATTESTED`, comparator preregistration §2), and the endpoint normalisation and log grid are audit control choices (`NULL_CONTROL`).
- **F02** joins two attested statements in one row.

A split register is supplied in review §4.

### D08 — Editorial items (EDITORIAL)

- (a) Register §4 has the malformed LaTeX `r_{L},m}`; read it as `r_{L,m}`. The formula is otherwise correct.
- (b) Review §4 says "A checker script and JSON in this package". The six-file package contains no checker script; the JSON is the decision record.
- (c) Plan §2 "centred all-point Gram kernels" leaves the centring undefined. The V5B protocol should use the base-point-free kernel `|γ(s)−γ(t)|²`, or anchor at γ(0) and re-anchor at γ(ℓ) for reversal.
- (d) Plan §3.4/§2 requires equivalence transitivity but does not say that an EQUAL path joining a certified UNEQUAL pair must produce `FAILED`.
- (e) Plan §3.1 "open DIAGRAM interval u∈[0,3π]" means an open (non-closed) curve on a closed interval.
- (f) Plan §2 makes projected regularity a precondition. Kernel completeness does not need it: isolated speed zeros keep the arclength map a homeomorphism. Only the enclosure of θ(s) becomes harder. Treating such cases as UNRESOLVED is conservative, not wrong.

### D09 — V5B scope divergence (NOTE)

- **First-review plan §3.1:** reciprocal plus all eight A controls, deduplicated.
- **Unsigned freeze-note draft §7:** reciprocal, Archimedean and log `m=1` as a minimal pilot.

Both are prospective. The human should fix the scope in the V5B protocol before any execution.

### D10 — Tag census completed (RESOLVED)

`V5_SOURCE_AND_BLOB_VERIFICATION.csv`:
- All 14 pre-tag objects consulted are `IDENTICAL_AT_TAG`: 12 documents, from v0.5/v0.6 to the v0.8 closeouts, and 2 code files.
- Fifteen v0.9 sources `POSTDATE` the tag. Each is touched last by a commit with VALIDSIG D4EC that is an ancestor of V5.
- The commits that last touched the v0.5/v0.6/torus documents and the code files are unsigned (pre-signing era), and so is the tag-target merge commit `85748bff`. Their contents are authenticated through the signed tag object `12afd9f9…` (VALIDSIG D4EC), which names that commit, its tree and therefore those blobs.

### D11 — Log-grid multiplicity (EDITORIAL)

The six log rates are six fixed objects. A summary such as "reciprocal vs best log member" carries six-fold selection opportunity and must be reported with family-level bookkeeping, or per member only (V5 §4, §6.5).

## 3. Supplement to the parity matrix (D03) — prospective, derived from sources, no geometry evaluated

| Object | Free fitted parameters | Fixed shape parameters (source / audit) | Scale | Domain | Chirality | Endpoint match to reciprocal |
|---|---|---|---|---|---|---|
| A reciprocal | 0 | none (r=1/θ) | k ∈ {G30, GHALF}, fixed per branch | θ∈[1,1+3π] | θ increasing counter-clockwise about +z; same for all A objects | — |
| A Archimedean | 0 | 2-parameter affine family fixed by 2 endpoint conditions | same k | same | same | both radii |
| A log m | 0 | 1-parameter family; rate fixed by grid index m | same k | same | same | both radii only for m=1 |
| A Golden Mean | 0 | rate fixed at 2 ln φ/π | same k | same | same | outer radius only |
| B reciprocal | 0 | (w,e) one of 25 fixed cells; map fixed | k inside map | θ∈[1,1+3π] | v=θ−1 increasing about +z; same for all B objects | — |
| B log m | 0 | rate fixed by m; identical (w,e,k) | same | same | same | both endpoints only for m=1; others share the outer endpoint (u=0, v=0) |
| B Golden Mean | 0 | rate fixed at 2 ln φ/π; identical (w,e,k) | same | same | same | outer endpoint only |

**Common to every eligible row:**
- Observation lane: TR-ANALYTIC only.
- Translation quotient; no scale.
- SO(2) primary and O(2) separate.
- Reversal as a separate declared branch; no cyclic shift (open curves).
- Roll quotiented, not counted.
- Camera tier G0 (six signed views).
- Rank/evaluability: to be certified in V5B preflight. Invalid views are retained and reported, never deleted.
- Precision ceiling, stop rule and work budget identical for candidate and control (plan §3.6).
- Search freedom: none.

## 4. Deferral ledger — every deferred item and its bound

| Item | Status | Bound / reason | Where it may reopen |
|---|---|---|---|
| A-PROSE comparisons | INELIGIBLE (2 rows) | A comparator with a finite outer radius cannot reach the equatorial PROSE endpoint (check A19); the v0.8 comparator preregistration §4 forbids a cutoff. The reciprocal PROSE curve itself is a regular closed arc on S² (A04), so a later reciprocal-only lane is mathematically definable. | Separate signed protocol only |
| Variant B projection lane | DESIGN_ELIGIBLE, not scheduled | 25×7×2 matched cells; V5 §7 staging places them after A-DIAGRAM | Separately signed V5B expansion |
| V5-N0 deterministic 3D comparator | NULL_NOT_YET_INSTANTIATED | Not defined in any signed document | V5B protocol |
| V5-N3 equal-complexity generic | NULL_NOT_YET_INSTANTIATED | No family, DOF, smoothness, seed or complexity accounting | Separate signed design |
| K canonical (3,10) reference | DEFERRED | No document-registered metric or pose (code defaults are not authority); dimple map F_Meru unknown | Separate reference-lane protocol |
| C0 reciprocal-to-torus candidate | DEFERRED / not a V5 candidate | Code-default conventions only (D06) | Separate protocol |
| Ribbon / opaque object / optics | UNRESOLVED | No width, normal/twist field, material, occlusion or illumination | Separate 3D-object/occlusion protocol |
| SET-IMAGE | DEFERRED | No qualified exact set-equality algorithm | Separate protocol |
| CS-NONCONVEX | DEFERRED | Not authorised for a first V5 run | Separate protocol |
| Continuous equality proof / implementation | DEFERRED to V5B | Plan plus the D02 and D08(c)/(d) corrections | Signed V5B protocol, implementation freeze, independent QC |
| G1/G2 tiers for candidate lanes | DEFERRED | First run at G0 only | Signed expansion |
| Historical FIRST HAND / target use | CLOSED | `NO_REPRODUCIBLE_PUBLISHED_FIRST_HAND_CONSTRUCTION_RECOVERED`; target barrier unchanged | Independent target-use gate |
