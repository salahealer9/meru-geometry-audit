# Meru 3D-V5-R2-A1 — Third Reviewer, Stage 2: Independent Evidence Comparison

**Status assigned:** `MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_QUALIFIED` (prospective)
**Date:** 2026-10-22
**Reviewer:** third reviewer, independent of the reviewer that proposed the SO(2)/O(2) correction.
AI model, session configured `claude-opus-5` (the serving model may differ from the configured identifier; stated as a limit, not a credential). Isolated cloud workspace.
**Stage-1 blind proof, sealed and unchanged:** SHA-256 `0f398922a863b051c667c450576d5ba7c303e1eeb1530538cac90f991e16a1b9`

This status does **not** revise the historical second-review verdict
`MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_INCOMPLETE`, which stands as recorded in ZIP `567e2017…c13c`, unchanged.
It licenses only the drafting of a separately signed V5B preregistration. It authorises **no** V5B computation.
No commit, push, freeze, V5B execution or Hebrew/target access occurred. See §8 for independence limits.

---

## 1. Authentication and provenance (independently performed)

### 1.1 Stage-2 package integrity

All six supplied files verify against the package manifest (`sha256sum -c`: 6/6 OK). The two Markdown
documents were additionally checked against the Git **blob** identities named in the Stage-1
`00_READ_FIRST.md`, computed locally:

| File | Computed git blob SHA-1 | Claimed | Result |
|---|---|---|---|
| `SIGNED_V5_R2_A1_AMENDMENT.md` | `a1ed423f9ff2f42b030a47afb2fe9df8f79e2c64` | `a1ed423f…` | **match** |
| `SIGNED_V5_PROTOCOL.md` | `9bc215654470785f625c799371168b36e88e1a2b` | `9bc21565…` | **match** |

### 1.2 Review archives

| Archive | Computed SHA-256 | Amendment §0 claim | Internal manifest |
|---|---|---|---|
| `FIRST_REVIEW_ORIGINAL.zip` | `42fa29c800d58a4df7f8230e48db4e4271b9521fb0d6e9fa1adfb603dedbc7f7` | identical | 5/5 OK (6 members) |
| `SECOND_REVIEW_ORIGINAL.zip` | `567e2017f4b6ef2717800ecd44ebedde100c6f5e84027180eee744c42f1ac13c` | identical | 15/15 OK (16 members) |
| `POST_AMENDMENT_REQUALIFICATION_ORIGINAL.zip` | `5f698ee6a74d45322efbb61382dd6ef3c7e74bbd5383dab515fcf32422b893ab` | (not claimed in amendment) | 11/11 OK (12 members) |

Both reviews cited by the amendment are byte-identical to the archives supplied. No archive was edited.

### 1.3 Live Git verification — performed independently, read-only

Network access to `api.github.com` for this repository is not enabled for this session (HTTP 403), so the
GitHub API attestation reported by the earlier requalification could **not** be reproduced. The Git transport
was reachable, so lineage was verified directly. To respect the target-access prohibition I fetched
**commit objects only** (`git fetch --filter=tree:0`), i.e. no blobs and no file content, and later resolved
two tree paths by name only. No file content was retrieved from the repository at any point.

| Check | Result |
|---|---|
| `git ls-remote` branch `hebrew-projection-capacity-v0.9` tip | `9daaf5a706e9097aa98f0e27740a72f9f99b7126` — **matches claim** |
| parent of `9daaf5a7…` | `2073a5618719230c6ec4d5aad7a2941825c7fd77` — **matches claim** |
| parent of `2073a561…` | `aa79d6509b95b302bd6c8092464aed7717f71554` (signed V4 freeze) — **matches claim** |
| commit scope `2073a561…` → `9daaf5a7…` | exactly one file **added**, no other path touched — **matches claim** |
| blob at the amendment path in `9daaf5a7…` | `a1ed423f9ff2f42b030a47afb2fe9df8f79e2c64` — **matches**, and equals the supplied file |
| V5 protocol blob at HEAD | `9bc215654470785f625c799371168b36e88e1a2b` — **unchanged**, and equals the supplied file |
| signature present on all three commits | yes, OpenPGP, pubkey algo 1 (RSA) |
| issuer fingerprint in the **hashed (signed)** subpacket of all three signatures | `D4EC014EEFCC90E619D2AA59A91239ABCF512130` — **matches the expected fingerprint** |
| author / committer of `9daaf5a7…` | `Salah-Eddin Gherbi <salahealer@gmail.com>` |
| cryptographic validity of the signatures | **UNVERIFIABLE in this session** — see below |

**On signature validity.** `git log %G?` returns `E` (cannot check — key unavailable). A public-keyserver
fetch of `D4EC…2130` was refused by this environment's network policy (`No keyserver available`). I therefore
did **not** verify the signature mathematics. I deliberately did not import the key from the repository's own
provenance JSON: a signature checked against a key published in the same repository is circular, as the
earlier requalification itself noted when it reported `VALIDSIG … TRUST_UNDEFINED`.

What I *can* state independently is stronger than nothing and weaker than validation: the lineage, the
one-file scope and both blob identities are confirmed against the live remote, and each signature's own
signed payload names fingerprint `D4EC…2130`. The owner's local `TRUST_ULTIMATE` is the only authority that
settles the key, and it was not reproduced here. **Identity verdict: lineage and content PASS; signature
trust UNVERIFIABLE, not PASS.**

### 1.4 Recounted factual claims

Recounted directly from `V5_CANDIDATE_NULL_PARITY_MATRIX.csv`, not copied from any review:

- **38** data rows, 17 columns.
- `design_status`: **30** `DESIGN_ELIGIBLE` / **2** `INELIGIBLE` (both `A_PROSE_RECIPROCAL`) / **6** `DEFERRED`.
- `execution_status`: **38/38** `NOT_AUTHORIZED`. No execution artefact anywhere in the archive.
- `observation_lane`: every one of the 32 non-deferred rows is **`TR-ANALYTIC`**. No row selects `SET-IMAGE`.
- `transform_budget`: translation + SO(2) primary, O(2) separate, reversal separate, **no scale fit**, roll quotiented.
- `control_tier` in the frozen CSV still uses unprefixed `N0`–`N3`, which is D01 exactly; the amendment
  correctly forbids editing the frozen file and requires reading it through `V5-N0`–`V5-N3`.

The `TR-ANALYTIC` finding is material: it independently settles C2 in substance (§4.2).

---

## 2. What the amendment says, measured against the sealed blind proof

I derived T01–T08 with no access to any of this material (Stage-1 §0). The comparison below is between
that sealed proof and amendment §§2.1–2.5.

| Blind result (Stage 1) | Amendment clause | Agreement |
|---|---|---|
| T01 §2.2 `p_t(U)·p_t(V) = B_t` for every proper frame | §2.1 | **agrees** |
| T01 §2.3 `det(p_t(U),p_t(V)) = D_t` for every proper frame | §2.1 | **agrees** |
| T01 §2.5 `B_{−t}=B_t`, `D_{−t}=−D_t` | §2.1 | **agrees** |
| T01 §2.6 antipodal views differ by a planar reflection, `det R = −1` for *every* admissible pair of proper lifts | §2.1 ("up to a common proper 2-D rotation/choice of frame") | **agrees** |
| T01 §2.4 `B_UU·B_VV − B_UV² = D²` — Gram fixes `|D|` only | §2.1 asserts reflection-even witnesses are insufficient | **agrees; my identity proves it** (§5.1) |
| T02 lemma: no reversal ⟹ congruent to mirror iff affine span ≤ 1 | §2.2 lemma | **agrees**, same conclusion, independent proof |
| T02 §3.3 proof is regularity-free; rank-one zigzags behave correctly | §2.2 proof is determinant-based | **agrees**; resolves my C5 concern (§4.5) |
| T02 §3.3 reparametrization lemma: only residual freedom is reversal | §2.2 ("an arclength-preserving, order-preserving map fixes each s") | **agrees** |
| T03: the lemma fails once reversal is permitted; exact noncollinear counterexample | §2.3 first sentence | **agrees**; amendment states it, I exhibit it |
| T04 §5.1 W invariant under translation, SO(2) and reanchored reversal; odd under reflection | §2.3 | **agrees**, all four laws |
| T04 §5.2 certified `W≠0` ⟹ inequivalent even with reversal | §2.3 | **agrees** |
| T04 §5.3 `W=0` does not imply congruence | §2.3 ("`W=0` is inconclusive") | **agrees**; amendment states it, I exhibit it |
| T05 §6.2 `G` complete for O(2) | §2.4 | **agrees** |
| T05 §6.3 `(G,A)` complete for SO(2); rank-one needs the proper-extension argument | §2.4 ("rank-one/nonconstant cases admit a proper extension") | **agrees** |
| T05 §6.4 kernels must be **re-anchored** under reversal | §2.4 ("re-anchor at `h(ℓ)`") | **agrees**; I add the closed-form transformation |
| T05 §6.5 finite samples can never certify EQUAL | §2.4 | **agrees**; I add a constructive witness |
| T06 §7.1 `E* ⊆ ~` so an UNEQUAL inside an EQUAL component is a contradiction | §2.5 (⟹ fail-closed `FAILED`) | **agrees** |
| T06 §7.3 class-count bounds | §2.5 | **agrees**; I characterise the bound (§5.4) |
| T06 §7.4 constant trace ⟹ `NOT_EVALUABLE` | §2.2 final sentence | **agrees** |
| A10 primitive direction reduction; `±t` neither merged nor split a priori | §2.1 ("primitive integer camera triple"), protocol §5 | **agrees** |

**No disagreement was found between the sealed blind proof and amendment §§2.1–2.5.**
Every mathematical claim in §2 that I checked is correct as written. I found no defect in the amendment's
mathematics, and I attempted to (Stage-1 §8.6; this report §5).

### 2.1 A notable convergence, and what it does and does not prove

The focused requalification's `a1_orientation_proofs.py` (23/23 PASS) used a **quaternion-parametrised
general proper frame** — the same device I chose blindly — and its counterexample `P5e/P5f` is an isoceles
V-shape congruent to its mirror by rotation-by-π plus reversal, which is the same construction as my
Stage-1 §4.2, at different coordinates (theirs `(0,0),(1,1),(2,0)`; mine `(0,0),(3/5,4/5),(6/5,0)`).

Two blind sessions reaching the same device and the same counterexample family is real corroboration of the
mathematics. It is also direct evidence for the correlation risk I recorded in Stage-1 §11.1 before seeing
any of this: shared model lineage can produce convergent reasoning, so agreement between two Claude sessions
is weaker evidence of independence than agreement between two unrelated reviewers. Both readings are true at
once and I report both.

---

## 3. Prior-review comparison

- **First review.** Its certification plan proposes only reflection-even witnesses (endpoint chord, total
  projected arclength, distances between arclength-located points). My T01 §2.4 identity shows *why* no such
  witness can ever separate an antipodal pair: every one is a function of `B_t`, and `B_t` determines `|D_t|`
  but not its sign. The first review's gap is real and is correctly diagnosed by D02.
- **Second review (D02, B35 FAIL).** Its antipodal lemma, its W witness and its properties are exactly my
  T02/T04. Its §6.1 Gram/determinant completeness proof (Steps 1–3, including the `d = 1` composition with a
  reflection fixing `span g` pointwise) is essentially identical to my §6.2–6.3, reached independently. Its
  statement that "interval arithmetic can certify only UNEQUAL" matches my §6.5. I confirm `B35 FAIL` against
  the first-review plan as correct, and `B41 UNVERIFIABLE` as the correct label: non-execution cannot be
  proved from documents, and the absence of results is not affirmative evidence either way.
- **Focused requalification.** Its R09–R17 conclusions match mine item by item. Its own §6 process caveat —
  that it is the same reviewer and session that proposed the D02 remedy, and therefore not independent
  confirmation — is accurate and properly disclosed. Discharging that caveat is the purpose of this review.
- **Editorial E1.** Independently upheld (QC `Q4a`). `V5-N1` is Variant-A **radial-law** substitution, so its
  nearest original type is P0A0 **N2** ("generic 1.5-turn vortices with non-fixed radial laws"), not N1
  ("length/curvature/complexity-matched"). The amendment's §1.2 relation column points at N1. Harmless,
  because §1.2's blanket clause denies satisfaction of *any* original tier, but an additive erratum is right.
- **E2** (raw-parameter rationale) independently upheld: raw parameters are admissible for the rank witness
  because affine rank is parametrization-independent, which is a cleaner reason than "same intrinsic arclength
  labelling". The amendment's stated reason is true but does more work than needed; the conclusion is sound.

---

## 4. C1–C5 disposition

### 4.1 C1 — exact projected-arclength quartiles versus index-based quartiles — **SPECIFIED, deferred correctly**

This was my most serious Stage-1 finding. The amendment already contains the guard, explicitly:

> §2.3: "Certifying nonzero `W` requires globally justified enclosure of projected arclength, certified
> inversion of `s↦θ(s)` at quarter/mid/three-quarter length, and outward bounds on the final expression. If
> endpoint/quarter-point identification, degeneracy, or precision cannot be certified under the registered
> budget, return `UNRESOLVED_PAIR`; **never substitute uniformly sampled raw `θ` points**."

Protocol §6.3–6.4 reinforce it (entire-domain coverage, certified enclosures for sin/cos/exp/log/π, declared
precision before evaluation, `UNRESOLVED_PAIR` rather than tie-breaking by tolerance).

My Stage-1 §5.4 counterexample is therefore **not a defect**. Its contribution is to show the guard is
*load-bearing rather than merely tidy*: violating it yields a **false UNEQUAL certificate**, not just a loose
one. On the isoceles V — a curve I proved congruent to its mirror by rotation-by-π plus reversal — index-based
quartiles give `W = 6/25 ≠ 0` while the true arclength `W = 0`. A reviewer who read "never substitute raw θ
points" as a precision nicety would be wrong: it is the difference between a sound and an unsound certificate,
because the `W≠0` proof depends on `W(Rg) = W(g)`, which fails for asymmetric sampling.
**Recommendation R-1:** V5B should carry this as a mandatory negative test — an implementation must reproduce
`W = 0` on a known mirror-congruent fixture and must *fail* if its quartile construction returns nonzero.

No V5B implementation exists and none is authorised, so there is nothing here to find non-compliant.

### 4.2 C2 — parametrised-curve congruence versus point-set congruence — **RESOLVED at protocol level**

Protocol §5 already separates the two lanes and does not conflate them:

> `TR-ANALYTIC`: "the oriented order of a … centreline under orthographic projection, considered up to
> orientation-preserving reparametrisation … **This is not equality of the projected occupied point set when
> overlaps or retracings exist.**"
> `SET-IMAGE`: "the unlabelled *occupied geometric image* … with an explicit exact equality/rigorous enclosure
> algorithm **yet to be qualified**."

Amendment §3.3 defers `SET-IMAGE`; the second review's B38 confirms it goes to later studies; and I recounted
that **all 32 non-deferred matrix rows are `TR-ANALYTIC`**. The amendment's §2 objects are defined as
arclength representatives throughout. So the point-set reading is nowhere in the eligible V5 design.

My Stage-1 §3.4 circular-arc counterexample is therefore **not a defect**; it is a justification for the
protocol's separation. But it yields a forward-looking finding that is **not** recorded anywhere in the three
archives, and it matters when `SET-IMAGE` is eventually qualified:

> **Under the `SET-IMAGE` reading the entire §2 toolkit fails.** The §2.2 lemma is false — a circular arc is
> noncollinear yet its mirror is a rotation of it as a *set* — and `W` is not even well defined, since a point
> set has no canonical `o, e, m, p₁, p₃`. So `SET-IMAGE` inequivalence needs its own witnesses, built from
> genuinely set-level orientation invariants; none of §2.2–2.3 transfers.

**Recommendation R-2:** annotate amendment §2 as `TR-ANALYTIC`-scope only, by additive erratum, and record
that a future `SET-IMAGE` qualification must derive fresh orientation witnesses. The word "trace" in §2.3
currently reads ambiguously against protocol §5's vocabulary, where `SET-IMAGE` *is* the trace-as-set lane.
Classification: **missing future guard (documentation)**, low severity, no effect on V5 qualification.

### 4.3 C3 — rigorous `W ≠ 0` certificates and whole-curve equality proofs — **SPECIFIED, deferred correctly**

Amendment §2.3 requires rigorous certification and disjoint enclosures; §2.4 requires that `EQUAL` use "a valid
symbolic identity / complete kernel proof / rigorously proved group symmetry" and states that "finite samples
and tight intervals alone cannot prove exact equality"; §2.5 defers the interval library, rounding contract,
precision and time budgets, stopping rules and independent non-importing verification to the signed V5B
protocol. Protocol §6.3–6.6 require the same and demand a second, non-importing QC method.

My Stage-1 §6.5 counterexample **confirms** §2.4 and is a constructive witness that is absent from all three
archives (verified by keyword search): two non-congruent curves of the same length whose anchored Gram kernel,
oriented kernel **and** `W` agree exactly on the entire sample grid. It converts an assertion into a
demonstrated fact. **Recommendation R-3:** adopt it as a second mandatory V5B negative test — any pipeline that
reports `EQUAL` for that pair has an unsound equality path.

I also verified the amendment's generalisation that *disjoint `W` enclosures for two curves* prove
inequivalence (QC `Q1a–Q1c`): `W` is a class function of the translation+SO(2)+reversal equivalence, so this is
sound beyond the antipodal case. One unstated caveat: `W` is **odd** under reflection, so it is not an O(2)
invariant; an O(2)-branch witness must use `|W|` or `W²` (QC `Q2a–Q2b`). The amendment uses `W` only for SO(2),
so nothing is wrong today. **Recommendation R-4** (minor): say so, in case `W` is later reused in the O(2) branch.

### 4.4 C4 — traversal reversal, branch correspondence, antipodal directions — **RESOLVED; one Stage-1 finding withdrawn**

- **Reversal.** Amendment §2 requires "registering whether reversal is allowed *before* inspecting any candidate
  projection"; protocol §5 gives `TR-ANALYTIC` "explicitly separate reversal and closed-curve shift branches";
  protocol §7 requires the reversal permission to be frozen pre-execution. Pre-registration is exactly the
  right control, because my T03 shows the reversal policy changes the antipodal class count. **Resolved.**
- **Antipodal directions.** Amendment §2.1 and protocol §5 ("Signed antipodal views are O2-equivalent **only**
  for the same equivariant orthographic forward model"); G0 is the six signed axes, i.e. three antipodal pairs,
  so the question is live in the first proposed trial and is handled per pair rather than by a blanket rule.
  Primitive reduction is required by both documents. **Resolved** — this is my Stage-1 A10 in full.
- **Branch correspondence.** **I withdraw this Stage-1 finding as a defect.** My §8.5 treated "branchwise" in
  the Stage-1 challenge as "per connected component of the projected figure". Against protocol §5 and amendment
  §2.5, "branch" means *analysis branch* — the SO(2) branch versus the O(2) branch, kept as separate matrices.
  My multi-component concern was therefore about a scope the documents do not assert. The V5 candidates are
  single open curves, so multi-component figures do not arise; self-intersection and retracing are handled
  under `TR-ANALYTIC` and protocol §6.1. I retain the observation only as a scope note: *if* a future extension
  projects a multi-component object (`SET-IMAGE`, finite-width ribbons, or a three-copies-at-120° model), then
  per-component EQUAL would not imply whole-figure congruence under one camera roll, and an UNEQUAL verdict
  would have to quantify over component matchings. Classification: **withdrawn; retained as a future scope note.**

### 4.5 C5 — proper camera-frame orientation and rank-degeneracy handling — **RESOLVED, with one minor guard**

- **Rank degeneracy.** Amendment §3.1: "Model-specific ranks, zero-length views and projection critical points
  are **NOT YET CERTIFIED** and must be established in the authorised V5B preflight; no rank is inferred from
  this read-only V5 review." §2.2 sends constant traces to `NOT_EVALUABLE`; D08 records that nonconstant
  rectifiable curves admit arclength representatives even with isolated zero-speed points, to be handled
  conservatively; protocol §6.4 requires guard handling around poles, almost-collapsed extents, retracing and
  tangent loss. This is a **correctly deferred obligation**, and deferring it is right: certifying ranks would
  require evaluating projections, which V5 forbids at this stage.
- **Regularity / proof method.** My Stage-1 C5 asked whether the amendment's §2.2 proof is curvature-based,
  which would mis-handle rank-one zigzags. It is **not**: the proof argues that every anchored displacement
  determinant must vanish, which assumes no regularity at all and handles zigzags, corners and non-injective
  traces correctly. **Concern resolved; the proof is sound as written.**
- **Frame convention.** The amendment requires a "proper camera lift" and inherited, non-fitted chirality, but
  does not pin the construction convention (`e₂ = n × e₁` versus `e₁ × n`). I verified in Stage 1 that
  `(e₁, n × e₁, n)` is the proper one. A global convention flip is invisible to every Gram-based self-check and
  inverts the sign of every `D_t`. Its effect is bounded and worth stating precisely: pairwise SO(2)
  inequivalence verdicts are **unaffected** (the mirror relation is symmetric and `W≠0` is sign-agnostic), but
  any **absolute** chirality statement would be inverted. Since amendment §3.1 makes chirality an inherited,
  non-fitted contract, the exposure is a single global sign. **Recommendation R-5:** pin the cross-product
  convention explicitly in V5B and include a known-chirality fixture test plus a degenerate-seed guard for
  `e₁ ∥ n`. Classification: **missing future guard**, low severity.

---

## 5. Independent contributions beyond the existing record

Checked against all three archives by keyword and by reading the relevant proof scripts; these are absent from
the first review, second review and focused requalification.

1. **`B_t(U,U)·B_t(V,V) − B_t(U,V)² = D_t(U,V)²`** (Stage-1 §2.4, symbolically verified for a generic
   quaternion frame). This upgrades amendment §2.1's assertion that reflection-even witnesses cannot separate
   an antipodal pair from a claim into a theorem: the Gram form determines `|D_t|` exactly and the sign not at
   all, so the orientation datum is precisely one bit and no function of `B_t` can recover it. It also explains
   the first review's failure structurally rather than by enumeration of its witnesses.
   **Recommendation R-6:** record it by additive erratum in the eventual archive as the proof of §2.1's
   insufficiency clause.
2. **Finite-sample indistinguishability witness** (Stage-1 §6.5) — see R-3.
3. **Demonstrated false `UNEQUAL` from non-arclength quartiles** (Stage-1 §5.4) — see R-1.
4. **`SET-IMAGE` non-transfer of the §2 toolkit** (Stage-1 §3.4, developed in §4.2 here) — see R-2.
5. **Class-count bound characterisation.** Amendment §2.5 requires "rigorous lower and upper class-count bounds
   over all equivalence partitions compatible with the certified relations". I verified (QC `Q5a`) that the
   minimum over compatible partitions is exactly the **chromatic number** `χ(H)` of the graph `H` whose vertices
   are `EQUAL`-components and whose edges are certified `UNEQUAL` pairs, with the upper bound the number of
   components: `χ(H) ≤ N ≤ k`. `χ` is NP-hard in general, so a V5B implementation will in practice compute a
   relaxation. **Recommendation R-7:** require V5B to declare which sound lower bound it reports (clique number,
   fractional/LP bound, or exact `χ` for small instances) rather than computing an unnamed quantity — a bound
   that is not provably `≤ χ(H)` would silently overstate separation. My Stage-1 §5.3 counterexample also shows
   the `UNRESOLVED_PAIR` bucket will contain genuinely *inequivalent* pairs, not only equivalent ones, so these
   bounds will be substantively loose and must not be read as near-exact.
6. **Scale prohibition is conservative, not load-bearing.** `det(S − λQ) = (λ−1)(λ+1)`, so for `λ > 0, λ ≠ 1`
   the map is invertible and no nonconstant curve is mirror-congruent at all. Forbidding scale cannot create a
   false merge; its actual function is to keep `ℓ` an invariant, which is the cheapest sound `UNEQUAL` witness
   available. **Recommendation R-8** (minor): note that any length normalisation would discard that witness.
7. **Closed-form reversal transformation of the anchored kernels**
   `G_R(s,t) = G(ℓ−s,ℓ−t) − G(ℓ−s,ℓ) − G(ℓ,ℓ−t) + G(ℓ,ℓ)` and the matching `A_R`, verified exactly. The
   requalification's `P5h` establishes that re-anchoring is necessary; these give the substitution to implement.
8. **`W²`/`|W|` for the O(2) branch** (QC `Q2b`) — see R-4.
9. **Chord-closed signed area is reversal-odd** (QC `Q3a–Q3c`). The second review offers it as a simpler
   witness "when reversal is not permitted". I confirm it is odd under **both** reflection and reversal, so it
   is a valid orientation witness **only** in the no-reversal branch and is unsound if reversal is permitted.
   The second review states this correctly; **Recommendation R-9:** if it is carried into V5B, the restriction
   must travel with it, since it is the one proposed witness that `W`'s reversal-invariance does not protect.

---

## 6. Stage-1 counterexample disposition

Each Stage-1 counterexample, classified as the brief requires. All are preserved unchanged in
`THIRD_REVIEW_BLIND_PROOF.md`.

| # | Stage-1 counterexample | Tests | Disposition |
|---|---|---|---|
| CE-1 | Isoceles V, exact rationals: noncollinear, `Fg = Rot(π)·Rg + (6/5,0)` | §2.3 sentence 1 | **Correctly deferred obligation / confirmation.** Not a defect — the amendment states this limit itself. Independently reproduces the requalification's `P5e/P5f` at different coordinates. |
| CE-2 | Four unit segments, `o,m,e` collinear: `W = 0` yet non-congruent with or without reversal | §2.3 "`W=0` is inconclusive" | **Confirmation; strengthens the record.** The requalification's `P5g` relies on a non-palindromic length sequence `(1,1,2)`; mine has all segments equal, so the length sequence *is* palindromic and non-congruence rests on the turning sequence alone (proved in exact complex arithmetic). This closes the loophole that `W=0` cases might always be cheaply detectable by length. Not a defect. |
| CE-3 | Two equal-length non-congruent curves with identical `G`, `A`, `W` on the whole sample grid | §2.4 final paragraph | **Missing future guard (test asset).** Not a defect; the amendment's statement is correct. New to the record — adopt as mandatory V5B negative test (R-3). |
| SG-A | Index-based quartiles give `W = 6/25 ≠ 0` on a proved mirror-congruent curve | §2.3 "never substitute uniformly sampled raw `θ` points" | **Correctly deferred obligation, with the guard already in the signed text.** Not a defect. Reclassified from Stage-1 "soundness-critical, unverified": the guard exists, and my counterexample shows it is load-bearing (R-1). |
| SG-B | Branchwise independent isometries do not compose | — | **Withdrawn.** Rested on my misreading of "branchwise" (§4.4). Retained only as a future multi-component scope note. |
| CE-4 | Circular arc: noncollinear, trace congruent to its mirror | protocol §5 `TR-ANALYTIC` / `SET-IMAGE` separation | **Missing future guard.** Not a defect — the protocol already separates the lanes and `SET-IMAGE` is unqualified. New finding: the §2 toolkit does not transfer to `SET-IMAGE` at all (R-2). |

**Stage-1 assumptions A1–A10:** A1 resolved at protocol level with a documentation gap (R-2); A2 resolved
(pre-registered reversal); A3 withdrawn; A4 correctly deferred; A5 specified, see R-1; A6 minor guard (R-5);
A7 resolved (`NOT_EVALUABLE`); A8 resolved and shown conservative (R-8); A9 resolved (the proof is
regularity-free); A10 resolved (primitive triples, per-pair antipodal certificates).

---

## 7. V5 qualification requirements versus legitimately deferred V5B requirements

The distinction the brief asks for, against protocol §8's own label definitions.

**V5 qualification requirements — all met.**

| Requirement | Evidence |
|---|---|
| Exact source attribution and provenance classes | Register plus amendment §1, §3.2 D07 split requirement; D01 cured by the `V5-*` namespace with a blanket non-satisfaction clause |
| Inherited domains and maps recovered literally, not invented | Amendment §3.1 (A/B domains, `θ∈[1,1+3π]`, G30/GHALF, 25 `(w,e)` cells, endpoint non-parity disclosed) |
| Matched-control design specified | 38-row matrix recounted: 30 eligible, 2 ineligible, 6 deferred, all `NOT_AUTHORIZED` |
| An orientation-sensitive certificate **design** exists and is mathematically valid | Amendment §2.1–2.5, independently re-derived here with no disagreement — this is what cures `B35` |
| Separate SO(2)/O(2) matrices; fail-closed three-valued logic; contradiction ⟹ `FAILED` | Amendment §2.5, verified sound (Stage-1 §7.1) |
| Identity, lineage and archive preservation | §1.3 live verification; both review archives byte-identical and unedited |
| No target leakage, no execution artefact | §1.4; independently searched, none found |

**Legitimately deferred to V5B — correctly, and `QUALIFIED` explicitly contemplates deferral.** Protocol §8
defines `QUALIFIED` as adequate specification "**with explicitly deferred continuous-geometry proof and optical
gates**". Deferred: certified projected-arclength enclosure and inversion of `s↦θ(s)` at `ℓ/4, ℓ/2, 3ℓ/4`;
interval library, rounding contract, precision and work budgets; stopping rules and certificate retention;
model-specific ranks, zero-length views and projection critical points (V5B preflight); the `V5-N0`
deterministic comparator and `V5-N3` ensembles; `SET-IMAGE`, `CS-NONCONVEX`, ribbon optics, K/C0 metrics,
G1/G2 extensions, Variant-B runs; the V5B primary-subset choice (D09); independent non-importing QC.

**Critically:** none of my findings is a missing *V5* requirement. R-1 through R-9 are all either additive
errata to the signed record or preconditions on a V5B protocol that does not yet exist. Consistent with the
brief, I assume no incorrect implementation exists — none is authorised, and I found no implementation to test.

**Against the three labels.** `BLOCKED` requires "immutable evidence / identity failure or forbidden target
leakage": none found; lineage, blobs, one-file scope and archive integrity all verify, and the only identity
item short of PASS is signature *trust*, which is an evidentiary limitation of my session, not a failure.
`INCOMPLETE` requires "a material domain, map, comparator, parity or proof obligation … not supportable without
inventing source content": D01 and D02 were the two material items, and both are cured by valid mathematics
and faithful source restatement with nothing invented; D03's residue is honest deferral. Therefore
**`QUALIFIED`** is the protocol-correct assignment.

---

## 8. Limits of independence in this session

1. **Procedural independence held.** Stage 1 was derived with no access to any prior review, amendment,
   requalification, project document or repository object; the proof was sealed and hashed before this package
   was opened, and the seal verifies unchanged (`0f398922…a1b9`). I did not run any prior reviewer's script as
   an oracle at any stage; where I inspected their scripts in Stage 2, it was to establish overlap, after my
   own results were fixed.
2. **Model-lineage correlation is real and is now evidenced, not merely hypothesised.** I am an AI model of the
   same family as the reviewer that proposed the correction (that session configured `claude-opus-5-5`, this
   one `claude-opus-5`). I predicted this risk in Stage-1 §11.1; §2.1 above shows it materialising — the same
   quaternion device and the same V-shape counterexample family, reached blind. This is the principal residual
   caveat, it cannot be discharged from inside this session, and it is **not** removed by my agreement with the
   amendment. What offsets it partially: the mathematics is elementary and mechanically checkable, every
   counterexample is exact rational data, and my four new findings are checks the earlier reviewer did not make.
3. **Signature trust was not established.** See §1.3. Lineage and content are verified live; cryptographic
   validity is `UNVERIFIABLE` here, and the GitHub attestation was not reproducible (403).
4. **Self-authored verification.** I wrote the symbolic checks confirming my own derivations. They detect
   algebra errors, not shared conceptual errors. All scripts and exact inputs are attached for re-execution.
5. **What would strengthen the record further.** A short check of amendment §2.2–2.3 by a human mathematician
   or a different provider's model, before the freeze — which is precisely what the focused requalification
   itself asked for in its §6. My review substantially discharges amendment §4.2's "genuinely independent"
   requirement in the procedural sense, and I judge the mathematics sound; it does not make the reviewer
   non-AI, and the owner should weigh that when deciding whether to proceed to the freeze.

---

## 9. Decision

**`MERU_3D_V5_SOURCE_MODEL_AND_NULL_DESIGN_QUALIFIED`** (prospective), on the following basis:

- D01 is cured without discharging any original P0A0/P0A1 obligation by stealth (E1 erratum recommended).
- D02 is cured: amendment §§2.1–2.5 are mathematically correct. I independently re-derived every claim blind
  and found **no disagreement and no defect**, having actively tried to break them.
- D03 is adequate, with rank/degeneracy and precision contracts honestly deferred to the V5B preflight.
- D04–D11 have adequate written dispositions.
- Lineage, blob identities, one-file commit scope and archive integrity verify against the live remote.
- No target leakage, no execution artefact, no identity failure.
- `B35` is satisfied prospectively; `B41` remains correctly `UNVERIFIABLE`; the historical second-review
  `INCOMPLETE` stands unaltered.

**Conditions carried forward (none blocks this status; R-1, R-2 and R-3 should be discharged before the V5B
protocol is signed, not before the freeze):**

| id | Recommendation | Type |
|---|---|---|
| R-1 | Mandatory V5B negative test: index/approximate quartiles must be shown to fail on a known mirror-congruent fixture | V5B precondition |
| R-2 | Additive erratum: annotate §2 as `TR-ANALYTIC`-scope; record that the toolkit does not transfer to `SET-IMAGE` | erratum + future scope |
| R-3 | Mandatory V5B negative test: the finite-sample indistinguishable pair must not return `EQUAL` | V5B precondition |
| R-4 | Note that an O(2)-branch orientation witness must use `|W|`/`W²`, not `W` | minor erratum |
| R-5 | Pin the camera-frame cross-product convention; known-chirality fixture; degenerate-seed guard | V5B precondition |
| R-6 | Record `B_UU·B_VV − B_UV² = D²` as the proof of §2.1's insufficiency clause | erratum |
| R-7 | V5B must declare which sound lower bound on `χ(H)` it reports | V5B precondition |
| R-8 | Note that `ℓ` is an invariant only because scale is forbidden; do not length-normalise | minor erratum |
| R-9 | If the chord-closed signed area is carried into V5B, the no-reversal restriction must travel with it | minor erratum |
| R-10 | E1/E2 editorial errata as the requalification proposed, independently upheld here | erratum |

**Not authorised and not performed:** any V5B calculation, precision or tolerance selection; any commit, push,
signature or freeze; any Hebrew, glyph, font, chart or source-image access; any candidate, control or null
projection; any V1–V4 re-execution. The human-controlled freeze note was not prepared, completed or signed.
`QUALIFIED` licenses only the drafting of a separately signed V5B preregistration.
