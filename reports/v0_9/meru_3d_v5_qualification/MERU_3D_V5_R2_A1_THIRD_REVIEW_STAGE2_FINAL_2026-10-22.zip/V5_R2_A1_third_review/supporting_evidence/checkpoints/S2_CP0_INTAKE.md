# Stage-2 CP0 — intake and authentication

- Stage-1 seal re-verified UNCHANGED before opening Stage 2: `0f398922a863b051c667c450576d5ba7c303e1eeb1530538cac90f991e16a1b9`.
- Stage-2 package manifest 6/6 OK.
- Both supplied Markdown documents are byte-identical to the Git blobs named in Stage-1 `00_READ_FIRST.md`
  (`a1ed423f…`, `9bc21565…`), computed locally with `git hash-object`.
- First impression requiring correction: the file named `SIGNED_V5_R2_A1_AMENDMENT.md` self-declares
  "DRAFT FOR HUMAN REVIEW — UNSIGNED". This is **not** a discrepancy: protocol §9.1 establishes that the
  DRAFT header remains archival and that authority comes from the GPG-signed commit. Recorded so the
  initial reading is not mistaken for a finding.
- Three review archives extracted; internal manifests 5/5, 15/15, 11/11 OK; archive hashes match the
  amendment's §0 claims. No archive was edited.
