# Stage-2 CP1 — findings before deliverables

1. No disagreement between the sealed Stage-1 blind proof and amendment §§2.1–2.5. Zero mathematical defects.
2. C1 is already specified in the signed text (§2.3 forbids raw-θ sampling and requires certified arclength
   inversion). My Stage-1 counterexample reclassifies from "soundness-critical, unverified" to
   "correctly deferred obligation, guard shown load-bearing".
3. C2 is resolved at protocol level (§5 TR-ANALYTIC vs SET-IMAGE); independently confirmed by the recount
   showing all 32 non-deferred matrix rows are TR-ANALYTIC. New forward finding: the §2 toolkit does not
   transfer to SET-IMAGE at all.
4. C5's regularity worry is resolved: the amendment's §2.2 proof is determinant-based, hence regularity-free.
5. One Stage-1 finding is WITHDRAWN: "branchwise" means analysis branch (SO(2) vs O(2)), not connected
   component. My §8.5 concern was about a scope the documents do not assert.
6. Convergence with the proposing reviewer on the quaternion device and the V-shape counterexample family
   is both corroboration and evidence of the lineage-correlation risk predicted in Stage-1 §11.1.
7. Four substantive contributions absent from the prior record; see the final QC JSON.
8. Status on protocol §8 criteria: QUALIFIED. No blocking item. Signature trust UNVERIFIABLE, not PASS.
