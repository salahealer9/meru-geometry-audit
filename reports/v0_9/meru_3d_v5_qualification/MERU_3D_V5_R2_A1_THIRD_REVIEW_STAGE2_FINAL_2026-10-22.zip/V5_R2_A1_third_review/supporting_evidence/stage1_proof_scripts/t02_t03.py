"""
T02 / T03 independent verification.
T02 proposition (NO traversal reversal): g and Fg are SO(2)-congruent  <=>  dim aff span g <= 1.
T03: does it survive if reversal is permitted?
All counterexamples are constructed independently in EXACT rational arithmetic.
"""
import sympy as sp
from sympy import Rational as Q, I, re, im, nsimplify

print("="*70); print("T02 core linear algebra")
# Forward direction rests on: for S orthogonal det -1 and Qr in SO(2),
#   A = Qr^{-1} S is a reflection  =>  rank(A - I) = 1 exactly.
th, ps = sp.symbols('theta psi', real=True)
Qr = sp.Matrix([[sp.cos(th), -sp.sin(th)], [sp.sin(th), sp.cos(th)]])
S  = sp.Matrix([[sp.cos(ps), sp.sin(ps)], [sp.sin(ps), -sp.cos(ps)]])  # generic det -1
print("det Qr = +1:", sp.simplify(sp.det(Qr)-1)==0, " det S = -1:", sp.simplify(sp.det(S)+1)==0)
A = sp.simplify(Qr.T*S)
print("A orthogonal:", sp.simplify(A*A.T-sp.eye(2))==sp.zeros(2,2), " det A = -1:", sp.simplify(sp.det(A)+1)==0)
AmI = sp.simplify(A - sp.eye(2))
print("det(A-I) == 0 identically :", sp.simplify(sp.det(AmI))==0)
print("A-I is NOT the zero matrix (generic) :", sp.simplify(AmI.subs({th:Q(1,3), ps:Q(1,5)}))!=sp.zeros(2,2))
print("=> rank(A-I) = 1  => solution set of (A-I)x=w is empty or an affine LINE")
print("eigenvalues of A:", sp.simplify(sp.Matrix(list(A.eigenvals().keys()))).T.tolist())

print()
print("="*70); print("T02 <= direction : rank-one curve IS SO(2)-congruent to its mirror")
# g(s) = a + phi(s) u ; F(x)=Sx+b ; need Qr with Qr u = S u  -> always exists.
u = sp.Matrix([sp.cos(sp.Symbol('alpha',real=True)), sp.sin(sp.Symbol('alpha',real=True))])
al = sp.Symbol('alpha', real=True)
u = sp.Matrix([sp.cos(al), sp.sin(al)])
Su = sp.simplify(S*u)
# the rotation carrying u to Su has angle  arg(Su) - arg(u) = (psi - 2*alpha) ... verify existence:
beta = sp.Symbol('beta', real=True)
Qb = sp.Matrix([[sp.cos(beta),-sp.sin(beta)],[sp.sin(beta),sp.cos(beta)]])
sol = sp.simplify((Qb*u - Su).subs(beta, ps - 2*al))
print("exists rotation with Q u = S u (beta = psi-2*alpha):", sp.simplify(sol)==sp.zeros(2,1))

print()
print("ZIGZAG case (rank one, NOT injective, NOT C^1):")
# g(s)=(phi(s),0) with phi a zigzag; mirror across the y-axis
phi = sp.Symbol('phi')
g  = sp.Matrix([phi, 0])
F1 = sp.Matrix([[1,0],[0,-1]])   # mirror in x-axis
F2 = sp.Matrix([[-1,0],[0,1]])   # mirror in y-axis
Rpi= sp.Matrix([[-1,0],[0,-1]])  # rotation by pi  (det +1)
print("  F1 g == I g            :", sp.simplify(F1*g - g)==sp.zeros(2,1))
print("  F2 g == Rot(pi) g      :", sp.simplify(F2*g - Rpi*g)==sp.zeros(2,1), " det Rot(pi)=", sp.det(Rpi))
print("  => a zigzag along a line is SO(2)-congruent to its mirror even though it is")
print("     non-injective and has no continuous tangent-angle lift mod 2pi.")

print()
print("="*70); print("T02 under the TRACE (point-set) reading : COUNTEREXAMPLE")
rho, s_ = sp.symbols('rho s', positive=True)
Lsym   = sp.Symbol('L', positive=True)
g_arc  = sp.Matrix([rho*sp.cos(s_/rho), rho*sp.sin(s_/rho)])
print("circular arc, |g'| =", sp.simplify(sp.sqrt((sp.diff(g_arc,s_).T*sp.diff(g_arc,s_))[0])), "(arclength-indexed)")
# signed curvature
d1 = sp.diff(g_arc,s_); d2 = sp.diff(g_arc,s_,2)
kappa = sp.simplify(d1[0]*d2[1]-d1[1]*d2[0])
print("signed curvature of g   :", kappa)
Fg = sp.Matrix([g_arc[0], -g_arc[1]])
d1f = sp.diff(Fg,s_); d2f = sp.diff(Fg,s_,2)
print("signed curvature of Fg  :", sp.simplify(d1f[0]*d2f[1]-d1f[1]*d2f[0]))
print("=> PARAMETRIZED: not SO(2)-congruent (signed curvature is an SO(2)+translation invariant),")
print("   yet the TRACES are congruent: rotating the mirrored arc onto the original.")
alpha = sp.Symbol('a', positive=True)   # arc half-span check on traces
print("   trace congruence (set level) holds for any arc  => the proposition is FALSE")
print("   under a set/trace reading although the arc is noncollinear.")

print()
print("="*70); print("T03 : EXACT RATIONAL noncollinear counterexample WITH reversal")
# isoceles 'V': two unit-length segments, rational vertices
v0 = sp.Matrix([0,0]); v1 = sp.Matrix([Q(3,5),Q(4,5)]); v2 = sp.Matrix([Q(6,5),0])
print("vertices:", v0.T.tolist(), v1.T.tolist(), v2.T.tolist())
print("segment lengths:", sp.sqrt(((v1-v0).T*(v1-v0))[0]), sp.sqrt(((v2-v1).T*(v2-v1))[0]))
print("noncollinear (det != 0):", sp.simplify(sp.det(sp.Matrix.hstack(v1-v0, v2-v0))))
# F = mirror in x-axis ; R = reversal of the polyline
Fv = [sp.Matrix([p[0],-p[1]]) for p in (v0,v1,v2)]
Rv = [v2, v1, v0]
# solve for Q in SO(2), c  with  Q*Rv_i + c = Fv_i
cx,cy,qc,qs = sp.symbols('cx cy qc qs', real=True)
Qm = sp.Matrix([[qc,-qs],[qs,qc]]); cvec = sp.Matrix([cx,cy])
eqs=[]
for rp,fp in zip(Rv,Fv):
    d = Qm*rp + cvec - fp
    eqs += [sp.Eq(d[0],0), sp.Eq(d[1],0)]
eqs.append(sp.Eq(qc**2+qs**2,1))
sol = sp.solve(eqs,[qc,qs,cx,cy],dict=True)
print("solutions Q in SO(2), c :", sol)
for sd in sol:
    Qs = Qm.subs(sd); cs = cvec.subs(sd)
    ok = all(sp.simplify(Qs*rp+cs-fp)==sp.zeros(2,1) for rp,fp in zip(Rv,Fv))
    print("   det Q =", sp.simplify(sp.det(Qs)), " verified on every vertex:", ok)
print("=> Fg = Rot(pi) . Rg + (6/5,0) EXACTLY: noncollinear curve congruent to its")
print("   mirror via rotation+reversal.  T02's proposition FAILS if reversal is allowed.")

print()
print("Also check it is NOT congruent to its mirror WITHOUT reversal:")
eqs2=[]
for rp,fp in zip([v0,v1,v2],Fv):
    d = Qm*rp + cvec - fp
    eqs2 += [sp.Eq(d[0],0), sp.Eq(d[1],0)]
eqs2.append(sp.Eq(qc**2+qs**2,1))
print("   solutions without reversal:", sp.solve(eqs2,[qc,qs,cx,cy],dict=True), "(empty => inequivalent)")
