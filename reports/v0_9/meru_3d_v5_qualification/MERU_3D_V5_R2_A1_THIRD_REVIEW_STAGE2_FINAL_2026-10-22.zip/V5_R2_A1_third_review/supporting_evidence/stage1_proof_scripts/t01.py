"""
T01 independent symbolic verification.
Everything is checked for a GENERIC proper (det=+1) orthonormal 3-frame,
parametrized two independent ways:
  (i) a full quaternion parametrization of SO(3)  -> reaches every proper frame
  (ii) an explicit camera roll by an arbitrary angle phi applied to a generic frame
No convenient coordinate specialization is used.
"""
import sympy as sp

# ---------- generic SO(3) via quaternion (exact, no sqrt) ----------
w,x,y,z = sp.symbols('w x y z', real=True)
N = w**2+x**2+y**2+z**2
M = sp.Matrix([
 [w**2+x**2-y**2-z**2, 2*(x*y-w*z),         2*(x*z+w*y)],
 [2*(x*y+w*z),         w**2-x**2+y**2-z**2, 2*(y*z-w*x)],
 [2*(x*z-w*y),         2*(y*z+w*x),         w**2-x**2-y**2+z**2]]) / N

print("M orthogonal  :", sp.simplify(M*M.T - sp.eye(3)) == sp.zeros(3,3))
print("det M = +1    :", sp.simplify(sp.det(M) - 1) == 0)

e1 = M.row(0).T; e2 = M.row(1).T; n = M.row(2).T

U = sp.Matrix(sp.symbols('u1 u2 u3', real=True))
V = sp.Matrix(sp.symbols('v1 v2 v3', real=True))

def proj(e_a, e_b, X): return sp.Matrix([ (e_a.T*X)[0], (e_b.T*X)[0] ])
def cross(a,b): return sp.Matrix([a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]])

pU = proj(e1,e2,U); pV = proj(e1,e2,V)

# B_t with t = lambda*n, lambda>0 : B depends on t only through n
B = (U.T*V)[0] - (n.T*U)[0]*(n.T*V)[0]
D = (n.T*cross(U,V))[0]

print("\n--- (i) generic quaternion frame ---")
print("p.p  == B_t      :", sp.simplify((pU.T*pV)[0] - B) == 0)
print("det(pU,pV)== D_t :", sp.simplify((pU[0]*pV[1]-pU[1]*pV[0]) - D) == 0)

# Gram-determinant identity: the Gram form determines |D| but NOT its sign.
BUU = (U.T*U)[0]-(n.T*U)[0]**2
BVV = (V.T*V)[0]-(n.T*V)[0]**2
BUV = B
print("B_UU*B_VV-B_UV^2 == D^2 :", sp.simplify(BUU*BVV-BUV**2 - D**2) == 0)

# ---------- (ii) arbitrary camera roll on the generic frame ----------
c,s = sp.symbols('c s', real=True)          # c=cos(phi), s=sin(phi)
roll = {c**2+s**2: 1}
e1r = c*e1 + s*e2
e2r = -s*e1 + c*e2
pUr = proj(e1r,e2r,U); pVr = proj(e1r,e2r,V)
gram_r = sp.simplify(sp.expand((pUr.T*pVr)[0]) - B)
det_r  = sp.simplify(sp.expand(pUr[0]*pVr[1]-pUr[1]*pVr[0]) - D)
# substitute the unit-circle relation
gram_r = sp.simplify(gram_r.subs(s**2, 1-c**2))
det_r  = sp.simplify(det_r.subs(s**2, 1-c**2))
print("\n--- (ii) arbitrary proper roll (cos phi, sin phi) ---")
print("roll-invariance of B :", sp.simplify(gram_r) == 0)
print("roll-invariance of D :", sp.simplify(det_r) == 0)

# ---------- antipodal normal: n -> -n ----------
print("\n--- antipodal viewing normal ---")
nm = -n
Bm = (U.T*V)[0] - (nm.T*U)[0]*(nm.T*V)[0]
Dm = (nm.T*cross(U,V))[0]
print("B_(-t) == B_t  (even) :", sp.simplify(Bm - B) == 0)
print("D_(-t) == -D_t (odd)  :", sp.simplify(Dm + D) == 0)

# ALL proper frames with third vector -n are rolls of (e1, -e2, -n).
print("base frame (e1,-e2,-n) is proper:",
      sp.simplify(sp.det(sp.Matrix.vstack(e1.T, (-e2).T, (-n).T)) - 1) == 0)
c2,s2 = sp.symbols('c2 s2', real=True)
f1 = c2*e1 + s2*(-e2)
f2 = -s2*e1 + c2*(-e2)
# R_ij = f_i . e_j  (relates the two planar frames)
R = sp.Matrix([[(f1.T*e1)[0], (f1.T*e2)[0]],
               [(f2.T*e1)[0], (f2.T*e2)[0]]])
R = sp.simplify(R)
detR = sp.simplify(sp.expand(sp.det(R)).subs(s2**2, 1-c2**2))
print("R entries:", R.tolist())
print("det R == -1 for EVERY proper antipodal frame :", sp.simplify(detR + 1) == 0)

# and p_{-t} = R p_t  pointwise
pU_m = proj(f1,f2,U)
diff = sp.simplify(sp.expand(pU_m - R*pU))
print("p_(-t) == R p_t pointwise :", sp.simplify(diff) == sp.zeros(2,1))
