"""
T04 independent verification of the W witness.
W(g) = det(m-o, e-o) * ( |q1-o|^2 - |q3-e|^2 )
with o=g(0), e=g(L), m=g(L/2), q1=g(L/4), q3=g(3L/4).
(a) translation (b) proper rotation (c) mirror (d) reanchored reversal
Then: is W!=0 a sound SO(2)-antipodal witness even with reversal?  Does W=0 imply equality?
"""
import sympy as sp
from sympy import Rational as Q

ox,oy,ex,ey,mx,my,ax,ay,bx,by = sp.symbols('ox oy ex ey mx my ax ay bx by', real=True)
o=sp.Matrix([ox,oy]); e=sp.Matrix([ex,ey]); m=sp.Matrix([mx,my])
q1=sp.Matrix([ax,ay]); q3=sp.Matrix([bx,by])

def W(o,e,m,q1,q3):
    det = sp.det(sp.Matrix.hstack(m-o, e-o))
    nrm = ((q1-o).T*(q1-o))[0] - ((q3-e).T*(q3-e))[0]
    return sp.expand(det*nrm)

W0 = W(o,e,m,q1,q3)
print("="*70); print("T04  exact transformation laws (generic symbolic sample points)")

# (a) translation
tx,ty = sp.symbols('tx ty', real=True); T=sp.Matrix([tx,ty])
print("(a) translation      : W(g+t) - W(g) =",
      sp.simplify(W(o+T,e+T,m+T,q1+T,q3+T) - W0))

# (b) proper rotation (generic, exact via qc^2+qs^2=1)
qc,qs = sp.symbols('qc qs', real=True)
Rot = sp.Matrix([[qc,-qs],[qs,qc]])
Wrot = sp.expand(W(Rot*o,Rot*e,Rot*m,Rot*q1,Rot*q3))
print("(b) proper rotation  : W(Qg) - W(g) =",
      sp.simplify(sp.expand(Wrot - (qc**2+qs**2)**2*W0)), "  (modulo qc^2+qs^2=1 -> 0)")
print("    check with qs^2 -> 1-qc^2 :", sp.simplify(sp.expand(Wrot - W0).subs(qs**2,1-qc**2)))

# (c) mirror reflection (generic det -1 orthogonal, exact)
sc,ss = sp.symbols('sc ss', real=True)
Ref = sp.Matrix([[sc,ss],[ss,-sc]])     # det = -(sc^2+ss^2) = -1 on the unit circle
Wref = sp.expand(W(Ref*o,Ref*e,Ref*m,Ref*q1,Ref*q3))
print("(c) mirror reflection: W(Fg) + W(g) =",
      sp.simplify(sp.expand(Wref + W0).subs(ss**2,1-sc**2)), "  => W(Fg) = -W(g)")
# with a translation part too
bx2,by2=sp.symbols('bx2 by2',real=True); Bv=sp.Matrix([bx2,by2])
Wref2 = sp.expand(W(Ref*o+Bv,Ref*e+Bv,Ref*m+Bv,Ref*q1+Bv,Ref*q3+Bv))
print("    full improper isometry Sx+b :",
      sp.simplify(sp.expand(Wref2 + W0).subs(ss**2,1-sc**2)))

# (d) reversal with reanchoring: s -> L-s  maps  o<->e, m->m, q1<->q3
print("(d) reanchored reversal: sample relabelling o'=e, e'=o, m'=m, q1'=q3, q3'=q1")
Wrev = W(e,o,m,q3,q1)
print("    det factor flips sign :", sp.simplify(sp.det(sp.Matrix.hstack(m-e,o-e)) + sp.det(sp.Matrix.hstack(m-o,e-o))) == 0)
print("    norm factor flips sign:", sp.simplify((((q3-e).T*(q3-e))[0]-((q1-o).T*(q1-o))[0]) + (((q1-o).T*(q1-o))[0]-((q3-e).T*(q3-e))[0])) == 0)
print("    W(Rg) - W(g) =", sp.simplify(sp.expand(Wrev - W0)), " => W is REVERSAL-INVARIANT")

print()
print("Soundness: translations, SO(2) and reanchored reversal all preserve W;")
print("every improper isometry negates it. So W(g)!=0 => g is not congruent to Fg")
print("under <translations, SO(2), reversal>.  Conversely congruence forces W=0.")

print()
print("="*70); print("Does W=0 imply congruence?  EXACT RATIONAL COUNTEREXAMPLE")
# 4 unit segments, rational unit directions, o,m,e deliberately collinear
d=[sp.Matrix([1,0]), sp.Matrix([Q(3,5),Q(4,5)]), sp.Matrix([Q(4,5),Q(3,5)]), sp.Matrix([Q(24,25),Q(7,25)])]
v=[sp.Matrix([0,0])]
for dd in d: v.append(v[-1]+dd)
print("vertices:", [tuple(p) for p in v])
print("all segment lengths 1 :", all(sp.simplify(((dd.T*dd)[0])-1)==0 for dd in d))
o_,q1_,m_,q3_,e_ = v[0],v[1],v[2],v[3],v[4]      # L=4, samples at s=0,1,2,3,4
print("det(m-o,e-o) =", sp.det(sp.Matrix.hstack(m_-o_,e_-o_)), " -> o,m,e COLLINEAR")
print("W(g) =", W(o_,e_,m_,q1_,q3_))

# exact congruence search: polylines with equal unit segments correspond vertex-to-vertex
cx,cy = sp.symbols('cx cy', real=True)
Qm = sp.Matrix([[qc,-qs],[qs,qc]]); cv=sp.Matrix([cx,cy])
Fv=[sp.Matrix([p[0],-p[1]]) for p in v]          # mirror in the x-axis
def congruent(src,dst):
    eqs=[]
    for a,b in zip(src,dst):
        dd=Qm*a+cv-b; eqs += [sp.Eq(dd[0],0),sp.Eq(dd[1],0)]
    eqs.append(sp.Eq(qc**2+qs**2,1))
    return sp.solve(eqs,[qc,qs,cx,cy],dict=True)
print("SO(2)+translation  g -> Fg      :", congruent(v,Fv), " (empty => inequivalent)")
print("SO(2)+translation  Rg -> Fg     :", congruent(list(reversed(v)),Fv), " (empty => inequivalent)")
print("=> W(g)=0 yet g is NOT congruent to its mirror, with or without reversal.")
print("   W=0 is therefore NECESSARY but NOT SUFFICIENT: a one-sided (fail-closed) witness.")

# exact non-palindromy of the turning sequence, as an independent cross-check
print()
def turn(d1,d2):      # exact unit complex number of the turning angle
    z1=d1[0]+sp.I*d1[1]; z2=d2[0]+sp.I*d2[1]
    return sp.simplify(z2/z1)
ts=[turn(d[i],d[i+1]) for i in range(3)]
print("turning unit-complexes:", ts)
print("beta1 == beta3 ? ", sp.simplify(ts[0]-ts[2])==0, " -> turning sequence NOT palindromic")
print("all beta in {0,pi} ? ", all(sp.simplify(sp.im(t))==0 for t in ts), " -> curve not collinear")

print()
print("="*70); print("A reversal-congruent curve must have W=0 (consistency check)")
v0=sp.Matrix([0,0]); v1=sp.Matrix([Q(3,5),Q(4,5)]); v2=sp.Matrix([Q(6,5),0])
oV,eV,mV = v0, v2, v1
q1V = v0 + Q(1,2)*(v1-v0); q3V = v1 + Q(1,2)*(v2-v1)
print("isoceles V of T03:  W =", W(oV,eV,mV,q1V,q3V), " (vanishes, as the theorem requires)")

print()
print("="*70); print("IMPLEMENTATION HAZARD: W's reversal-invariance needs EXACT ARCLENGTH quartiles")
P=[sp.Matrix([0,0]),sp.Matrix([1,0]),sp.Matrix([Q(3,2),1]),sp.Matrix([3,1]),
   sp.Matrix([Q(7,2),3]),sp.Matrix([5,3])]                      # non-uniform spacing, N=6 (even)
def W_byindex(pts):
    n=len(pts)-1
    return W(pts[0],pts[-1],pts[n//2],pts[n//4],pts[(3*n)//4])
print("W by POINT INDEX, forward :", W_byindex(P))
print("W by POINT INDEX, reversed:", W_byindex(list(reversed(P))))
print("equal? ", sp.simplify(W_byindex(P)-W_byindex(list(reversed(P))))==0)
print("=> index-based 'quartiles' on a non-uniformly sampled polyline are NOT symmetric")
print("   under s -> L-s, so the reversal-invariance theorem does not apply to them.")
