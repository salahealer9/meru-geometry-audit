import sympy as sp
from sympy import Rational as Q
print("="*72); print("Probe 1: does allowing POSITIVE SCALE create a loophole?")
lam,qc,qs,sc,ss=sp.symbols('lam qc qs sc ss',positive=True),None,None,None,None
lam=sp.Symbol('lam',positive=True); qc,qs,sc,ss=sp.symbols('qc qs sc ss',real=True)
Rot=sp.Matrix([[qc,-qs],[qs,qc]]); Ref=sp.Matrix([[sc,ss],[ss,-sc]])
Mx=sp.simplify(Ref-lam*Rot)
dete=sp.simplify(sp.expand(sp.det(Mx)).subs({qs**2:1-qc**2, ss**2:1-sc**2}))
print("det(S - lam*Q) =", sp.factor(sp.simplify(dete)))
print("=> invertible for every lam != 1 (lam>0).  Then (S-lam*Q)g(s)=const forces g CONSTANT.")
print("   So with scale allowed, a NONCONSTANT curve is never mirror-congruent at all:")
print("   the scale prohibition is not load-bearing for T02; it only preserves L as an invariant.")

print(); print("="*72); print("Probe 2: reparametrization lemma")
print("If g and g.sigma are both arclength-indexed on [0,L] and sigma is monotone onto,")
print("then length(g.sigma|[a,b]) = |sigma(b)-sigma(a)| must equal b-a for all a,b,")
print("so sigma is an isometry of [0,L]:  sigma(s)=s or sigma(s)=L-s.")
print("=> arclength indexing leaves EXACTLY ONE residual freedom: traversal reversal.")
print("   'monotone reparametrization absorbed by arclength' is therefore correct,")
print("   but it does NOT absorb reversal, which must be declared separately.")

print(); print("="*72); print("Probe 3: palindromic characterisation (reversal permitted)")
print("For a polyline with segment lengths l and turning angles b:")
print("  reflection  -> ( l , -b )")
print("  reversal    -> ( reverse l , -reverse b )")
print("so  Fg ~SO(2) g   <=> all b_i in {0,pi}  (collinear)")
print("    Fg ~SO(2) Rg  <=> l palindromic AND b palindromic")
# verify the reversal action on (l,b) concretely
def lb(P):
    d=[P[i+1]-P[i] for i in range(len(P)-1)]
    l=[sp.sqrt((x.T*x)[0]) for x in d]
    u=[(x/sp.sqrt((x.T*x)[0])) for x in d]
    b=[sp.simplify((u[i+1][0]+sp.I*u[i+1][1])/(u[i][0]+sp.I*u[i][1])) for i in range(len(u)-1)]
    return l,b
P=[sp.Matrix([0,0]),sp.Matrix([1,0]),sp.Matrix([Q(8,5),Q(4,5)]),sp.Matrix([Q(12,5),Q(7,5)])]
l,b=lb(P); lr,br=lb(list(reversed(P)))
print("  forward  l,b :",l,[sp.simplify(x) for x in b])
print("  reversed l,b :",lr,[sp.simplify(x) for x in br])
print("  reversal == (reverse l, conj of reverse b) :",
      lr==list(reversed(l)), all(sp.simplify(br[i]-sp.conjugate(list(reversed(b))[i]))==0 for i in range(len(b))))
print("  (conjugation of the unit complex = negation of the angle)")

print(); print("="*72); print("Probe 4: integrality of t and census de-duplication")
print("B_t and D_t depend on t ONLY through n = t/||t||:")
print("  B_(c t) = B_t and D_(c t) = D_t for every c > 0.")
print("=> a census over t in Z^3 must be reduced to PRIMITIVE representatives, or the")
print("   same projection is counted with multiplicity (gcd classes).")
print("=> and +t vs -t are mirror images (T01), so they must NOT be identified under")
print("   SO(2) unless the per-pair test says so.  Neither blanket rule is sound:")
print("   'always identify'  under-counts (the original O(2) error);")
print("   'never identify'   over-counts (fails on rank-<=1 and, with reversal, on")
print("                      palindromic curves, which symmetric source geometry favours).")
print()
print("Probe 5: BRANCHWISE equivalence")
print("If independent isometries are allowed per branch, EQUAL per branch does NOT imply")
print("the two whole projected figures are congruent by a SINGLE camera roll: different")
print("rotations on different branches are not realisable by one camera. And a per-branch")
print("W witness only certifies inequivalence once the branch MATCHING is fixed; with k")
print("branches an UNEQUAL verdict must rule out all k! matchings.")
