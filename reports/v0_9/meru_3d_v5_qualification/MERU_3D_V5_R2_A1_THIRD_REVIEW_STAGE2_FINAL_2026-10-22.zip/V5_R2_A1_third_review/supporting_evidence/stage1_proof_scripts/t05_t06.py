import sympy as sp
from sympy import Rational as Q
qc,qs,cx,cy = sp.symbols('qc qs cx cy', real=True)
Qm=sp.Matrix([[qc,-qs],[qs,qc]]); cv=sp.Matrix([cx,cy])
def congruent(src,dst):
    eqs=[]
    for a,b in zip(src,dst):
        d=Qm*a+cv-b; eqs+=[sp.Eq(d[0],0),sp.Eq(d[1],0)]
    eqs.append(sp.Eq(qc**2+qs**2,1))
    return sp.solve(eqs,[qc,qs,cx,cy],dict=True)
def W(o,e,m,q1,q3):
    return sp.expand(sp.det(sp.Matrix.hstack(m-o,e-o))*(((q1-o).T*(q1-o))[0]-((q3-e).T*(q3-e))[0]))

print("="*72)
print("T07-A  FALSE 'UNEQUAL' CERTIFICATE from index-based quartiles")
print("="*72)
# the isoceles V of T03: genuinely congruent to its mirror via rotation+reversal
v0=sp.Matrix([0,0]); v1=sp.Matrix([Q(3,5),Q(4,5)]); v2=sp.Matrix([Q(6,5),0])
d1=(v1-v0); d2=(v2-v1)
# asymmetric polyline sampling of the SAME curve (extra vertex only on the 1st segment)
P=[v0, v0+Q(1,4)*d1, v1, v2]
n=len(P)-1
o_,e_,m_,q1_,q3_ = P[0],P[-1],P[n//2],P[n//4],P[(3*n)//4]
print("asymmetric sample list :", [tuple(p) for p in P])
print("index-based W          :", W(o_,e_,m_,q1_,q3_))
# true arclength quartiles (L=2)
tq = W(v0, v2, v1, v0+Q(1,2)*d1, v1+Q(1,2)*d2)
print("true arclength-quartile W :", tq)
Fv=[sp.Matrix([p[0],-p[1]]) for p in (v0,v1,v2)]
print("curve IS congruent to its mirror (rotation+reversal):",
      congruent([v2,v1,v0],Fv))
print()
print(">>> index-based W != 0 would certify UNEQUAL for a curve that is in fact")
print(">>> congruent to its mirror. The W theorem is SOUND only for exact arclength")
print(">>> quartiles; an index/parameter-approximate implementation is UNSOUND.")

print()
print("="*72)
print("T05  Gram / determinant kernel completeness")
print("="*72)
# necessity: invariance of G under O(2), of A under SO(2), sign flip under reflection
sc,ss=sp.symbols('sc ss',real=True)
Ref=sp.Matrix([[sc,ss],[ss,-sc]])
a1,a2,b1,b2=sp.symbols('a1 a2 b1 b2',real=True)
va=sp.Matrix([a1,a2]); vb=sp.Matrix([b1,b2])
print("G invariant under rotation :",
      sp.simplify(sp.expand(((Qm*va).T*(Qm*vb))[0]-(va.T*vb)[0]).subs(qs**2,1-qc**2))==0)
print("G invariant under mirror   :",
      sp.simplify(sp.expand(((Ref*va).T*(Ref*vb))[0]-(va.T*vb)[0]).subs(ss**2,1-sc**2))==0)
print("A invariant under rotation :",
      sp.simplify(sp.expand(sp.det(sp.Matrix.hstack(Qm*va,Qm*vb))-sp.det(sp.Matrix.hstack(va,vb))).subs(qs**2,1-qc**2))==0)
print("A negated  under mirror    :",
      sp.simplify(sp.expand(sp.det(sp.Matrix.hstack(Ref*va,Ref*vb))+sp.det(sp.Matrix.hstack(va,vb))).subs(ss**2,1-sc**2))==0)
print("A == 0 identically  <=>  rank(span v) <= 1   (det of parallel vectors)")

print()
print("Reversal transforms the ANCHORED kernels (anchor moves from g(0) to g(L)):")
s_,t_,L_=sp.symbols('s t L')
print("  G_R(s,t) = G(L-s,L-t) - G(L-s,L) - G(L,L-t) + G(L,L)")
print("  A_R(s,t) = A(L-s,L-t) - A(L-s,L) - A(L,L-t)        [A(L,L)=0]")
# verify this algebraic identity on a concrete curve
pts={0:sp.Matrix([0,0]),1:sp.Matrix([1,0]),2:sp.Matrix([Q(8,5),Q(4,5)]),3:sp.Matrix([Q(12,5),Q(7,5)]),4:sp.Matrix([Q(84,25),Q(42,25)])}
L=4
def Gk(s,t,g): v1=g[s]-g[0]; v2=g[t]-g[0]; return (v1.T*v2)[0]
def Ak(s,t,g): v1=g[s]-g[0]; v2=g[t]-g[0]; return sp.det(sp.Matrix.hstack(v1,v2))
gR={i:pts[L-i] for i in range(L+1)}
okG=all(sp.simplify(Gk(s,t,gR)-(Gk(L-s,L-t,pts)-Gk(L-s,L,pts)-Gk(L,L-t,pts)+Gk(L,L,pts)))==0
        for s in range(L+1) for t in range(L+1))
okA=all(sp.simplify(Ak(s,t,gR)-(Ak(L-s,L-t,pts)-Ak(L-s,L,pts)-Ak(L,L-t,pts)))==0
        for s in range(L+1) for t in range(L+1))
print("  identity verified for G :",okG,"   for A :",okA)
print("  => the kernels are NOT reversal-invariant; all four combinations")
print("     (id/reversal) x (A / -A) must be tested explicitly.")

print()
print("="*72)
print("T05/T07-B  FINITE SAMPLING CANNOT CERTIFY EQUALITY (exact counterexample)")
print("="*72)
# g and g' : same length 4, identical at s = 0,1,2,3,4, non-congruent.
A0=sp.Matrix([0,0]); Vup=sp.Matrix([Q(3,10),Q(2,5)]); Vdn=sp.Matrix([Q(3,10),-Q(2,5)]); B0=sp.Matrix([Q(3,5),0])
tail_d=[sp.Matrix([1,0]), sp.Matrix([Q(3,5),Q(4,5)]), sp.Matrix([Q(4,5),Q(3,5)])]
tail=[B0]
for dd in tail_d: tail.append(tail[-1]+dd)
g  = [A0,Vup,B0]+tail[1:]
gp = [A0,Vdn,B0]+tail[1:]
print("g  vertices:", [tuple(p) for p in g])
print("g' vertices:", [tuple(p) for p in gp])
seg=lambda P:[sp.sqrt(((P[i+1]-P[i]).T*(P[i+1]-P[i]))[0]) for i in range(len(P)-1)]
print("segment lengths g :",seg(g)," total",sum(seg(g)))
print("segment lengths g':",seg(gp)," total",sum(seg(gp)))
samp=[0,1,2,3,4]   # arclength parameters;  s=0 -> A0, s=1 -> B0, then unit steps
gs ={0:A0,1:B0,2:tail[1],3:tail[2],4:tail[3]}
gps={0:A0,1:B0,2:tail[1],3:tail[2],4:tail[3]}
print("sampled points identical :", all(sp.simplify(gs[s]-gps[s])==sp.zeros(2,1) for s in samp))
print("=> G and A agree EXACTLY on the whole 5x5 sample grid, and W is identical.")
Fg=[sp.Matrix([p[0],-p[1]]) for p in g]
print("g congruent to g'  (no reversal) :", congruent(g,gp))
print("g congruent to Rg' (reversal)    :", congruent(g,list(reversed(gp))),
      "  [length sequences differ:",seg(g),"vs",list(reversed(seg(gp))),"]")
print(">>> two non-congruent curves of equal length, indistinguishable by any")
print(">>> finite sampled kernel containing those parameters.  EQUAL can never be")
print(">>> certified from finite samples; only UNEQUAL can.")

print()
print("="*72)
print("T06  closure consistency and certified class-count bounds")
print("="*72)
print("Theorem: let ~ be true congruence, E subset of ~ the EQUAL certificates,")
print("U subset of complement(~) the UNEQUAL certificates.  Then the reflexive-")
print("symmetric-transitive closure E* satisfies E* subset of ~ (a closure of a")
print("subrelation of an equivalence relation stays inside it), hence E* cap U = empty.")
print("Contrapositive: E* cap U != empty  =>  at least one certificate is UNSOUND.")
print("So the no-contradiction requirement is a THEOREM given sound certificates,")
print("and simultaneously a usable audit test for unsoundness.")
print()
print("Bounds: E* partitions the candidates into k blocks; every block lies inside one")
print("true class, so N <= k.  Build graph H on blocks with an edge whenever some U-pair")
print("joins them; a true class assignment is a proper colouring of H, so N >= chi(H)")
print(">= omega(H).  Certified bound:  chi(H) <= N <= k   (omega(H) computable lower bd).")
# toy demo
import itertools
blocks=['B1','B2','B3','B4']; Uedges=[('B1','B2'),('B2','B3'),('B1','B3')]
adj={b:set() for b in blocks}
for a,b in Uedges: adj[a].add(b); adj[b].add(a)
omega=max(len(c) for r in range(1,len(blocks)+1) for c in itertools.combinations(blocks,r)
          if all(y in adj[x] for x,y in itertools.combinations(c,2)))
def chrom(bl,adj):
    for k in range(1,len(bl)+1):
        for asg in itertools.product(range(k),repeat=len(bl)):
            mp=dict(zip(bl,asg))
            if len(set(asg))==k and all(mp[a]!=mp[b] for a,b in Uedges): return k
    return len(bl)
print("toy: 4 blocks, UNEQUAL edges",Uedges," -> omega =",omega," chi =",chrom(blocks,adj),
      " bound:",chrom(blocks,adj),"<= N <=",len(blocks))
