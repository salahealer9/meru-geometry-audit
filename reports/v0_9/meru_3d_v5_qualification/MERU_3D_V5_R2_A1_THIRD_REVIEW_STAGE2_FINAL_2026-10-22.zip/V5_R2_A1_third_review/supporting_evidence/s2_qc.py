"""Stage-2 QC: machine-check amendment claims NOT already covered by my sealed Stage-1 work,
plus the alternative witness the second review proposes for the no-reversal branch."""
import sympy as sp
from sympy import Rational as Q
res=[]
def rec(i,c,ok,note=""): res.append((i,c,"PASS" if ok else "FAIL",note)); print(f"{i:6} {'PASS' if ok else 'FAIL'}  {c}" + (f"   [{note}]" if note else ""))

print("="*78); print("S2-QC  amendment claims re-checked at Stage 2"); print("="*78)

# --- Q1: amendment 2.3 generalisation: disjoint W enclosures prove inequivalence for ANY pair
# W is invariant under <translation, SO(2), reanchored reversal>; hence W(g) != W(h) => g !~ h.
ox,oy,ex,ey,mx,my,ax,ay,bx,by=sp.symbols('ox oy ex ey mx my ax ay bx by',real=True)
o=sp.Matrix([ox,oy]);e=sp.Matrix([ex,ey]);m=sp.Matrix([mx,my]);q1=sp.Matrix([ax,ay]);q3=sp.Matrix([bx,by])
def W(o,e,m,q1,q3):
    return sp.expand(sp.det(sp.Matrix.hstack(m-o,e-o))*(((q1-o).T*(q1-o))[0]-((q3-e).T*(q3-e))[0]))
W0=W(o,e,m,q1,q3)
qc,qs,tx,ty=sp.symbols('qc qs tx ty',real=True)
Rot=sp.Matrix([[qc,-qs],[qs,qc]]);T=sp.Matrix([tx,ty])
inv_rot=sp.simplify(sp.expand(W(Rot*o+T,Rot*e+T,Rot*m+T,Rot*q1+T,Rot*q3+T)-W0).subs(qs**2,1-qc**2))
inv_rev=sp.simplify(W(e,o,m,q3,q1)-W0)
rec("Q1a","W invariant under translation+SO(2) jointly (generic)", inv_rot==0)
rec("Q1b","W invariant under reanchored reversal (generic)", inv_rev==0)
rec("Q1c","=> W is a class function of the SO(2)+reversal equivalence, so disjoint W\n       enclosures for two curves prove them inequivalent (amendment 2.3 generalisation)",
    inv_rot==0 and inv_rev==0)

# --- Q2: W is NOT an O(2) invariant; |W| (or W^2) is. Amendment uses W only for SO(2): consistent.
sc,ss=sp.symbols('sc ss',real=True); Ref=sp.Matrix([[sc,ss],[ss,-sc]])
Wref=sp.simplify(sp.expand(W(Ref*o,Ref*e,Ref*m,Ref*q1,Ref*q3)+W0).subs(ss**2,1-sc**2))
rec("Q2a","W odd under reflection => W is not an O(2) invariant", Wref==0)
rec("Q2b","W^2 is an O(2) invariant (so an O(2)-branch witness must use |W|, not W)",
    sp.simplify(sp.expand(W(Ref*o,Ref*e,Ref*m,Ref*q1,Ref*q3)**2-W0**2).subs(ss**2,1-sc**2))==0,
    "not stated in the amendment; only matters if W is ever reused in the O(2) branch")

# --- Q3: second review's alternative no-reversal witness: chord-closed signed area.
# A(g) = 1/2 * sum over the closed polygon (curve + closing chord). Claim: odd under BOTH
# reflection and reversal => valid ONLY in the no-reversal branch.
def closed_area(pts):
    P=list(pts)
    if P[0]!=P[-1]: P=P+[P[0]]
    return sp.Rational(1,2)*sum(P[i][0]*P[i+1][1]-P[i+1][0]*P[i][1] for i in range(len(P)-1))
g=[(0,0),(1,0),(Q(3,2),1),(Q(1,2),1)]
gm=[(x,-y) for x,y in g]
gr=list(reversed(g))
A0=closed_area(g)
rec("Q3a","chord-closed signed area is odd under reflection", sp.simplify(closed_area(gm)+A0)==0, f"A={A0}")
rec("Q3b","chord-closed signed area is odd under traversal reversal", sp.simplify(closed_area(gr)+A0)==0)
rec("Q3c","=> signed area is a valid orientation witness ONLY in the no-reversal branch,\n       exactly as the second review states; it is UNSOUND if reversal is permitted",
    sp.simplify(closed_area(gm)+A0)==0 and sp.simplify(closed_area(gr)+A0)==0)

# --- Q4: E1 (requalification editorial) - independent check of the namespace cross-reference.
orig={"N0":"arbitrary smooth 3-D curves",
      "N1":"length/curvature/complexity-matched curves",
      "N2":"generic 1.5-turn vortices with NON-FIXED RADIAL LAWS",
      "N3":"same-carrier, same-span non-reciprocal controls"}
v5n1="Variant-A RADIAL-LAW substitutions (Archimedean/logarithmic/Golden Mean)"
print()
print("Q4   E1 cross-reference check (textual, no computation):")
print("     V5-N1 =", v5n1)
print("     nearest original tier by CONTENT = N2:", orig["N2"])
print("     amendment's 'Relation' column for V5-N1 references original N1:", orig["N1"])
rec("Q4a","E1 upheld: V5-N1's nearest original type is N2 (radial-law), not N1 (complexity-matched)",
    True, "editorial only; the blanket non-satisfaction clause prevents substantive harm")

# --- Q5: class-count bound - amendment requires 'bounds over all compatible partitions'.
# Formalise: lower bound = chromatic number of the UNEQUAL graph on EQUAL-blocks; upper = #blocks.
import itertools
def bounds(blocks,U):
    k=len(blocks)
    for n in range(1,k+1):
        for asg in itertools.product(range(n),repeat=k):
            if len(set(asg))!=n: continue
            mp=dict(zip(blocks,asg))
            if all(mp[a]!=mp[b] for a,b in U): return n,k
    return k,k
b=['B1','B2','B3','B4']; U=[('B1','B2'),('B2','B3'),('B1','B3')]
lo,hi=bounds(b,U)
rec("Q5a","min over compatible partitions = chromatic number of the UNEQUAL graph", (lo,hi)==(3,4), f"{lo} <= N <= {hi}")
rec("Q5b","chromatic number is NP-hard in general => V5B must declare a SOUND relaxation\n       (clique/fractional/LP lower bound), not silently compute something else",
    True, "amendment says 'rigorous bounds' but not how")

print()
print("="*78)
print(f"TOTAL {sum(1 for r in res if r[2]=='PASS')}/{len(res)} PASS")
import json
json.dump({"schema":"meru-v5-r2-a1-third-review-stage2-qc-1","sympy":sp.__version__,
           "results":[{"id":i,"claim":c.replace('\n       ',' '),"result":r,"note":n} for i,c,r,n in res],
           "n_pass":sum(1 for r in res if r[2]=='PASS'),"n_total":len(res),
           "scope":"generic symbolic objects and invented rational polylines only; no Meru candidate/control/projection/target"},
          open('/home/claude/stage2_qc/stage2_qc_checks.json','w'),indent=1)
