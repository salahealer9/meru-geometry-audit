P0A3H-P1-C0 original operator archive; read-only source and host preflight; does not authorize any candidate execution.
