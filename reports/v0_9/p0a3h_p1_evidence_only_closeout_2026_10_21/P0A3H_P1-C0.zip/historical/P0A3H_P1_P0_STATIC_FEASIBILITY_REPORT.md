# P0A3H-P1 — P1-P0 Static Authentication and Feasibility Report (read-only; not P1-C0)

**Prepared:** 2026-10-21, 20:37–20:41Z, by the AI engineering agent. This is unsigned, read-only engineering analysis. It is not the authoritative P1-C0, which the operator collects on the target host, and it is not a QC decision.
**Feasibility finding:** **`P0A3H_P1_SCOPE_AMENDMENT_REQUIRED`**. The permitted two-file delta is statically insufficient: a third candidate file contains the same old runtime root and the same old lineage pins (§3).
**Activity attestation:** zero candidate imports or executions, zero tests, dry runs, smoke tests or previews, zero source edits, zero Git writes, no keys. Static reading, hashing, Git/GPG checks and one syntax-only `ast.parse` pass were performed (§6).

## 1. Authentication of signed authority (agent-side)
| Check | Result |
|---|---|
| Branch tip (`git ls-remote` and fresh clone) | `4c1634e6660a02ebdea62195f13fc4810fd08d41`, worktree clean |
| Direct parent | `8f4163df75ad33f9892b72cd62b75dbda24f0505` |
| Commit diff | exactly one addition: `docs/v0_9/p0a3h_p1_prospective_portability_and_cross_host_identity_rebinding_protocol_2026_10_21.md` |
| Protocol Git blob / content SHA-256 / bytes | `557e778363c068b893855928f973dd3e9071597e` / `adac839f73b1039a2400da2fa20990cdb420489ccc77e89755ef1f4fdea3c7aa` / 25,073; read in full |
| `git verify-commit --raw` VALIDSIG `D4EC014EEFCC90E619D2AA59A91239ABCF512130` | 4c1634e6, 8f4163df, 39364f5a, 11203600, 2b77d6f3, d9d0d6ad, e491e1e9, 0e86df64, 59eb47f7; all 33 commits since the v0.8.0 target; signed tag v0.8.0 |
| L1 closeout blob | `177197ba9e208fa90c3af5568c0401d88a115abd` (matches the protocol) |
| Not established | GitHub signature badge not checked. Ownertrust not asserted (key taken from the in-repo provenance file, key-file SHA-256 `af66fcd2…63b8`). |

## 2. Inherited frozen objects (from signed Git objects at 4c1634e6)
| Object | Observed |
|---|---|
| `original_P0A3G_R2_C1_REV1.zip` | 197,250 B, `b34a3cd2…9b1`; ZIP check PASS (85 members) |
| `lock/SOURCE_LOCK.json` / `lock/R2_EXTERNAL_LOCK.json` | `abff7aa8…5902` / `2c8301fd…89b6` |
| 51 candidate files | match SOURCE_LOCK (bytes and SHA-256); byte-identical to the signed G-CFINAL candidate (`8b0ec808…3a6a`, 1,271,972 B, ZIP check PASS) |
| Kernels | `algebra.py` `442065…6d2d`, `core.py` `37701d…d420`, `arithmetic.py` `72b3c3…f0ba`: all match |
| `R2_H01.request.json` | 735 B, `0807f224…98fa` |
| L1 runtime audit / L1-C0 | 3,646 B `3b7dcc3b…2ca8` / 105,474 B `774e58c7…7e3a` (ZIP check PASS, 21 members) |

The reference tree was extracted read-only to `/home/claude/P0A3H_P1/reference/`. No derivative tree was created.

## 3. Static runtime and authority dependency map
| # | Location (unchanged reference bytes) | Dependency | Covered by the permitted delta? |
|---|---|---|---|
| D1 | `schemas/v0_9/p0a3g/resource_policy.json` (`9b7221fc…`) | `interpreter` `/usr/bin/python3.12`, `interpreter_sha256`, `openssl` `/usr/bin/openssl`, `openssl_sha256` | **Yes** (file 1, four fields) |
| D2 | `supervisor.py` l.75, 77 | worker launched as `POLICY['interpreter'] -I -S -B worker.py …` after `sha(read_bytes(POLICY['interpreter'])) == interpreter_sha256` (follows symlinks) | Yes, via D1; no supervisor edit needed |
| D3 | `src/.../identity.py` (`77aef8ba…`) l.31–34 `environment()` | stdlib root `/usr/lib/python3.12` plus the 11 relative dependency files; `sys.version`, `platform.platform()`, executable realpath and SHA-256, flags | **Yes** (file 2) |
| D4 | `src/.../identity.py` l.20–23, 71 | `PROTOCOL` `adacfdbc…`, `PARENT` `d95c50ea…`, `ANCESTRY` (6 commits), `BASELINE` `6ec2b6e9…` (R1-CFINAL); the envelope must equal these exactly | **Yes** (file 2, lineage constants) |
| D5 | `src/.../identity.py` l.56–65 `openssl_verify` | `POLICY['openssl']` resolved and hash-pinned; CLI `pkeyutl -verify -pubin -rawin -sigfile`, success iff rc 0 and `Signature Verified Successfully` | Yes, via D1; CLI semantics on 3.0.22 unverified (§5) |
| **D6** | **`reference/v0_9/qo2d_exact/identity.py` (`9bb68f70…`) l.16–17** | **independent checker's own `PINS`: `protocol_commit` `adacfdbc…`, `signed_parent` `d95c50ea…`, `git_ancestry` (same 6), `baseline_archive_sha256` `6ec2b6e9…`; envelope must equal them (l.23)** | **NO** |
| **D7** | **`reference/v0_9/qo2d_exact/identity.py` l.47–49** | **independent checker recomputes `environment` with a hard-coded `/usr/lib/python3.12` root (same 11 files) and compares it to the envelope's `environment_sha256`** | **NO** |
| D8 | `reference/.../checker.py` l.96, `service.py` | the reference checker calls D6/D7 on every `check` worker run (in `supervisor.checked_record`) | Affected by D6/D7 |
| D9 | `schemas/v0_9/p0a3g/authority_envelope.schema.json` (`6fab2c47…`) | JSON-Schema `const` values for the old pins | Documentation only: not loaded at runtime (no code reads it). It would become stale text. |
| D10 | `tests/dev_v0_9/p0a3g/authority_fixtures.py` (`6e2325a2…`), `g_checks.py` | old pins, `/usr/lib/python3.12`, `/usr/bin/python3.12` and `/usr/bin/python3.13` in historical test helpers | Not on the runtime path; P1 builders and tests are new external code. They must stay byte-unchanged because `files()` hashes `tests/`. |

**Why D6/D7 block the two-file route:**
- `supervisor.run` accepts nothing unless the `check` worker succeeds, and that worker runs the reference identity gate.
- **D7:** on the Debian host `/usr/lib/python3.12/*` is absent (L1 audit), so the gate raises and returns `CODE_IDENTITY_MISMATCH / EXTERNAL_IDENTITY_MISMATCH` for every envelope.
- **D6:** even if D7 were fixed, an envelope stating the P1 lineage (as the protocol requires) is rejected by the old checker pins. An envelope stating the old P0A3G lineage would be accepted by the checker but contradicts the protocol's requirement that P1 authority is not satisfied by reciting the old identity, and would disagree with a P1-rebound production `identity.py`.
- **Consequence:** P02, the positive half of P03, and P05 could not succeed without an edit outside the permitted set. Host-side aliasing (for example creating `/usr/lib/python3.12`) would be the prohibited alias or symlink cure and is not proposed.

**Minimal additional delta for a human-signed amendment (proposal only; nothing edited):**
- Third file: `reference/v0_9/qo2d_exact/identity.py`.
  - Change exactly (a) the `PINS` lineage values, mirroring the production P1 constants.
  - Change exactly (b) the stdlib root literal on line 48, to the same measured root as production.
- Optionally, for documentation consistency only, update `authority_envelope.schema.json` (D9) or record it as a historical label. Leaving it unchanged does not affect runtime.

**Other Python 3.11 compatibility (static, no execution):**
- All 20 `.py` files parse with `ast.parse(feature_version=(3,11))` under 3.12.3. The f-strings are simple, with no PEP 701 nesting.
- APIs used (`sys.set/get_int_max_str_digits`, `str.removeprefix`, `os.walk`, `subprocess.Popen(start_new_session, preexec_fn)`, `selectors`, `resource`) all exist in 3.11.
- No 3.12-only API was found (`Path.walk`, `is_integer`, `batched` and similar).
- Kernels use only `fractions.Fraction`, `int.bit_length` and `math.gcd`.
- Limit of this check: the parse ran on the 3.12 parser. The operator should repeat the syntax-only parse with the real 3.11.2 parser (§5).

## 4. Proposed changes (text only; not applied)
1. `resource_policy.json`: set `interpreter` `/usr/bin/python3.11` (a regular file per the recorded profile; symlink `/usr/bin/python3` not used), `interpreter_sha256` to the re-measured value (recorded `9bee109d…1a5f`), `openssl` `/usr/bin/openssl`, `openssl_sha256` to the re-measured value (recorded `66521161…ad7d`). Keep key order, indentation and all other fields byte-identical.
2. `src/.../identity.py`:
   - Change the stdlib root literal on line 32 to the measured root (expected `/usr/lib/python3.11`) and keep the same 11 names.
   - Change `PROTOCOL` to `4c1634e6660a02ebdea62195f13fc4810fd08d41` and `PARENT` to `8f4163df75ad33f9892b72cd62b75dbda24f0505`.
   - Choose `ANCESTRY` truthfully; this is a reviewer decision. Option A is the full first-parent chain `4c1634e6…` back to `59eb47f7…` (18 commits). Option B is a minimal list of the P1 commit, its parent and the R2/P0A3G/P0A3D anchors.
   - Choose for `BASELINE` either to retain the historical R1-CFINAL value with an explicit "historical referent" comment, or to rebind it to the actual derivative source archive R2-C1-REV1 `b34a3cd2…`. This needs the reviewer's reading of "lineage adjustment".
3. **(Amendment required)** `reference/v0_9/qo2d_exact/identity.py`: the identical P1 lineage values in `PINS`, and the same stdlib root on line 48.
4. No change to `supervisor.py`, `wire.py`, `worker.py`, the kernels, the tests, `checker.py`, `ed25519_ref.py`, bounds, schemas (other than the optional D9) or modes. `DEPLOYMENT` stays fail-closed in both routes (`identity.py` l.76 `REAL_HUMAN_SIGNED_AUTHORITY_ABSENT`; reference l.26).

## 5. Required operator measurements for P1-C0 (passive; target host)
1. `/etc/os-release`, `uname -srvm`, virtualization or container status (the recorded kernel string suggests a vendor VM kernel; record it, do not assume).
2. For `/usr/bin/python3.11`, `/usr/bin/python3` and `/usr/bin/openssl`: `readlink -f`, regular-file or symlink status, size, SHA-256.
3. `python3.11 -I -S -B -c` that prints `sys.version`, `sys.flags` and `sysconfig.get_paths()['stdlib']`. This runs the interpreter without any candidate import.
4. SHA-256 and existence of the 11 dependency files under the measured stdlib root. Confirm `pathlib.py` is a single file and `decimal.py` exists.
5. `openssl version -a`; `openssl pkeyutl -help` (help text only) to confirm `-rawin` and `-sigfile` exist. No signature operation.
6. `ldd` of python3.11 and openssl, with SHA-256 of the resolved shared libraries (libcrypto, libssl, libc, libpython if any). Package versions via `dpkg -l python3.11 libpython3.11-stdlib openssl libssl3`.
7. `/proc` mount and the passive `/proc/self` entries; shell `ulimit -a` or `prlimit` to show that RLIMIT_AS, CPU, FSIZE, NOFILE and CORE can be set. Free disk space for the 16 MiB attempt bound.
8. Syntax-only parse of all 20 reference `.py` files with the real `/usr/bin/python3.11` (`ast.parse` on file bytes; no import, no `py_compile`).

## 6. Unverified assumptions (to be resolved by measurement or the released attempt)
- **U1** The recorded binary hashes are unchanged on the target host.
- **U2** The stdlib root is `/usr/lib/python3.11` and contains all 11 files.
- **U3** OpenSSL 3.0.22 verifies Ed25519 with the same CLI and output string.
- **U4** The CPython 3.11 worker's startup VmSize satisfies the candidate's calibration rule (VmSize + 64 MiB ≤ 256 MiB) under RLIMIT_AS 256 MiB. This is checkable only at runtime (P02).
- **U5** Canonical JSON and exact Fraction results are identical between 3.11 and 3.12, so P05's comparison with retained R2 comparators holds.
- **U6** The host can enforce all rlimits. If not, the result is `ENVIRONMENT_UNQUALIFIED`.
- **U7** `platform.platform()` and `sys.version` are stable between envelope build and worker run on the same host.

## 7. Intended contents
- **P1-C0** (operator-built; per protocol §4): signed-authority and lineage ledger (§1); historical negative-status ledger; reference ZIP digests and 51-file checks (§2); host profile and dependency register (§5); this static dependency map and the scope finding; role and exposure ledger (§8); trust and residual-threat register; unchanged resource policy; operator-attested `NO_P1_CANDIDATE_EXECUTION_YET` chronology; manifest/inventory; durable readback.
- **P1-C1** (only after C0 review and, given this finding, a signed amendment):
  - the 51-file reference and SOURCE_LOCK;
  - the 51-file derivative with a per-file before/after ledger (2, or 3 if amended, changed files) and kernel proof;
  - `P1_CANDIDATE_LOCK.json`, labelled `P0A3H_P1_NEW_PORTABLE_SOFTWARE_CANDIDATE_UNQUALIFIED`;
  - field-level change proof;
  - external P1 envelope/receipt builders bound to P1 lineage, with a non-production key generation spec;
  - bounded launcher, raw-stream recorder and standalone reconciler;
  - static P01–P06 fixtures, commands and acceptance rules (P05 comparator = retained signed R2 outputs or the frozen reference, fixed in advance);
  - the P1-C0 receipt and hash, chronology, and a P1-C2 receipt-inclusion checklist (C0 receipt, C1 receipt and release physically inside C2).

## 8. Role and exposure disclosure
- **Authorship of the candidate:** this agent authored the P0A3E/F/G candidate code, including both `identity.py` files, `supervisor.py`, `streamcapture.py`, `authority_fixtures.py` and `g_checks.py`.
- **Authorship of the R2 and C3 tooling:** this agent authored the R2 external driver, H01–H06 wrapper and reconciler, and the C3 tools, and wrote all the R2 and C3 receipts.
- **Executions run by this agent:** the P0A3G smoke1 and smoke2 scripts, four pre-lock dry runs and `P0A3G_DEV_01`, and the R2 single attempt (20/20).
- **Prior P0A3H work:** this agent prepared P0A3H H-C0, which stopped incomplete after two platform safety interruptions while preparing H02–H05. No tests were run in that lane.
- **Independence:** this agent did not participate in L1 (operator-run). It is not an independent source reviewer of this candidate, and any review it performs is author-review, not developer-independent review.
