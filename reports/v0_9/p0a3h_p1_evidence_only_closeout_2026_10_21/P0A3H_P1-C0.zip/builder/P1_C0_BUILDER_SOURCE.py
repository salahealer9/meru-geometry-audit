#!/usr/bin/env python3
"""P0A3H-P1-A1 local C0 archive and static-host collector.

ChatGPT/GPT-6 authored on 2026-10-21. Preparation-only, not an independent
source-design audit. Executes ordinary local archival/Git/host-inspection tools,
never imports or launches mathematical candidate code or registered tests.

Operator statement about no prelock tests is an attestation, not host telemetry.
"""
from __future__ import annotations
import argparse
import ast
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import resource
import shutil
import stat
import subprocess
import sys
import sysconfig
import zipfile

BRANCH='hebrew-projection-capacity-v0.9'
A1='82dc0d2b2f2b81f90ec60dfed8e3aade19555d40'
P1='4c1634e6660a02ebdea62195f13fc4810fd08d41'
DIRECT_PARENT=P1
P1_PARENT='8f4163df75ad33f9892b72cd62b75dbda24f0505'
P0A3D='59eb47f7500d57866e4935822b78a555d3bcb515'
KEY='D4EC014EEFCC90E619D2AA59A91239ABCF512130'
A1_DOC='docs/v0_9/p0a3h_p1_a1_three_file_identity_rebinding_scope_amendment_protocol_2026_10_21.md'
A1_BLOB='a3a27a4f9379f8aacae085938eca39e5bb5b215f'
P1_DOC='docs/v0_9/p0a3h_p1_prospective_portability_and_cross_host_identity_rebinding_protocol_2026_10_21.md'
P1_BLOB='557e778363c068b893855928f973dd3e9071597e'
H_CLOSEOUT='docs/v0_9/p0a3h_hc0_incomplete_preflight_independent_qc_preservation_2026_10_21.md'
H_CLOSEOUT_BLOB='1335e1a192f3cfcc510f5c6640d1cf5fd0668b65'
L1_CLOSEOUT='docs/v0_9/p0a3h_l1_c0_runtime_pin_blocker_independent_qc_preservation_2026_10_21.md'
L1_CLOSEOUT_BLOB='177197ba9e208fa90c3af5568c0401d88a115abd'
ORIGINALS={
  'R2-C1-REV1':('reports/v0_9/p0a3g_r2_independent_qc_incomplete_checkpoint/original_P0A3G_R2_C1_REV1.zip',197250,'b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1'),
  'G-CFINAL':('reports/v0_9/p0a3g_independent_qc_incomplete_checkpoint/original_P0A3G_G-CFINAL.zip',1271972,'8b0ec808ddea05d31422ad30308d3a5bbe8aaadb860cd613adf51bdcc9f33a6a'),
  'L1-C0':('reports/v0_9/p0a3h_l1_c0_runtime_pin_blocker_checkpoint/original_P0A3H_L1-C0.zip',105474,'774e58c72921bdf97cf14cd9628278c4bab1c327086e9297879c8a46b4117e3a'),
}
STATIC_REPORT={'filename':'P0A3H_P1_P0_STATIC_FEASIBILITY_REPORT.md','bytes':13613,'sha256':'50158e256f78748ba3fde6467c461869adbf5093830e008de8116a646c84789f'}
STATIC_JSON={'filename':'P0A3H_P1_P0_STATIC_FEASIBILITY_FINDINGS.json','bytes':3263,'sha256':'e46b172389d8ef4fc9975daa75a562ff4e60a1050487bd18fe5b4b5125f55179'}
KERNELS={
  'src/meru_geometry/v0_9/qo2d_exact/algebra.py':'442065847937252db00d3f63b02184c15d57989f958f764c5c731cb385de6d2d',
  'src/meru_geometry/v0_9/qo2d_exact/core.py':'37701d034d98725673240a881420892893906c70387f68432b5993f8557dd420',
  'reference/v0_9/qo2d_exact/arithmetic.py':'72b3c37f02be65b2df7616a94e84601d66cf4af5b7a50e878724de647e5bf0ba',
}
FROZEN_FILES={
  'schemas/v0_9/p0a3g/resource_policy.json':'9b7221fcfb54dc313874c9873423001ae7856b3a1889f12b92f9638abd904e09',
  'src/meru_geometry/v0_9/qo2d_exact/identity.py':'77aef8baaaa53e2642e6b13bbff86ca74401e749c6835aadd823a6ce074f7076',
  'reference/v0_9/qo2d_exact/identity.py':'9bb68f707bb1c3bf5802276408b8ad4800f2b2f78a502f9217ad704bba04aa24',
}
LIBNAMES=['decimal.py','fractions.py','hashlib.py','json/__init__.py','json/decoder.py','json/encoder.py','json/scanner.py','pathlib.py','selectors.py','subprocess.py','tempfile.py']
EXPECTED_PY='/usr/bin/python3.11'
EXPECTED_PY_SHA='9bee109da0dce17a7c9eeaca9f420cc6770a9fe143b9382d73bd22fe59b21a5f'
EXPECTED_SSL='/usr/bin/openssl'
EXPECTED_SSL_SHA='66521161cfad981e189bbc746560e0cc71a141b3765b3fe3658704d877c6ad7d'

def H(data:bytes)->str:return hashlib.sha256(data).hexdigest()
def jbytes(obj)->bytes:return (json.dumps(obj,indent=2,sort_keys=True,ensure_ascii=False)+'\n').encode()
def require(ok,why):
    if not ok:raise RuntimeError('P0A3H_P1_PREFLIGHT_INCOMPLETE: '+why)
def run(argv,cwd=None,timeout=45):
    p=subprocess.run(argv,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=timeout,check=False)
    require(p.returncode==0,f'host command failed: {argv!r}; {p.stderr[:200]}')
    return p.stdout.strip(),p.stderr.strip()
def zipcheck_bytes(raw:bytes, expected_size=None, expected_sha=None, require_inv=True):
    if expected_size is not None:require(len(raw)==expected_size,'ZIP bytes disagree with signed size')
    if expected_sha is not None:require(H(raw)==expected_sha,'ZIP hash differs from signed value')
    import io
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        names=z.namelist()
        require(len(names)==len(set(names)),'duplicate ZIP paths')
        for v in z.infolist():
            n=v.filename
            require(n and not n.startswith('/') and '\\' not in n and '..' not in PurePosixPath(n).parts and not v.is_dir(),'unsafe zip member '+n)
            require(stat.S_IFMT(v.external_attr>>16) in (0,stat.S_IFREG),'nonregular ZIP member '+n)
            require(v.file_size <= 4*1024*1024, 'unexpected large member: '+n)
        require(z.testzip() is None,'ZIP CRC failure')
        if require_inv:
            require('SHA256SUMS' in names and 'PACKAGE_INVENTORY.json' in names,'missing archive manifests')
            checks={}
            for line in z.read('SHA256SUMS').decode().splitlines():
                m=re.fullmatch(r'([0-9a-f]{64})  (.+)',line)
                require(m is not None,'malformed checksum line')
                require(m.group(2) not in checks,'duplicate checksum row')
                checks[m.group(2)]=m.group(1)
            require(set(checks)==set(names)-{'SHA256SUMS'},'checksum coverage mismatch')
            for n,dh in checks.items():require(H(z.read(n))==dh,'member SHA mismatch: '+n)
            inv=json.loads(z.read('PACKAGE_INVENTORY.json'))
            rows=inv.get('payload_files',inv.get('files'))
            require(isinstance(rows,list),'missing inventory list')
            require(len({r['path'] for r in rows})==len(rows),'duplicate inventory rows')
            require({r['path'] for r in rows}==set(names)-{'SHA256SUMS','PACKAGE_INVENTORY.json'},'inventory coverage mismatch')
            for r in rows:
                b=z.read(r['path']);require(H(b)==r['sha256'] and len(b)==r['bytes'],'inventory mismatch '+r['path'])
        return {'sha256':H(raw),'bytes':len(raw),'members':len(names)}
def pack(path:Path,payloads:dict[str,bytes]):
    require(all('/' not in n[:1] and '\\' not in n and '..' not in PurePosixPath(n).parts for n in payloads),'unsafe outgoing archive name')
    inv={'excludes':['SHA256SUMS','PACKAGE_INVENTORY.json'],'payload_count':len(payloads),'payload_files':[
        {'path':n,'bytes':len(v),'sha256':H(v)} for n,v in sorted(payloads.items())]}
    all_items=dict(payloads)
    all_items['PACKAGE_INVENTORY.json']=jbytes(inv)
    all_items['SHA256SUMS']=''.join(f'{H(v)}  {n}\n' for n,v in sorted(all_items.items())).encode()
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=False) as z:
        for n,v in sorted(all_items.items()):
            info=zipfile.ZipInfo(n,date_time=(2026,10,21,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=(stat.S_IFREG|0o644)<<16
            z.writestr(info,v)
    return zipcheck_bytes(path.read_bytes())
def sigcheck(repo,commit):
    o,e=run(['git','verify-commit','--raw',commit],cwd=repo)
    require('VALIDSIG '+KEY in e or 'VALIDSIG '+KEY in o, 'valid GPG signature missing '+commit)
    label,_=run(['git','log','-1','--format=%G?%n%GF',commit],cwd=repo)
    require(label=='G\n'+KEY,'GPG status/fingerprint differs '+commit)
def safe_bin(path,expected):
    f=Path(path)
    require(f.is_file(),'required executable not present '+path)
    require(not f.is_symlink(), 'expected executable is symlink '+path)
    b=f.read_bytes()
    require(H(b)==expected,'host binary digest different from registered P1 host '+path)
    return {'path':path,'realpath':str(f.resolve()),'bytes':len(b),'sha256':H(b),'symlink':f.is_symlink(),'file_mode':oct(f.stat().st_mode)}
def main():
    ap=argparse.ArgumentParser(description='P1-C0 nonexecuting archive, frozen-source and local host collector')
    ap.add_argument('--repo',type=Path,required=True)
    ap.add_argument('--engineering-report',type=Path,required=True)
    ap.add_argument('--engineering-findings',type=Path,required=True)
    ap.add_argument('--output-root',type=Path,required=True)
    ap.add_argument('--affirm-no-p1-execution',action='store_true',help='Explicit human attestation, not independent telemetry')
    args=ap.parse_args()
    require(args.affirm_no_p1_execution,'human attestation flag absent')
    repo=args.repo.expanduser().resolve(strict=True)
    require((repo/'.git').exists(),'repository .git not found')
    outroot=args.output_root.expanduser().resolve()
    require(repo!=outroot and repo not in outroot.parents, 'output would enter frozen repository')
    branch,_=run(['git','branch','--show-current'],cwd=repo)
    head,_=run(['git','rev-parse','HEAD'],cwd=repo)
    parent,_=run(['git','rev-parse','HEAD^'],cwd=repo)
    remote,_=run(['git','ls-remote','origin','refs/heads/'+BRANCH],cwd=repo)
    dirty,_=run(['git','status','--porcelain'],cwd=repo)
    require(branch==BRANCH and head==A1 and parent==DIRECT_PARENT,'signed branch/commit/parent not exact')
    require(remote.split()[0]==A1,'remote branch not at signed A1')
    require(dirty=='','checkout dirty')
    for commit in (A1,P1,P1_PARENT,P0A3D):sigcheck(repo,commit)
    for name,blob in ((A1_DOC,A1_BLOB),(P1_DOC,P1_BLOB),(H_CLOSEOUT,H_CLOSEOUT_BLOB),(L1_CLOSEOUT,L1_CLOSEOUT_BLOB)):
        v,_=run(['git','rev-parse','HEAD:'+name],cwd=repo)
        require(v==blob,'signed protocol Git blob mismatch: '+name)
    onefile,_=run(['git','diff-tree','--no-commit-id','--name-status','-r',A1],cwd=repo)
    require(onefile=='A\t'+A1_DOC,'A1 is not one-file-only')
    chain=[];now=P1
    while True:
        chain.append(now)
        require(len(chain)<=100,'excessive/incomplete lineage')
        if now==P0A3D:break
        parents,_=run(['git','show','-s','--format=%P',now],cwd=repo)
        require(parents!='','P0A3D not an ancestor')
        now=parents.split()[0]
    require(chain[:2]==[P1,P1_PARENT],'first-parent lineage start incorrect')
    # Cross-check the complete chain from Git with no omitted intervening commits.
    for c in chain:sigcheck(repo,c)
    originals={};payload={}
    for label,(path,size,digest) in ORIGINALS.items():
        b=(repo/path).read_bytes();originals[label]=zipcheck_bytes(b,size,digest)
        if label!='G-CFINAL':payload['historical/original_'+label+'.zip']=b
    eng={}
    for label,datum,pp in (('report',STATIC_REPORT,args.engineering_report),('findings',STATIC_JSON,args.engineering_findings)):
        raw=pp.expanduser().read_bytes()
        require(len(raw)==datum['bytes'] and H(raw)==datum['sha256'],'original engineering '+label+' bytes do not match A1')
        payload['historical/'+datum['filename']]=raw
        eng[label]={'sha256':H(raw),'bytes':len(raw)}
    # Static original-candidate lock comparison, never import any candidate member.
    import io
    r2raw=(repo/ORIGINALS['R2-C1-REV1'][0]).read_bytes()
    graw=(repo/ORIGINALS['G-CFINAL'][0]).read_bytes()
    with zipfile.ZipFile(io.BytesIO(r2raw)) as r2,zipfile.ZipFile(io.BytesIO(graw)) as g:
        lockbytes=r2.read('lock/SOURCE_LOCK.json')
        require(H(lockbytes)=='abff7aa8df19f73e070d9f06ebd23334f8d98b45c1736d38399b845c69835902','source lock hash')
        lock=json.loads(lockbytes);entries=lock['files']
        require(len(entries)==51,'candidate file count not 51')
        rows=[];syntax=[]
        for name,v in sorted(entries.items()):
            bb=r2.read('candidate/'+name)
            require(len(bb)==v['bytes'] and H(bb)==v['sha256'],'R2 source mismatch '+name)
            require(g.read('candidate/'+name)==bb,'G comparator mismatch '+name)
            if name in KERNELS:require(H(bb)==KERNELS[name],'kernel mismatch '+name)
            if name in FROZEN_FILES:require(H(bb)==FROZEN_FILES[name],'identity or policy mismatch '+name)
            if name.endswith('.py'):
                ast.parse(bb.decode('utf-8'),filename=name,feature_version=(3,11))
                syntax.append(name)
            rows.append({'path':name,'bytes':len(bb),'sha256':H(bb),'g_cfinal_byte_identical':True})
        require(set(KERNELS).issubset(entries),'missing protected kernel')
        original_policy=r2.read('candidate/schemas/v0_9/p0a3g/resource_policy.json')
        r2fix=r2.read('r2_external/fixtures/R2_H01.request.json')
        require(H(r2fix)=='0807f2245f10dd3ebf819f2c9be1206587a4aa55cd0f4226163bf79f5cf898fa' and len(r2fix)==735,'known fixture mismatch')
        payload['source/SOURCE_LOCK.json']=lockbytes
        payload['source/ORIGINAL_RESOURCE_POLICY.json']=original_policy
        payload['source/SOURCE_51_FILE_LOCK_LEDGER.json']=jbytes(rows)
        payload['source/ORIGINAL_R2_H01_REQUEST.json']=r2fix
    pyhost=safe_bin(EXPECTED_PY,EXPECTED_PY_SHA)
    sslhost=safe_bin(EXPECTED_SSL,EXPECTED_SSL_SHA)
    require(str(Path(sys.executable).resolve())==EXPECTED_PY, 'collector must run exact /usr/bin/python3.11')
    require(sys.version_info[:3]==(3,11,2),'Python 3.11.2 not running; re-scope')
    require(sys.flags.isolated==1 and sys.flags.no_site==1 and sys.dont_write_bytecode, 'run with -I -S -B')
    libroot=Path(sysconfig.get_paths()['stdlib']).resolve()
    require(libroot.is_dir(),'measured Python stdlib root missing')
    libraries={}
    for n in LIBNAMES:
        p=libroot/n
        require(p.is_file() and not p.is_symlink(),'missing/symlink stdlib dependency '+str(p))
        b=p.read_bytes();libraries[n]={'path':str(p),'bytes':len(b),'sha256':H(b)}
    sslver,_=run([EXPECTED_SSL,'version','-a'],timeout=15)
    require('3.0.22' in sslver, 'OpenSSL host version changed; stop')
    osrelease=Path('/etc/os-release').read_text('utf-8') if Path('/etc/os-release').exists() else '<absent>'
    limits={name:list(resource.getrlimit(getattr(resource,name))) for name in ['RLIMIT_AS','RLIMIT_CPU','RLIMIT_FSIZE','RLIMIT_NOFILE','RLIMIT_CORE']}
    proc={n:{'exists':Path('/proc/self/'+n).exists(),'readable':os.access('/proc/self/'+n,os.R_OK)} for n in ['status','maps','cmdline','exe','fd','environ','limits']}
    # ldd only on the pre-pinned local host executables, never a candidate or unknown executable.
    dynamic={}
    for label,b in [('python3.11',EXPECTED_PY),('openssl',EXPECTED_SSL)]:
        txt,_=run(['ldd',b],timeout=15)
        dynamic[label]={'ldd_stdout':txt,'resolved_absolute_paths':{}}
        for pathname in set(re.findall(r'(?<![\w])(/[^\s()]+)',txt)):
            fp=Path(pathname)
            if fp.is_file():
                dynamic[label]['resolved_absolute_paths'][pathname]={'sha256':H(fp.read_bytes()),'realpath':str(fp.resolve()),'bytes':fp.stat().st_size}
    pkg=''
    try:pkg,_=run(['dpkg-query','-W','-f=${Package}\t${Version}\t${Status}\n','python3.11','libpython3.11-stdlib','openssl','libssl3'],timeout=15)
    except RuntimeError as e:pkg='UNQUALIFIED: '+str(e)
    host={
        'uname':os.uname()._asdict() if hasattr(os.uname(),'_asdict') else dict(zip(('sysname','nodename','release','version','machine'),os.uname())),
        'platform':platform.platform(),'os_release':osrelease,'python':pyhost,'python_version':sys.version,
        'python_sysconfig_stdlib':str(libroot),'python_flags':str(sys.flags),'openssl':sslhost,
        'openssl_version_full':sslver,'python_stdlib_11':libraries,'ldd_and_shared_libraries':dynamic,
        'package_versions':pkg,'resource_limit_current_hard':limits,'proc_self_capabilities':proc,
        'filesystem_statvfs_available_bytes':os.statvfs(str(repo)).f_bavail*os.statvfs(str(repo)).f_frsize,
        'local_operator_role':'Human repository owner; same human signs eventual evidence (not independent execution observation)',
        'external_script_authorship':'ChatGPT/GPT-6; disclosed, not independently source-designed',
        'unresolved':'P1-C1 source feasibility/host enforcement/worker VmSize/OpenSSL test signature behavior / six P1 tests require later witness/release',
    }
    now=dt.datetime.now(dt.timezone.utc).isoformat()
    chronology={'recorded_at_utc':now,'authority_A1':A1,'authority_P1':P1,
        'p1_c0':'BUILT_ONLY_AS_STATIC_INPUT_PACKAGE','p1_c1':'NOT_BUILT',
        'p1_dev_01':'NOT_AUTHORIZED','human_attestation':'NO_P1_CANDIDATE_EXECUTION_YET',
        'basis':'human operator --affirm-no-p1-execution CLI, not independent continuous host monitoring',
        'permitted_operations':'Git/GPG, hash/ZIP, host binaries version and dynamic library enumeration, static AST parse, archive packaging only',
        'historical_P1_two_file_scope_blocker':'P0A3H_P1_SCOPE_AMENDMENT_REQUIRED; retained original report unchanged',
        'historical_L1_status':'P0A3H_L1_PREFLIGHT_INCOMPLETE ABSOLUTE_RUNTIME_PINS_UNSATISFIED',
        'P0A4':'NOT_AUTHORIZED'}
    inputs={'P1':P1,'P1_PARENT':P1_PARENT,'A1':A1,'A1_PARENT':DIRECT_PARENT,
        'P1_GIT_BLOB':P1_BLOB,'A1_GIT_BLOB':A1_BLOB,'first_parent_ancestry_P1_to_P0A3D_inclusive':chain,
        'GPG_VALID_CRYPTOSIGNATURE_FROM_LOCAL':KEY,'GPG_OWNERTRUST':'NOT INDEPENDENTLY ESTABLISHED BY THIS REPORT',
        'comparison_originals':originals,'engineering_reports':eng,
        'three_protected_kernels':KERNELS,'source_members':len(rows),'python_source_parse_count':len(syntax),
        'allowed_future_derivative_edit_files':list(FROZEN_FILES.keys())}
    payload['authority/ORIGINAL_P1_SIGNED_PROTOCOL.md']=(repo/P1_DOC).read_bytes()
    payload['authority/ORIGINAL_A1_SIGNED_AMENDMENT.md']=(repo/A1_DOC).read_bytes()
    payload['historical/ORIGINAL_SIGNED_P0A3H_HC0_INCOMPLETE_CLOSEOUT.md']=(repo/H_CLOSEOUT).read_bytes()
    payload['historical/ORIGINAL_SIGNED_L1_RUNTIME_BLOCKER_CLOSEOUT.md']=(repo/L1_CLOSEOUT).read_bytes()
    payload['authority/AUTHENTICATION_CHAIN_AND_SOURCE_PINS.json']=jbytes(inputs)
    payload['operator/LOCAL_HOST_AND_DEPENDENCY_REGISTER.json']=jbytes(host)
    payload['operator/NO_EXECUTION_ATTESTATION_AND_CHRONOLOGY.json']=jbytes(chronology)
    payload['operator/STATIC_P1_C0_REVIEW_NOTES.md']=(
      '# P0A3H-P1-C0 — preparation-only checkpoint\n\n'
      'This C0 contains only archival/Git/source-hash/static AST/host observations. '\
      'No derivative candidate has been created or run. Original A1 scope finding remains historical.\n\n'
      'P1-C1 must prospectively lock the exact THREE allowed source changes, separate P1-specific schema, '\
      'six tests, resources, original receipt and precise release gate. P01–P06, H01–H07 and P0A4 remain unauthorized.\n\n'
      'Observer feasibility, loaded-code identity, resource enforcement and mathematical portability are untested.\n'
    ).encode()
    payload['builder/P1_C0_BUILDER_SOURCE.py']=Path(__file__).read_bytes()
    payload['README.md']=b'P0A3H-P1-C0 original operator archive; read-only source and host preflight; does not authorize any candidate execution.\n'
    outroot.mkdir(parents=True,exist_ok=True)
    folder=outroot/('P1_C0_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    require(not folder.exists(),'output exists')
    folder.mkdir(mode=0o700)
    zpath=folder/'P0A3H_P1-C0.zip'
    meta=pack(zpath,payload)
    receipt={'original_archive':'P0A3H_P1-C0.zip','status':'P0A3H_P1_C0_SUBMITTED_FOR_INDEPENDENT_BYTE_AND_SOURCE_QC',
      'archive':meta,'authority':A1,'p1_c1':'NOT BUILT','p1_dev_01':'NOT AUTHORIZED',
      'operator_no_prior_p1_test':'SELF-ATTESTED VIA CLI FLAG','created_utc':now}
    (folder/'P0A3H_P1-C0_RECEIPT.json').write_bytes(jbytes(receipt))
    readback=folder/'readback_separate_directory';readback.mkdir()
    shutil.copyfile(zpath,readback/zpath.name)
    copied=(readback/zpath.name).read_bytes()
    check=zipcheck_bytes(copied,meta['bytes'],meta['sha256'])
    require(copied==zpath.read_bytes(),'fresh readback not byte-identical')
    record={'status':'BYTE_IDENTICAL_SAME_HOST_COPY_ONLY','archive':meta,'readback':check,
            'warning':'This is not independently observed durable remote upload; preserve original archive, then upload for reviewer'}
    (folder/'P0A3H_P1-C0_LOCAL_READBACK.json').write_bytes(jbytes(record))
    print('P0A3H-P1-C0 STATIC PREPARATION ONLY — ARCHIVE SEALED')
    print('directory:',folder)
    print('bytes:',meta['bytes'],'SHA-256:',meta['sha256'],'members:',meta['members'])
    print('source: 51/51 locked; kernels 3/3 locked; P1/A1 signed chain checked')
    print('P1-C1: NOT BUILT; P01-P06: NOT AUTHORIZED; H01-H07: NOT AUTHORIZED')
    print('UPLOAD:',zpath.name,'P0A3H_P1-C0_RECEIPT.json','P0A3H_P1-C0_LOCAL_READBACK.json')

if __name__=='__main__':
    try:main()
    except Exception as exc:
        print('P0A3H-P1-C0 STOP: '+str(exc),file=sys.stderr)
        raise SystemExit(2)
