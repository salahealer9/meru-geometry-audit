# P0A3H-P1-C0 — preparation-only checkpoint

This C0 contains only archival/Git/source-hash/static AST/host observations. No derivative candidate has been created or run. Original A1 scope finding remains historical.

P1-C1 must prospectively lock the exact THREE allowed source changes, separate P1-specific schema, six tests, resources, original receipt and precise release gate. P01–P06, H01–H07 and P0A4 remain unauthorized.

Observer feasibility, loaded-code identity, resource enforcement and mathematical portability are untested.
