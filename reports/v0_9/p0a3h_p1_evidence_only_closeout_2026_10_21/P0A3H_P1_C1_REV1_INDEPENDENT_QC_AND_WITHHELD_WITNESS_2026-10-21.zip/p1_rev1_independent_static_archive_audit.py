"""Read-only independent static audit of supplied P0A3H-P1 C1 and C1-REV1 ZIPs.
Never imports, executes or calls candidate or external test/driver source."""
import base64, hashlib, io, json, pathlib, stat, zipfile, ast
D=pathlib.Path('/mnt/data')
REV=D/'P0A3H_P1-C1-REV1.zip'; ORIG=D/'P0A3H_P1-C1 (1).zip'
B64=D/'P0A3H_P1-C1-REV1.zip.b64.txt'
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]; metadata={}
def check(label,ok,detail=None):
 checks.append({'check':label,'pass':bool(ok),'detail':detail})
def archive(path,want,n_members,n_sums,n_inv):
 data=path.read_bytes(); h=sha(data);z=zipfile.ZipFile(io.BytesIO(data)); names=z.namelist();ns=set(names)
 check(path.name+':sha256',h==want,h);check(path.name+':unique_paths',len(names)==len(ns));
 check(path.name+':regular_safe_paths',all(not (n:=i.filename).startswith('/') and '..' not in n.split('/') and '\\' not in n and (i.external_attr>>16 ==0 or stat.S_ISREG(i.external_attr>>16)) for i in z.infolist()))
 check(path.name+':crc',z.testzip() is None);check(path.name+':count',len(ns)==n_members,len(ns))
 entries=[]
 for l in z.read('SHA256SUMS').decode().splitlines():
  if l.strip():
   dg,n=l.split(None,1);entries.append((n,dg))
 check(path.name+':sha_list_completeness',len(entries)==n_sums and len({p for p,h in entries})==len(entries) and {p for p,h in entries}==ns-{'SHA256SUMS'},len(entries))
 check(path.name+':sha_list_values',all(sha(z.read(n))==v for n,v in entries))
 inv=json.loads(z.read('PACKAGE_INVENTORY.json')); files=inv['payload_files'];check(path.name+':inventory_completeness',len(files)==n_inv and inv['payload_count']==n_inv and {i['path'] for i in files}==ns-{'SHA256SUMS','PACKAGE_INVENTORY.json'},len(files))
 check(path.name+':inventory_values',all(len(z.read(i['path']))==i['bytes'] and sha(z.read(i['path']))==i['sha256'] for i in files))
 metadata[path.name]={'sha256':h,'bytes':len(data),'member_count':len(names),'sha_entries':len(entries),'inventory_entries':len(files)}
 return z
rz=archive(REV,'733352e73b23f97423965407b39121fc7baae47332a7fa7386aa46fca7c2bbeb',158,157,156)
oz=archive(ORIG,'0ab255773debd5a68c21fa2555c954b347971d28902ee345beb1f254d02013d4',149,148,147)
rawb=B64.read_bytes();check('rev1_base64_sha',sha(rawb)=='cc18c51cad19694296050bee2a8166f17564783d3e15c348b36df7162ce206cc')
check('rev1_base64_decodes_to_original_bytes',base64.b64decode(rawb)==REV.read_bytes())
check('original_copy_byte_same',ORIG.read_bytes()==(D/'P0A3H_P1-C1.zip').read_bytes())
old={n:oz.read(n) for n in oz.namelist() if n not in ('PACKAGE_INVENTORY.json','SHA256SUMS')};new={n:rz.read(n) for n in rz.namelist() if n not in ('PACKAGE_INVENTORY.json','SHA256SUMS')}
changed=[n for n in sorted(set(old)&set(new)) if old[n]!=new[n]]
added=sorted(set(new)-set(old));removed=sorted(set(old)-set(new))
upmeta=json.loads((D/'REV1_VS_ORIGINAL_C1_MEMBER_CHANGES.json').read_text())
check('rev1_no_original_payload_removed',not removed,removed)
check('rev1_member_delta_report_matches',set(changed)=={x['path'] for x in upmeta['changes'] if x['change']=='CHANGED'} and set(added)-{'ledger/REV1_VS_ORIGINAL_C1.diff','ledger/REV1_VS_ORIGINAL_C1_MEMBER_CHANGES.json'}=={x['path'] for x in upmeta['changes'] if x['change']=='ADDED'})
check('rev1_change_ledger_exact_digests',all((old.get(x['path']) is None if x['original_sha256'] is None else sha(old[x['path']])==x['original_sha256']) and (new.get(x['path']) is None if x['rev1_sha256'] is None else sha(new[x['path']])==x['rev1_sha256']) for x in upmeta['changes']))
allowed={'P1_AUTHORSHIP_LIMITATIONS_AND_FINDINGS.md','P1_C1_REV1_RESPONSE_TO_WITNESS_FINDINGS.md','P1_C2_RECEIPT_INCLUSION_PLAN.md','P1_CASE_CATALOGUE.md','P1_PRE_RUN_CHRONOLOGY.md','README.md','lock/P1_EXTERNAL_LOCK.json','p1_external/P1_C2_PACKAGER.py','p1_external/P1_DRIVER.py','p1_external/p1_verifier.py','p1_external/p1_authority.py','p1_external/locks/P1_EXPECTED_OUTCOMES.json','p1_external/schemas/p1_authority_envelope.validation.schema.json'}
check('rev1_changes_restricted_external_docs_locks_history',set(changed).issubset(allowed) and all(x.startswith(('history/','ledger/')) or x=='P1_C1_REV1_RESPONSE_TO_WITNESS_FINDINGS.md' for x in added),(changed,added))
for grp in ['authority/','c0/','derivative_candidate/','reference_candidate/','ledger/','p1_external/fixtures/','p1_external/comparators/']:
 ks=[n for n in old if n.startswith(grp)]
 check('rev1_bytes_unchanged_'+grp,len(ks)>0 and all(old[n]==new.get(n) for n in ks),len(ks))
for n in ('lock/P1_CANDIDATE_LOCK.json','lock/SOURCE_LOCK.json'):
 check('rev1_lock_same_'+n,old[n]==new[n],sha(new[n]))
for prefix,key,file in [('derivative_candidate/','derivative_files','lock/P1_CANDIDATE_LOCK.json'),('reference_candidate/','files','lock/SOURCE_LOCK.json'),('p1_external/','files','lock/P1_EXTERNAL_LOCK.json')]:
 lock=json.loads(new[file])[key]
 actual={n[len(prefix):] for n in new if n.startswith(prefix)}
 check(prefix+':lock_file_set',actual==set(lock),len(actual))
 check(prefix+':lock_hashes',all(len(new[prefix+n])==q['bytes'] and sha(new[prefix+n])==q['sha256'] for n,q in lock.items()))
check('rev1_ext_lock_digest',sha(new['lock/P1_EXTERNAL_LOCK.json'])=='b1ea930862758c32dea23932b8114de043e4a93b97ca4401c7e53efacdfab2c5')
check('rev1_candidate_lock_digest',sha(new['lock/P1_CANDIDATE_LOCK.json'])=='18c7d153e236560e0e99738f50137f46bb1dae94beaf125340835dadacaf106e')
check('rev1_source_lock_digest',sha(new['lock/SOURCE_LOCK.json'])=='abff7aa8df19f73e070d9f06ebd23334f8d98b45c1736d38399b845c69835902')
ref={p[len('reference_candidate/'):]:b for p,b in new.items() if p.startswith('reference_candidate/')};der={p[len('derivative_candidate/'):]:b for p,b in new.items() if p.startswith('derivative_candidate/')}
expected_edit={'schemas/v0_9/p0a3g/resource_policy.json','src/meru_geometry/v0_9/qo2d_exact/identity.py','reference/v0_9/qo2d_exact/identity.py'}
check('derivative_exact_three_changes',{p for p in ref if der[p]!=ref[p]}==expected_edit and set(ref)==set(der),len(der))
pins={'src/meru_geometry/v0_9/qo2d_exact/algebra.py':'442065847937252db00d3f63b02184c15d57989f958f764c5c731cb385de6d2d','src/meru_geometry/v0_9/qo2d_exact/core.py':'37701d034d98725673240a881420892893906c70387f68432b5993f8557dd420','reference/v0_9/qo2d_exact/arithmetic.py':'72b3c37f02be65b2df7616a94e84601d66cf4af5b7a50e878724de647e5bf0ba'}
for p,h in pins.items():check('immutable_kernel_'+p,sha(ref[p])==sha(der[p])==h)
check('rev1_host_pins',json.loads(new['p1_external/locks/P1_HOST_PINS.json'])['python']['sha256']=='9bee109da0dce17a7c9eeaca9f420cc6770a9fe143b9382d73bd22fe59b21a5f')
expect_old=json.loads(old['p1_external/locks/P1_EXPECTED_OUTCOMES.json']);expect_new=json.loads(new['p1_external/locks/P1_EXPECTED_OUTCOMES.json'])
check('rev1_six_cases_no_existing_expected_outcome_changed', set(expect_old['cases'])==set(expect_new['cases']) and all(all(expect_new['cases'][c].get(k)==v for k,v in obj.items()) for c,obj in expect_old['cases'].items()))
check('rev1_scientific_case_order_preserved', all(expect_new['order'].index(k)<expect_new['order'].index(j) for k,j in zip(expect_old['order'],expect_old['order'][1:])))
check('original_receipt_retained',new['history/ORIGINAL_P0A3H_P1-C1_RECEIPT.json']==(D/'P0A3H_P1-C1_RECEIPT.json').read_bytes())
check('old_witness_retained',new['history/original_C1_witness_review/P0A3H_P1_C1_INDEPENDENT_WITNESS_REVIEW_2026-10-21.md']==(D/'P0A3H_P1_C1_INDEPENDENT_WITNESS_REVIEW_2026-10-21.md').read_bytes())
for n in ['p1_external/P1_DRIVER.py','p1_external/p1_verifier.py','p1_external/P1_C2_PACKAGER.py','p1_external/p1_authority.py']:
 try:ast.parse(new[n]);ok=True
 except SyntaxError:ok=False
 check('ast_parse_'+n,ok)
summary={'status':'INDEPENDENT_ARCHIVE_SOURCE_STATIC_QC_ONLY','checks':checks,'passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks),'archive_metadata':metadata,'changed_payload_count':len(changed),'added_payload_count':len(added),'removed_payload_count':len(removed),'changed_external_source':[n for n in changed if n.startswith('p1_external/')],'note':'Static evidence only; not an execution witness; no candidate, test or driver code run.'}
(D/'P0A3H_P1_REV1_INDEPENDENT_ARCHIVE_SOURCE_AUDIT_2026-10-21.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print('checks',summary['passed'],'/',len(checks),'failed',summary['failed'])
for c in checks:
 if not c['pass']:print('FAIL',c['check'],str(c['detail'])[:450])
print('changes',changed);print('additions',added)
