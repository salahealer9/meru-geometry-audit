# P0A3H_P1-C1-REV1 — Response to the withheld-witness findings on the original P1-C1

**Original C1 (retained unchanged; never executed):**
- `P0A3H_P1-C1.zip`, 308,794 B, SHA-256 `0ab255773debd5a68c21fa2555c954b347971d28902ee345beb1f254d02013d4`;
- base64 copy `b27434e7…fc33`;
- receipt `9145a3d1…5878`;
- lock receipt `c6eec000…407e`.

**Witness disposition on the original:** `P0A3H_P1_C1_PREEXECUTION_WITNESS_WITHHELD_PENDING_CONTROL_COMPLETENESS`, with 71/71 archival and source checks passing. The review files are carried in `history/original_C1_witness_review/`.

**Scope of REV1:** only `p1_external/` machinery, its locks and the documents change. The 51-file reference, the 51-file derivative (still exactly the three A1 files changed), all kernels, all fixtures, all comparators, `P1_CANDIDATE_LOCK.json` (`18c7d153…`, byte-identical), the derivative ledger and the static source diff are **unchanged**. No P01–P06 construction or acceptance criterion is weakened; REV1 only adds checks.

## W01 — whole-attempt disk ≤ 16 MiB (blocking) → enforced and evidenced by the driver
The cap is **not redefined**. The "whole attempt" is taken as the most inclusive reading: the entire `--work` directory, covering
- the extracted C1 trees and the upstream copies;
- journals and ledgers;
- every case directory, including all raw worker evidence;
- the controller key directories;
- the runner TMPDIR.

**Mechanism (`p1_external/P1_DRIVER.py`):**
1. **Free-space gate:** at least 2 × 16 MiB must be free on the work filesystem before anything is written; otherwise `ENVIRONMENT_UNQUALIFIED`.
2. **Whole-tree measurement:** `lstat` of every entry. The apparent size (sum of `st_size`) **and** the allocated size (sum of `st_blocks`×512) must both be ≤ 16,777,216 bytes.
3. **When the tree is measured:**
   - at stage boundaries: after extraction, before the first candidate invocation, after each case, and at the end;
   - **every 0.2 s** while any runner or reconciler process tree is alive.
4. **On exceedance at any sample:** the driver sends SIGKILL to the whole runner process tree (descendants are found through `/proc` *before* killing, so candidate workers in their own sessions are included) and the case **cannot PASS**. A sampling error gives `ENVIRONMENT_UNQUALIFIED`.
5. **Per-file bound:** each runner now has `RLIMIT_FSIZE` = 16 MiB (it was 64 MiB), so no single file can exceed the whole cap. The unchanged candidate still caps workers at 2 MiB per file and 16 MiB per run directory.
6. **Final check:** the whole tree is checked again at the end. Any exceedance means the attempt is not passed.
7. **Evidence:** `P1_DISK_LEDGER.json` records stage records, per-process peaks, killed PIDs, 1 Hz samples and an exceedance flag. `P1_ATTEMPT_SUMMARY.json` carries `whole_attempt_disk_within_cap`.
8. **Packager safety bound:** `P1_C2_PACKAGER.py` refuses input above 2 × the cap, so its traversal is bounded. An attempt that failed on the cap is still packaged, so the failure is preserved.

**Feasibility:** the expected total is far below the cap. The extracted trees are about 0.8 MB, and the evidence of P02–P06 is a few hundred small files. This is an estimate, not a measurement. No prior run was made.

**Declared residuals (cooperative-host model):**
- Polling cannot pre-empt writes made between two 0.2 s samples. Any such exceedance is detected at the next sample and fails the attempt; it can never yield a PASS.
- Candidate **workers** run with the environment fixed by the frozen supervisor (`PATH`, `LC_ALL`). Their transient OpenSSL `p0a3g_sig_*` temporary directories (three small files, deleted when the call returns) are created in `/tmp`, outside `--work`. The driver records that residue before and after each case.
- A kernel-level quota, cgroup or size-limited mount would give pre-emptive enforcement. It is not used, because it would need host privileges and setup outside the registered protocol. If the reviewer considers polled enforcement plus detection insufficient for the signed text, this is the point at which a human-signed decision is required. REV1 does not reinterpret the cap.

## W02 — human release consumed before the first candidate invocation → implemented
**Inputs:** the driver now **requires** three files:
- `--release-certificate`: the original human release text as received;
- `--c0-receipt`: the original, SHA-256 `469c1cc5…`;
- `--c1-receipt`: the original `P0A3H_P1-C1-REV1_RECEIPT.json`.

**Steps, as the very first stage and before archive extraction, the host gate or any candidate import:**
1. It checks that the C1 bytes equal the released digest.
2. It checks that the certificate contains exactly `P0A3H-P1-C1 LOCK WITNESSED; SHA-256 <that digest>; AUTHORIZE ONE P0A3H_P1_DEV_01`.
3. It checks that the C0 receipt is the original and that the C1 receipt names the released digest.
4. It writes byte-identical copies to `<work>/upstream/`.
5. It writes `PRELAUNCH_RELEASE_RECEIPT.json`, holding the hashes, the consumption time, the source path and mtime (informational), the check results and `candidate_invocations_before_this_receipt: 0`.
6. It journals `HUMAN_RELEASE_CONSUMED`.

`FIRST_P1_CANDIDATE_INVOCATION` is journalled later, together with the SHA-256 of the prelaunch receipt. If any check fails, the result is `P0A3H_P1_PREDEV_LOCK_NOT_WITNESSED` with no candidate launch.

**Packager:** it refuses to write C2 unless
- the attempt's `upstream/` copies are byte-identical to the originals supplied again at packaging time;
- the prelaunch receipt is consistent;
- the journal shows `HUMAN_RELEASE_CONSUMED` before `FIRST_P1_CANDIDATE_INVOCATION`.

C2 then stores the three originals at top-level `upstream/` **and** at `attempt/upstream/`, and re-verifies both after writing.

**Limitation (unchanged and explicit):** a text and digest match is not cryptographic proof of human origin. The human release remains a separate, witnessed human-authority requirement.

## W03 — external P1 schema → role stated, and made operational as a supplementary check
**Necessity:** the schema is **not necessary** for the candidate's authority decisions. Both identity routes enforce the P1 lineage themselves, and P03 shows the old-lineage envelope rejected by both. Signed A1 §3 does require the schema to be supplied and pinned before release.

**What REV1 changes:**
- The unused `validate_p1_envelope` helper is removed from the builder.
- `p1_verifier.schema_problems()` (verifier-owned code, with no builder or candidate import) checks every saved envelope for:
  - canonical bytes and the exact field set;
  - the P1 lineage consts and an allowed `authority_mode`;
  - 64-hex digests, the `run_id` pattern and the `key_id` type;
  - `files` equal to the locked derivative source map (45 `.py/.json/.md` files under `src/`, `reference/`, `schemas/` and `tests/`).

**Added checks:**
- P02, P05 (all four inputs) and P06 A and B envelopes must conform;
- the P03 valid envelope must conform;
- the P04 deployment-probe envelope must conform;
- the **P03 N3 old-lineage envelope must violate the lineage consts**.

This only adds checks; it never relaxes a candidate gate.

## W04 — residual unknowns
These are unchanged and acknowledged: Python 3.11 and OpenSSL Ed25519 behaviour, worker VmSize margin, P05 exact equality between 3.11 and 3.12, timeouts, rlimit enforcement and live stream relationships. There has been no rehearsal. The first attempt may fail and would be preserved.

## Static-only preparation of REV1
- The REV1 sources were checked by:
  - syntax-only parsing (`ast.parse`, 3.11 grammar, on the agent's 3.12 parser);
  - the static name analyser **pyflakes**, installed from PyPI into the agent workspace, which reads source without executing it.
- pyflakes found one defect in a REV1 draft of `p1_verifier.py` before the lock: regex constants were defined before `import re`. It was fixed before locking.
- pyflakes reports no findings on the final REV1 sources, and none on the original C1 sources.
- No candidate import, test, dry run or key generation took place.
