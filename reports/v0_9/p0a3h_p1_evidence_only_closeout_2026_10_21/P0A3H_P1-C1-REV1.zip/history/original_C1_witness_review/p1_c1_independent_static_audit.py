"""Independent read-only P0A3H-P1 C1 audit, 2026-10-21.
DO NOT import/launch C1 executable sources. Inspects uploaded ZIP bytes and AST only.
"""
from pathlib import Path,PurePosixPath
import zipfile,hashlib,json,base64,ast,re,difflib
C1=Path('/mnt/data/P0A3H_P1-C1.zip')
C0=Path('/mnt/data/P0A3H_P1-C0.zip')
OUT=Path('/mnt/data/P0A3H_P1_C1_INDEPENDENT_STATIC_AUDIT_RESULTS_2026-10-21.json')
checks={};observations={}
def check(k,v): checks[k]=bool(v)
def sha(b):return hashlib.sha256(b).hexdigest()
def json_get(z,p):return json.loads(z.read(p))
cb=C1.read_bytes();check('C1 exact SHA',sha(cb)=='0ab255773debd5a68c21fa2555c954b347971d28902ee345beb1f254d02013d4');check('C1 exact byte size',len(cb)==308794)
z=zipfile.ZipFile(C1); names=z.namelist();check('C1 CRC all files',z.testzip() is None);check('149 members',len(names)==149);check('unique names',len(set(names))==len(names));check('safe names',all(n and not n.startswith('/') and n not in ('.','..') and '..' not in PurePosixPath(n).parts and '\\' not in n for n in names));check('regular entries no directory',all((not x.is_dir()) and ((x.external_attr>>16)&0o170000 == 0o100000) for x in z.infolist()))
sums={};sumvalid=True
for line in z.read('SHA256SUMS').decode().splitlines():
 if not line.strip():continue
 h,n=line.split(None,1)
 if n in sums: sumvalid=False
 sums[n]=h
check('SHA256SUMS exact N-1 set',sumvalid and set(sums)==set(names)-{'SHA256SUMS'})
check('148 SHA256SUMS rows',len(sums)==148)
check('all internal payload SHA256 exact',all(sha(z.read(n))==h for n,h in sums.items()))
inv=json_get(z,'PACKAGE_INVENTORY.json');payload=inv['payload_files'];i_names=[x['path'] for x in payload]
check('PACKAGE_INVENTORY exact N-2 set',set(i_names)==set(names)-{'SHA256SUMS','PACKAGE_INVENTORY.json'} and len(i_names)==len(set(i_names)))
check('147 inventory entries',len(payload)==147)
check('inventory exact byte length/hash',all(len(z.read(e['path']))==e['bytes'] and sha(z.read(e['path']))==e['sha256'] for e in payload))
raw64=Path('/mnt/data/P0A3H_P1-C1.zip.b64.txt').read_bytes()
check('original base64 digest',sha(raw64)=='b27434e7b8dea722a2797f81d9bdb57090210ee40f3201bb848beb176ef5fc33')
check('original base64 byte equality',base64.b64decode(raw64)==cb)
for p,label in [('P0A3H_P1-C1_RECEIPT.json','C1 external receipt'),('P1_DERIVATIVE_LEDGER.json','external derivative ledger'),('P1_CASE_CATALOGUE.md','external case catalogue'),('P1_STATIC_SOURCE_DIFF.diff','external static diff'),('P0A3H_P1-C1_LOCK_RECEIPT.md','external C1 lock receipt')]:
 b=Path('/mnt/data/'+p).read_bytes();nested={'P1_DERIVATIVE_LEDGER.json':'ledger/P1_DERIVATIVE_LEDGER.json','P1_CASE_CATALOGUE.md':'P1_CASE_CATALOGUE.md','P1_STATIC_SOURCE_DIFF.diff':'ledger/P1_STATIC_SOURCE_DIFF.diff'}.get(p)
 if nested:check(label+' matches C1 internal',z.read(nested)==b)
receipt=json.loads(Path('/mnt/data/P0A3H_P1-C1_RECEIPT.json').read_bytes());check('C1 external receipt SHA and size',receipt['archive']['sha256']==sha(cb) and receipt['archive']['bytes']==len(cb))
check('C1 external receipt member/inventory/sums',receipt['archive']['members']==len(names) and receipt['archive']['inventory_entries']==len(payload) and receipt['archive']['sha256sums_non_self']==len(sums))
# C0
c0b=C0.read_bytes();check('original C0 348416 bytes',len(c0b)==348416);check('original C0 pinned hash',sha(c0b)=='067efd1e0fb66bc7bf5c61df186d43558ef2a81f223ca90912f67bca23439f5e')
zc=zipfile.ZipFile(C0);check('original C0 CRC',zc.testzip() is None)
external_c0=Path('/mnt/data/P0A3H_P1-C0_RECEIPT.json').read_bytes()
check('C0 receipt physical inclusion byte equal', z.read('c0/P0A3H_P1-C0_RECEIPT.json')==external_c0)
check('C0 receipt stated hash',sha(external_c0)=='469c1cc5d16555e5b8e56e906b4bd5a0dfc147a68c147d8eef932bacdc14bdd3')
# Frozen R2 archival source independently
r2=zc.read('historical/original_R2-C1-REV1.zip');check('R2 C1 REV1 exact hash',sha(r2)=='b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1')
from io import BytesIO
zr=zipfile.ZipFile(BytesIO(r2));check('R2 archive CRC',zr.testzip() is None)
src=json_get(z,'lock/SOURCE_LOCK.json');srcfiles=src['files'];c_lock=json_get(z,'lock/P1_CANDIDATE_LOCK.json');e_lock=json_get(z,'lock/P1_EXTERNAL_LOCK.json')['files'];ledger=json_get(z,'ledger/P1_DERIVATIVE_LEDGER.json')
ref={n[len('reference_candidate/'):]:z.read(n) for n in names if n.startswith('reference_candidate/')};der={n[len('derivative_candidate/'):]:z.read(n) for n in names if n.startswith('derivative_candidate/')};ext={n[len('p1_external/'):]:z.read(n) for n in names if n.startswith('p1_external/')}
check('51 reference candidate members',len(ref)==51);check('51 derivative candidate members',len(der)==51);check('reference paths equal frozen lock',set(ref)==set(srcfiles));check('derivative paths equal frozen lock',set(der)==set(srcfiles));check('reference member identity == original signed R2 source',all(ref[p]==zr.read('candidate/' + p) for p in srcfiles));check('reference hashes match original source lock',all(sha(ref[p])==srcfiles[p]['sha256'] and len(ref[p])==srcfiles[p]['bytes'] for p in srcfiles));check('original source lock exact digest',sha(z.read('lock/SOURCE_LOCK.json'))=='abff7aa8df19f73e070d9f06ebd23334f8d98b45c1736d38399b845c69835902')
check('derivative 51 locked hashes and sizes',len(c_lock['derivative_files'])==51 and all(sha(der[p])==v['sha256'] and len(der[p])==v['bytes'] for p,v in c_lock['derivative_files'].items()))
check('23 external files match external lock',len(ext)==len(e_lock)==23 and set(ext)==set(e_lock) and all(sha(ext[p])==v['sha256'] and len(ext[p])==v['bytes'] for p,v in e_lock.items()))
changed=sorted(p for p in ref if ref[p]!=der[p]); allowed=sorted(['reference/v0_9/qo2d_exact/identity.py','schemas/v0_9/p0a3g/resource_policy.json','src/meru_geometry/v0_9/qo2d_exact/identity.py'])
check('changed exactly 3 A1 files',changed==allowed)
check('all remaining 48 candidate files unchanged',all(ref[p]==der[p] for p in ref if p not in allowed))
kpins={'reference/v0_9/qo2d_exact/arithmetic.py':'72b3c37f02be65b2df7616a94e84601d66cf4af5b7a50e878724de647e5bf0ba','src/meru_geometry/v0_9/qo2d_exact/algebra.py':'442065847937252db00d3f63b02184c15d57989f958f764c5c731cb385de6d2d','src/meru_geometry/v0_9/qo2d_exact/core.py':'37701d034d98725673240a881420892893906c70387f68432b5993f8557dd420'}
check('three kernels equal original pins and reference',all(sha(der[p])==v and ref[p]==der[p] for p,v in kpins.items()))
check('derivative ledger 51 rows',len(ledger['per_file_ledger'])==51)
check('derivative ledger actual before and after',all(sha(ref[r['path']])==r['before_sha256'] and sha(der[r['path']])==r['after_sha256'] and len(ref[r['path']])==r['before_bytes'] and len(der[r['path']])==r['after_bytes'] and (ref[r['path']]!=der[r['path']])==r['changed'] for r in ledger['per_file_ledger']))
oldp=json.loads(ref['schemas/v0_9/p0a3g/resource_policy.json']);newp=json.loads(der['schemas/v0_9/p0a3g/resource_policy.json']);allowed_fields={'interpreter','interpreter_sha256','openssl','openssl_sha256'}
check('policy only four permitted values change',set(oldp)==set(newp) and all(oldp[k]==newp[k] for k in oldp if k not in allowed_fields))
check('unchanged candidate resource caps',all(newp[k]==oldp[k] for k in ['worker_wall_seconds','worker_cpu_seconds','worker_memory_bytes','worker_file_bytes','worker_open_files','run_disk_bytes','request_bytes','calibration_memory_bytes']))
check('Python 3.11 / OpenSSL 3.0.22 local hashes',newp['interpreter']=='/usr/bin/python3.11' and newp['interpreter_sha256']=='9bee109da0dce17a7c9eeaca9f420cc6770a9fe143b9382d73bd22fe59b21a5f' and newp['openssl']=='/usr/bin/openssl' and newp['openssl_sha256']=='66521161cfad981e189bbc746560e0cc71a141b3765b3fe3658704d877c6ad7d')
# Frozen identity constants read from AST, with literal-only changes
prodpath='src/meru_geometry/v0_9/qo2d_exact/identity.py';refpath='reference/v0_9/qo2d_exact/identity.py'
def assignments(source):
 result={}
 for s in ast.parse(source.decode()).body:
  if isinstance(s,ast.Assign) and len(s.targets)==1 and isinstance(s.targets[0],ast.Name):
   try:result[s.targets[0].id]=ast.literal_eval(s.value)
   except:pass
 return result
pr=assignments(der[prodpath]);rp=assignments(der[refpath])['PINS'];ident=ledger['new_identity_values']
check('P1/A1 lineage pin all three identity values',pr['PROTOCOL']==ident['PROTOCOL'] and pr['PARENT']==ident['PARENT'] and pr['ANCESTRY']==ident['ANCESTRY'] and pr['BASELINE']==ident['BASELINE'] and rp['protocol_commit']==pr['PROTOCOL'] and rp['signed_parent']==pr['PARENT'] and rp['git_ancestry']==pr['ANCESTRY'] and rp['baseline_archive_sha256']==pr['BASELINE'])
check('18 commit ancestry from P1 to P0A3D',len(pr['ANCESTRY'])==18 and pr['ANCESTRY'][0]=='4c1634e6660a02ebdea62195f13fc4810fd08d41' and pr['ANCESTRY'][-1]=='59eb47f7500d57866e4935822b78a555d3bcb515')
check('schema and loaded code PINS unchanged',rp['schema']=='p0a3g-authority-envelope-1' and rp['loaded_code_identity']=='LOADED_CODE_IDENTITY_UNVERIFIED')
check('both identity files reference new stdlib root', all(b'/usr/lib/python3.11' in der[p] and b'/usr/lib/python3.12' not in der[p] for p in [prodpath,refpath]))
for p in [prodpath,refpath]:
 oldlines=ref[p].splitlines();newlines=der[p].splitlines()
 changedlines=[i+1 for i,(x,y) in enumerate(zip(oldlines,newlines)) if x!=y]
 exp=[20,21,22,23,32] if p==prodpath else [16,17,48]
 check(p+' exactly authorized edit lines',len(oldlines)==len(newlines) and changedlines==exp)
check('old envelope schema stays identical',ref['schemas/v0_9/p0a3g/authority_envelope.schema.json']==der['schemas/v0_9/p0a3g/authority_envelope.schema.json'])
# host context
hp=json.loads(ext['locks/P1_HOST_PINS.json']);c0host=json_get(zc,'operator/LOCAL_HOST_AND_DEPENDENCY_REGISTER.json');
check('11 stdlib dependency hashes specified',len(hp['stdlib_11'])==11)
check('pinned interpreter/openssl hashes agree derivative', hp['python']['sha256']==newp['interpreter_sha256'] and hp['openssl']['sha256']==newp['openssl_sha256'])
check('C0 register digest matches original',sha(zc.read('operator/LOCAL_HOST_AND_DEPENDENCY_REGISTER.json'))==hp['c0_register_sha256'])
# Fixture provenance
fv=json.loads(ext['locks/FIXTURE_AND_COMPARATOR_PROVENANCE.json']);check('five registered fixtures exact file hashes', all(sha(ext['fixtures/'+n])==v['sha256'] and len(ext['fixtures/'+n])==v['bytes'] for n,v in fv['fixtures'].items()))
check('eight historical comparator hashes match declared provenance',all(sha(ext['comparators/'+n])==v['sha256'] and len(ext['comparators/'+n])==v['bytes'] for n,v in fv['comparators'].items()))
check('four R2 input fixtures equal original frozen R2-C1',all(ext['fixtures/'+n]==zr.read('r2_external/fixtures/'+n) for n in ['R2_H01.request.json','R2_H02.request.json','R2_H03.request.json','R2_H04.request.json']))
old=json.loads(ext['fixtures/R2_H01.request.json']);new=json.loads(ext['fixtures/P06A_OVER_LIMIT.request.json']);check('P06 overlimit one limit changed 8 to 9',old['limits']['max_vertices']==8 and new['limits']['max_vertices']==9 and {**old,'limits':{**old['limits'],'max_vertices':9}}==new)
check('P06 request 9 exceeds candidate cap 8',new['limits']['max_vertices']>newp['max_vertices'])
# Independently corroborate all eight historical P05 comparators from actual signed Git-preserved R2-C2 ZIP.
r2c2path=Path('/mnt/data/P0A3G_R2-C2.zip')
r2c2b=r2c2path.read_bytes()
check('historical R2-C2 original SHA256 matches signed provenance',sha(r2c2b)=='860d93dce952a73b65b097e3f7b4da420c0a327ee0ca8b6d4c213865db2d1cbb')
check('historical R2-C2 Git blob identity equals GitHub signed commit',hashlib.sha1(b'blob '+str(len(r2c2b)).encode()+b'\0'+r2c2b).hexdigest()=='954e27a424a2b047b026a98f390d5687ecc42521')
zr2c2=zipfile.ZipFile(BytesIO(r2c2b))
check('historical R2-C2 CRC valid',zr2c2.testzip() is None)
for case in ('R2_H01','R2_H02','R2_H03','R2_H04'):
 for suffix,suffix_historical in (('certificate.json','certificate.json'),('check_stdout.json','stdout')):
  candidate=ext['comparators/'+case+'.'+suffix]
  original=zr2c2.read('attempt/P0A3G_R2_DEV_01/H/P0A3G_R2_DEV_01_H/raw_workers/'+case+'/w0003.'+suffix_historical)
  check('historical P05 '+case+' '+suffix+' exact original payload',candidate==original)
# Static syntax parse only (never import/execute)
pyfiles=[p for p in ext if p.endswith('.py')];errors=[]
for p in pyfiles:
 try: ast.parse(ext[p].decode(),feature_version=(3,11))
 except Exception as e: errors.append((p,str(e)))
check('all external Python sources parse with 3.11 grammar',len(pyfiles)==6 and not errors)
observations['external_python_parse_count']=len(pyfiles);observations['python_syntax_errors']=errors
# Requirement concern from original P1 §3 / §6: whole attempt budget
sdrv=ext['P1_DRIVER.py'].decode();sver=ext['p1_verifier.py'].decode()
observations['driver_has_16_mib_global_disk_enforcement']=any(s in sdrv for s in ('16777216','run_disk_bytes','whole_attempt_disk','attempt_disk_bytes','MAX_ATTEMPT_DISK'))
observations['driver_checks_human_release_file_before_launch']=('release-certificate' in sdrv or 'human-release' in sdrv or 'HUMAN_RELEASE_CERTIFICATE' in sdrv)
observations['P1_driver_checks_only_release_sha_in_launch_args']=("for k in ('release-sha', 'c1', 'work')" in sdrv and "if sha(c1) != A['release-sha'].lower()" in sdrv)
observations['signed_original_R2_C2_archive_original_bytes_not_available_in_C1_or_C0']=not any('R2_C2.zip' in n or 'R2-C2.zip' in n for n in names+zc.namelist())
observations['external_authority_schema_function_used_elsewhere']=sum((b'validate_p1_envelope' in val) for name,val in ext.items() if name!='p1_authority.py')
observations['upload_C1_sha256']=sha(cb);observations['upload_C1_b64_sha256']=sha(raw64);observations['changed_files']=changed
result={'schema':'p0a3h-p1-c1-independent-static-audit-v1','original_zip_sha256':sha(cb),'original_zip_bytes':len(cb),'checks_passed':sum(checks.values()),'checks_total':len(checks),'checks_failed':[k for k,v in checks.items() if not v],'checks':checks,'independent_design_observations':observations,'execution_performed':'NO_CANDIDATE_IMPORTS_OR_RUNS_AND_NO_P1_SCRIPT_INVOCATION'}
OUT.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print('PASSED',sum(checks.values()),'/',len(checks));print('FAILED',result['checks_failed']);print('OBS',json.dumps(observations,indent=2));print('OUTPUT',OUT)
