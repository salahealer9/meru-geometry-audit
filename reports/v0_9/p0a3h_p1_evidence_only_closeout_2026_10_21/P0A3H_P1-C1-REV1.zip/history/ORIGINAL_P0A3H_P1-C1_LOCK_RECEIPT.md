# P0A3H_P1-C1 LOCK RECEIPT (for independent witness)

| Item | Value |
|---|---|
| File | `P0A3H_P1-C1.zip` |
| Bytes | **308,794** |
| SHA-256 | **`0ab255773debd5a68c21fa2555c954b347971d28902ee345beb1f254d02013d4`** |
| Members | 149 (148 covered by SHA256SUMS, which does not list itself; 147 in the inventory) |
| Durable copy | private artifact "P0A3H-P1 Checkpoint Register", version `1792618505-5a9e`, `checkpoints/P0A3H_P1-C1.zip.b64.txt` (417,146 B, `b27434e7…fc33`); decode with `base64 -d` |
| Fresh readback | Read into a new directory. SHA-256 and size match; CRC passes; checksums and inventory pass; byte-identical to the built file. Reference equals `SOURCE_LOCK` (51 files); derivative equals `P1_CANDIDATE_LOCK` (51 files); exactly 3 files changed; kernels identical; external tree equals its lock (23 files); C0 receipt unchanged. |

**Inputs authenticated:**
- P1 `4c1634e6…` and A1 `82dc0d2b…`, both carrying VALIDSIG `D4EC014EEFCC90E619D2AA59A91239ABCF512130`; remote tip equals A1.
- Original P1-C0 `067efd1e…f39e` (348,416 B), with its receipt `469c1cc5…` and local readback `821aaf49…`.
- The 18-commit first-parent chain equals Git, with every edge and signature verified.

**Locks:**

| Lock | SHA-256 |
|---|---|
| `SOURCE_LOCK` | `abff7aa8…5902` |
| `P1_CANDIDATE_LOCK` | `18c7d153…106e` |
| `P1_EXTERNAL_LOCK` | `9689d896…3f0d` |
| Derivative tree digest | `d40ded35…3d1d` |

**Derivative delta:**

| File | Before → after SHA-256 | Change |
|---|---|---|
| `schemas/v0_9/p0a3g/resource_policy.json` | `9b7221fc…` → see ledger | `interpreter` `/usr/bin/python3.12` → `/usr/bin/python3.11`; `interpreter_sha256` → `9bee109d…1a5f`; `openssl_sha256` → `66521161…ad7d`; `openssl` path unchanged |
| `src/meru_geometry/v0_9/qo2d_exact/identity.py` | `77aef8ba…` → see ledger | `PROTOCOL` `4c1634e6…`, `PARENT` `8f4163df…`, `ANCESTRY` the 18-commit chain, `BASELINE` `b34a3cd2…`; stdlib root `/usr/lib/python3.11` |
| `reference/v0_9/qo2d_exact/identity.py` | `9bb68f70…` → see ledger | `PINS` `protocol_commit`, `signed_parent`, `git_ancestry`, `baseline_archive_sha256` set to the same values; stdlib root `/usr/lib/python3.11`; `schema` and `loaded_code_identity` unchanged |

The AST of each identity file equals the original after substituting only the permitted literals. There are no formatting-only bytes. The old authority JSON schema is byte-identical and is not referenced by any `.py` file.

**Cases P01–P06:** see `P1_CASE_CATALOGUE.md` and `p1_external/locks/P1_EXPECTED_OUTCOMES.json`. P05 comparators are the retained signed R2 certificates: H01 `0b0ef621…`, H02 `eee6abc9…`, H03 `98c6e107…`, H04 `ceaa40fb…`.

**Attestation:**
- Zero candidate imports, worker or parser launches, signature trials, test keys, P01–P06 executions, dry runs, previews or Git writes before witness.
- The verifier's P01 logic was not run.
- Static checks only: syntax-only parsing under the 3.11 grammar, AST-literal comparison, hashing.

**Release format** (the digest must come from the reviewer's own verification):
`P0A3H-P1-C1 LOCK WITNESSED; SHA-256 <reviewer-verified digest>; AUTHORIZE ONE P0A3H_P1_DEV_01`

This receipt is not a release.
