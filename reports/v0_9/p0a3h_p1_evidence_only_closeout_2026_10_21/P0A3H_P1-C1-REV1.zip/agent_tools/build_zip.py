"""R2 deterministic checkpoint ZIP builder (agent-side; never imports candidate code).

usage: python3 -I build_zip.py <source_dir> <out.zip> <label>
Every regular file under source_dir (symlinks/specials refused), sorted; adds
PACKAGE_INVENTORY.json (path/bytes/sha256 of every payload file; excludes itself and
SHA256SUMS) and SHA256SUMS (every member except the conventional SHA256SUMS self entry).
Fixed timestamps 1980-01-01, mode 0644, DEFLATE. Refuses private-key markers.
"""
import hashlib, json, os, stat, sys, zipfile

_B, _K = b'-----' + b'BEGIN ', b'PRIVATE' + b' KEY'
MARKERS = tuple(_B + p + _K for p in (b'PGP ', b'OPENSSH ', b'', b'RSA ', b'EC '))


def sha(b):
    return hashlib.sha256(b).hexdigest()


def main(src, out, label):
    files = {}
    for root, dirs, fs in os.walk(src, followlinks=False):
        dirs.sort()
        for d in dirs:
            if os.path.islink(os.path.join(root, d)):
                raise SystemExit('REFUSED_SYMLINK_DIR ' + d)
        for f in sorted(fs):
            p = os.path.join(root, f)
            if not stat.S_ISREG(os.lstat(p).st_mode):
                raise SystemExit('REFUSED_NON_REGULAR ' + p)
            rel = os.path.relpath(p, src).replace(os.sep, '/')
            if rel in ('SHA256SUMS', 'PACKAGE_INVENTORY.json'):
                raise SystemExit('REFUSED_RESERVED ' + rel)
            b = open(p, 'rb').read()
            if any(m in b for m in MARKERS):
                raise SystemExit('REFUSED_PRIVATE_KEY_MARKER ' + rel)
            files[rel] = b
    payload = [{'path': n, 'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())]
    inv = {'schema': 'p0a3g-r2-package-inventory-1', 'checkpoint': label,
           'excludes': ['PACKAGE_INVENTORY.json', 'SHA256SUMS'],
           'self_hash_exception': 'SHA256SUMS does not list itself',
           'payload_count': len(payload), 'payload_files': payload}
    files['PACKAGE_INVENTORY.json'] = (json.dumps(inv, indent=1, sort_keys=True) + '\n').encode()
    files['SHA256SUMS'] = ''.join('%s  %s\n' % (sha(files[n]), n) for n in sorted(files)).encode()
    tmp = out + '.tmp'
    with zipfile.ZipFile(tmp, 'w') as z:
        for n in sorted(files):
            zi = zipfile.ZipInfo(n, date_time=(1980, 1, 1, 0, 0, 0))
            zi.external_attr = 0o100644 << 16
            zi.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(zi, files[n])
    with open(tmp, 'rb') as f:
        os.fsync(f.fileno())
    os.replace(tmp, out)
    b = open(out, 'rb').read()
    print(json.dumps({'checkpoint': label, 'zip': out, 'bytes': len(b), 'sha256': sha(b), 'members': len(files),
                      'sums_non_self': len(files) - 1, 'inventory_entries': len(payload)}, sort_keys=True))


if __name__ == '__main__':
    main(*sys.argv[1:4])
