"""Agent-side static ledger/proof builder (reads files; never imports or executes candidate code).
usage: python3 -I derivative_ledger.py <reference_candidate_dir> <derivative_candidate_dir> <c0_extract_dir> <out.json>
"""
import ast, hashlib, json, os, sys
REF, DER, C0, OUT = sys.argv[1:5]
h = lambda b: hashlib.sha256(b).hexdigest()
def tree(root):
    out = {}
    for b, ds, fs in os.walk(root):
        for f in fs:
            p = os.path.join(b, f)
            if os.path.islink(p): raise SystemExit('SYMLINK ' + p)
            out[os.path.relpath(p, root).replace(os.sep, '/')] = open(p, 'rb').read()
    return out
R, D = tree(REF), tree(DER)
A = json.load(open(os.path.join(C0, 'authority/AUTHENTICATION_CHAIN_AND_SOURCE_PINS.json')))
H = json.load(open(os.path.join(C0, 'operator/LOCAL_HOST_AND_DEPENDENCY_REGISTER.json')))
CHAIN = A['first_parent_ancestry_P1_to_P0A3D_inclusive']
OLD = {'PROTOCOL': 'adacfdbc6efcca4922c8d087d029b67e9b0c5dc5', 'PARENT': 'd95c50ea96744ce266058c51f85fff320d1a27df',
       'ANCESTRY': ['adacfdbc6efcca4922c8d087d029b67e9b0c5dc5', 'd95c50ea96744ce266058c51f85fff320d1a27df', '83b9e6dcd53b100c5ac8b081832e81659cd1884a',
                    '1d38ea6f53b9266d853df887a66331c59e4fc3ae', '8ed3b988f716229bc9aee97d41ded0f524371193', '59eb47f7500d57866e4935822b78a555d3bcb515'],
       'BASELINE': '6ec2b6e96234836d629398fb7fc781909de8b47b0bf80f5cae11202620ff2f15', 'ROOT': '/usr/lib/python3.12'}
NEW = {'PROTOCOL': '4c1634e6660a02ebdea62195f13fc4810fd08d41', 'PARENT': '8f4163df75ad33f9892b72cd62b75dbda24f0505', 'ANCESTRY': CHAIN,
       'BASELINE': 'b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1', 'ROOT': H['python_sysconfig_stdlib']}
ALLOWED = ['schemas/v0_9/p0a3g/resource_policy.json', 'src/meru_geometry/v0_9/qo2d_exact/identity.py', 'reference/v0_9/qo2d_exact/identity.py']
KERNELS = {'src/meru_geometry/v0_9/qo2d_exact/algebra.py': '442065847937252db00d3f63b02184c15d57989f958f764c5c731cb385de6d2d',
           'src/meru_geometry/v0_9/qo2d_exact/core.py': '37701d034d98725673240a881420892893906c70387f68432b5993f8557dd420',
           'reference/v0_9/qo2d_exact/arithmetic.py': '72b3c37f02be65b2df7616a94e84601d66cf4af5b7a50e878724de647e5bf0ba'}
ledger = []
for p in sorted(set(R) | set(D)):
    a, b = R.get(p), D.get(p)
    ledger.append({'path': p, 'before_bytes': None if a is None else len(a), 'before_sha256': None if a is None else h(a),
                   'after_bytes': None if b is None else len(b), 'after_sha256': None if b is None else h(b),
                   'changed': a != b, 'permitted_to_change': p in ALLOWED})
changed = [e['path'] for e in ledger if e['changed']]
def subst_old_to_new(src):
    """Replace exactly the permitted old literal values by the new ones in a parsed AST (old file)."""
    t = ast.parse(src)
    m = {repr(OLD[k]): NEW[k] for k in ('PROTOCOL', 'PARENT', 'BASELINE')}
    m[repr(OLD['ROOT'])] = NEW['ROOT']
    class T(ast.NodeTransformer):
        def visit_Constant(self, n):
            if isinstance(n.value, str) and repr(n.value) in m: return ast.copy_location(ast.Constant(m[repr(n.value)]), n)
            return n
        def visit_List(self, n):
            vals = [e.value if isinstance(e, ast.Constant) else None for e in n.elts]
            if vals == OLD['ANCESTRY']:
                return ast.copy_location(ast.List([ast.Constant(c) for c in NEW['ANCESTRY']], ast.Load()), n)
            self.generic_visit(n)
            return n
    return ast.dump(T().visit(t), include_attributes=False)
proofs = {}
for p in ALLOWED[1:]:
    old_s, new_s = R[p].decode(), D[p].decode()
    ol, nl = old_s.splitlines(keepends=True), new_s.splitlines(keepends=True)
    diff_lines = [i + 1 for i, (x, y) in enumerate(zip(ol, nl)) if x != y]
    proofs[p] = {'line_count_equal': len(ol) == len(nl), 'changed_line_numbers': diff_lines,
                 'ast_equal_after_substituting_only_permitted_literals': subst_old_to_new(old_s) == ast.dump(ast.parse(new_s), include_attributes=False),
                 'old_baseline_and_py312_root_absent_in_new': all(v not in new_s for v in (OLD['BASELINE'], OLD['ROOT'])),
                 'note_old_protocol_parent_remain_only_as_ancestry_members': 'adacfdbc… and d95c50ea… are genuine members of the new 18-commit first-parent chain',
                 'trailing_newline_preserved': old_s.endswith('\n') == new_s.endswith('\n')}
po, pn = json.loads(R[ALLOWED[0]]), json.loads(D[ALLOWED[0]])
field_changes = {k: [po.get(k), pn.get(k)] for k in sorted(set(po) | set(pn)) if po.get(k) != pn.get(k)}
ol, nl = R[ALLOWED[0]].decode().splitlines(), D[ALLOWED[0]].decode().splitlines()
proofs[ALLOWED[0]] = {'keys_identical': sorted(po) == sorted(pn), 'changed_fields': field_changes,
                      'changed_fields_subset_of_permitted_four': set(field_changes) <= {'interpreter', 'interpreter_sha256', 'openssl', 'openssl_sha256'},
                      'openssl_path_unchanged_value': po['openssl'] == pn['openssl'] == '/usr/bin/openssl',
                      'all_other_fields_equal': all(po[k] == pn[k] for k in po if k not in ('interpreter', 'interpreter_sha256', 'openssl', 'openssl_sha256')),
                      'line_count_equal': len(ol) == len(nl), 'changed_line_numbers': [i + 1 for i, (x, y) in enumerate(zip(ol, nl)) if x != y],
                      'values_equal_C0_host_register': pn['interpreter'] == H['python']['path'] and pn['interpreter_sha256'] == H['python']['sha256'] and pn['openssl'] == H['openssl']['path'] and pn['openssl_sha256'] == H['openssl']['sha256']}
ri = D[ALLOWED[2]].decode(); pi = D[ALLOWED[1]].decode()
rt = ast.parse(ri); pt = ast.parse(pi)
def assigned(t, name):
    for n in t.body:
        if isinstance(n, ast.Assign) and any(isinstance(x, ast.Name) and x.id == name for x in n.targets): return ast.literal_eval(n.value)
pins = assigned(rt, 'PINS')
prod = {k: assigned(pt, k) for k in ('PROTOCOL', 'PARENT', 'ANCESTRY', 'BASELINE', 'LOADED')}
consistency = {'pins_protocol_eq_PROTOCOL': pins['protocol_commit'] == prod['PROTOCOL'] == NEW['PROTOCOL'],
               'pins_parent_eq_PARENT': pins['signed_parent'] == prod['PARENT'] == NEW['PARENT'],
               'pins_ancestry_eq_ANCESTRY_eq_C0_chain': pins['git_ancestry'] == prod['ANCESTRY'] == CHAIN and len(CHAIN) == 18,
               'pins_baseline_eq_BASELINE': pins['baseline_archive_sha256'] == prod['BASELINE'] == NEW['BASELINE'],
               'pins_schema_unchanged': pins['schema'] == 'p0a3g-authority-envelope-1',
               'pins_loaded_code_identity_unchanged': pins['loaded_code_identity'] == prod['LOADED'] == 'LOADED_CODE_IDENTITY_UNVERIFIED',
               'stdlib_root_both_files': ("Path('%s')" % NEW['ROOT']) in pi and ("Path('%s')" % NEW['ROOT']) in ri}
out = {'schema': 'p0a3h-p1-derivative-ledger-1', 'reference_files': len(R), 'derivative_files': len(D),
       'same_path_set': sorted(R) == sorted(D), 'changed_files': changed, 'changed_exactly_permitted_three': sorted(changed) == sorted(ALLOWED),
       'kernels_byte_identical': {k: h(D[k]) == v == h(R[k]) for k, v in KERNELS.items()},
       'no_bytecode_or_extra_files': not any(p.endswith(('.pyc', '.pyo')) or '__pycache__' in p for p in D),
       'derivative_python_files_parse': all(ast.parse(D[p]) is not None for p in D if p.endswith('.py')),
       'new_identity_values': NEW, 'old_identity_values_historical': OLD,
       'historical_note': 'old BASELINE 6ec2b6e9… is the historical R1-CFINAL referent; it is no longer an accepted P1 value',
       'field_and_syntax_proofs': proofs, 'production_reference_identity_consistency': consistency,
       'old_authority_envelope_schema_unchanged': R['schemas/v0_9/p0a3g/authority_envelope.schema.json'] == D['schemas/v0_9/p0a3g/authority_envelope.schema.json'],
       'per_file_ledger': ledger}
open(OUT, 'w').write(json.dumps(out, indent=1, sort_keys=True) + '\n')
summ = {k: out[k] for k in ('reference_files', 'derivative_files', 'same_path_set', 'changed_files', 'changed_exactly_permitted_three', 'kernels_byte_identical', 'no_bytecode_or_extra_files', 'derivative_python_files_parse', 'old_authority_envelope_schema_unchanged')}
print(json.dumps(summ, indent=1)); print(json.dumps(proofs, indent=1)); print(json.dumps(consistency, indent=1))
