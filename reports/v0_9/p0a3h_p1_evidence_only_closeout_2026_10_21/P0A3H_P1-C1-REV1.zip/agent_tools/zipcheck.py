"""R2 agent-side ZIP verifier (stdlib only; never imports or runs candidate code).

usage: python3 -I zipcheck.py <zip> [expected_sha256|-] [expected_bytes|-]
Checks outer size/SHA-256, unique safe member names, no symlink/special modes, CRC by full
read of every member, every SHA256SUMS line except the self entry, and every inventory
record (PACKAGE_INVENTORY.json: list, or dict with payload_files/files/entries).
Prints JSON; exit 0 only on PASS.
"""
import hashlib, json, stat, sys, zipfile


def sha(b):
    return hashlib.sha256(b).hexdigest()


def safe(n):
    if not n or n.startswith('/') or '\\' in n or '\x00' in n or (len(n) > 1 and n[1] == ':'):
        return False
    return all(p not in ('', '.', '..') for p in n.rstrip('/').split('/'))


def check(path, exp_sha=None, exp_bytes=None):
    raw = open(path, 'rb').read()
    out = {'path': path, 'bytes': len(raw), 'sha256': sha(raw), 'errors': []}
    if exp_sha and exp_sha != out['sha256']:
        out['errors'].append('OUTER_SHA256')
    if exp_bytes is not None and exp_bytes != out['bytes']:
        out['errors'].append('OUTER_BYTES')
    z = zipfile.ZipFile(path)
    infos = z.infolist()
    names = [i.filename for i in infos]
    out['members'] = len(infos)
    if len(names) != len(set(names)):
        out['errors'].append('DUPLICATE_NAMES')
    data = {}
    for i in infos:
        if not safe(i.filename):
            out['errors'].append('UNSAFE:' + i.filename)
        mode = (i.external_attr >> 16) & 0xFFFF
        if mode and any(f(mode) for f in (stat.S_ISLNK, stat.S_ISCHR, stat.S_ISBLK, stat.S_ISFIFO, stat.S_ISSOCK)):
            out['errors'].append('SPECIAL_MODE:' + i.filename)
        elif mode and not stat.S_IFMT(mode):
            out.setdefault('notes', []).append('MODE_WITHOUT_FILE_TYPE_BITS:%s:%s' % (i.filename, oct(mode)))
        if i.is_dir():
            continue
        try:
            data[i.filename] = z.read(i)
        except Exception as e:  # CRC failure raises
            out['errors'].append('CRC:%s:%s' % (i.filename, type(e).__name__))
    out['crc'] = 'PASS' if not any(e.startswith('CRC') for e in out['errors']) else 'FAIL'
    if 'SHA256SUMS' in data:
        ok = 0
        covered = set()
        for line in data['SHA256SUMS'].decode().splitlines():
            if not line.strip():
                continue
            h, n = line.split(None, 1)
            n = n.strip().lstrip('*')
            covered.add(n)
            if n == 'SHA256SUMS':
                continue
            if n in data and sha(data[n]) == h:
                ok += 1
            else:
                out['errors'].append('SUMS:' + n)
        out['sums_non_self_verified'] = ok
        out['members_not_in_sums'] = sorted(set(data) - covered - {'SHA256SUMS'})
        if out['members_not_in_sums']:
            out['errors'].append('UNCOVERED_MEMBERS')
    else:
        out['errors'].append('NO_SHA256SUMS')
    inv_name = next((n for n in ('PACKAGE_INVENTORY.json', 'PAYLOAD_INVENTORY.json') if n in data), None)
    if inv_name:
        inv = json.loads(data[inv_name])
        recs = inv if isinstance(inv, list) else (inv.get('payload_files') or inv.get('files') or inv.get('entries') or [])
        ok = 0
        for r in recs:
            p = r.get('path')
            if p in data and len(data[p]) == r.get('bytes') and sha(data[p]) == r.get('sha256'):
                ok += 1
            else:
                out['errors'].append('INVENTORY:%s' % p)
        out['inventory_entries'] = len(recs)
        out['inventory_verified'] = ok
    out['verdict'] = 'PASS' if not out['errors'] else 'FAIL'
    return out


if __name__ == '__main__':
    a = sys.argv[1:]
    es = a[1] if len(a) > 1 and a[1] != '-' else None
    eb = int(a[2]) if len(a) > 2 and a[2] != '-' else None
    o = check(a[0], es, eb)
    print(json.dumps(o, indent=1, sort_keys=True))
    sys.exit(0 if o['verdict'] == 'PASS' else 1)
