"""P0A3G caller-supplied external code authority (production route).

Distinguishable authority states (never conflated):
  NON_PRODUCTION_TEST_AUTHORITY  - Ed25519 signature by a key the CALLER's trust store
                                   scopes as NON_PRODUCTION_TEST_AUTHORITY; accepted only
                                   in explicit mode TEST_AUTHORITY. Not deployment trust.
  UNSIGNED_STAGING_PROPOSAL +    - R1-style unsigned caller fixture; accepted only in
  CALLER_OWNED_DEV_FIXTURE         explicit mode DEV_UNSIGNED, for regression/negatives.
  HUMAN_SIGNED_CODE_FREEZE       - real human-signed code authority. NOT IMPLEMENTED and
                                   never accepted here: mode DEPLOYMENT always fails closed.
The candidate holds no default key and no trust store; both come from the caller.
Loaded runtime instruction integrity is NOT attested: LOADED_CODE_IDENTITY_UNVERIFIED.
Production signature verification uses the pinned OpenSSL CLI (external binary; its
libcrypto and loader are not attested). The reference checker uses a separate
pure-Python RFC 8032 route.
"""
import hashlib,json,os,platform,re,subprocess,sys,tempfile,types
from pathlib import Path
from .wire import ROOT,Boundary,decode,POLICY
PROTOCOL='4c1634e6660a02ebdea62195f13fc4810fd08d41'
PARENT='8f4163df75ad33f9892b72cd62b75dbda24f0505'
ANCESTRY=['4c1634e6660a02ebdea62195f13fc4810fd08d41','8f4163df75ad33f9892b72cd62b75dbda24f0505','39364f5a4345c8b60a879f6411b8d80cc6c299c6','1120360074462c09863b45b85b64dc2b3f733626','2b77d6f3be9499b5725b4f51fc41aabf7fe37400','d9d0d6ad5b7cc310ed14af774355aeaa2652ea89','f5e31de09a8b79ddb1b5f0ba738443fc4012a390','e491e1e9f96391cd512db0dd528765d63bc179c1','4b488825ed35c7ac91a19abe62be068e75e9a076','7de01ab2c90afe52dd763652a9eaffd2e9a2cff9','0e86df64e30d081065bbeb75b6f53391e287f8f3','adacfdbc6efcca4922c8d087d029b67e9b0c5dc5','d95c50ea96744ce266058c51f85fff320d1a27df','83b9e6dcd53b100c5ac8b081832e81659cd1884a','1d38ea6f53b9266d853df887a66331c59e4fc3ae','8ed3b988f716229bc9aee97d41ded0f524371193','c48c7a60777200a172ae3c72f5b0402162370ec7','59eb47f7500d57866e4935822b78a555d3bcb515']
BASELINE='b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1'
MODES=('TEST_AUTHORITY','DEV_UNSIGNED','DEPLOYMENT')
LOADED='LOADED_CODE_IDENTITY_UNVERIFIED'
ENVELOPE_FIELDS={'schema','authority_mode','protocol_commit','signed_parent','git_ancestry','baseline_archive_sha256','files','environment_sha256','resource_policy_sha256','input_sha256','run_id','key_id','loaded_code_identity'}
RECEIPT_FIELDS={'schema','mode','run_id','envelope_sha256','signature_sha256','trust_store_sha256'}
SPKI_ED25519=bytes.fromhex('302a300506032b6570032100')
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def environment():
    base=Path('/usr/lib/python3.11')
    deps=['fractions.py','decimal.py','json/__init__.py','json/decoder.py','json/encoder.py','json/scanner.py','hashlib.py','pathlib.py','subprocess.py','selectors.py','tempfile.py']
    return {'python':sys.version,'implementation':sys.implementation.name,'platform':platform.platform(),'executable_realpath':str(Path(sys.executable).resolve()),'executable_sha256':sha(Path(sys.executable).read_bytes()),'flags':{'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode},'dependencies':{n:sha((base/n).read_bytes()) for n in deps}}
def files():
    out={}
    for folder in ('src','reference','schemas','tests'):
        for p in sorted((ROOT/folder).rglob('*')):
            if p.is_symlink() or p.suffix in ('.pyc','.pyo'):raise Boundary('CODE_IDENTITY_MISMATCH','SOURCE_SYMLINK_OR_BYTECODE')
            if p.is_file() and p.suffix in ('.py','.json','.md'):out[p.relative_to(ROOT).as_posix()]=sha(p.read_bytes())
    return out
def policy_sha():return sha((ROOT/'schemas/v0_9/p0a3g/resource_policy.json').read_bytes())
def loaded_check():
    # Narrow accidental module-function mutation check, NOT runtime attestation.
    for name,mod in tuple(sys.modules.items()):
        if not (name.startswith('meru_geometry.') or name.startswith('reference.')):continue
        path=getattr(mod,'__file__',None)
        if not path or not str(path).endswith('.py'):continue
        p=Path(path)
        if ROOT not in p.resolve().parents:raise ValueError('loaded outside root')
        code=compile(p.read_bytes(),str(p),'exec',dont_inherit=True,optimize=0)
        funcs={c.co_name:c for c in code.co_consts if isinstance(c,types.CodeType)}
        for key,value in vars(mod).items():
            if isinstance(value,types.FunctionType) and value.__module__==name:
                if key not in funcs or value.__code__!=funcs[key]:raise ValueError('loaded function mismatch')
def openssl_verify(public_key,message,signature):
    exe=POLICY['openssl']
    if sha(Path(exe).resolve().read_bytes())!=POLICY['openssl_sha256']:raise ValueError('openssl identity')
    if type(public_key) is not bytes or len(public_key)!=32 or type(signature) is not bytes or len(signature)!=64:raise ValueError('key/signature length')
    with tempfile.TemporaryDirectory(prefix='p0a3g_sig_') as t:
        der=SPKI_ED25519+public_key
        pem=b'-----BEGIN PUBLIC KEY-----\n'+__import__('base64').encodebytes(der)+b'-----END PUBLIC KEY-----\n'
        for n,b in (('k.pem',pem),('m.bin',message),('s.bin',signature)):Path(t,n).write_bytes(b)
        r=subprocess.run([exe,'pkeyutl','-verify','-pubin','-inkey',str(Path(t,'k.pem')),'-rawin','-in',str(Path(t,'m.bin')),'-sigfile',str(Path(t,'s.bin'))],capture_output=True,timeout=POLICY['signature_verify_seconds'],env={'PATH':os.defpath,'LC_ALL':'C.UTF-8'})
    return r.returncode==0 and b'Signature Verified Successfully' in r.stdout
def authority(envelope,receipt,signature,trust,*,mode):
    """Authority and trust checks only (no source/runtime comparison). Returns status string."""
    if mode not in MODES:raise ValueError('mode')
    m=decode(envelope,POLICY['document_bytes']);t=decode(receipt,POLICY['document_bytes'])
    if type(m) is not dict or set(m)!=ENVELOPE_FIELDS or m['schema']!='p0a3g-authority-envelope-1':raise ValueError('envelope fields')
    if (m['protocol_commit'],m['signed_parent'],m['git_ancestry'],m['baseline_archive_sha256'],m['loaded_code_identity'])!=(PROTOCOL,PARENT,ANCESTRY,BASELINE,LOADED):raise ValueError('envelope authority pins')
    if type(t) is not dict or set(t)!=RECEIPT_FIELDS or t['schema']!='p0a3g-caller-receipt-1':raise ValueError('receipt fields')
    if t['mode']!=mode:raise ValueError('mode mismatch')
    if t['envelope_sha256']!=sha(envelope):raise ValueError('receipt envelope binding')
    if type(t['run_id']) is not str or not re.fullmatch('[A-Za-z0-9_.-]{1,64}',t['run_id']) or t['run_id']!=m['run_id']:raise ValueError('run binding')
    if mode=='DEPLOYMENT':raise ValueError('REAL_HUMAN_SIGNED_AUTHORITY_ABSENT')
    if mode=='DEV_UNSIGNED':
        if m['authority_mode']!='UNSIGNED_STAGING_PROPOSAL' or m['key_id'] is not None or signature is not None or trust is not None or t['signature_sha256'] is not None or t['trust_store_sha256'] is not None:raise ValueError('unsigned dev fixture shape')
        return 'CALLER_OWNED_DEV_FIXTURE_UNSIGNED'
    # TEST_AUTHORITY
    if m['authority_mode']!='NON_PRODUCTION_TEST_AUTHORITY':raise ValueError('authority mode not test authority')
    if type(signature) is not bytes or type(trust) is not bytes:raise ValueError('signature/trust missing')
    if t['signature_sha256']!=sha(signature) or t['trust_store_sha256']!=sha(trust):raise ValueError('receipt signature/trust binding')
    s=decode(trust,POLICY['document_bytes'])
    if type(s) is not dict or set(s)!={'schema','store_id','keys'} or s['schema']!='p0a3g-trust-store-1' or type(s['keys']) is not list:raise ValueError('trust store')
    keys=[k for k in s['keys'] if type(k) is dict and k.get('key_id')==m['key_id']]
    if len(keys)!=1:raise ValueError('signer not in caller trust store')
    k=keys[0]
    if set(k)!={'key_id','algorithm','public_key_hex','scope','revoked'} or k['algorithm']!='ed25519' or k['scope']!='NON_PRODUCTION_TEST_AUTHORITY' or k['revoked'] is not False:raise ValueError('key scope/revocation')
    if not re.fullmatch('[0-9a-f]{64}',k['public_key_hex']):raise ValueError('public key')
    if not openssl_verify(bytes.fromhex(k['public_key_hex']),envelope,signature):raise ValueError('signature')
    return 'NON_PRODUCTION_TEST_AUTHORITY_VERIFIED'
def verify(envelope,input_hash=None,receipt=None,signature=None,trust=None,*,mode):
    try:
        status=authority(envelope,receipt,signature,trust,mode=mode)
        m=decode(envelope,POLICY['document_bytes'])
        if m['files']!=files() or m['environment_sha256']!=sha(canonical(environment())) or m['resource_policy_sha256']!=policy_sha():raise ValueError('source/runtime')
        h=m['input_sha256']
        if type(h) is not str or not re.fullmatch('[0-9a-f]{64}',h) or (input_hash is not None and input_hash!=h):raise ValueError('input')
        loaded_check()
        return {'authority_status':status,'loaded_code_identity':LOADED,'envelope_sha256':sha(envelope)}
    except Exception as e:raise Boundary('CODE_IDENTITY_MISMATCH','EXTERNAL_AUTHORITY_REJECTED') from e
