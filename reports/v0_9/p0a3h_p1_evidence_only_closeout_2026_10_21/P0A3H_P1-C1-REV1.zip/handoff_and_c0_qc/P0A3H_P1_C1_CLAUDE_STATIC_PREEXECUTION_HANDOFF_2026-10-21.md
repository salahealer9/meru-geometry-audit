# P0A3H-P1/A1 — Claude static P1-C1 preparation and mandatory witness handoff

**Status:** P1-C0 independently reviewed and byte/source integrity qualified. **Authorized activities:** strictly static P1-P1 candidate construction and C1 archive creation/readback. **Never authorize P1 DEV or any candidate import/execute.** The previous Claude feasibility report and A1 discovery remain immutable.

## 1. Exact signed authority and source inputs

Repository: `salahealer9/meru-geometry-audit`; branch `hebrew-projection-capacity-v0.9`.

- Human-signed P1 protocol commit `4c1634e6660a02ebdea62195f13fc4810fd08d41`; Git blob `557e778363c068b893855928f973dd3e9071597e`.
- Human-signed A1 scope amendment commit/current expected HEAD `82dc0d2b2f2b81f90ec60dfed8e3aade19555d40`; direct parent P1; Git blob `a3a27a4f9379f8aacae085938eca39e5bb5b215f`.
- Expected human GPG fingerprint `D4EC014EEFCC90E619D2AA59A91239ABCF512130`.
- **Authoritative original operator P1-C0:** `P0A3H_P1-C0.zip`, **348,416 bytes**, SHA-256 `067efd1e0fb66bc7bf5c61df186d43558ef2a81f223ca90912f67bca23439f5e` (user to attach ORIGINAL ZIP, not a reconstruction). Original external C0 receipt/readback available separately.
- Independent static C0 QC report accompanying this handoff. Reviewer outcome `P0A3H_P1_C0_INDEPENDENT_BYTE_AND_SOURCE_QC_PASS` is **C0-only**; it gives no permission to run a single P1 method.
- Frozen signed R2-C1-REV1 ZIP nested inside original C0, size 197,250 bytes, SHA-256 `b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1`; locked 51-file source manifest SHA `abff7aa8df19f73e070d9f06ebd23334f8d98b45c1736d38399b845c69835902`.

First independently retrieve/read **both full signed protocols** at the pinned GitHub commits; authenticate the exact direct-parent links, GPG validity using the authorized signer, source ZIP and all original C0 bytes. The GitHub branch must still match expected HEAD; if it advances, stop rather than silently changing authority. Preserve original previous evidence and full status ledger (original F/R1/G/R2/H/L1 negatives, C3 administrative-only PASS) without upgrading anything.

## 2. Local host authority vs Claude host

Use the original C0 `operator/LOCAL_HOST_AND_DEPENDENCY_REGISTER.json` as the **claimed measured operator machine**; Claude's current Python 3.12 host must **never** substitute its own runtime identities. The local host claims Debian 12/x86_64, Python 3.11.2 `/usr/bin/python3.11` SHA-256 `9bee109da0dce17a7c9eeaca9f420cc6770a9fe143b9382d73bd22fe59b21a5f`, OpenSSL 3.0.22 `/usr/bin/openssl` SHA-256 `66521161cfad981e189bbc746560e0cc71a141b3765b3fe3658704d877c6ad7d`, stdlib root `/usr/lib/python3.11`, eleven dependency path/digest pairs. Preserve provenance and independent verification limitations; no claim that Claude independently measured those files.

Do not execute code in a local-host emulator or a different container to 'verify' the candidate. Reconfirm actual operator binary identities and all eleven dependency hashes from the owner's machine **before any eventual released test**; the signed protocol handles host drift fail-closed.

## 3. Authorized static derivative construction

In a **new outside-repository** `P0A3H_P1/` workspace, retain a byte-exact original reference tree and separately named derivative. Change only:

1. `schemas/v0_9/p0a3g/resource_policy.json`: the four `interpreter`, `interpreter_sha256`, `openssl`, `openssl_sha256` fields; no limit/security changes.
2. `src/meru_geometry/v0_9/qo2d_exact/identity.py`: the measured Python standard-library root and only P1 protocol/PARENT/ANCESTRY/BASELINE lineage constants.
3. `reference/v0_9/qo2d_exact/identity.py`: matching measured standard-library root and exactly the four specified `PINS` lineage fields, with the old schema strings and `loaded_code_identity` value unchanged.

**Protected kernels, never edit:** `src/meru_geometry/v0_9/qo2d_exact/algebra.py` `442065847937252db00d3f63b02184c15d57989f958f764c5c731cb385de6d2d`; `src/meru_geometry/v0_9/qo2d_exact/core.py` `37701d034d98725673240a881420892893906c70387f68432b5993f8557dd420`; `reference/v0_9/qo2d_exact/arithmetic.py` `72b3c37f02be65b2df7616a94e84601d66cf4af5b7a50e878724de647e5bf0ba`.

No edits to checker arithmetic, supervision, workers, schemas, authority semantics, signature verifier, resource caps, other 48 source files or the original Git repository. If a fourth changed file is needed or an observed source/ABI contract cannot be satisfied within these edits, preserve `P0A3H_P1_SCOPE_AMENDMENT_REQUIRED` for the new issue and **STOP** for signed A2. Never silently repair after a trial.

**Exact prospective P1 identity:** `PROTOCOL` = P1 signed `4c1634e6...`; `PARENT` = actual P1 direct parent `8f4163df...`; `ANCESTRY` = full ordered first-parent list of 18 SHAs from P1 to signed P0A3D `59eb47f7500d57866e4935822b78a555d3bcb515` inclusive, **as recorded in original P1-C0 authority ledger** and independently checked by GitHub; `BASELINE` = original R2-C1-REV1 outer SHA `b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1`. A1 signed SHA/blob separately pinned in candidate lock and external receipts, **not falsely substituted as P1's parent**. The original JSON schema with old P0A3G `const` values remains byte-identical historical content; create a new external **P1-specific** validation schema and statically demonstrate the old schema is not used to accept P1 authority. Old-lineage envelopes must fail; test-only authority only; DEPLOYMENT must stay rejected.

Create a full before/after 51-file per-byte ledger, complete static diff with field-level proof, separate candidate identity/source lock, and all SHA256SUMS/inventory. Disclose any proposed formatting-only bytes in the two identity `.py` files as potential out-of-scope edits; do not broaden permitted changes.

## 4. External P1 test source — lock, do NOT execute

Prepare a complete separately versioned `p1_external/` tree without importing or modifying the candidate: standalone bounded launcher, raw stream/process evidence recorder, independent verifier/reconciler, test-only envelope fixture and release receipt schemas, and six predeclared portability cases with exact input bytes, command lines, status outcomes, time/CPU/memory/file limits, expected arithmetic equality and error classifications:

- P01 immutable 51-file diff, three kernel pins and new lineage.
- P02 measured local Python/OpenSSL envelope and previously exposed benign R2-H01 generic input.
- P03 non-production scoped authority: valid only if properly scoped, invalid analogue rejected.
- P04 `DEPLOYMENT` rejected as `REAL_HUMAN_SIGNED_AUTHORITY_ABSENT`.
- P05 exact canonical mathematical/reference consistency, with independently sourced comparator prelocked.
- P06 bounded invalid/over-limit generic request or observation-loss case, with raw evidence and fail-closed classification.

No H01–H07 security-substitution/shadowing challenge is part of P1. Do not add real-world attack tooling or production credentials. Keep resource policy unchanged: 8 s worker wall, 6 s CPU, 256 MiB worker RAM, 2 MiB stream/file, NOFILE 32, concurrency 1, recursion 256, 16 MiB attempt disk, 64 KiB request; preserve all further signed policy fields. P01–P06 must not be modified after execution.

**Allowed prelock:** source text edit, static AST parsing, manifests, archive checks, hashing, read-only GPG/Git, environmental metadata inspection; no candidate imports, tests, signature trials, worker/parser launches, numerical previews, smoke/dry runs, test keys in use or dev runs.

## 5. Exact C1 checkpoint and HARD STOP

Produce original `P0A3H_P1-C1.zip` with full original and derivative 51-file trees, locked P1 source manifest and 3-file change ledger, complete external implementation/fixtures, all frozen case descriptions/expected outcomes, the P1-C0 original SHA/receipt, operator-host identity ledger, Git identities and 18-commit ancestry, source authorship/conflicts, and a physically prepared plan for P1-C2 to contain the literal **C0 receipt, C1 receipt and human release certificate IN C2 itself**, plus nested original cumulative CFINAL after future execution.

Preserve C0 unchanged; independently durably store C1; **fresh-read back** its bytes from separately retained storage; verify exact SHA-256/byte count, ZIP CRC, safe paths/unique regular files, SHA256SUMS and inventory, source-lock identities and chronology. Supply ORIGINAL downloadable C1 archive (not a summary/reconstruction), its outer hash and size, receipt/readback, full static source/diff ledger and any failure/interruption report. Also return original C0 or identify original user upload, not another fabricated C0.

**STOP UNCONDITIONALLY at the P1-C1 external-witness gate**. No P1-C2, CFINAL or P01–P06 execution. No Git commit/push, tags, candidate freeze, P0A4, Hebrew target/glyph/QH/3D analysis, production signing, or attempt to upgrade earlier negative findings. Explicit SHA-specific **human** release for `P0A3H_P1_DEV_01` may occur only AFTER a genuinely separate reviewer inspects complete original C1; nothing in this handoff is that release.

If any safety restriction, missing source, infeasible implementation, undocumented run, unauthorized source edit, unavailable host requirement, inconsistent authority or incomplete C1 evidence occurs: STOP, preserve literal negative artifacts, and ask for separately signed prospective remediation—never bypass a platform safeguard or retrofit evidence.
