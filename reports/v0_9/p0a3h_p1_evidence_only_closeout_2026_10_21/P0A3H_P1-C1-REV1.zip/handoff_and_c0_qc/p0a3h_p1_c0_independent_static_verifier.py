#!/usr/bin/env python3
"""Read-only independent file/record QC for the original P0A3H-P1 C0 archive.
Not an execution or observation of candidate code, process tests, or signer key ownertrust.
"""
import hashlib, io, json, pathlib, stat, zipfile

ROOT=pathlib.Path('/mnt/data')
FILE=ROOT/'P0A3H_P1-C0.zip'
SHA='067efd1e0fb66bc7bf5c61df186d43558ef2a81f223ca90912f67bca23439f5e'
checks=[]
def ck(label, ok): checks.append({'name':label,'ok':bool(ok)})
def digest(b): return hashlib.sha256(b).hexdigest()
def check_archive(z, prefix):
    names=z.namelist(); ck(prefix+'.zip_crc',z.testzip() is None)
    ck(prefix+'.all_unique',len(names)==len(set(names)))
    ck(prefix+'.safe_regular_paths',all(not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts and not n.startswith('/') and '\\' not in n and not stat.S_ISLNK((i.external_attr>>16)&0xffff) for i in z.infolist() for n in [i.filename]))
    return names
raw=FILE.read_bytes()
ck('outer.byte_length',len(raw)==348416);ck('outer.sha256',digest(raw)==SHA)
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    names=check_archive(z,'C0');ck('C0.member_count',len(names)==20)
    inv=json.loads(z.read('PACKAGE_INVENTORY.json'))
    rows=inv['payload_files']
    ck('C0.inventory_count',len(rows)==18 and inv['payload_count']==18)
    ck('C0.inventory_exclusions',set(inv['excludes'])=={'SHA256SUMS','PACKAGE_INVENTORY.json'})
    ck('C0.inventory_path_exactness',set(x['path'] for x in rows)==set(names)-set(inv['excludes']))
    for row in rows:
        path=row['path'];b=z.read(path)
        ck('member.length:'+path,len(b)==row['bytes'])
        ck('member.sha256:'+path,digest(b)==row['sha256'])
    sumrows={}
    for line in z.read('SHA256SUMS').decode().splitlines():
        h,p=line.split('  ',1);ck('SHA256SUMS.syntax:'+p,len(h)==64 and p not in sumrows)
        sumrows[p]=h
    ck('C0.checksum_count',len(sumrows)==19)
    ck('C0.checksum_path_exactness',set(sumrows)==set(names)-{'SHA256SUMS'})
    for p,h in sumrows.items():ck('SHA256SUMS.content:'+p,digest(z.read(p))==h)
    rec=json.loads((ROOT/'P0A3H_P1-C0_RECEIPT.json').read_bytes())
    back=json.loads((ROOT/'P0A3H_P1-C0_LOCAL_READBACK.json').read_bytes())
    for which,rr in [('RECEIPT',rec),('READBACK',back)]:
        ck(which+'.sha256',rr['archive']['sha256']==SHA)
        ck(which+'.size',rr['archive']['bytes']==len(raw))
        ck(which+'.members',rr['archive']['members']==len(names))
    ck('READBACK.same_host_claim',back['status']=='BYTE_IDENTICAL_SAME_HOST_COPY_ONLY')
    ck('RECEIPT.C1_not_built',rec['p1_c1']=='NOT BUILT')
    ck('RECEIPT.execution_not_authorized',rec['p1_dev_01']=='NOT AUTHORIZED')
    ck('RECEIPT.authority',rec['authority']=='82dc0d2b2f2b81f90ec60dfed8e3aade19555d40')
    ck('RECEIPT.no_execution_self_attestation',rec['operator_no_prior_p1_test']=='SELF-ATTESTED VIA CLI FLAG')
    auth=json.loads(z.read('authority/AUTHENTICATION_CHAIN_AND_SOURCE_PINS.json'))
    expected=[
      '4c1634e6660a02ebdea62195f13fc4810fd08d41','8f4163df75ad33f9892b72cd62b75dbda24f0505',
      '39364f5a4345c8b60a879f6411b8d80cc6c299c6','1120360074462c09863b45b85b64dc2b3f733626',
      '2b77d6f3be9499b5725b4f51fc41aabf7fe37400','d9d0d6ad5b7cc310ed14af774355aeaa2652ea89',
      'f5e31de09a8b79ddb1b5f0ba738443fc4012a390','e491e1e9f96391cd512db0dd528765d63bc179c1',
      '4b488825ed35c7ac91a19abe62be068e75e9a076','7de01ab2c90afe52dd763652a9eaffd2e9a2cff9',
      '0e86df64e30d081065bbeb75b6f53391e287f8f3','adacfdbc6efcca4922c8d087d029b67e9b0c5dc5',
      'd95c50ea96744ce266058c51f85fff320d1a27df','83b9e6dcd53b100c5ac8b081832e81659cd1884a',
      '1d38ea6f53b9266d853df887a66331c59e4fc3ae','8ed3b988f716229bc9aee97d41ded0f524371193',
      'c48c7a60777200a172ae3c72f5b0402162370ec7','59eb47f7500d57866e4935822b78a555d3bcb515']
    ck('AUTH.ancestry_exact_18',auth['first_parent_ancestry_P1_to_P0A3D_inclusive']==expected)
    ck('AUTH.provenance',auth['A1']==rec['authority'] and auth['A1_PARENT']==auth['P1'] and auth['P1']==expected[0] and auth['P1_PARENT']==expected[1])
    ck('AUTH.protocol_SHA256',digest(z.read('authority/ORIGINAL_P1_SIGNED_PROTOCOL.md'))=='adac839f73b1039a2400da2fa20990cdb420489ccc77e89755ef1f4fdea3c7aa')
    ck('AUTH.amendment_SHA256',digest(z.read('authority/ORIGINAL_A1_SIGNED_AMENDMENT.md'))=='6c2c3bd0c7af36530e9fd4d7778ad0b10b0e95fde5d3c9a636ea86445ca06464')
    for path,expected_sha in [('historical/P0A3H_P1_P0_STATIC_FEASIBILITY_REPORT.md','50158e256f78748ba3fde6467c461869adbf5093830e008de8116a646c84789f'),('historical/P0A3H_P1_P0_STATIC_FEASIBILITY_FINDINGS.json','e46b172389d8ef4fc9975daa75a562ff4e60a1050487bd18fe5b4b5125f55179')]:
        ck('HISTORY.original_report:'+path,digest(z.read(path))==expected_sha)
    ck('HISTORY.L1_C0_exact',digest(z.read('historical/original_L1-C0.zip'))=='774e58c72921bdf97cf14cd9628278c4bab1c327086e9297879c8a46b4117e3a')
    with zipfile.ZipFile(io.BytesIO(z.read('historical/original_L1-C0.zip'))) as l1:
        ck('HISTORY.L1_C0_zip_crc',l1.testzip() is None)
    refbytes=z.read('historical/original_R2-C1-REV1.zip')
    ck('SOURCE.original_R2_sha256',digest(refbytes)=='b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1')
    with zipfile.ZipFile(io.BytesIO(refbytes)) as rz:
        rnames=check_archive(rz,'R2')
        ck('R2.member_count',len(rnames)==85)
        lock=z.read('source/SOURCE_LOCK.json')
        ck('SOURCE.original_lock_sha256',digest(lock)=='abff7aa8df19f73e070d9f06ebd23334f8d98b45c1736d38399b845c69835902')
        ck('SOURCE.original_lock_equal_nested',lock==rz.read('lock/SOURCE_LOCK.json'))
        file_manifest=json.loads(lock)['files']
        ledger=json.loads(z.read('source/SOURCE_51_FILE_LOCK_LEDGER.json'))
        ck('SOURCE.file_count',len(file_manifest)==51)
        ck('SOURCE.ledger_count',len(ledger)==51)
        ck('SOURCE.ledger_paths_exact',set(x['path'] for x in ledger)==set(file_manifest))
        ck('SOURCE.R2_candidate_exact_paths',set('candidate/'+p for p in file_manifest)==set(n for n in rnames if n.startswith('candidate/')))
        for path,v in file_manifest.items():
            b=rz.read('candidate/'+path)
            ck('SOURCE.hash:'+path,digest(b)==v['sha256'])
            ck('SOURCE.length:'+path,len(b)==v['bytes'])
        for row in ledger:
            p=row['path'];ref=file_manifest[p]
            ck('SOURCE.ledger_identity:'+p,row['sha256']==ref['sha256'] and row['bytes']==ref['bytes'])
            ck('SOURCE.ledger_G_identical_claim:'+p,row['g_cfinal_byte_identical'] is True)
        kernels={
         'src/meru_geometry/v0_9/qo2d_exact/algebra.py':'442065847937252db00d3f63b02184c15d57989f958f764c5c731cb385de6d2d',
         'src/meru_geometry/v0_9/qo2d_exact/core.py':'37701d034d98725673240a881420892893906c70387f68432b5993f8557dd420',
         'reference/v0_9/qo2d_exact/arithmetic.py':'72b3c37f02be65b2df7616a94e84601d66cf4af5b7a50e878724de647e5bf0ba'}
        for p,h in kernels.items():ck('SOURCE.protected_kernel:'+p,digest(rz.read('candidate/'+p))==h and auth['three_protected_kernels'][p]==h)
        ck('SOURCE.original_resource_policy',z.read('source/ORIGINAL_RESOURCE_POLICY.json')==rz.read('candidate/schemas/v0_9/p0a3g/resource_policy.json'))
        ck('SOURCE.original_request',z.read('source/ORIGINAL_R2_H01_REQUEST.json')==rz.read('r2_external/fixtures/R2_H01.request.json'))
    host=json.loads(z.read('operator/LOCAL_HOST_AND_DEPENDENCY_REGISTER.json'))
    ck('HOST.python_identity_recorded',host['python']['path']=='/usr/bin/python3.11' and host['python']['sha256']=='9bee109da0dce17a7c9eeaca9f420cc6770a9fe143b9382d73bd22fe59b21a5f' and not host['python']['symlink'])
    ck('HOST.openssl_identity_recorded',host['openssl']['path']=='/usr/bin/openssl' and host['openssl']['sha256']=='66521161cfad981e189bbc746560e0cc71a141b3765b3fe3658704d877c6ad7d' and not host['openssl']['symlink'])
    ck('HOST.python_version_recorded',host['python_version'].startswith('3.11.2 '))
    ck('HOST.openssl_version_recorded',host['openssl_version_full'].startswith('OpenSSL 3.0.22 '))
    ck('HOST.stdlib_root_recorded',host['python_sysconfig_stdlib']=='/usr/lib/python3.11')
    expected_std={'decimal.py','fractions.py','hashlib.py','json/__init__.py','json/decoder.py','json/encoder.py','json/scanner.py','pathlib.py','selectors.py','subprocess.py','tempfile.py'}
    ck('HOST.stdlib_11_files',set(host['python_stdlib_11'])==expected_std)
    for p,v in host['python_stdlib_11'].items():
        ck('HOST.stdlib_syntax:'+p,v['path']=='/usr/lib/python3.11/'+p and len(v['sha256'])==64 and isinstance(v['bytes'],int) and v['bytes']>0)
    ck('HOST.ldd_coverage',len(host['ldd_and_shared_libraries']['openssl']['resolved_absolute_paths'])>=3 and len(host['ldd_and_shared_libraries']['python3.11']['resolved_absolute_paths'])>=3)
    chronology=json.loads(z.read('operator/NO_EXECUTION_ATTESTATION_AND_CHRONOLOGY.json'))
    ck('CHRONOLOGY.no_execution_attestation',chronology['human_attestation']=='NO_P1_CANDIDATE_EXECUTION_YET')
    ck('CHRONOLOGY.no_C1',chronology['p1_c1']=='NOT_BUILT')
    ck('CHRONOLOGY.no_release',chronology['p1_dev_01']=='NOT_AUTHORIZED')
    ck('CHRONOLOGY.source_of_claim',chronology['basis'].startswith('human operator --affirm-no-p1-execution CLI'))

failed=[x for x in checks if not x['ok']]
result={'schema':'P0A3H-P1-C0-static-independent-QC-1','original_zip':FILE.name,'outer_sha256':digest(raw),'outer_bytes':len(raw),'assertions_total':len(checks),'assertions_pass':len(checks)-len(failed),'assertions_fail':len(failed),'failed_assertions':failed,'github_first_parent_links_separately_checked':17,'github_first_parent_links_status':'17/17 one-commit comparisons matched','scope_exclusions':['No P1-C1 or candidate derivative was built in the supplied package','No P01–P06 experimental executions were performed as part of this QC','Host binary and stdlib hashes are operator-observed file identities, not remotely remeasured bytes','No independent monitor of no-execution chronology','No actual Git signature ownertrust check performed by this verifier','Comparison of 51 source files to G-CFINAL is carried as operator ledger claim; this verifier checked them directly against original R2 and original SOURCE_LOCK'],'disposition':'P0A3H_P1_C0_INDEPENDENT_BYTE_AND_SOURCE_QC_PASS' if not failed else 'P0A3H_P1_C0_INDEPENDENT_QC_INCOMPLETE'}
(ROOT/'P0A3H_P1_C0_INDEPENDENT_QC_RESULTS_2026-10-21.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2));
if failed: raise SystemExit(1)
