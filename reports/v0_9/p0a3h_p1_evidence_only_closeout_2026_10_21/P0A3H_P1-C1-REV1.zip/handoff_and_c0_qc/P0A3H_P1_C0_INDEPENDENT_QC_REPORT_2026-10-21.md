# P0A3H-P1 — Independent P1-C0 Archive and Source-Integrity QC

**Review date:** 2026-10-21. **Type:** independent, static file/record verification; no candidate code, signature tests, workers, observers or P01–P06 invoked.

**Disposition:** `P0A3H_P1_C0_INDEPENDENT_BYTE_AND_SOURCE_QC_PASS` — **C0 only**.

## Original submitted evidence

- `P0A3H_P1-C0.zip`: **348,416 bytes**; **SHA-256** `067efd1e0fb66bc7bf5c61df186d43558ef2a81f223ca90912f67bca23439f5e`.
- Original external `P0A3H_P1-C0_RECEIPT.json` and `P0A3H_P1-C0_LOCAL_READBACK.json` agree with ZIP SHA-256/size/member count. The latter explicitly qualifies its readback as a same-host copy; separate uploaded original ZIP bytes were read by the reviewer.
- ZIP: **20** safe, unique, regular members; CRC PASS; **19** non-self SHA256SUMS rows and **18** PACKAGE_INVENTORY payload rows, all matching exact bytes/sizes/hashes.
- Standalone read-only reviewer verifier: **346 / 346** deterministic assertions passed, **0** failures. The number counts file and ledger comparisons, **not** scientific trials.

## Authority and lineage

- Human-signed P1 foundational commit `4c1634e6660a02ebdea62195f13fc4810fd08d41`, Git blob `557e778363c068b893855928f973dd3e9071597e`.
- Human-signed P1-A1 amendment `82dc0d2b2f2b81f90ec60dfed8e3aade19555d40`, direct parent P1; Git blob `a3a27a4f9379f8aacae085938eca39e5bb5b215f`.
- The original P1 and A1 text copied into C0 matches its expected content SHA-256 (`adac839f73b1039a2400da2fa20990cdb420489ccc77e89755ef1f4fdea3c7aa` and `6c2c3bd0c7af36530e9fd4d7778ad0b10b0e95fde5d3c9a636ea86445ca06464`, respectively).
- The literal **18-commit** P1-to-P0A3D ordered ancestry is present. All **17 adjacent GitHub comparisons** independently yielded one-commit-ahead/zero-behind, consistent with an unbroken first-parent chain. Remote branch equals A1 commit at review time.
- GitHub source identities and user-provided GPG verification output are distinct from an independently witnessed local GPG ownertrust evaluation; none is claimed by this QC.

## Frozen data and historical findings

- Original nested R2-C1-REV1 ZIP: **197,250 bytes**, SHA-256 `b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1`; 85 member CRC PASS.
- Original `lock/SOURCE_LOCK.json`: SHA-256 `abff7aa8df19f73e070d9f06ebd23334f8d98b45c1736d38399b845c69835902`; exact copy in nested source ZIP.
- Exactly **51 original candidate files**: all 51 original path/hash/length entries verified directly from nested R2 ZIP. The 51-file external ledger reproduces these identities. Its G-CFINAL equal-byte statements were not separately recomputed from an original G-CFINAL ZIP within this C0 package; that distinct comparison remains a historical preserved assertion.
- All three mathematical kernel hashes match: `algebra.py` `442065847937252db00d3f63b02184c15d57989f958f764c5c731cb385de6d2d`; `core.py` `37701d034d98725673240a881420892893906c70387f68432b5993f8557dd420`; reference `arithmetic.py` `72b3c37f02be65b2df7616a94e84601d66cf4af5b7a50e878724de647e5bf0ba`.
- Previous L1-C0 ZIP: SHA-256 `774e58c72921bdf97cf14cd9628278c4bab1c327086e9297879c8a46b4117e3a`, internally valid.
- Original Claude P1 static feasibility report and findings: SHA-256 `50158e256f78748ba3fde6467c461869adbf5093830e008de8116a646c84789f` and `e46b172389d8ef4fc9975daa75a562ff4e60a1050487bd18fe5b4b5125f55179`, preserved unchanged. The pre-execution `P0A3H_P1_SCOPE_AMENDMENT_REQUIRED` discovery remains historical and A1 prospectively expands exactly one permitted file.

## Local operating environment (operator-measured, recorded)

Debian 12/x86_64, CPython **3.11.2** `/usr/bin/python3.11`, binary SHA-256 `9bee109da0dce17a7c9eeaca9f420cc6770a9fe143b9382d73bd22fe59b21a5f`; OpenSSL **3.0.22** `/usr/bin/openssl`, binary SHA-256 `66521161cfad981e189bbc746560e0cc71a141b3765b3fe3658704d877c6ad7d`. Reported actual `sysconfig` standard-library root `/usr/lib/python3.11` and all eleven enumerated dependency file names with claimed byte sizes/digests. Report contains shared-library/ELF dependency observations, process capabilities and current resource limits.

**Observation limitations:** These host hashes and local no-test assertions come from the human operator's supplied archive. They have not been independently measured on the live user machine. Current unrestricted RLIMIT_AS/CPU/FSIZE is not evidence that the prospective launcher can enforce frozen bounds. Actual worker memory, OpenSSL CLI semantics, runtime and six-case verdicts remain untested.

## Binding limitations and next step

- `P0A3H_P1-C1`: **NOT BUILT**, `P0A3H_P1_DEV_01`: **NOT AUTHORIZED**, `P0A4`: **NOT AUTHORIZED**.
- The original signed P1 + A1 jointly permit construction of an **outside-repository** new derivative from the exact 51 source files, with changes restricted to `schemas/v0_9/p0a3g/resource_policy.json`, `src/meru_geometry/v0_9/qo2d_exact/identity.py` and `reference/v0_9/qo2d_exact/identity.py`; all kernels byte-identical. This QC grants **no execution**.
- C1 shall contain the complete reference and derivative, all external implementation/fixtures and fixed P01–P06 expected results, new P1-specific authority validation schema, exact host pins, operator/source authorship, original C0 receipt, intended C2 receipt/release inclusion plan and independent verifier source.
- C1 must be durably saved, freshly read back, externally independently reviewed and then separately **human released by exact original C1 SHA-256** before **one** P1 DEV attempt. No candidate import, tests, signature trials, dry runs, numerical previews or hidden prelock probes during preparation. Missing or additional necessary in-candidate modifications require fail-closed A2, not an unregistered repair.
- Passing C0 is a *byte/source-integrity and preflight-record qualification only*: no portable candidate QC PASS, full loaded-code attestation, production authority, R2 retrospective cure, H01–H07 permission, or P0A4 authority.
