"""P0A3H-P1 single-case runner (P02..P06). Launched ONLY by P1_DRIVER.py, ONLY after an exact
human-relayed SHA-specific release of the witnessed P1-C1, once per case, never retried.

usage (driver only):
  /usr/bin/python3.11 -I -S -B p1_case_runner.py <case_id> <candidate_root> <new_case_dir> <private_key_dir> <p1_external_dir> <attempt_id>

This process imports the unmodified 51-file P1 DERIVATIVE candidate through its public functions
(supervisor.run, supervisor.Authority, identity.authority/verify, reference identity.verify). It does
not patch, monkeypatch or replace candidate logic. It RECORDS raw outcomes only; the separate
p1_verifier.py (which imports nothing from the candidate) decides PASS/FAIL from the saved files.
Negative controls are confined to owned synthetic authority records built here; no production key,
no deployment trust root, no third-party target.
"""
import hashlib, json, os, sys, time, traceback
from pathlib import Path

CASE, CAND, OUT, KEYDIR, EXT, AID = sys.argv[1], Path(sys.argv[2]).resolve(), Path(sys.argv[3]), Path(sys.argv[4]), Path(sys.argv[5]).resolve(), sys.argv[6]
if CASE not in ('P02', 'P03', 'P04', 'P05', 'P06'):
    raise SystemExit('UNKNOWN_CASE')
HOST = json.loads((EXT / 'locks/P1_HOST_PINS.json').read_bytes())
PROV = json.loads((EXT / 'locks/FIXTURE_AND_COMPARATOR_PROVENANCE.json').read_bytes())
OUT.mkdir(exist_ok=False)
RUN = OUT / 'raw_workers'
RUN.mkdir()
AUTH_DIR = OUT / 'authority_public'
AUTH_DIR.mkdir()
sys.path[:0] = [str(CAND / 'src'), str(CAND)]
from meru_geometry.v0_9.qo2d_exact import supervisor, identity            # noqa: E402
from reference.v0_9.qo2d_exact import identity as refid                   # noqa: E402
sys.path.insert(0, str(EXT))
import p1_authority as pa                                                 # noqa: E402

ROOT_STDLIB = HOST['stdlib_root']
OPENSSL = HOST['openssl']['path']
RESULT = {'schema': 'p0a3h-p1-case-result-1', 'case': CASE, 'attempt_id': AID, 'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
          'runner': {'sys_version': sys.version, 'executable': sys.executable, 'pid': os.getpid(), 'ppid': os.getppid(),
                     'flags': {'isolated': sys.flags.isolated, 'no_site': sys.flags.no_site, 'dont_write_bytecode': sys.dont_write_bytecode},
                     'proc_self_exe': os.readlink('/proc/self/exe') if os.path.exists('/proc/self/exe') else None},
          'observations': {}}
KEYS = {}


def h(b):
    return hashlib.sha256(b).hexdigest()


def enc(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False, default=repr).encode()


def save():
    (OUT / 'CASE_RESULT.json').write_bytes(enc(RESULT))


def fixture(name):
    fn = name + '.request.json'
    b = (EXT / 'fixtures' / fn).read_bytes()
    if h(b) != PROV['fixtures'][fn]['sha256']:
        raise RuntimeError('FIXTURE_HASH_MISMATCH ' + fn)
    return b


def key_a():
    if 'A' not in KEYS:
        KEYS['A'] = pa.TestKey(OPENSSL, KEYDIR, 'p1-test-key-A')
        KEYS['store'] = pa.trust_store([KEYS['A'].public_record()])
        (AUTH_DIR / 'trust_store.json').write_bytes(KEYS['store'])
        (AUTH_DIR / 'NON_PRODUCTION_TEST_PUBLIC_KEY.json').write_bytes(enc({
            'label': 'NON_PRODUCTION_TEST_AUTHORITY', 'generated_by': 'openssl genpkey -algorithm ed25519 (P1 case runner, after release)',
            'public_record': KEYS['A'].public_record(), 'trust_store_sha256': h(KEYS['store'])}))
    return KEYS['A'], KEYS['store']


def keep(label, **blobs):
    d = AUTH_DIR / label
    d.mkdir()
    for k, v in blobs.items():
        if v is not None:
            (d / k).write_bytes(v)
    return {k: (None if v is None else {'bytes': len(v), 'sha256': h(v)}) for k, v in blobs.items()}


def bundle(raw, run_id, pins=None):
    ka, store = key_a()
    env = pa.envelope(CAND, raw, run_id, ROOT_STDLIB, pins=pins)
    sig = ka.sign(env)
    rec = pa.receipt(env, run_id, 'TEST_AUTHORITY', sig, store)
    return env, rec, sig, store


def auth(env, rec, sig, trust, mode='TEST_AUTHORITY'):
    return supervisor.Authority(env, rec, sig, trust, mode, AID)


def call(fn):
    try:
        v = fn()
        return {'raised': False, 'value': v}
    except BaseException as e:
        c = e.__cause__
        return {'raised': True, 'type': type(e).__name__, 'state': getattr(e, 'state', None), 'reason': getattr(e, 'reason', None),
                'message': str(e), 'cause_type': type(c).__name__ if c is not None else None, 'cause': str(c) if c is not None else None}


def full_run(name, run_rel, **options):
    raw = fixture(name)
    env, rec, sig, trust = bundle(raw, run_rel)
    ids = keep(run_rel, envelope=env, receipt=rec, signature=sig, trust=trust)
    t0 = time.monotonic_ns()
    out = supervisor.run(raw, auth(env, rec, sig, trust), RUN / run_rel, **options)
    return {'fixture': name, 'run_dir': run_rel, 'options': options, 'submitted': ids, 'elapsed_ns': time.monotonic_ns() - t0,
            'run_dir_created': (RUN / run_rel).exists(), 'result': out}


def p02():
    o = full_run('R2_H01', 'P02_R2_H01')
    o['candidate_environment_equals_builder_environment'] = identity.environment() == pa.environment(ROOT_STDLIB)
    o['builder_environment'] = pa.environment(ROOT_STDLIB)
    return o


def p03():
    raw = fixture('R2_H01')
    ka, store = key_a()
    env = pa.envelope(CAND, raw, 'P03_VALID', ROOT_STDLIB)
    sig = ka.sign(env)
    rec = pa.receipt(env, 'P03_VALID', 'TEST_AUTHORITY', sig, store)
    obs = {'valid': {'ids': keep('P03_VALID', envelope=env, receipt=rec, signature=sig, trust=store),
                     'production_route': call(lambda: identity.verify(env, h(raw), rec, sig, store, mode='TEST_AUTHORITY')),
                     'reference_route': call(lambda: refid.verify(env, raw, rec, sig, store, mode='TEST_AUTHORITY'))}}
    negatives = {}
    t1 = pa.trust_store([ka.public_record(scope='PRODUCTION_CODE_AUTHORITY')])
    r1 = pa.receipt(env, 'P03_VALID', 'TEST_AUTHORITY', sig, t1)
    negatives['N1_WRONG_SCOPE'] = (env, r1, sig, t1)
    t2 = pa.trust_store([ka.public_record(revoked=True)])
    r2 = pa.receipt(env, 'P03_VALID', 'TEST_AUTHORITY', sig, t2)
    negatives['N2_REVOKED'] = (env, r2, sig, t2)
    e3 = pa.envelope(CAND, raw, 'P03_OLD_LINEAGE', ROOT_STDLIB, pins=pa.OLD_P0A3G_PINS)
    s3 = ka.sign(e3)
    r3 = pa.receipt(e3, 'P03_OLD_LINEAGE', 'TEST_AUTHORITY', s3, store)
    negatives['N3_OLD_P0A3G_LINEAGE'] = (e3, r3, s3, store)
    m4 = json.loads(env)
    last = m4['input_sha256'][-1]
    m4['input_sha256'] = m4['input_sha256'][:-1] + ('0' if last != '0' else '1')
    e4 = pa.enc(m4)
    r4 = pa.receipt(e4, 'P03_VALID', 'TEST_AUTHORITY', sig, store)
    negatives['N4_TAMPERED_ENVELOPE_ORIGINAL_SIGNATURE'] = (e4, r4, sig, store)
    for label, (e, r, s, t) in negatives.items():
        obs[label] = {'ids': keep(label, envelope=e, receipt=r, signature=s, trust=t),
                      'production_route': call(lambda: identity.verify(e, h(raw), r, s, t, mode='TEST_AUTHORITY')),
                      'reference_route': call(lambda: refid.verify(e, raw, r, s, t, mode='TEST_AUTHORITY'))}
    obs['N4_TAMPERED_ENVELOPE_ORIGINAL_SIGNATURE']['byte_diff_count'] = sum(1 for a, b in zip(env, e4) if a != b) if len(env) == len(e4) else None
    e3run = supervisor.run(raw, auth(e3, r3, s3, store), RUN / 'P03_OLD_LINEAGE_RUN')
    obs['N3_end_to_end_controller'] = {'result': e3run, 'run_dir_created': (RUN / 'P03_OLD_LINEAGE_RUN').exists()}
    return obs


def p04():
    raw = fixture('R2_H01')
    env = pa.envelope(CAND, raw, 'P04_DEPLOYMENT', ROOT_STDLIB, authority_mode='HUMAN_SIGNED_CODE_FREEZE', key_id=None)
    rec = pa.receipt(env, 'P04_DEPLOYMENT', 'DEPLOYMENT', None, None)
    obs = {'ids': keep('P04_DEPLOYMENT', envelope=env, receipt=rec),
           'production_authority_gate': call(lambda: identity.authority(env, rec, None, None, mode='DEPLOYMENT')),
           'production_verify': call(lambda: identity.verify(env, h(raw), rec, None, None, mode='DEPLOYMENT')),
           'reference_verify': call(lambda: refid.verify(env, raw, rec, None, None, mode='DEPLOYMENT'))}
    out = supervisor.run(raw, auth(env, rec, None, None, mode='DEPLOYMENT'), RUN / 'P04_DEPLOYMENT_RUN')
    obs['controller_run'] = {'result': out, 'run_dir_created': (RUN / 'P04_DEPLOYMENT_RUN').exists()}
    return obs


def p05():
    return {name: full_run(name, 'P05_' + name) for name in ('R2_H02', 'R2_H03', 'R2_H04')}


def p06():
    return {'P06A_OVER_LIMIT': full_run('P06A_OVER_LIMIT', 'P06A_OVER_LIMIT'),
            'P06B_WALL_TIMEOUT': full_run('R2_H01', 'P06B_WALL_TIMEOUT', dev_fault='timeout')}


try:
    RESULT['observations'] = {'P02': p02, 'P03': p03, 'P04': p04, 'P05': p05, 'P06': p06}[CASE]()
    RESULT['runner_exception'] = None
except BaseException:
    RESULT['runner_exception'] = traceback.format_exc()
finally:
    if 'A' in KEYS:
        KEYS['A'].destroy()
    RESULT['private_key_files_left'] = sorted(p.name for p in KEYDIR.iterdir() if p.suffix == '.pem') if KEYDIR.exists() else []
    RESULT['finished_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    save()
print(json.dumps({'case': CASE, 'runner_exception': RESULT['runner_exception'] is not None}))
sys.exit(1 if RESULT['runner_exception'] else 0)
