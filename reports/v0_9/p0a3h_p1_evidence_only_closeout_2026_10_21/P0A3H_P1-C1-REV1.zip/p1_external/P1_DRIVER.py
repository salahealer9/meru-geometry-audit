"""P0A3H-P1 single-attempt driver for P0A3H_P1_DEV_01 (locked in P1-C1-REV1; NOT run before witness and release).

REV1 (2026-10-21) addresses independent witness findings on the original P1-C1 (0ab25577…13d4):
  W01  whole-attempt disk <= 16 MiB is enforced and evidenced by the driver (see DISK below);
  W02  the separately issued human release certificate, the original C0 receipt and the C1-REV1
       receipt are consumed, checked, copied byte-identically into the attempt and receipted
       BEFORE any candidate invocation (text match only; human origin is NOT authenticated here);
  W03  the external P1 envelope schema is applied by p1_verifier as a supplementary check.

usage (exactly once, on the operator host, only after the human-relayed release
 'P0A3H-P1-C1 LOCK WITNESSED; SHA-256 <full digest>; AUTHORIZE ONE P0A3H_P1_DEV_01'):
  /usr/bin/python3.11 -I -S -B <extracted C1-REV1>/p1_external/P1_DRIVER.py \
      --release-sha <64-hex digest quoted in the release> \
      --c1 <path to the original P0A3H_P1-C1-REV1.zip, freshly retrieved> \
      --release-certificate <file holding the original human release text, as received> \
      --c0-receipt <original P0A3H_P1-C0_RECEIPT.json> \
      --c1-receipt <original P0A3H_P1-C1-REV1_RECEIPT.json> \
      --work <NEW directory that does not yet exist>

Fixed order: free-space gate -> release consumption (no candidate) -> verify C1 bytes -> extract -> locks
-> disk check -> HOST_GATE (no candidate) -> P01 (no candidate) -> P02..P06 (each once, monitored) ->
final disk check -> summary -> manifest. Fail-closed: the first non-PASS verdict ends the attempt.
Exit: 0 all passed; 1 failed (evidence preserved); 3 quarantine; 2 stopped before any candidate launch.

DISK (W01): the 'whole attempt' is the entire --work directory: extracted C1 trees, upstream receipts,
journals, every case directory, raw worker evidence, controller key directories and the runner TMPDIR.
CAP = 16,777,216 bytes, applied to BOTH the apparent size (sum st_size) and the allocated size
(sum st_blocks*512) of all entries (lstat, symlinks not followed). The driver samples the whole tree
every 0.2 s while each runner/reconciler process tree is alive and between all stages; if a sample exceeds
CAP it SIGKILLs the whole runner process tree (descendants found through /proc before killing) and the
attempt fails. Each runner also has RLIMIT_FSIZE = CAP (no single file can exceed the whole cap); the
unchanged candidate additionally limits workers (2 MiB per file, 16 MiB per run directory). Before any
work the --work filesystem must have >= 2*CAP free. A sampling error is ENVIRONMENT_UNQUALIFIED.
Residual (declared): exceedance between two 0.2 s samples cannot be prevented by polling; it is always
detected at the next sample and fails the attempt. Transient OpenSSL signature temp files created by
candidate WORKERS under the system temp directory (their environment is fixed by the frozen supervisor)
are outside --work; they are counted before/after each case (p0a3g_sig_* residue) and recorded.
"""
import hashlib, io, json, os, resource, signal, subprocess, sys, time, zipfile

PY = '/usr/bin/python3.11'
AID = 'P0A3H_P1_DEV_01'
CAP = 16777216
CASES = ['P02', 'P03', 'P04', 'P05', 'P06']
CASE_WALL = {'P02': 300, 'P03': 180, 'P04': 180, 'P05': 600, 'P06': 300}
RUNNER_LIMITS = {'RLIMIT_AS': 1073741824, 'RLIMIT_CPU': 900, 'RLIMIT_NOFILE': 256, 'RLIMIT_CORE': 0, 'RLIMIT_FSIZE': CAP}
C0_RECEIPT_SHA256 = '469c1cc5d16555e5b8e56e906b4bd5a0dfc147a68c147d8eef932bacdc14bdd3'
RELEASE_FMT = 'P0A3H-P1-C1 LOCK WITNESSED; SHA-256 %s; AUTHORIZE ONE P0A3H_P1_DEV_01'


def sha(b):
    return hashlib.sha256(b).hexdigest()


def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


a = sys.argv[1:]
A = {a[i].lstrip('-'): a[i + 1] for i in range(0, len(a) - 1, 2)}
for k in ('release-sha', 'c1', 'release-certificate', 'c0-receipt', 'c1-receipt', 'work'):
    if k not in A:
        raise SystemExit('MISSING_ARGUMENT ' + k)
REL = A['release-sha'].lower()
WORK = os.path.abspath(A['work'])
parent = os.path.dirname(WORK)
st = os.statvfs(parent)
if st.f_bavail * st.f_frsize < 2 * CAP:
    raise SystemExit('ENVIRONMENT_UNQUALIFIED: less than 2*CAP free on the work filesystem')
os.makedirs(WORK, exist_ok=False)
JOURNAL = []
DISK = {'cap_bytes': CAP, 'measure': 'whole --work tree; lstat; apparent=sum st_size, allocated=sum st_blocks*512; both must stay <= cap',
        'free_bytes_before': st.f_bavail * st.f_frsize, 'stages': [], 'samples_1hz': [], 'exceeded': False, 'sampling_errors': 0}


def log(event, **kw):
    JOURNAL.append({'utc': utc(), 'event': event, **kw})
    with open(os.path.join(WORK, 'P1_DEV_JOURNAL.json'), 'w') as f:
        json.dump(JOURNAL, f, indent=1, sort_keys=True, default=str)


def write_json(name, obj):
    with open(os.path.join(WORK, name), 'w') as f:
        json.dump(obj, f, indent=1, sort_keys=True, default=str)


def measure():
    app = alloc = n = 0
    for base, ds, fs in os.walk(WORK):
        for x in ds + fs:
            s = os.lstat(os.path.join(base, x))
            app += s.st_size
            alloc += s.st_blocks * 512
            n += 1
    return app, alloc, n


LAST_1HZ = [0.0]


def sample(stage):
    try:
        app, alloc, n = measure()
    except OSError:
        DISK['sampling_errors'] += 1
        return None
    now = time.monotonic()
    if now - LAST_1HZ[0] >= 1.0:
        DISK['samples_1hz'].append([utc(), stage, app, alloc, n])
        LAST_1HZ[0] = now
    if app > CAP or alloc > CAP:
        DISK['exceeded'] = True
    return app, alloc, n


def stage_check(stage):
    s = sample(stage)
    rec = {'stage': stage, 'utc': utc(), 'apparent': None if s is None else s[0], 'allocated': None if s is None else s[1],
           'entries': None if s is None else s[2], 'within_cap': s is not None and s[0] <= CAP and s[1] <= CAP}
    DISK['stages'].append(rec)
    write_json('P1_DISK_LEDGER.json', DISK)
    return rec['within_cap']


def sig_residue():
    out = {}
    for d in ('/tmp', os.path.join(WORK, 'tmp')):
        try:
            out[d] = sorted(n for n in os.listdir(d) if n.startswith('p0a3g_sig_'))
        except OSError:
            out[d] = None
    return out


def manifest():
    files = []
    for base, ds, fs in os.walk(WORK):
        ds.sort()
        for fn in sorted(fs):
            p = os.path.join(base, fn)
            rel = os.path.relpath(p, WORK).replace(os.sep, '/')
            if rel == 'P1_ATTEMPT_FILE_MANIFEST.json' or os.path.islink(p) or not os.path.isfile(p):
                continue
            with open(p, 'rb') as f:
                b = f.read()
            files.append({'path': rel, 'bytes': len(b), 'sha256': sha(b)})
    write_json('P1_ATTEMPT_FILE_MANIFEST.json', {'schema': 'p0a3h-p1-attempt-manifest-1', 'attempt': AID, 'files': files})


def finish(status, code, **kw):
    final_ok = stage_check('final')
    if not final_ok and code == 0:
        status, code = 'P0A3H_P1_DEV_01_FAILED_EVIDENCE_PRESERVED', 1
        kw['final_disk_failure'] = 'WHOLE_ATTEMPT_DISK_CAP_EXCEEDED_OR_UNMEASURED'
    write_json('P1_ATTEMPT_SUMMARY.json', {'attempt': AID, 'status': status, 'release_sha': REL, 'whole_attempt_disk_within_cap': final_ok,
                                           'disk_cap_bytes': CAP, **kw})
    log('END', status=status)
    manifest()
    print(json.dumps({'status': status}))
    sys.exit(code)


# 1. W02: consume the separately issued human release BEFORE anything else (no candidate) ----------
c1 = open(A['c1'], 'rb').read()
cert = open(A['release-certificate'], 'rb').read()
r0 = open(A['c0-receipt'], 'rb').read()
r1 = open(A['c1-receipt'], 'rb').read()
up = os.path.join(WORK, 'upstream')
os.makedirs(up)
for name, data in (('HUMAN_RELEASE_CERTIFICATE.txt', cert), ('P0A3H_P1-C0_RECEIPT.json', r0), ('P0A3H_P1-C1-REV1_RECEIPT.json', r1)):
    with open(os.path.join(up, name), 'xb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
rel_checks = {
    'c1_bytes_equal_released_sha': sha(c1) == REL,
    'release_certificate_contains_exact_sentence_for_this_c1': (RELEASE_FMT % REL) in cert.decode('utf-8', 'replace'),
    'c0_receipt_is_original': sha(r0) == C0_RECEIPT_SHA256,
    'c1_receipt_names_released_c1': REL in r1.decode('utf-8', 'replace'),
    'copies_byte_identical': all(open(os.path.join(up, n), 'rb').read() == d for n, d in
                                 (('HUMAN_RELEASE_CERTIFICATE.txt', cert), ('P0A3H_P1-C0_RECEIPT.json', r0), ('P0A3H_P1-C1-REV1_RECEIPT.json', r1)))}
write_json('PRELAUNCH_RELEASE_RECEIPT.json', {
    'schema': 'p0a3h-p1-prelaunch-release-receipt-1', 'consumed_utc': utc(), 'attempt': AID, 'released_c1_sha256': REL,
    'c1_observed': {'bytes': len(c1), 'sha256': sha(c1), 'path': os.path.abspath(A['c1'])},
    'release_certificate': {'bytes': len(cert), 'sha256': sha(cert), 'source_path': os.path.abspath(A['release-certificate']),
                            'source_mtime_utc_informational': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(os.stat(A['release-certificate']).st_mtime)),
                            'archived_as': 'upstream/HUMAN_RELEASE_CERTIFICATE.txt'},
    'c0_receipt': {'bytes': len(r0), 'sha256': sha(r0), 'archived_as': 'upstream/P0A3H_P1-C0_RECEIPT.json'},
    'c1_receipt': {'bytes': len(r1), 'sha256': sha(r1), 'archived_as': 'upstream/P0A3H_P1-C1-REV1_RECEIPT.json'},
    'checks': rel_checks, 'candidate_invocations_before_this_receipt': 0,
    'limitation': 'Text and digest match only. Human origin of the release is NOT authenticated by this driver; it remains a separate human-authority requirement witnessed outside this process.'})
log('HUMAN_RELEASE_CONSUMED', checks=rel_checks, certificate_sha256=sha(cert))
if not all(rel_checks.values()):
    finish('P0A3H_P1_PREDEV_LOCK_NOT_WITNESSED', 2, reason='release certificate / receipts / C1 bytes do not satisfy the prelaunch release checks',
           checks=rel_checks)

# 2. archive integrity, extraction and locks (no candidate) ------------------------------------------
z = zipfile.ZipFile(io.BytesIO(c1))
names = z.namelist()
if z.testzip() is not None or len(names) != len(set(names)) or any(n.startswith('/') or '..' in n.split('/') for n in names):
    finish('P0A3H_P1_STOP_AND_QUARANTINE', 2, reason='C1 CRC or unsafe/duplicate member names')
for line in z.read('SHA256SUMS').decode().splitlines():
    if line.strip():
        hh, n = line.split(None, 1)
        if n != 'SHA256SUMS' and sha(z.read(n)) != hh:
            finish('P0A3H_P1_STOP_AND_QUARANTINE', 2, reason='C1 SHA256SUMS mismatch ' + n)
MAP = {'derivative_candidate/': 'candidate/', 'reference_candidate/': 'reference_candidate/', 'p1_external/': 'p1_external/', 'lock/': 'lock/'}
for n in names:
    for pre, dest in MAP.items():
        if n.startswith(pre) and not n.endswith('/'):
            p = os.path.join(WORK, dest + n[len(pre):])
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, 'wb') as f:
                f.write(z.read(n))


def tree_hashes(root):
    out = {}
    for base, ds, fs in os.walk(root):
        for fn in fs:
            p = os.path.join(base, fn)
            with open(p, 'rb') as f:
                b = f.read()
            out[os.path.relpath(p, root).replace(os.sep, '/')] = {'bytes': len(b), 'sha256': sha(b)}
    return out


EXT_LOCK = json.loads(z.read('lock/P1_EXTERNAL_LOCK.json'))['files']
CAND_LOCK = json.loads(z.read('lock/P1_CANDIDATE_LOCK.json'))['derivative_files']


def locks_ok(label):
    e = tree_hashes(os.path.join(WORK, 'p1_external')) == EXT_LOCK
    c = tree_hashes(os.path.join(WORK, 'candidate')) == CAND_LOCK
    log('lock_check_' + label, external_ok=e, candidate_ok=c)
    return e and c


if not locks_ok('pre_run'):
    finish('P0A3H_P1_STOP_AND_QUARANTINE', 2, reason='extracted trees differ from the C1 locks')
TMP = os.path.join(WORK, 'tmp')
os.makedirs(TMP)
if not stage_check('after_extraction'):
    finish('ENVIRONMENT_UNQUALIFIED', 2, reason='whole-attempt disk cap exceeded or unmeasurable before any candidate launch')
sys.path.insert(0, os.path.join(WORK, 'p1_external'))
import p1_verifier as V                                                    # noqa: E402

# 3. HOST_GATE and P01 (no candidate launch) ---------------------------------------------------------
verdicts = {}
hg = V.host_gate(os.path.join(WORK, 'p1_external'))
write_json('HOST_GATE.json', hg)
log('HOST_GATE', verdict=hg['verdict'], failed=hg.get('failed_checks'))
if hg['verdict'] != 'PASS':
    finish('ENVIRONMENT_UNQUALIFIED', 2, host_gate=hg, per_case={c: 'NOT_RUN_ENVIRONMENT_UNQUALIFIED' for c in ['P01'] + CASES})
p01 = V.p01(WORK)
write_json('P01_RESULT.json', p01)
verdicts['P01'] = p01['verdict']
log('P01', verdict=p01['verdict'], failed=p01.get('failed_checks'), quarantine=p01.get('quarantine_triggers'))
if p01['verdict'] != 'PASS':
    per = {'P01': p01['verdict'], **{c: 'NOT_RUN_AFTER_' + ('QUARANTINE' if p01['verdict'] == 'QUARANTINE' else 'FAILURE') for c in CASES}}
    finish('P0A3H_P1_STOP_AND_QUARANTINE' if p01['verdict'] == 'QUARANTINE' else 'P0A3H_P1_DEV_01_FAILED_EVIDENCE_PRESERVED',
           3 if p01['verdict'] == 'QUARANTINE' else 1, per_case=per)
if not stage_check('before_first_candidate_invocation'):
    finish('ENVIRONMENT_UNQUALIFIED', 2, reason='whole-attempt disk cap exceeded or unmeasurable before any candidate launch')


# 4. P02..P06, each once, under whole-attempt disk monitoring -----------------------------------------
def runner_limits():
    for k, v in RUNNER_LIMITS.items():
        resource.setrlimit(getattr(resource, k), (v, v))


def descendants(root_pid):
    kids = {}
    for d in os.listdir('/proc'):
        if not d.isdigit():
            continue
        try:
            with open('/proc/%s/stat' % d) as f:
                ppid = int(f.read().rsplit(')', 1)[1].split()[1])
            kids.setdefault(ppid, []).append(int(d))
        except (OSError, ValueError, IndexError):
            continue
    out, todo = [], [root_pid]
    while todo:
        p = todo.pop()
        for c in kids.get(p, []):
            out.append(c)
            todo.append(c)
    return out


def kill_tree(pid):
    victims = [pid] + descendants(pid)
    for v in victims:
        try:
            os.kill(v, signal.SIGKILL)
        except ProcessLookupError:
            pass
    return victims


def run(label, cmd, wall):
    log(label + '_start', command=cmd, wall_seconds=wall)
    t0 = time.monotonic()
    peak = [0, 0]
    killed_for = None
    victims = []
    with open(os.path.join(WORK, label + '.stdout'), 'wb') as so, open(os.path.join(WORK, label + '.stderr'), 'wb') as se:
        p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=so, stderr=se, cwd=WORK, start_new_session=True, preexec_fn=runner_limits,
                             env={'PATH': os.defpath, 'LC_ALL': 'C.UTF-8', 'TMPDIR': TMP}, close_fds=True)
        while True:
            rc = p.poll()
            s = sample(label)
            if s is None:
                killed_for = 'DISK_SAMPLING_ERROR'
            else:
                peak[0], peak[1] = max(peak[0], s[0]), max(peak[1], s[1])
                if s[0] > CAP or s[1] > CAP:
                    killed_for = 'WHOLE_ATTEMPT_DISK_CAP_EXCEEDED'
            if rc is not None and killed_for is None:
                break
            if killed_for is None and time.monotonic() - t0 > wall:
                killed_for = 'DRIVER_WALL_TIMEOUT'
            if killed_for is not None:
                victims = kill_tree(p.pid)
                p.wait()
                rc = killed_for
                break
            time.sleep(0.2)
    DISK['stages'].append({'stage': label, 'utc': utc(), 'peak_apparent': peak[0], 'peak_allocated': peak[1], 'killed_for': killed_for,
                           'killed_pids': victims, 'within_cap': killed_for is None and peak[0] <= CAP and peak[1] <= CAP})
    write_json('P1_DISK_LEDGER.json', DISK)
    log(label + '_end', exit=rc, wall_seconds=round(time.monotonic() - t0, 3), pid=p.pid, peak_disk=peak, killed_for=killed_for)
    with open(os.path.join(WORK, label + '.exit'), 'w') as f:
        f.write(str(rc) + '\n')
    return rc, killed_for


def scrub(keydir):
    left = []
    for fn in sorted(os.listdir(keydir)):
        p = os.path.join(keydir, fn)
        if os.path.isfile(p) and not os.path.islink(p):
            n = os.path.getsize(p)
            left.append({'file': fn, 'bytes': n})
            with open(p, 'r+b') as f:
                f.write(b'\0' * n)
                f.flush()
                os.fsync(f.fileno())
            os.unlink(p)
    return left


os.makedirs(os.path.join(WORK, 'cases'))
status, code = 'P0A3H_P1_DEV_01_ALL_6_PASSED_PENDING_CHECKPOINTS', 0
for i, case in enumerate(CASES):
    cdir = os.path.join(WORK, 'cases', case)
    kdir = os.path.join(WORK, 'controller_keys_' + case)
    os.makedirs(kdir, mode=0o700)
    residue_before = sig_residue()
    if i == 0:
        log('FIRST_P1_CANDIDATE_INVOCATION', prelaunch_release_receipt_sha256=sha(open(os.path.join(WORK, 'PRELAUNCH_RELEASE_RECEIPT.json'), 'rb').read()))
    rc, kf = run('RUNNER_' + case, [PY, '-I', '-S', '-B', os.path.join(WORK, 'p1_external/p1_case_runner.py'), case,
                                    os.path.join(WORK, 'candidate'), cdir, kdir, os.path.join(WORK, 'p1_external'), AID], CASE_WALL[case])
    left = scrub(kdir)
    os.rmdir(kdir)
    rw = os.path.join(cdir, 'raw_workers')
    rkf = None
    if os.path.isdir(rw) and kf is None:
        _, rkf = run('RECONCILE_' + case, [PY, '-I', '-S', '-B', os.path.join(WORK, 'p1_external/r2_stream_reconcile.py'), rw, AID,
                                           os.path.join(cdir, 'EXTERNAL_RECONCILIATION')], 300)
    ev = V.evaluate(case, cdir, WORK) if os.path.isdir(cdir) else {'verdict': 'INCOMPLETE', 'reason': 'CASE_DIRECTORY_MISSING'}
    ev['runner_exit'] = rc
    ev['driver_scrubbed_key_files'] = left
    ev['sig_temp_residue'] = {'before': residue_before, 'after': sig_residue()}
    within = stage_check('after_' + case)
    for bad, flag in ((rc != 0, 'runner_exit_zero'), (bool(left), 'no_runner_left_key_files'),
                      (kf is not None or rkf is not None, 'no_driver_kill:' + str(kf or rkf)), (not within, 'whole_attempt_disk_within_cap')):
        if bad and ev['verdict'] == 'PASS':
            ev['verdict'] = 'FAIL'
        if bad:
            ev['failed_checks'] = ev.get('failed_checks', []) + [flag]
    if kf in ('DISK_SAMPLING_ERROR',) or rkf in ('DISK_SAMPLING_ERROR',):
        ev['verdict'] = 'ENVIRONMENT_UNQUALIFIED'
    if not locks_ok('after_' + case):
        ev['verdict'] = 'QUARANTINE'
        ev['quarantine_triggers'] = ev.get('quarantine_triggers', []) + ['SOURCE_OR_EXTERNAL_LOCK_CHANGED']
    with open(os.path.join(WORK, 'cases', case + '_VERDICT.json'), 'w') as f:
        json.dump(ev, f, indent=1, sort_keys=True, default=str)
    verdicts[case] = ev['verdict']
    log(case + '_VERDICT', verdict=ev['verdict'], failed=ev.get('failed_checks'), quarantine=ev.get('quarantine_triggers'))
    if ev['verdict'] != 'PASS':
        tag = 'QUARANTINE' if ev['verdict'] == 'QUARANTINE' else 'FAILURE'
        for later in CASES[i + 1:]:
            verdicts[later] = 'NOT_RUN_AFTER_' + tag
        if ev['verdict'] == 'ENVIRONMENT_UNQUALIFIED':
            status, code = 'ENVIRONMENT_UNQUALIFIED', 1
        else:
            status = 'P0A3H_P1_STOP_AND_QUARANTINE' if tag == 'QUARANTINE' else 'P0A3H_P1_DEV_01_FAILED_EVIDENCE_PRESERVED'
            code = 3 if tag == 'QUARANTINE' else 1
        break
finish(status, code, per_case=verdicts, host_gate='PASS', retry_or_repair_performed=False)
