"""P0A3G-R2 external raw-stream / event reconciler (independent; imports NOTHING from candidate/).

usage:
  python3 -I r2_stream_reconcile.py <tree_root> <expected_attempt_id> <out_prefix> [registry.json ...]

For every recorded worker event file ``w####.event.json`` under <tree_root> (any depth):
re-read the two stream files the record names, from disk, recompute byte length and SHA-256,
and compare with (a) the recorded length/digest and (b) the recorded capture witness.
Identity checks: record path is the worker's own ``<worker_id>.<stream>``, run directory name
equals ``run_dir_id``, ``attempt_id`` equals the expected attempt, no stream file referenced twice.
Leftover ``.pending_*`` files and unreferenced ``*.stdout``/``*.stderr`` files are reported.

Row status:
  MATCH                          bytes, digest, witness and identity all agree
  EVIDENCE_STREAM_MISMATCH       anything else; then classified by ``explanation``:
     DECLARED_INJECTED_FAULT     event declares a SIMULATED_EVIDENCE_FAULT that a registry lists for
                                 that run directory AND that fault is allowed to disturb that stream
     REGISTERED_HARNESS_FAULT    registry lists a harness fault for that run directory
     UNEXPLAINED                 otherwise (a replication failure)
Registry files (JSON {run_dir_relative_to_tree_root: [fault, ...]}) are the ones written by
the locked runners before/while injecting; they are inputs, never edited here.

Writes <out_prefix>.csv and <out_prefix>.json. Exit 0 iff no UNEXPLAINED row.
"""
import csv, hashlib, json, os, sys

FAULT_STREAMS = {
    'forge_stdout_108': {'stdout'}, 'zero_stdout_after_save': {'stdout'}, 'truncate_stdout': {'stdout'},
    'alter_stdout': {'stdout'}, 'delete_stdout': {'stdout'}, 'after_rename_tamper': {'stdout'},
    'short_write': {'stdout'}, 'before_rename': {'stdout'}, 'wrong_worker_path': {'stdout'},
    'truncate_stderr': {'stderr'}, 'alter_stderr': {'stderr'}, 'delete_stderr': {'stderr'},
    'duplicate_path': {'stderr'}, 'swap_streams': {'stdout', 'stderr'}, 'stale_run': {'stdout', 'stderr'},
    'path_collision': {'stdout', 'stderr'}, 'orphan_stream_file': set(),
}


def digest(b):
    return hashlib.sha256(b).hexdigest()


def read_file(p):
    if os.path.islink(p) or not os.path.isfile(p):
        return None
    with open(p, 'rb') as f:
        return f.read()


def load_registry(paths):
    reg = {}
    for p in paths:
        with open(p, 'rb') as f:
            d = json.loads(f.read())
        for k, v in d.items():
            reg.setdefault(k, set()).update(v)
    return reg


def reconcile(root, attempt_id, registry):
    rows, referenced = [], set()
    event_files = []
    for base, dirs, files in os.walk(root, followlinks=False):
        dirs.sort()
        for f in sorted(files):
            if f.startswith('w') and f.endswith('.event.json'):
                event_files.append(os.path.join(base, f))
    for ef in event_files:
        run_abs = os.path.dirname(ef)
        run_rel = os.path.relpath(run_abs, root).replace(os.sep, '/')
        try:
            ev = json.loads(read_file(ef))
        except Exception:
            rows.append({'run_dir': run_rel, 'event_file': os.path.basename(ef), 'stream': '-', 'status': 'EVIDENCE_STREAM_MISMATCH',
                         'problems': 'EVENT_UNREADABLE', 'explanation': 'UNEXPLAINED'})
            continue
        wid = ev.get('worker_id')
        fault = ev.get('evidence_fault', 'none')
        fault_class = ev.get('evidence_fault_class')
        for s in ('stdout', 'stderr'):
            rec = ev.get(s) if isinstance(ev.get(s), dict) else {}
            rel = rec.get('path')
            problems = []
            if os.path.basename(ef) != '%s.event.json' % wid:
                problems.append('EVENT_FILENAME')
            if ev.get('attempt_id') != attempt_id:
                problems.append('ATTEMPT_ID')
            if ev.get('run_dir_id') != os.path.basename(run_abs):
                problems.append('RUN_DIR_ID')
            if rel != '%s.%s' % (wid, s):
                problems.append('PATH_NOT_OWN_WORKER')
            data = read_file(os.path.join(run_abs, rel)) if isinstance(rel, str) and '/' not in rel and rel not in ('', '.', '..') else None
            key = run_rel + '/' + rel if isinstance(rel, str) else None
            if data is None:
                problems.append('MISSING')
            else:
                if key in referenced:
                    problems.append('DUPLICATE_REFERENCE')
                referenced.add(key)
                if (len(data), digest(data)) != (rec.get('bytes'), rec.get('sha256')):
                    problems.append('BYTES_OR_SHA256')
            if (rec.get('capture_bytes'), rec.get('capture_sha256')) != (rec.get('bytes'), rec.get('sha256')):
                problems.append('CAPTURE_WITNESS')
            if data is not None and len(data) == 0 and ev.get('returncode') == 0 and not ev.get('controller_timeout'):
                problems.append('EMPTY_AFTER_NORMAL_EXIT')
            row = {'run_dir': run_rel, 'event_file': os.path.basename(ef), 'worker_id': wid, 'mode': ev.get('mode'),
                   'stream': s, 'recorded_bytes': rec.get('bytes'), 'recorded_sha256': rec.get('sha256'),
                   'capture_bytes': rec.get('capture_bytes'), 'capture_sha256': rec.get('capture_sha256'),
                   'saved_bytes': None if data is None else len(data), 'saved_sha256': None if data is None else digest(data),
                   'returncode': ev.get('returncode'), 'controller_timeout': ev.get('controller_timeout'),
                   'process_fault': ev.get('process_fault'), 'evidence_fault': fault, 'attempt_id': ev.get('attempt_id'),
                   'problems': ';'.join(problems)}
            if not problems:
                row.update(status='MATCH', explanation='')
            else:
                row['status'] = 'EVIDENCE_STREAM_MISMATCH'
                if (fault != 'none' and fault_class == 'SIMULATED_EVIDENCE_FAULT' and fault in registry.get(run_rel, set())
                        and s in FAULT_STREAMS.get(fault, set())):
                    row['explanation'] = 'DECLARED_INJECTED_FAULT'
                elif any(str(f).startswith('HARNESS:') for f in registry.get(run_rel, set())):
                    row['explanation'] = 'REGISTERED_HARNESS_FAULT'
                else:
                    row['explanation'] = 'UNEXPLAINED'
            rows.append(row)
    for base, dirs, files in os.walk(root, followlinks=False):
        dirs.sort()
        run_rel = os.path.relpath(base, root).replace(os.sep, '/')
        for f in sorted(files):
            kind = None
            if f.startswith('.pending_'):
                kind = 'PENDING_WRITE_FILE'
            elif f.endswith(('.stdout', '.stderr')) and run_rel + '/' + f not in referenced:
                kind = 'ORPHAN_STREAM_FILE'
            if kind:
                expl = 'DECLARED_INJECTED_FAULT' if registry.get(run_rel) else 'UNEXPLAINED'
                rows.append({'run_dir': run_rel, 'event_file': '-', 'stream': '-', 'status': kind, 'problems': f,
                             'explanation': expl})
    counts = {}
    for r in rows:
        k = r['status'] + ('/' + r['explanation'] if r.get('explanation') else '')
        counts[k] = counts.get(k, 0) + 1
    unexplained = [r for r in rows if r.get('explanation') == 'UNEXPLAINED']
    return rows, {'tree_root': root, 'expected_attempt_id': attempt_id, 'events': len(event_files),
                  'stream_rows': sum(1 for r in rows if r['stream'] in ('stdout', 'stderr')),
                  'counts': counts, 'unexplained': len(unexplained),
                  'verdict': 'ALL_STREAMS_MATCH_OR_EXPLAINED' if not unexplained else 'UNEXPLAINED_EVIDENCE_STREAM_MISMATCH'}


COLS = ['run_dir', 'event_file', 'worker_id', 'mode', 'stream', 'status', 'explanation', 'problems', 'recorded_bytes',
        'saved_bytes', 'capture_bytes', 'recorded_sha256', 'saved_sha256', 'capture_sha256', 'returncode',
        'controller_timeout', 'process_fault', 'evidence_fault', 'attempt_id']


def main(argv):
    root, attempt_id, out = argv[0], argv[1], argv[2]
    registry = load_registry(argv[3:])
    rows, summary = reconcile(root, attempt_id, registry)
    with open(out + '.csv', 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=COLS, extrasaction='ignore')
        w.writeheader()
        for r in rows:
            w.writerow(r)
    summary['registry'] = {k: sorted(v) for k, v in registry.items()}
    with open(out + '.json', 'w') as f:
        json.dump({'summary': summary, 'rows': rows}, f, indent=1, sort_keys=True, default=str)
    print(json.dumps(summary, sort_keys=True, default=str))
    return 0 if summary['verdict'] == 'ALL_STREAMS_MATCH_OR_EXPLAINED' else 1


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
