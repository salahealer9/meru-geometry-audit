"""P0A3H-P1 C2 packager (operator-side; imports nothing from the candidate; never re-runs anything). REV1.

usage (once, immediately after P1_DRIVER.py finished, whatever its outcome):
  /usr/bin/python3.11 -I -S -B P1_C2_PACKAGER.py <attempt_work_dir> <original P0A3H_P1-C0_RECEIPT.json> \
      <original P0A3H_P1-C1-REV1_RECEIPT.json> <original human release certificate> <out P0A3H_P1-C2.zip>

Refuses to write C2 unless:
  (a) the attempt directory holds the driver's PRELAUNCH_RELEASE_RECEIPT.json, written BEFORE the first
      candidate invocation (journal order is checked), and its upstream/ copies of the release certificate,
      C0 receipt and C1-REV1 receipt are byte-identical to the three original files supplied here;
  (b) the C0 receipt has the SHA-256 pinned in C1-REV1; the C1-REV1 receipt and the release certificate name
      the released C1 SHA-256 recorded in the attempt summary (exact release sentence);
  (c) the attempt directory is within a safety bound of 2 x the 16 MiB whole-attempt cap (the cap itself is
      enforced by the driver and recorded in P1_DISK_LEDGER.json; an attempt that failed on the cap is still
      packaged so that the failure is preserved).
The three originals are stored again at top-level upstream/ INSIDE C2 (and are also inside attempt/upstream/).
After writing, the ZIP is re-opened and the upstream members, SHA256SUMS (every member except itself) and
PACKAGE_INVENTORY (every member except itself and SHA256SUMS) are re-verified. Private-key markers are refused.
Text matching is not proof of human origin; human authority remains a separate witnessed requirement.
"""
import hashlib, json, os, sys, zipfile

CAP = 16777216
C0_RECEIPT_SHA256 = '469c1cc5d16555e5b8e56e906b4bd5a0dfc147a68c147d8eef932bacdc14bdd3'
RELEASE_FMT = 'P0A3H-P1-C1 LOCK WITNESSED; SHA-256 %s; AUTHORIZE ONE P0A3H_P1_DEV_01'
UP = {'HUMAN_RELEASE_CERTIFICATE.txt': 2, 'P0A3H_P1-C0_RECEIPT.json': 0, 'P0A3H_P1-C1-REV1_RECEIPT.json': 1}
_B, _K = b'-----' + b'BEGIN ', b'PRIVATE' + b' KEY'
MARKERS = tuple(_B + p + _K for p in (b'', b'RSA ', b'EC ', b'OPENSSH ', b'PGP ', b'ENCRYPTED '))


def sha(b):
    return hashlib.sha256(b).hexdigest()


def main(work, c0r, c1r, rel, out):
    summ = json.load(open(os.path.join(work, 'P1_ATTEMPT_SUMMARY.json')))
    c1_sha = summ['release_sha'].lower()
    originals = [open(c0r, 'rb').read(), open(c1r, 'rb').read(), open(rel, 'rb').read()]
    if sha(originals[0]) != C0_RECEIPT_SHA256:
        raise SystemExit('C0_RECEIPT_IDENTITY_MISMATCH')
    if c1_sha not in originals[1].decode('utf-8', 'replace'):
        raise SystemExit('C1_RECEIPT_DOES_NOT_NAME_RELEASED_C1')
    if (RELEASE_FMT % c1_sha) not in originals[2].decode('utf-8', 'replace'):
        raise SystemExit('RELEASE_CERTIFICATE_TEXT_MISMATCH')
    for name, idx in UP.items():
        p = os.path.join(work, 'upstream', name)
        if not os.path.isfile(p) or open(p, 'rb').read() != originals[idx]:
            raise SystemExit('ATTEMPT_UPSTREAM_COPY_NOT_BYTE_IDENTICAL ' + name)
    pre = json.load(open(os.path.join(work, 'PRELAUNCH_RELEASE_RECEIPT.json')))
    if pre.get('released_c1_sha256') != c1_sha or pre['release_certificate']['sha256'] != sha(originals[2]) or not all(pre['checks'].values()):
        raise SystemExit('PRELAUNCH_RELEASE_RECEIPT_INCONSISTENT')
    events = [e['event'] for e in json.load(open(os.path.join(work, 'P1_DEV_JOURNAL.json')))]
    if 'HUMAN_RELEASE_CONSUMED' not in events or ('FIRST_P1_CANDIDATE_INVOCATION' in events and
                                                  events.index('HUMAN_RELEASE_CONSUMED') > events.index('FIRST_P1_CANDIDATE_INVOCATION')):
        raise SystemExit('RELEASE_NOT_CONSUMED_BEFORE_FIRST_CANDIDATE_INVOCATION')
    files = {'upstream/P0A3H_P1-C0_RECEIPT.json': originals[0], 'upstream/P0A3H_P1-C1-REV1_RECEIPT.json': originals[1],
             'upstream/HUMAN_RELEASE_CERTIFICATE.txt': originals[2]}
    total = 0
    for base, ds, fs in os.walk(work):
        ds.sort()
        for fn in sorted(fs):
            p = os.path.join(base, fn)
            if os.path.islink(p) or not os.path.isfile(p):
                raise SystemExit('REFUSED_NON_REGULAR ' + p)
            total += os.path.getsize(p)
            if total > 2 * CAP:
                raise SystemExit('ATTEMPT_EXCEEDS_PACKAGER_SAFETY_BOUND')
            rel_p = 'attempt/' + os.path.relpath(p, work).replace(os.sep, '/')
            b = open(p, 'rb').read()
            if any(m in b for m in MARKERS):
                raise SystemExit('REFUSED_PRIVATE_KEY_MARKER ' + rel_p)
            files[rel_p] = b
    disk = json.load(open(os.path.join(work, 'P1_DISK_LEDGER.json')))
    payload = [{'path': n, 'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())]
    files['PACKAGE_INVENTORY.json'] = (json.dumps({'schema': 'p0a3h-p1-package-inventory-1', 'checkpoint': 'P0A3H_P1-C2', 'released_c1_sha256': c1_sha,
                                                    'attempt_status': summ.get('status'), 'whole_attempt_disk_within_cap': summ.get('whole_attempt_disk_within_cap'),
                                                    'disk_ledger_exceeded_flag': disk.get('exceeded'), 'attempt_apparent_bytes_at_packaging': total,
                                                    'payload_count': len(payload), 'payload_files': payload,
                                                    'self_hash_exception': 'SHA256SUMS does not list itself'}, indent=1, sort_keys=True) + '\n').encode()
    files['SHA256SUMS'] = ''.join('%s  %s\n' % (sha(files[n]), n) for n in sorted(files)).encode()
    tmp = out + '.tmp'
    with zipfile.ZipFile(tmp, 'w') as z:
        for n in sorted(files):
            zi = zipfile.ZipInfo(n, date_time=(1980, 1, 1, 0, 0, 0))
            zi.external_attr = 0o100644 << 16
            zi.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(zi, files[n])
    with open(tmp, 'rb') as f:
        os.fsync(f.fileno())
    os.replace(tmp, out)
    z = zipfile.ZipFile(out)
    assert z.testzip() is None
    names = z.namelist()
    for name, idx in UP.items():
        assert z.read('upstream/' + name) == originals[idx] == z.read('attempt/upstream/' + name), name
    sums = dict(l.split(None, 1)[::-1] for l in z.read('SHA256SUMS').decode().splitlines() if l.strip())
    assert set(sums) == set(names) - {'SHA256SUMS'} and all(sha(z.read(n)) == v for n, v in sums.items())
    inv = json.loads(z.read('PACKAGE_INVENTORY.json'))['payload_files']
    assert {e['path'] for e in inv} == set(names) - {'SHA256SUMS', 'PACKAGE_INVENTORY.json'}
    b = open(out, 'rb').read()
    print(json.dumps({'c2': out, 'bytes': len(b), 'sha256': sha(b), 'members': len(names), 'upstream_receipts_inside_c2': True}))


if __name__ == '__main__':
    main(*sys.argv[1:6])
