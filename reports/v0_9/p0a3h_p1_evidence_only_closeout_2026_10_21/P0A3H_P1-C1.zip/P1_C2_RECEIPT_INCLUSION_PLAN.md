# P0A3H-P1 — P1-C2 and P1-CFINAL plan (prepared before any execution)

## P1-C2: contents and mandatory physical receipt inclusion
After `P0A3H_P1_DEV_01`, whatever its outcome, the operator runs once:
```
/usr/bin/python3.11 -I -S -B p1_external/P1_C2_PACKAGER.py <attempt work dir> \
  <original P0A3H_P1-C0_RECEIPT.json> <original P0A3H_P1-C1_RECEIPT.json> <human release certificate .txt> P0A3H_P1-C2.zip
```

The packager refuses to write C2 unless all of the following hold:
1. The C0 receipt has SHA-256 `469c1cc5d16555e5b8e56e906b4bd5a0dfc147a68c147d8eef932bacdc14bdd3`, which is the original receipt carried in this C1 under `c0/`.
2. The C1 receipt names the released C1 SHA-256, the same value recorded in `P1_ATTEMPT_SUMMARY.json`.
3. The release certificate contains exactly `P0A3H-P1-C1 LOCK WITNESSED; SHA-256 <that digest>; AUTHORIZE ONE P0A3H_P1_DEV_01`.

It stores these three objects at `upstream/P0A3H_P1-C0_RECEIPT.json`, `upstream/P0A3H_P1-C1_RECEIPT.json` and `upstream/HUMAN_RELEASE_CERTIFICATE.txt` **inside C2 itself**, next to `attempt/` (the complete work directory).

**Checklist, verified by the packager after writing and again on fresh readback:**
- [ ] The 3 upstream members are present and byte-equal to their inputs.
- [ ] SHA256SUMS lists every member except itself.
- [ ] PACKAGE_INVENTORY lists every member except itself and SHA256SUMS.
- [ ] CRC passes; paths are safe and unique; no private-key markers.
- [ ] `attempt/` contains:
  - the journal, summary and manifest;
  - HOST_GATE and P01 results;
  - for each case: the runner's stdout, stderr and exit code; `CASE_RESULT.json`; `raw_workers/` (every worker event, stream, request, envelope, receipt, signature, trust store and certificate); `authority_public/` (public material only); the external reconciliation; the verdict;
  - the extracted candidate, reference and external trees as executed.

C2 is durably saved and freshly read back. If any receipt is missing, C2 is **not written** and the attempt is classified NOT QUALIFIED. C2 is never backfilled.

## P1-CFINAL
CFINAL nests byte-identical copies of:
- the original `P0A3H_P1-C0.zip` (`067efd1e…f39e`);
- the original witnessed `P0A3H_P1-C1.zip`;
- the original `P0A3H_P1-C2.zip`.

It also includes the source locks, the complete chronology, the failure and limitation register, the signed P1 and A1 identities, the release certificate, and a **blank** independent QC checklist. Any rejected C1 is preserved under its own name. CFINAL nesting is checked by outer SHA-256 on fresh readback.
