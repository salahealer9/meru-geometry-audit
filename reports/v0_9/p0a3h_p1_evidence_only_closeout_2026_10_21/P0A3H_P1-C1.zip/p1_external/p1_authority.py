"""P0A3H-P1 external caller-side test-only authority builder (outside the 51-file candidate).

Imports NOTHING from the candidate. Plays the CALLER/CONTROLLER role only:
  * ephemeral NON-PRODUCTION Ed25519 keys via the pinned OpenSSL CLI, generated only after
    the human release, inside a private key directory outside all evidence; destroyed at end;
  * its own source map / environment fingerprint / policy digest computation;
  * envelopes bound to the signed P1 lineage (A1 three-file scope), caller receipts, trust store.
Encodings mirror the frozen candidate contract (canonical JSON: sort_keys, (',', ':'), ASCII,
no NaN). Legacy field-schema identifiers 'p0a3g-authority-envelope-1' / 'p0a3g-caller-receipt-1'
are retained by the candidate; the enforced lineage VALUES are the P1 values below.
No production key, trust root or deployment authority exists here.
"""
import hashlib, json, os, platform, subprocess, sys
from pathlib import Path

SCOPE = 'NON_PRODUCTION_TEST_AUTHORITY'
P1_PINS = {'schema': 'p0a3g-authority-envelope-1',
           'protocol_commit': '4c1634e6660a02ebdea62195f13fc4810fd08d41',
           'signed_parent': '8f4163df75ad33f9892b72cd62b75dbda24f0505',
           'git_ancestry': ['4c1634e6660a02ebdea62195f13fc4810fd08d41', '8f4163df75ad33f9892b72cd62b75dbda24f0505',
                            '39364f5a4345c8b60a879f6411b8d80cc6c299c6', '1120360074462c09863b45b85b64dc2b3f733626',
                            '2b77d6f3be9499b5725b4f51fc41aabf7fe37400', 'd9d0d6ad5b7cc310ed14af774355aeaa2652ea89',
                            'f5e31de09a8b79ddb1b5f0ba738443fc4012a390', 'e491e1e9f96391cd512db0dd528765d63bc179c1',
                            '4b488825ed35c7ac91a19abe62be068e75e9a076', '7de01ab2c90afe52dd763652a9eaffd2e9a2cff9',
                            '0e86df64e30d081065bbeb75b6f53391e287f8f3', 'adacfdbc6efcca4922c8d087d029b67e9b0c5dc5',
                            'd95c50ea96744ce266058c51f85fff320d1a27df', '83b9e6dcd53b100c5ac8b081832e81659cd1884a',
                            '1d38ea6f53b9266d853df887a66331c59e4fc3ae', '8ed3b988f716229bc9aee97d41ded0f524371193',
                            'c48c7a60777200a172ae3c72f5b0402162370ec7', '59eb47f7500d57866e4935822b78a555d3bcb515'],
           'baseline_archive_sha256': 'b34a3cd2c27f9384adb7427fa6628d6c08e15712e73542bda80eaeef989009b1',
           'loaded_code_identity': 'LOADED_CODE_IDENTITY_UNVERIFIED'}
# Historical P0A3G lineage, used ONLY to build the P03 negative control that must be rejected.
OLD_P0A3G_PINS = {'schema': 'p0a3g-authority-envelope-1',
                  'protocol_commit': 'adacfdbc6efcca4922c8d087d029b67e9b0c5dc5',
                  'signed_parent': 'd95c50ea96744ce266058c51f85fff320d1a27df',
                  'git_ancestry': ['adacfdbc6efcca4922c8d087d029b67e9b0c5dc5', 'd95c50ea96744ce266058c51f85fff320d1a27df',
                                   '83b9e6dcd53b100c5ac8b081832e81659cd1884a', '1d38ea6f53b9266d853df887a66331c59e4fc3ae',
                                   '8ed3b988f716229bc9aee97d41ded0f524371193', '59eb47f7500d57866e4935822b78a555d3bcb515'],
                  'baseline_archive_sha256': '6ec2b6e96234836d629398fb7fc781909de8b47b0bf80f5cae11202620ff2f15',
                  'loaded_code_identity': 'LOADED_CODE_IDENTITY_UNVERIFIED'}
A1_AMENDMENT = {'commit': '82dc0d2b2f2b81f90ec60dfed8e3aade19555d40', 'git_blob': 'a3a27a4f9379f8aacae085938eca39e5bb5b215f',
                'parent': '4c1634e6660a02ebdea62195f13fc4810fd08d41'}
DEPS = ['fractions.py', 'decimal.py', 'json/__init__.py', 'json/decoder.py', 'json/encoder.py', 'json/scanner.py',
        'hashlib.py', 'pathlib.py', 'subprocess.py', 'selectors.py', 'tempfile.py']


def enc(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()


def h(b):
    return hashlib.sha256(b).hexdigest()


def source_map(root):
    root = Path(root)
    out = {}
    for folder in ('src', 'reference', 'schemas', 'tests'):
        for p in sorted((root / folder).rglob('*')):
            if p.is_symlink() or p.suffix in ('.pyc', '.pyo'):
                raise RuntimeError('SOURCE_SYMLINK_OR_BYTECODE ' + str(p))
            if p.is_file() and p.suffix in ('.py', '.json', '.md'):
                out[p.relative_to(root).as_posix()] = h(p.read_bytes())
    return out


def environment(stdlib_root):
    """Must run inside the pinned interpreter launched with -I -S -B (the driver guarantees this)."""
    base = Path(stdlib_root)
    return {'python': sys.version, 'implementation': sys.implementation.name, 'platform': platform.platform(),
            'executable_realpath': str(Path(sys.executable).resolve()),
            'executable_sha256': h(Path(sys.executable).read_bytes()),
            'flags': {'isolated': sys.flags.isolated, 'no_site': sys.flags.no_site,
                      'dont_write_bytecode': sys.dont_write_bytecode},
            'dependencies': {n: h((base / n).read_bytes()) for n in DEPS}}


class TestKey:
    def __init__(self, openssl, keydir, key_id):
        self.openssl, self.key_id = openssl, key_id
        self.private = Path(keydir) / (key_id + '.pem')
        r = subprocess.run([openssl, 'genpkey', '-algorithm', 'ed25519', '-out', str(self.private)], capture_output=True,
                           env={'PATH': os.defpath, 'LC_ALL': 'C.UTF-8'})
        if r.returncode != 0:
            raise RuntimeError('KEYGEN_FAILED')
        os.chmod(self.private, 0o600)
        der = subprocess.run([openssl, 'pkey', '-in', str(self.private), '-pubout', '-outform', 'DER'], capture_output=True,
                             check=True, env={'PATH': os.defpath, 'LC_ALL': 'C.UTF-8'}).stdout
        self.public = der[-32:]
        self.public_hex = self.public.hex()

    def sign(self, message):
        m = self.private.with_suffix('.msg')
        s = self.private.with_suffix('.sig')
        m.write_bytes(message)
        subprocess.run([self.openssl, 'pkeyutl', '-sign', '-inkey', str(self.private), '-rawin', '-in', str(m), '-out', str(s)],
                       check=True, capture_output=True, env={'PATH': os.defpath, 'LC_ALL': 'C.UTF-8'})
        sig = s.read_bytes()
        m.unlink()
        s.unlink()
        return sig

    def public_record(self, scope=SCOPE, revoked=False):
        return {'key_id': self.key_id, 'algorithm': 'ed25519', 'public_key_hex': self.public_hex, 'scope': scope, 'revoked': revoked}

    def destroy(self):
        if self.private.exists():
            self.private.write_bytes(b'\0' * self.private.stat().st_size)
            self.private.unlink()


def trust_store(records, store_id='p0a3h-p1-test-controller-store'):
    return enc({'schema': 'p0a3g-trust-store-1', 'store_id': store_id, 'keys': records})


def envelope(root, input_canonical, run_id, stdlib_root, *, authority_mode='NON_PRODUCTION_TEST_AUTHORITY', key_id='p1-test-key-A',
             pins=None, overrides=None):
    m = dict(P1_PINS if pins is None else pins)
    m.update({'authority_mode': authority_mode, 'files': source_map(root), 'environment_sha256': h(enc(environment(stdlib_root))),
              'resource_policy_sha256': h((Path(root) / 'schemas/v0_9/p0a3g/resource_policy.json').read_bytes()),
              'input_sha256': h(input_canonical), 'run_id': run_id, 'key_id': key_id})
    m.update(overrides or {})
    return enc(m)


def receipt(env_bytes, run_id, mode, signature=None, trust=None):
    return enc({'schema': 'p0a3g-caller-receipt-1', 'mode': mode, 'run_id': run_id, 'envelope_sha256': h(env_bytes),
                'signature_sha256': h(signature) if signature is not None else None,
                'trust_store_sha256': h(trust) if trust is not None else None})


def validate_p1_envelope(env_bytes, schema):
    """Static structural check of an envelope against the external P1 schema (no candidate code)."""
    m = json.loads(env_bytes)
    req = schema['required_fields']
    problems = []
    if sorted(m) != sorted(req):
        problems.append('FIELD_SET')
    for k, v in schema['const'].items():
        if m.get(k) != v:
            problems.append('CONST:' + k)
    if m.get('authority_mode') not in schema['allowed_authority_modes']:
        problems.append('AUTHORITY_MODE')
    return problems
