"""P0A3H-P1 single-attempt driver for P0A3H_P1_DEV_01 (locked in P1-C1; NOT run before witness and release).

usage (exactly once, on the operator host, only after the human-relayed release
 'P0A3H-P1-C1 LOCK WITNESSED; SHA-256 <full digest>; AUTHORIZE ONE P0A3H_P1_DEV_01'):
  /usr/bin/python3.11 -I -S -B <extracted C1>/p1_external/P1_DRIVER.py \
      --release-sha <64-hex digest quoted in the release> \
      --c1 <path to the original P0A3H_P1-C1.zip, freshly retrieved> \
      --work <NEW directory that does not yet exist>

Fixed order: verify C1 bytes against the release -> extract -> verify locks -> HOST_GATE (no candidate)
-> P01 (no candidate) -> P02 -> P03 -> P04 -> P05 -> P06, each case once in its own runner process.
Fail-closed: the first non-PASS verdict ends the attempt; remaining cases NOT_RUN_AFTER_FAILURE /
NOT_RUN_AFTER_QUARANTINE. No retry, repair or re-run. Exit: 0 all passed; 1 failed (evidence preserved);
3 quarantine; 2 stopped before any candidate launch.
"""
import hashlib, io, json, os, resource, signal, subprocess, sys, time, zipfile

PY = '/usr/bin/python3.11'
AID = 'P0A3H_P1_DEV_01'
CASES = ['P02', 'P03', 'P04', 'P05', 'P06']
CASE_WALL = {'P02': 300, 'P03': 180, 'P04': 180, 'P05': 600, 'P06': 300}
RUNNER_LIMITS = {'RLIMIT_AS': 1073741824, 'RLIMIT_CPU': 900, 'RLIMIT_NOFILE': 256, 'RLIMIT_CORE': 0, 'RLIMIT_FSIZE': 67108864}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


a = sys.argv[1:]
A = {a[i].lstrip('-'): a[i + 1] for i in range(0, len(a) - 1, 2)}
for k in ('release-sha', 'c1', 'work'):
    if k not in A:
        raise SystemExit('MISSING_ARGUMENT ' + k)
WORK = os.path.abspath(A['work'])
os.makedirs(WORK, exist_ok=False)
JOURNAL = []


def log(event, **kw):
    JOURNAL.append({'utc': utc(), 'event': event, **kw})
    with open(os.path.join(WORK, 'P1_DEV_JOURNAL.json'), 'w') as f:
        json.dump(JOURNAL, f, indent=1, sort_keys=True, default=str)


def write_json(name, obj):
    with open(os.path.join(WORK, name), 'w') as f:
        json.dump(obj, f, indent=1, sort_keys=True, default=str)


def manifest():
    files = []
    for base, ds, fs in os.walk(WORK):
        ds.sort()
        for fn in sorted(fs):
            p = os.path.join(base, fn)
            rel = os.path.relpath(p, WORK).replace(os.sep, '/')
            if rel == 'P1_ATTEMPT_FILE_MANIFEST.json' or os.path.islink(p) or not os.path.isfile(p):
                continue
            with open(p, 'rb') as f:
                b = f.read()
            files.append({'path': rel, 'bytes': len(b), 'sha256': sha(b)})
    write_json('P1_ATTEMPT_FILE_MANIFEST.json', {'schema': 'p0a3h-p1-attempt-manifest-1', 'attempt': AID, 'files': files})


def finish(status, code, **kw):
    write_json('P1_ATTEMPT_SUMMARY.json', {'attempt': AID, 'status': status, 'release_sha': A['release-sha'], **kw})
    log('END', status=status)
    manifest()
    print(json.dumps({'status': status}))
    sys.exit(code)


# 1. release identity and archive integrity (no candidate) ------------------------------------
c1 = open(A['c1'], 'rb').read()
log('release_check', c1_bytes=len(c1), c1_sha256=sha(c1), release_sha=A['release-sha'])
if sha(c1) != A['release-sha'].lower():
    finish('P0A3H_P1_PREDEV_LOCK_NOT_WITNESSED', 2, reason='C1 bytes do not match the released SHA-256')
z = zipfile.ZipFile(io.BytesIO(c1))
names = z.namelist()
if z.testzip() is not None or len(names) != len(set(names)) or any(n.startswith('/') or '..' in n.split('/') for n in names):
    finish('P0A3H_P1_STOP_AND_QUARANTINE', 2, reason='C1 CRC or unsafe/duplicate member names')
for line in z.read('SHA256SUMS').decode().splitlines():
    if line.strip():
        hh, n = line.split(None, 1)
        if n != 'SHA256SUMS' and sha(z.read(n)) != hh:
            finish('P0A3H_P1_STOP_AND_QUARANTINE', 2, reason='C1 SHA256SUMS mismatch ' + n)
MAP = {'derivative_candidate/': 'candidate/', 'reference_candidate/': 'reference_candidate/', 'p1_external/': 'p1_external/', 'lock/': 'lock/'}
for n in names:
    for pre, dest in MAP.items():
        if n.startswith(pre) and not n.endswith('/'):
            p = os.path.join(WORK, dest + n[len(pre):])
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, 'wb') as f:
                f.write(z.read(n))


def tree_hashes(root):
    out = {}
    for base, ds, fs in os.walk(root):
        for fn in fs:
            p = os.path.join(base, fn)
            with open(p, 'rb') as f:
                b = f.read()
            out[os.path.relpath(p, root).replace(os.sep, '/')] = {'bytes': len(b), 'sha256': sha(b)}
    return out


EXT_LOCK = json.loads(z.read('lock/P1_EXTERNAL_LOCK.json'))['files']
CAND_LOCK = json.loads(z.read('lock/P1_CANDIDATE_LOCK.json'))['derivative_files']


def locks_ok(label):
    e = tree_hashes(os.path.join(WORK, 'p1_external')) == EXT_LOCK
    c = tree_hashes(os.path.join(WORK, 'candidate')) == CAND_LOCK
    log('lock_check_' + label, external_ok=e, candidate_ok=c)
    return e and c


if not locks_ok('pre_run'):
    finish('P0A3H_P1_STOP_AND_QUARANTINE', 2, reason='extracted trees differ from the C1 locks')
sys.path.insert(0, os.path.join(WORK, 'p1_external'))
import p1_verifier as V                                                    # noqa: E402

# 2. HOST_GATE and P01 (no candidate launch) ------------------------------------------------------
verdicts = {}
hg = V.host_gate(os.path.join(WORK, 'p1_external'))
write_json('HOST_GATE.json', hg)
log('HOST_GATE', verdict=hg['verdict'], failed=hg.get('failed_checks'))
if hg['verdict'] != 'PASS':
    finish('ENVIRONMENT_UNQUALIFIED', 2, host_gate=hg, per_case={c: 'NOT_RUN_ENVIRONMENT_UNQUALIFIED' for c in ['P01'] + CASES})
p01 = V.p01(WORK)
write_json('P01_RESULT.json', p01)
verdicts['P01'] = p01['verdict']
log('P01', verdict=p01['verdict'], failed=p01.get('failed_checks'), quarantine=p01.get('quarantine_triggers'))
if p01['verdict'] != 'PASS':
    per = {'P01': p01['verdict'], **{c: 'NOT_RUN_AFTER_' + ('QUARANTINE' if p01['verdict'] == 'QUARANTINE' else 'FAILURE') for c in CASES}}
    finish('P0A3H_P1_STOP_AND_QUARANTINE' if p01['verdict'] == 'QUARANTINE' else 'P0A3H_P1_DEV_01_FAILED_EVIDENCE_PRESERVED',
           3 if p01['verdict'] == 'QUARANTINE' else 1, per_case=per)


# 3. P02..P06, each once ---------------------------------------------------------------------------
def runner_limits():
    for k, v in RUNNER_LIMITS.items():
        resource.setrlimit(getattr(resource, k), (v, v))


def run(label, cmd, wall):
    log(label + '_start', command=cmd, wall_seconds=wall)
    t0 = time.monotonic()
    with open(os.path.join(WORK, label + '.stdout'), 'wb') as so, open(os.path.join(WORK, label + '.stderr'), 'wb') as se:
        p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=so, stderr=se, cwd=WORK, start_new_session=True,
                             preexec_fn=runner_limits, env={'PATH': os.defpath, 'LC_ALL': 'C.UTF-8'}, close_fds=True)
        try:
            rc = p.wait(timeout=wall)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(p.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            p.wait()
            rc = 'DRIVER_TIMEOUT_KILLED'
    log(label + '_end', exit=rc, wall_seconds=round(time.monotonic() - t0, 3), pid=p.pid)
    with open(os.path.join(WORK, label + '.exit'), 'w') as f:
        f.write(str(rc) + '\n')
    return rc


def scrub(keydir):
    left = []
    for fn in sorted(os.listdir(keydir)):
        p = os.path.join(keydir, fn)
        if os.path.isfile(p) and not os.path.islink(p):
            n = os.path.getsize(p)
            left.append({'file': fn, 'bytes': n})
            with open(p, 'r+b') as f:
                f.write(b'\0' * n)
                f.flush()
                os.fsync(f.fileno())
            os.unlink(p)
    return left


os.makedirs(os.path.join(WORK, 'cases'))
status, code = 'P0A3H_P1_DEV_01_ALL_6_PASSED_PENDING_CHECKPOINTS', 0
for i, case in enumerate(CASES):
    cdir = os.path.join(WORK, 'cases', case)
    kdir = os.path.join(WORK, 'controller_keys_' + case)
    os.makedirs(kdir, mode=0o700)
    if i == 0:
        log('FIRST_P1_CANDIDATE_INVOCATION')
    rc = run('RUNNER_' + case, [PY, '-I', '-S', '-B', os.path.join(WORK, 'p1_external/p1_case_runner.py'), case,
                                os.path.join(WORK, 'candidate'), cdir, kdir, os.path.join(WORK, 'p1_external'), AID], CASE_WALL[case])
    left = scrub(kdir)
    os.rmdir(kdir)
    rw = os.path.join(cdir, 'raw_workers')
    if os.path.isdir(rw):
        run('RECONCILE_' + case, [PY, '-I', '-S', '-B', os.path.join(WORK, 'p1_external/r2_stream_reconcile.py'), rw, AID,
                                  os.path.join(cdir, 'EXTERNAL_RECONCILIATION')], 300)
    ev = V.evaluate(case, cdir, WORK) if os.path.isdir(cdir) else {'verdict': 'INCOMPLETE', 'reason': 'CASE_DIRECTORY_MISSING'}
    ev['runner_exit'] = rc
    ev['driver_scrubbed_key_files'] = left
    if rc != 0 and ev['verdict'] == 'PASS':
        ev['verdict'] = 'FAIL'
        ev['failed_checks'] = ev.get('failed_checks', []) + ['runner_exit_zero']
    if left and ev['verdict'] == 'PASS':
        ev['verdict'] = 'FAIL'
        ev['failed_checks'] = ev.get('failed_checks', []) + ['no_runner_left_key_files']
    if not locks_ok('after_' + case):
        ev['verdict'] = 'QUARANTINE'
        ev['quarantine_triggers'] = ev.get('quarantine_triggers', []) + ['SOURCE_OR_EXTERNAL_LOCK_CHANGED']
    with open(os.path.join(WORK, 'cases', case + '_VERDICT.json'), 'w') as f:
        json.dump(ev, f, indent=1, sort_keys=True, default=str)
    verdicts[case] = ev['verdict']
    log(case + '_VERDICT', verdict=ev['verdict'], failed=ev.get('failed_checks'), quarantine=ev.get('quarantine_triggers'))
    if ev['verdict'] != 'PASS':
        tag = 'QUARANTINE' if ev['verdict'] == 'QUARANTINE' else 'FAILURE'
        for later in CASES[i + 1:]:
            verdicts[later] = 'NOT_RUN_AFTER_' + tag
        status = 'P0A3H_P1_STOP_AND_QUARANTINE' if tag == 'QUARANTINE' else 'P0A3H_P1_DEV_01_FAILED_EVIDENCE_PRESERVED'
        code = 3 if tag == 'QUARANTINE' else 1
        break
finish(status, code, per_case=verdicts, host_gate='PASS', retry_or_repair_performed=False)
