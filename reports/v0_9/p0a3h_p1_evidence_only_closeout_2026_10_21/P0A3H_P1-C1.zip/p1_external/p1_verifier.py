"""P0A3H-P1 independent verifier (imports NOTHING from the candidate; standard library only).

Provides, for P1_DRIVER.py:
  host_gate(ext)            -- pinned host identities vs P1_HOST_PINS (before any candidate launch)
  p01(work)                 -- P01 source/lineage integrity, decided from file bytes and AST literals only
  evaluate(case, case_dir, work) -- P02..P06 verdicts from the runner's saved CASE_RESULT.json, the raw
                               run-directory files, the external reconciler output and the locked comparators.
Verdicts: PASS | FAIL | QUARANTINE | INCOMPLETE. Expected values are read from locks/P1_EXPECTED_OUTCOMES.json.
"""
import ast, hashlib, json, os, platform, subprocess, sys
from pathlib import Path


def h(b):
    return hashlib.sha256(b).hexdigest()


def canon(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()


def jload(p):
    with open(p, 'rb') as f:
        return json.loads(f.read())


def tree(root):
    out = {}
    for b, ds, fs in os.walk(root):
        ds.sort()
        for f in sorted(fs):
            p = os.path.join(b, f)
            if os.path.islink(p):
                out[os.path.relpath(p, root).replace(os.sep, '/')] = None
                continue
            with open(p, 'rb') as fh:
                out[os.path.relpath(p, root).replace(os.sep, '/')] = fh.read()
    return out


def verdict(checks, quarantine=()):
    q = [k for k in quarantine if checks.get(k) is not True]
    if q:
        return {'verdict': 'QUARANTINE', 'quarantine_triggers': q, 'checks': checks}
    bad = [k for k, v in checks.items() if v is not True]
    return {'verdict': 'PASS' if not bad else 'FAIL', 'failed_checks': bad, 'checks': checks}


# ----------------------------------------------------------------------------- host gate
def host_gate(ext):
    pins = jload(Path(ext) / 'locks/P1_HOST_PINS.json')
    c = {}
    for k in ('python', 'openssl'):
        p = pins[k]['path']
        c[k + '_exists_regular_not_symlink'] = os.path.isfile(p) and not os.path.islink(p)
        c[k + '_realpath_equal'] = os.path.realpath(p) == p
        try:
            with open(p, 'rb') as f:
                b = f.read()
            c[k + '_sha256_equal'] = h(b) == pins[k]['sha256']
            c[k + '_bytes_equal'] = len(b) == pins[k]['bytes']
        except OSError:
            c[k + '_sha256_equal'] = c[k + '_bytes_equal'] = False
    for name, rec in pins['stdlib_11'].items():
        try:
            with open(rec['path'], 'rb') as f:
                c['stdlib:' + name] = h(f.read()) == rec['sha256'] and rec['path'] == pins['stdlib_root'] + '/' + name
        except OSError:
            c['stdlib:' + name] = False
    osr = {}
    try:
        for line in Path('/etc/os-release').read_text().splitlines():
            if '=' in line:
                k, v = line.split('=', 1)
                osr[k] = v.strip('"')
    except OSError:
        pass
    c['os_release_debian_12'] = osr.get('ID') == pins['os_release_id'] and osr.get('VERSION_ID') == pins['os_version_id']
    c['machine_x86_64'] = platform.machine() == pins['machine']
    c['driver_interpreter_is_pinned_path'] = sys.executable == pins['python']['path']
    c['driver_interpreter_version'] = sys.version.startswith(pins['python']['version_prefix'])
    c['driver_flags_I_S_B'] = sys.flags.isolated == 1 and sys.flags.no_site == 1 and sys.dont_write_bytecode is True
    try:
        v = subprocess.run([pins['openssl']['path'], 'version'], capture_output=True, timeout=10, env={'PATH': os.defpath, 'LC_ALL': 'C.UTF-8'})
        c['openssl_version_prefix'] = v.returncode == 0 and v.stdout.decode('ascii', 'replace').startswith(pins['openssl']['version_prefix'])
    except Exception:
        c['openssl_version_prefix'] = False
    c['proc_self_readable'] = all(os.path.exists('/proc/self/' + n) for n in ('exe', 'cmdline', 'status', 'fd'))
    return verdict(c)


# ----------------------------------------------------------------------------- P01
def _assigned(tree_ast, name):
    for n in tree_ast.body:
        if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in n.targets):
            return ast.literal_eval(n.value)
    return None


def p01(work):
    work = Path(work)
    lock = jload(work / 'lock/P1_CANDIDATE_LOCK.json')
    src_lock = jload(work / 'lock/SOURCE_LOCK.json')['files']
    der, ref = tree(work / 'candidate'), tree(work / 'reference_candidate')
    c = {}
    c['derivative_no_symlinks_or_bytecode'] = all(v is not None for v in der.values()) and not any(
        p.endswith(('.pyc', '.pyo')) or '__pycache__' in p for p in der)
    c['derivative_equals_P1_CANDIDATE_LOCK'] = sorted(der) == sorted(lock['derivative_files']) and all(
        der[p] is not None and h(der[p]) == e['sha256'] and len(der[p]) == e['bytes'] for p, e in lock['derivative_files'].items())
    c['reference_equals_original_SOURCE_LOCK'] = sorted(ref) == sorted(src_lock) and all(
        ref[p] is not None and h(ref[p]) == e['sha256'] and len(ref[p]) == e['bytes'] for p, e in src_lock.items())
    changed = sorted(p for p in der if der.get(p) != ref.get(p))
    c['exactly_three_permitted_files_changed'] = changed == sorted(lock['permitted_changed_files'])
    c['kernels_byte_identical'] = all(der[p] is not None and h(der[p]) == v for p, v in lock['kernels'].items())
    pt = ast.parse(der['src/meru_geometry/v0_9/qo2d_exact/identity.py'])
    rt = ast.parse(der['reference/v0_9/qo2d_exact/identity.py'])
    exp = lock['p1_identity']
    c['production_lineage_constants'] = (_assigned(pt, 'PROTOCOL'), _assigned(pt, 'PARENT'), _assigned(pt, 'ANCESTRY'), _assigned(pt, 'BASELINE')) == (
        exp['protocol_commit'], exp['signed_parent'], exp['git_ancestry'], exp['baseline_archive_sha256'])
    pins = _assigned(rt, 'PINS') or {}
    c['reference_PINS_lineage'] = (pins.get('protocol_commit'), pins.get('signed_parent'), pins.get('git_ancestry'), pins.get('baseline_archive_sha256')) == (
        exp['protocol_commit'], exp['signed_parent'], exp['git_ancestry'], exp['baseline_archive_sha256'])
    c['reference_PINS_schema_and_loaded_unchanged'] = pins.get('schema') == 'p0a3g-authority-envelope-1' and pins.get('loaded_code_identity') == 'LOADED_CODE_IDENTITY_UNVERIFIED'
    c['ancestry_18_first_parent'] = len(exp['git_ancestry']) == 18 and exp['git_ancestry'][0] == exp['protocol_commit'] and exp['git_ancestry'][1] == exp['signed_parent'] and exp['git_ancestry'][-1] == '59eb47f7500d57866e4935822b78a555d3bcb515'
    root = "Path('%s')" % exp['stdlib_root']
    c['stdlib_root_both_identity_files'] = root.encode() in der['src/meru_geometry/v0_9/qo2d_exact/identity.py'] and root.encode() in der['reference/v0_9/qo2d_exact/identity.py'] and b'/usr/lib/python3.12' not in der['src/meru_geometry/v0_9/qo2d_exact/identity.py'] + der['reference/v0_9/qo2d_exact/identity.py']
    po, pn = json.loads(ref['schemas/v0_9/p0a3g/resource_policy.json']), json.loads(der['schemas/v0_9/p0a3g/resource_policy.json'])
    four = {'interpreter', 'interpreter_sha256', 'openssl', 'openssl_sha256'}
    c['policy_only_runtime_identity_fields_changed'] = sorted(po) == sorted(pn) and all(po[k] == pn[k] for k in po if k not in four)
    c['policy_runtime_values'] = {k: pn[k] for k in four} == lock['policy_runtime_values']
    c['old_authority_schema_byte_identical'] = der['schemas/v0_9/p0a3g/authority_envelope.schema.json'] == ref['schemas/v0_9/p0a3g/authority_envelope.schema.json']
    c['old_authority_schema_not_referenced_by_any_python_source'] = not any(b'authority_envelope.schema' in v for p, v in der.items() if p.endswith('.py'))
    c['signed_authorities_pinned'] = lock['signed_authority']['p1']['commit'] == exp['protocol_commit'] and lock['signed_authority']['a1']['commit'] == '82dc0d2b2f2b81f90ec60dfed8e3aade19555d40'
    out = verdict(c, quarantine=('derivative_equals_P1_CANDIDATE_LOCK', 'reference_equals_original_SOURCE_LOCK', 'kernels_byte_identical',
                                 'exactly_three_permitted_files_changed'))
    out['changed_files_observed'] = changed
    out['classification'] = 'SOURCE_DIFF_AND_P1_AUTHORITY_BOUND' if out['verdict'] == 'PASS' else out['verdict']
    return out


# ----------------------------------------------------------------------------- P02..P06
def _recon(case_dir):
    p = Path(case_dir) / 'EXTERNAL_RECONCILIATION.json'
    if not p.exists():
        return None
    return jload(p)


def _run_rows_ok(recon, run_dir, events):
    if recon is None:
        return False
    rows = [r for r in recon['rows'] if r['run_dir'] == run_dir]
    streams = [r for r in rows if r.get('stream') in ('stdout', 'stderr')]
    return len(streams) == 2 * events and len(rows) == len(streams) and all(r['status'] == 'MATCH' for r in rows)


def _raised(o, typ, state=None, reason=None, cause=None, message=None):
    return (isinstance(o, dict) and o.get('raised') is True and o.get('type') == typ
            and (state is None or o.get('state') == state) and (reason is None or o.get('reason') == reason)
            and (cause is None or o.get('cause') == cause) and (message is None or o.get('message') == message))


def _receipts_bound(run_path, events, env, rec):
    try:
        return all((run_path / ('w%04d.receipt.json' % i)).read_bytes() == rec and (run_path / ('w%04d.expected.json' % i)).read_bytes() == env
                   for i in range(events))
    except OSError:
        return False


def _success_run(o, run_path, exp, pins, policy_sha, case_dir, recon):
    res = o.get('result') or {}
    ev = res.get('worker_events') or []
    sub = Path(case_dir) / 'authority_public' / o['run_dir']
    env, rec = (sub / 'envelope').read_bytes(), (sub / 'receipt').read_bytes()
    return {
        'state_success': res.get('state') == exp['success_state'],
        'authority_test_only': res.get('authority_status') == 'NON_PRODUCTION_TEST_AUTHORITY_VERIFIED',
        'loaded_code_identity_unverified': res.get('loaded_code_identity') == 'LOADED_CODE_IDENTITY_UNVERIFIED',
        'stream_evidence_reconciled': res.get('stream_evidence') == 'ALL_WORKER_STREAMS_RECONCILED',
        'new_checked_record': res.get('recovery') == 'NEW_CHECKED_RECORD',
        'reference_check_success': (res.get('verification') or {}).get('state') == exp['success_state'] and ((res.get('verification') or {}).get('details') or {}).get('check') == exp['reference_check'],
        'four_worker_events': [e.get('mode') for e in ev] == ['calibrate_produce', 'calibrate_check', 'produce', 'check'],
        'workers_exit_zero': all(e.get('returncode') == 0 and e.get('controller_timeout') is False for e in ev),
        'workers_pinned_interpreter': all(e.get('interpreter_sha256') == pins['python']['sha256'] and (e.get('command') or [None])[0] == pins['python']['path'] for e in ev),
        'workers_policy_digest': all(e.get('policy_sha256') == policy_sha for e in ev),
        'workers_attempt_id': all(e.get('attempt_id') == 'P0A3H_P1_DEV_01' for e in ev),
        'checkpoint_written': (run_path / 'checkpoint.json').is_file(),
        'caller_receipt_and_envelope_bound_in_every_event': _receipts_bound(run_path, 4, env, rec),
        'external_reconciler_all_match': _run_rows_ok(recon, o['run_dir'], 4),
    }


def _cert_vs_comparator(o, run_path, ext, name, exp_cert):
    comp = Path(ext) / 'comparators'
    cb, cs = comp / (name + '.certificate.json'), comp / (name + '.check_stdout.json')
    if not cb.exists() or not cs.exists():
        return None
    cbytes = cb.read_bytes()
    c = {'comparator_certificate_pinned': h(cbytes) == exp_cert}
    try:
        c['certificate_file_bytes_equal_comparator'] = (run_path / 'w0003.certificate.json').read_bytes() == cbytes
        c['result_certificate_canonical_equal_comparator'] = canon((o.get('result') or {}).get('certificate')) == cbytes
        mine, theirs = json.loads((run_path / 'w0003.stdout').read_bytes()), json.loads(cs.read_bytes())
        c['reference_check_output_equal_comparator'] = all(mine.get(k) == theirs.get(k) for k in ('state', 'certificate_sha256', 'input_sha256', 'details', 'authority_status', 'loaded_code_identity'))
    except Exception:
        c['certificate_file_bytes_equal_comparator'] = c['result_certificate_canonical_equal_comparator'] = c['reference_check_output_equal_comparator'] = False
    return c


def evaluate(case, case_dir, work):
    work, case_dir = Path(work), Path(case_dir)
    ext = work / 'p1_external'
    exp = jload(ext / 'locks/P1_EXPECTED_OUTCOMES.json')
    pins = jload(ext / 'locks/P1_HOST_PINS.json')
    lock = jload(work / 'lock/P1_CANDIDATE_LOCK.json')
    policy_sha = lock['derivative_files']['schemas/v0_9/p0a3g/resource_policy.json']['sha256']
    rp = case_dir / 'CASE_RESULT.json'
    if not rp.exists():
        return {'verdict': 'INCOMPLETE', 'reason': 'CASE_RESULT_MISSING'}
    R = jload(rp)
    if R.get('runner_exception'):
        return {'verdict': 'FAIL', 'reason': 'RUNNER_EXCEPTION', 'runner_exception': R['runner_exception']}
    O, recon, run = R['observations'], _recon(case_dir), case_dir / 'raw_workers'
    base = {'no_private_key_left': R.get('private_key_files_left') == [],
            'runner_interpreter': R['runner']['executable'] == pins['python']['path'] and R['runner']['sys_version'].startswith(pins['python']['version_prefix'])
            and R['runner']['flags'] == {'isolated': 1, 'no_site': 1, 'dont_write_bytecode': True},
            'reconciler_ran_and_no_unexplained': recon is not None and recon['summary']['verdict'] == 'ALL_STREAMS_MATCH_OR_EXPLAINED'}
    E = exp['cases'][case]
    if case == 'P02':
        c = dict(base)
        c.update(_success_run(O, run / O['run_dir'], exp, pins, policy_sha, case_dir, recon))
        be = O.get('builder_environment') or {}
        c['candidate_environment_equals_builder'] = O.get('candidate_environment_equals_builder_environment') is True
        c['environment_executable_pinned'] = be.get('executable_realpath') == pins['python']['path'] and be.get('executable_sha256') == pins['python']['sha256']
        c['environment_stdlib_pinned'] = be.get('dependencies') == {k: v['sha256'] for k, v in pins['stdlib_11'].items()}
        c['proc_self_exe_pinned'] = R['runner'].get('proc_self_exe') == pins['python']['path']
        c['certificate_request_is_fixture'] = canon(((O.get('result') or {}).get('certificate') or {}).get('request')) == (ext / 'fixtures/R2_H01.request.json').read_bytes()
        c['no_non_test_authority_accepted'] = (O.get('result') or {}).get('authority_status') in (None, 'NON_PRODUCTION_TEST_AUTHORITY_VERIFIED')
        return verdict(c, quarantine=('no_non_test_authority_accepted',))
    if case == 'P03':
        c = dict(base)
        v = O['valid']
        c['valid_production_test_only'] = v['production_route'].get('raised') is False and (v['production_route'].get('value') or {}).get('authority_status') == 'NON_PRODUCTION_TEST_AUTHORITY_VERIFIED'
        c['valid_reference_test_only'] = v['reference_route'].get('raised') is False and (v['reference_route'].get('value') or {}).get('authority_status') == 'NON_PRODUCTION_TEST_AUTHORITY_VERIFIED'
        q = []
        for n, ne in E['negatives'].items():
            o = O.get(n) or {}
            pr, rr = o.get('production_route') or {}, o.get('reference_route') or {}
            c[n + ':production_rejected'] = pr.get('raised') is True
            c[n + ':reference_rejected'] = rr.get('raised') is True
            q += [n + ':production_rejected', n + ':reference_rejected']
            c[n + ':production_boundary_reached'] = _raised(pr, 'Boundary', 'CODE_IDENTITY_MISMATCH', 'EXTERNAL_AUTHORITY_REJECTED', ne['production_cause'])
            c[n + ':reference_boundary_reached'] = _raised(rr, 'IdentityMismatch', message='EXTERNAL_IDENTITY_MISMATCH', cause=ne['reference_cause'])
        c['N4_exactly_one_byte_changed'] = (O.get('N4_TAMPERED_ENVELOPE_ORIGINAL_SIGNATURE') or {}).get('byte_diff_count') == 1
        e2e = O.get('N3_end_to_end_controller') or {}
        r = e2e.get('result') or {}
        c['N3_controller_not_success'] = r.get('state') != exp['success_state'] and 'certificate' not in r
        q.append('N3_controller_not_success')
        c['N3_controller_identity_mismatch_no_worker'] = r.get('state') == 'CODE_IDENTITY_MISMATCH' and r.get('reason') == 'EXTERNAL_AUTHORITY_REJECTED' and r.get('worker_events') == [] and e2e.get('run_dir_created') is False
        return verdict(c, quarantine=tuple(q))
    if case == 'P04':
        c = dict(base)
        c['production_gate_REAL_HUMAN_SIGNED_AUTHORITY_ABSENT'] = _raised(O['production_authority_gate'], 'ValueError', message='REAL_HUMAN_SIGNED_AUTHORITY_ABSENT')
        c['production_verify_rejects_with_cause'] = _raised(O['production_verify'], 'Boundary', 'CODE_IDENTITY_MISMATCH', 'EXTERNAL_AUTHORITY_REJECTED', 'REAL_HUMAN_SIGNED_AUTHORITY_ABSENT')
        c['reference_verify_rejects_with_cause'] = _raised(O['reference_verify'], 'IdentityMismatch', message='EXTERNAL_IDENTITY_MISMATCH', cause='no real human-signed authority')
        r = O['controller_run'].get('result') or {}
        c['deployment_not_accepted_anywhere'] = O['production_authority_gate'].get('raised') is True and O['production_verify'].get('raised') is True and O['reference_verify'].get('raised') is True and r.get('state') != exp['success_state'] and 'certificate' not in r
        c['controller_rejects_before_any_worker'] = r.get('state') == 'CODE_IDENTITY_MISMATCH' and r.get('reason') == 'EXTERNAL_AUTHORITY_REJECTED' and r.get('worker_events') == [] and O['controller_run'].get('run_dir_created') is False
        return verdict(c, quarantine=('deployment_not_accepted_anywhere',))
    if case == 'P05':
        c = dict(base)
        p02 = case_dir.parent / 'P02'
        R2 = jload(p02 / 'CASE_RESULT.json')['observations'] if (p02 / 'CASE_RESULT.json').exists() else None
        sets = [('R2_H01', R2, p02 / 'raw_workers' / 'P02_R2_H01', _recon(p02), p02)] + [
            (n, O.get(n), run / ('P05_' + n), recon, case_dir) for n in ('R2_H02', 'R2_H03', 'R2_H04')]
        incomplete = False
        for n, o, rpath, rc, cdir in sets:
            if o is None:
                c[n + ':evidence_present'] = False
                continue
            s = _success_run(o, rpath, exp, pins, policy_sha, cdir, rc)
            for k, v in s.items():
                c[n + ':' + k] = v
            cc = _cert_vs_comparator(o, rpath, ext, n, E['comparator_certificate_sha256'][n])
            if cc is None:
                incomplete = True
                c[n + ':comparator_present'] = False
            else:
                for k, v in cc.items():
                    c[n + ':' + k] = v
        out = verdict(c)
        if incomplete and out['verdict'] != 'PASS':
            out['verdict'] = 'INCOMPLETE'
        return out
    if case == 'P06':
        c = dict(base)
        a = O['P06A_OVER_LIMIT']
        ra = a.get('result') or {}
        fx = (ext / 'fixtures/P06A_OVER_LIMIT.request.json').read_bytes()
        c['A_not_accepted'] = ra.get('state') != exp['success_state'] and 'certificate' not in ra
        c['A_resource_incomplete_policy_cap'] = ra.get('state') == 'RESOURCE_INCOMPLETE' and ra.get('reason') == 'REQUEST_POLICY_CAP'
        c['A_no_worker_no_directory'] = ra.get('worker_events') == [] and a.get('run_dir_created') is False
        c['A_raw_identity_recorded'] = (ra.get('raw_identity') or {}).get('bytes') == len(fx) and (ra.get('raw_identity') or {}).get('prefix_sha256') == h(fx)
        b = O['P06B_WALL_TIMEOUT']
        rb = b.get('result') or {}
        ev = rb.get('worker_events') or []
        rpath = run / 'P06B_WALL_TIMEOUT'
        c['B_not_accepted'] = rb.get('state') != exp['success_state'] and 'certificate' not in rb
        c['B_resource_incomplete_wall_timeout'] = rb.get('state') == 'RESOURCE_INCOMPLETE' and rb.get('reason') == 'CONTROLLER_WALL_TIMEOUT'
        c['B_three_events'] = [e.get('mode') for e in ev] == ['calibrate_produce', 'calibrate_check', 'produce']
        last = ev[-1] if ev else {}
        c['B_actual_timeout_kill'] = last.get('process_fault') == 'timeout' and last.get('controller_timeout') is True and last.get('returncode') == -9 and (last.get('elapsed_ns') or 0) >= E['min_timeout_elapsed_ns']
        try:
            so, se = (rpath / 'w0002.stdout').read_bytes(), (rpath / 'w0002.stderr').read_bytes()
            c['B_empty_stdout_preserved'] = so == b'' and (last.get('stdout') or {}).get('bytes') == 0
            c['B_partial_stderr_preserved'] = b'entering injected sleep' in se and (last.get('stderr') or {}).get('sha256') == h(se)
        except OSError:
            c['B_empty_stdout_preserved'] = c['B_partial_stderr_preserved'] = False
        c['B_no_checkpoint'] = not (rpath / 'checkpoint.json').exists()
        sub = case_dir / 'authority_public' / 'P06B_WALL_TIMEOUT'
        c['B_receipt_chain_complete'] = _receipts_bound(rpath, 3, (sub / 'envelope').read_bytes(), (sub / 'receipt').read_bytes())
        c['B_external_reconciler_all_match'] = _run_rows_ok(recon, 'P06B_WALL_TIMEOUT', 3)
        return verdict(c, quarantine=('A_not_accepted', 'B_not_accepted'))
    return {'verdict': 'INCOMPLETE', 'reason': 'UNKNOWN_CASE'}
