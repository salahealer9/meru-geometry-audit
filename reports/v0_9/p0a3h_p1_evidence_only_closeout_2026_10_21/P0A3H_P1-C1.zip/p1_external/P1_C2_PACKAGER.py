"""P0A3H-P1 C2 packager (agent/operator-side; imports nothing from the candidate; never re-runs anything).

usage (once, immediately after P1_DRIVER.py finished, whatever its outcome):
  /usr/bin/python3.11 -I -S -B P1_C2_PACKAGER.py <attempt_work_dir> <original_P0A3H_P1-C0_RECEIPT.json> \
      <original_P0A3H_P1-C1_RECEIPT.json> <human_release_certificate.txt> <out P0A3H_P1-C2.zip>

Guarantees the three upstream objects are PHYSICALLY inside C2 (prevents a repeat of
R2_QCF01_C2_PRIOR_RECEIPTS_OMITTED): it refuses to write C2 unless (a) the C0 receipt bytes have the
SHA-256 pinned in C1, (b) the C1 receipt names the same C1 SHA-256 as the attempt summary, and (c) the
release certificate contains the exact release sentence with that SHA-256. After writing, it re-opens the
ZIP and re-verifies all three members, SHA256SUMS (all members except itself) and PACKAGE_INVENTORY
(all members except itself and SHA256SUMS). Private-key material is refused.
"""
import hashlib, json, os, sys, zipfile

C0_RECEIPT_SHA256 = '469c1cc5d16555e5b8e56e906b4bd5a0dfc147a68c147d8eef932bacdc14bdd3'
RELEASE_FMT = 'P0A3H-P1-C1 LOCK WITNESSED; SHA-256 %s; AUTHORIZE ONE P0A3H_P1_DEV_01'
_B, _K = b'-----' + b'BEGIN ', b'PRIVATE' + b' KEY'
MARKERS = tuple(_B + p + _K for p in (b'', b'RSA ', b'EC ', b'OPENSSH ', b'PGP ', b'ENCRYPTED '))


def sha(b):
    return hashlib.sha256(b).hexdigest()


def main(work, c0r, c1r, rel, out):
    summ = json.load(open(os.path.join(work, 'P1_ATTEMPT_SUMMARY.json')))
    c1_sha = summ['release_sha'].lower()
    b0, b1, br = open(c0r, 'rb').read(), open(c1r, 'rb').read(), open(rel, 'rb').read()
    if sha(b0) != C0_RECEIPT_SHA256:
        raise SystemExit('C0_RECEIPT_IDENTITY_MISMATCH')
    if c1_sha not in b1.decode('utf-8', 'replace'):
        raise SystemExit('C1_RECEIPT_DOES_NOT_NAME_RELEASED_C1')
    if (RELEASE_FMT % c1_sha) not in br.decode('utf-8', 'replace'):
        raise SystemExit('RELEASE_CERTIFICATE_TEXT_MISMATCH')
    files = {'upstream/P0A3H_P1-C0_RECEIPT.json': b0, 'upstream/P0A3H_P1-C1_RECEIPT.json': b1,
             'upstream/HUMAN_RELEASE_CERTIFICATE.txt': br}
    for base, ds, fs in os.walk(work):
        ds.sort()
        for fn in sorted(fs):
            p = os.path.join(base, fn)
            if os.path.islink(p) or not os.path.isfile(p):
                raise SystemExit('REFUSED_NON_REGULAR ' + p)
            rel_p = 'attempt/' + os.path.relpath(p, work).replace(os.sep, '/')
            b = open(p, 'rb').read()
            if any(m in b for m in MARKERS):
                raise SystemExit('REFUSED_PRIVATE_KEY_MARKER ' + rel_p)
            files[rel_p] = b
    payload = [{'path': n, 'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())]
    files['PACKAGE_INVENTORY.json'] = (json.dumps({'schema': 'p0a3h-p1-package-inventory-1', 'checkpoint': 'P0A3H_P1-C2',
                                                    'released_c1_sha256': c1_sha, 'payload_count': len(payload), 'payload_files': payload,
                                                    'self_hash_exception': 'SHA256SUMS does not list itself'}, indent=1, sort_keys=True) + '\n').encode()
    files['SHA256SUMS'] = ''.join('%s  %s\n' % (sha(files[n]), n) for n in sorted(files)).encode()
    tmp = out + '.tmp'
    with zipfile.ZipFile(tmp, 'w') as z:
        for n in sorted(files):
            zi = zipfile.ZipInfo(n, date_time=(1980, 1, 1, 0, 0, 0))
            zi.external_attr = 0o100644 << 16
            zi.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(zi, files[n])
    with open(tmp, 'rb') as f:
        os.fsync(f.fileno())
    os.replace(tmp, out)
    z = zipfile.ZipFile(out)
    assert z.testzip() is None
    names = z.namelist()
    for n in ('upstream/P0A3H_P1-C0_RECEIPT.json', 'upstream/P0A3H_P1-C1_RECEIPT.json', 'upstream/HUMAN_RELEASE_CERTIFICATE.txt'):
        assert n in names and z.read(n) == files[n], n
    sums = dict(l.split(None, 1)[::-1] for l in z.read('SHA256SUMS').decode().splitlines() if l.strip())
    assert set(sums) == set(names) - {'SHA256SUMS'} and all(sha(z.read(n)) == v for n, v in sums.items())
    inv = json.loads(z.read('PACKAGE_INVENTORY.json'))['payload_files']
    assert {e['path'] for e in inv} == set(names) - {'SHA256SUMS', 'PACKAGE_INVENTORY.json'}
    b = open(out, 'rb').read()
    print(json.dumps({'c2': out, 'bytes': len(b), 'sha256': sha(b), 'members': len(names), 'upstream_receipts_inside_c2': True}))


if __name__ == '__main__':
    main(*sys.argv[1:6])
