# P0A3H-P1 — Pre-run chronology through P1-C1 (UTC, 2026-10-21) · `NO_P1_CANDIDATE_EXECUTION_YET`

| Time | Event | Candidate or P1 test execution? |
|---|---|---|
| 20:37–20:41Z | P1-P0 static feasibility. Fresh clone; P1 `4c1634e6…` authenticated (VALIDSIG D4EC…, one-file diff, blob `557e7783…`); frozen sources verified; dependency map. Result `P0A3H_P1_SCOPE_AMENDMENT_REQUIRED` (reference `identity.py`). Report `50158e25…` and findings `e46b1723…` delivered. | No |
| (operator) | A1 `82dc0d2b…` human-signed; operator builds P1-C0 `067efd1e…` (21:00:47Z); independent C0 QC PASS (C0 only) | — (operator attests no P1 execution) |
| 21:10:33Z | C1 handoff bundle (`49eea050…`) received and read; A1 authenticated (remote tip `82dc0d2b…`, parent P1, one file, blob `a3a27a4f…`, VALIDSIG D4EC…); A1 read in full | No |
| ~21:11Z | **Stopped:** the original P1-C0 was not attached. Requested from the human; nothing built. | No |
| 21:18:47Z | Original C0, receipt and readback received. Outer SHA-256/size, CRC, 19 checksums and 18 inventory entries PASS. | No |
| 21:19:51Z | C0 contents verified: 18-commit first-parent chain equals Git, with every edge and VALIDSIG checked; P1/A1 text hashes; historical reports; nested R2-C1-REV1 and L1-C0; 51-file ledger equals the nested R2 candidate and the agent's own signed-object tree; 11 stdlib records well-formed; receipt and readback agree | No |
| ~21:20Z | Derivative created by copying the reference; exactly 3 files edited by literal replacement (assert-once). Ledger and AST proofs built. Two bugs in the agent's own proof script were fixed and the ledger rebuilt (candidate unaffected). | No |
| 21:21–21:32Z | `p1_external/` authored: fixtures and comparators copied from signed archives; P06A fixture derived by JSON transformation; host pins from C0; P1 schema; builder, runner, verifier, driver and C2 packager written. One verifier correction before lock (the P02 quarantine trigger narrowed to an accepted non-test authority). | No |
| ~21:32Z | Syntax-only `ast.parse(feature_version=(3,11))` of all 6 external `.py` files on the agent's 3.12 parser (not executed); static AST-literal cross-checks of the pins | No |
| ~21:33–21:35Z | Locks written: `P1_CANDIDATE_LOCK.json` `18c7d153…` and `P1_EXTERNAL_LOCK.json` `9689d896…` (23 files). Catalogue, C2 plan, limitations, chronology and README written. C1 assembled. | No |

**Totals before witness:**
- candidate imports: 0
- worker or parser launches: 0
- signature trials: 0
- test keys generated: 0
- P01–P06 executions: 0
- dry runs, smoke runs or numerical previews: 0
- Git writes: 0

P1-P2 and P1-P3 have not begun. The verifier's P01 logic was **not** run against the derivative; structural consistency was checked only by the agent's separate static ledger script.
