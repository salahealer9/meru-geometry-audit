# P0A3H-P1 — Locked portability case catalogue P01–P06 (prospective; NOT executed)

**Authority:** signed P1 `4c1634e6660a02ebdea62195f13fc4810fd08d41` (§6) and signed A1 `82dc0d2b2f2b81f90ec60dfed8e3aade19555d40`.
**Attempt:** one attempt, `P0A3H_P1_DEV_01`, permitted only after the human release `P0A3H-P1-C1 LOCK WITNESSED; SHA-256 <reviewer-verified C1 digest>; AUTHORIZE ONE P0A3H_P1_DEV_01`.
**Implementation:**
- `p1_external/P1_DRIVER.py`
- `p1_case_runner.py`, which is the only module that imports the derivative, and only after release
- `p1_authority.py`, `p1_verifier.py` and `r2_stream_reconcile.py`, none of which import the candidate
- machine-readable expectations in `p1_external/locks/P1_EXPECTED_OUTCOMES.json`

## Command (once, on the operator host)
```
/usr/bin/python3.11 -I -S -B <extracted C1>/p1_external/P1_DRIVER.py \
  --release-sha <released 64-hex> --c1 <original P0A3H_P1-C1.zip> --work <new directory>
```

**Fixed order:**
1. Verify the C1 bytes against the release: SHA-256, CRC, safe and unique names, SHA256SUMS.
2. Extract the C1 contents and check both locks.
3. **HOST_GATE**, with no candidate launch. It checks:
   - `/usr/bin/python3.11` and `/usr/bin/openssl`: regular file, not a symlink, realpath, size and SHA-256 equal the C0 register;
   - the 11 stdlib files under `/usr/lib/python3.11`;
   - Debian 12 on x86_64;
   - that the driver itself runs as `/usr/bin/python3.11` with `-I -S -B`, Python 3.11.2;
   - that `openssl version` begins `OpenSSL 3.0.22`;
   - that `/proc/self` is readable.
4. **P01**, with no candidate launch.
5. P02, P03, P04, P05 and P06, each in its own runner process:
   - interpreter `/usr/bin/python3.11 -I -S -B`;
   - `start_new_session`, environment `PATH=os.defpath, LC_ALL=C.UTF-8`;
   - per-case private key directory (mode 0700) outside the evidence;
   - after each case: driver key scrub, external reconciler, verifier and post-case lock re-check.

**Runner limits (the observer's own, additional):**
- wall time: P02 300 s, P03 180 s, P04 180 s, P05 600 s, P06 300 s;
- RLIMIT_AS 1 GiB, CPU 900 s, NOFILE 256, CORE 0, FSIZE 64 MiB.

**Candidate worker limits:** unchanged policy: 8 s wall, 6 s CPU, 256 MiB, 2 MiB streams and files, NOFILE 32, concurrency 1, recursion 256, 16 MiB run disk, 64 KiB request. The calibration limit of 512 MiB is calibration-only. The supervisor's own `install_limits` enforces these. All runner hard limits are at or above the worker targets, so workers can only lower them.

**Stop rule:** fail-closed. The first case that does not PASS ends the attempt, and later cases become `NOT_RUN_AFTER_FAILURE` or `NOT_RUN_AFTER_QUARANTINE`. A HOST_GATE failure gives `ENVIRONMENT_UNQUALIFIED` with no candidate launch. Any change to a lock after a case gives QUARANTINE.

**Exit codes:**

| Code | Meaning |
|---|---|
| 0 | all six cases passed |
| 1 | failed, evidence preserved |
| 3 | quarantine |
| 2 | stopped before any candidate launch |

## Cases
| Case | Exact construction (inputs locked in `p1_external/fixtures`) | PASS only if (all of) | QUARANTINE if |
|---|---|---|---|
| **P01** source and lineage integrity | Verifier reads the extracted derivative and reference trees and the locks (file bytes and AST literals only) | Derivative equals `P1_CANDIDATE_LOCK` (51 files); reference equals the original `SOURCE_LOCK`; exactly the 3 permitted files differ; all 3 kernels match their pins; production `PROTOCOL/PARENT/ANCESTRY/BASELINE` and reference `PINS` equal the P1 values (18-commit chain); `PINS.schema` and `loaded_code_identity` unchanged; stdlib root `/usr/lib/python3.11` in both identity files and no 3.12 root; policy has only the runtime-identity fields changed, with the locked values; the old authority schema is byte-identical and referenced by no `.py` file; P1 and A1 are pinned. Classification `SOURCE_DIFF_AND_P1_AUTHORITY_BOUND`. | the lock, the reference, a kernel or the three-file set mismatches |
| **P02** local process and runtime identity | `supervisor.run(R2_H01.request.json [735 B, 0807f224…], TEST_AUTHORITY, run_dir P02_R2_H01)` with a fresh `p1-test-key-A` envelope bound to P1 lineage | state `ENGINEERING_EXACT_CERTIFICATE_CANDIDATE_UNVALIDATED`; `NON_PRODUCTION_TEST_AUTHORITY_VERIFIED`; `LOADED_CODE_IDENTITY_UNVERIFIED`; `ALL_WORKER_STREAMS_RECONCILED`; `NEW_CHECKED_RECORD`; reference check `ORIGINAL_INPUT_EXACT_RECOMPUTATION_AND_DIRECT_RESIDUAL`; 4 worker events (calibrate_produce, calibrate_check, produce, check), each with exit 0, interpreter SHA and `command[0]` pinned, the derivative policy digest and attempt id; checkpoint written; caller receipt and envelope bound in every event; external reconciler 8/8 MATCH; runner is `/usr/bin/python3.11` 3.11.2 with I/S/B flags and `/proc/self/exe` pinned; the candidate `identity.environment()` equals the builder's environment, with executable and 11 stdlib digests equal to the pins; certificate request equals the fixture; no private key left | any accepted authority status other than test-only |
| **P03** test-only signature and scope | Valid: both routes (production via OpenSSL, reference via pure Python). Negatives, each signed by the same test key: **N1** trust-store scope `PRODUCTION_CODE_AUTHORITY`; **N2** `revoked: true`; **N3** historical P0A3G lineage envelope; **N4** envelope with the last hex character of `input_sha256` changed (exactly 1 byte), original signature kept; plus an N3 end-to-end controller run | Valid: both routes `NON_PRODUCTION_TEST_AUTHORITY_VERIFIED`. Each negative rejected by both routes, and rejected **at the specified boundary**: production `Boundary CODE_IDENTITY_MISMATCH/EXTERNAL_AUTHORITY_REJECTED` with cause N1/N2 `key scope/revocation`, N3 `envelope authority pins`, N4 `signature`; reference `IdentityMismatch('EXTERNAL_IDENTITY_MISMATCH')` with cause N1/N2 `key`, N3 `authority pins`, N4 `signature`. N4 changes exactly 1 byte. N3 controller run gives `CODE_IDENTITY_MISMATCH`, no worker and no run directory. A rejection at a different boundary is FAIL (invalid negative control), never PASS. | any negative accepted by either route, or the N3 controller succeeds |
| **P04** deployment refusal | P1-lineage envelope with `authority_mode HUMAN_SIGNED_CODE_FREEZE`, `key_id null`, receipt mode `DEPLOYMENT`, no signature and no trust store; no production key exists | `identity.authority` raises `ValueError('REAL_HUMAN_SIGNED_AUTHORITY_ABSENT')`; `identity.verify` raises `Boundary CODE_IDENTITY_MISMATCH/EXTERNAL_AUTHORITY_REJECTED` with that cause; reference raises `IdentityMismatch` with cause `no real human-signed authority`; `supervisor.run(mode DEPLOYMENT)` gives `CODE_IDENTITY_MISMATCH/EXTERNAL_AUTHORITY_REJECTED`, no worker, no run directory, no certificate | any acceptance |
| **P05** frozen QO reference consistency | R2_H01 (from P02 evidence), plus fresh runs of R2_H02 (`27eb835c…`), R2_H03 (`6623fb58…`) and R2_H04 (`27dfd8d5…`, corrigendum geometry) | For each input: all P02 success-run checks, and `w0003.certificate.json` bytes equal the retained R2 certificate bytes: H01 `0b0ef621…`, H02 `eee6abc9…`, H03 `98c6e107…`, H04 `ceaa40fb…`. The canonical result certificate equals those bytes. The reference check output fields (state, certificate_sha256, input_sha256, details, authority_status, loaded_code_identity) equal the retained R2 check output. Any discrepancy is FAIL; a missing comparator is INCOMPLETE. | — |
| **P06** bounded failure and evidence completeness | **A:** `P06A_OVER_LIMIT.request.json` (735 B, `1d963478…`; R2_H01 with `limits.max_vertices` 9 > policy 8). **B:** R2_H01 with the candidate's own registered actual process fault `dev_fault='timeout'` (TEST_AUTHORITY) | **A:** `RESOURCE_INCOMPLETE/REQUEST_POLICY_CAP` before any worker, no run directory, no certificate, `raw_identity` (735 B, prefix SHA) recorded. **B:** `RESOURCE_INCOMPLETE/CONTROLLER_WALL_TIMEOUT`; 3 events (calibrate_produce, calibrate_check, produce); produce worker shows `process_fault timeout`, `controller_timeout` true, returncode −9, elapsed ≥ 8 s; empty stdout preserved (0 B) and partial stderr (`entering injected sleep`) preserved with recorded SHA; no checkpoint; caller receipt and envelope bound in all 3 events; external reconciler 6/6 MATCH | any certificate or success state in A or B |

All cases also require that the runner is the pinned interpreter with I/S/B flags, that no private key is left, that the reconciler ran with no unexplained row, that the runner exited 0, that no key file was left for the driver to scrub, and that both locks are unchanged after the case.

**Not part of P1:** no H01–H07 substitution, shadowing or forgery challenge; no production key; no deployment enablement; no third-party target. Negative controls are synthetic authority records and a request owned by this lane, plus the candidate's own pre-existing `timeout` dev fault.
