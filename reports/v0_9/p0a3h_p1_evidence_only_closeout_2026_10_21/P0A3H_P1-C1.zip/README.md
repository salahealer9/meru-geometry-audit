# P0A3H_P1-C1 — prospective lock for independent witness · `NO_P1_CANDIDATE_EXECUTION_YET`

**Status:** `P0A3H_P1_C1_PREEXECUTION_LOCK_SUBMITTED_FOR_EXTERNAL_WITNESS`. The candidate is labelled `P0A3H_P1_NEW_PORTABLE_SOFTWARE_CANDIDATE_UNQUALIFIED`. This is unsigned engineering evidence. It is not a release, not QC and not a code freeze.

**Authority:**
- P1 `4c1634e6660a02ebdea62195f13fc4810fd08d41` (blob `557e7783…`, parent `8f4163df…`).
- A1 `82dc0d2b2f2b81f90ec60dfed8e3aade19555d40` (blob `a3a27a4f…`, parent P1).
- Signer `D4EC014EEFCC90E619D2AA59A91239ABCF512130`.
- P1-C0 `067efd1e0fb66bc7bf5c61df186d43558ef2a81f223ca90912f67bca23439f5e` (348,416 B).

| Path | Content |
|---|---|
| `reference_candidate/` | Original 51 files, byte-identical to the signed R2-C1-REV1 (`b34a3cd2…`) `SOURCE_LOCK` |
| `derivative_candidate/` | The P1 derivative. Exactly 3 files differ: `schemas/v0_9/p0a3g/resource_policy.json` (3 of the 4 runtime fields changed in value; `openssl` path unchanged), `src/.../identity.py` (lines 20–23 lineage, line 32 stdlib root) and `reference/.../identity.py` (lines 16–17 `PINS` lineage, line 48 stdlib root). The 3 kernels are byte-identical. |
| `lock/SOURCE_LOCK.json` | Original signed 51-file lock (`abff7aa8…`) |
| `lock/P1_CANDIDATE_LOCK.json` | Derivative identity (`18c7d153…`): 51-file map, tree digest `d40ded35…`, before/after for the 3 files, P1 identity values, 18-commit ancestry, policy values, stdlib digests, P1/A1/C0 pins |
| `lock/P1_EXTERNAL_LOCK.json` | Per-file lock of `p1_external/` (23 files) |
| `ledger/` | `P1_DERIVATIVE_LEDGER.json` (51-file before/after, field-level and AST proofs) and `P1_STATIC_SOURCE_DIFF.diff` (complete diff) |
| `p1_external/` | Driver, case runner, P1 authority builder, independent verifier, R2 external reconciler (unchanged `ae18681e…`), C2 packager, fixtures, signed-R2 comparators, new P1 validation schema, host pins, expected outcomes |
| `P1_CASE_CATALOGUE.md` | P01–P06: exact constructions, commands, PASS and QUARANTINE rules, limits, stop rule |
| `P1_C2_RECEIPT_INCLUSION_PLAN.md` | C0 receipt, C1 receipt and release certificate physically inside C2 (enforced by the packager); CFINAL nesting |
| `P1_AUTHORSHIP_LIMITATIONS_AND_FINDINGS.md` | Roles, limitations, unresolved findings |
| `P1_PRE_RUN_CHRONOLOGY.md` | Chronology: zero candidate executions |
| `c0/` | Original C0 receipt and local readback (unchanged bytes); agent ZIP check of C0 |
| `authority/` | Signed P1 and A1 text (blob-verified copies) |
| `handoff_and_c0_qc/` | The C1 handoff and the independent C0 QC files as received |
| `agent_tools/` | Agent-side ledger, ZIP check and builder scripts (no candidate imports) |

`SHA256SUMS` covers every member except itself. `PACKAGE_INVENTORY.json` covers every member except itself and `SHA256SUMS`. The human-readable lock receipt is delivered separately, outside the ZIP.
