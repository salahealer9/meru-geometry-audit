# P0A3H-P1 — Authorship, limitations and unresolved findings (P1-C1)

## Authorship and roles
- **This agent (Claude):**
  - authored the original P0A3E/F/G candidate code (including both `identity.py` files), the R2 and C3 tooling, and this C1: the derivative edits, `p1_external/` and the ledgers;
  - ran the historical P0A3G and R2 tests;
  - prepared P0A3H H-C0, which stopped incomplete after two platform safety interruptions;
  - wrote the P1 two-file feasibility report (`P0A3H_P1_SCOPE_AMENDMENT_REQUIRED`).
  
  **Any review by this agent is author review, not developer-independent review.**
- **P1-C0 builder script:** authored by ChatGPT/GPT-6, according to the C0 register (disclosed there).
- **Human operator:** measured the host profile and attests that no P1 test has been run (C0). The operator will run the attempt and is the sole Git signer.
- **Independent reviewer:** the separate research chat, which produced the C0 QC included under `handoff_and_c0_qc/`.

## Limitations
- **Host pins are operator-measured.** The Python 3.11.2, OpenSSL 3.0.22 and stdlib digests come from the C0 register. The agent did not measure them, and its own host (Python 3.12.3) was never substituted. HOST_GATE re-measures them at release, and drift gives `ENVIRONMENT_UNQUALIFIED`.
- **Static checks only.** All `p1_external` code has been checked only by syntax parse (3.11 grammar on the agent's 3.12 parser) and static reading. Nothing has been executed. Interface errors, if any, will appear as FAIL in the single attempt, and no repair is permitted.
- **Untested assumptions:**
  - U3: OpenSSL 3.0.22 CLI semantics for Ed25519 sign and verify.
  - U4: the CPython 3.11 worker passes the calibration memory rule (VmSize + 64 MiB ≤ 256 MiB).
  - U5: canonical JSON and Fraction results are identical between 3.11 and 3.12 (P05).
  - U6: rlimit enforcement on the operator host; the C0 register shows unlimited current limits, which is not evidence of enforcement.
- **P04 boundary reading.** P04 identifies the `REAL_HUMAN_SIGNED_AUTHORITY_ABSENT` gate through the exception cause chain and the direct `identity.authority` call. The controller-level result exposes only `CODE_IDENTITY_MISMATCH/EXTERNAL_AUTHORITY_REJECTED`, as in the frozen source.
- **P05 comparator provenance.** The comparators are retained R2 outputs from the pre-derivative candidate running on CPython 3.12.3, taken from the signed preservation `e491e1e9…` (R2-C2 `860d93dc…`). Equality is evidence of cross-runtime reproducibility of these four certificates. It is not a new mathematical proof.
- **Lineage note.** The original P0A3G `ANCESTRY` constant omitted first-parent commit `c48c7a60777200a172ae3c72f5b0402162370ec7`. The new 18-commit list is the complete first-parent chain recorded in C0 and verified against Git.
- **Disclosures that remain true:** `LOADED_CODE_IDENTITY_UNVERIFIED` and `PRODUCTION_CODE_AUTHORITY_ABSENT`. There is no hostile-host, TOCTOU or process-memory claim. Same-host operator logs cannot prove the absence of undisclosed runs.
- **Withheld status:** P0A4 is not run and not authorized. The historical negatives remain unchanged:
  - `P0A3F_R1_INDEPENDENT_QC_NOT_QUALIFIED`, `P0A3G_INDEPENDENT_QC_NOT_QUALIFIED`;
  - `R2_QCF01_C2_PRIOR_RECEIPTS_OMITTED`, `P0A3G_R2_INDEPENDENT_QC_NOT_FULLY_QUALIFIED`;
  - `P0A3H_PREFLIGHT_INCOMPLETE`, `P0A3H_L1_PREFLIGHT_INCOMPLETE`;
  - C3 remains an administrative-only PASS.

## Unresolved findings for the reviewer
1. No scope blocker was found: exactly the three permitted files changed, with no formatting-only bytes.
2. **P04 classification:** the reviewer should confirm that reading the required `REAL_HUMAN_SIGNED_AUTHORITY_ABSENT` from the cause chain is acceptable.
3. **P06 choices:** P06 uses the candidate's pre-existing actual `timeout` dev fault as the over-budget probe, plus an over-limit request. The reviewer should confirm that both fit P1 §6.
4. **Strictness of P03 causes:** P03 locks exact cause strings so that each rejection is shown to occur at the intended boundary. This means a correct rejection at a different gate would be recorded as FAIL rather than PASS.
