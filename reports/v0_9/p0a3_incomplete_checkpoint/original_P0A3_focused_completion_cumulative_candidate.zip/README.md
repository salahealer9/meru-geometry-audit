# P0A3 focused completion — cumulative candidate

**P0A3_IMPLEMENTATION_INCOMPLETE. Readiness NOT QUALIFIED; not approved or frozen.**

Start with reports/v0_9/p0a3_implementation/COMPLETION_ENGINEERING_REVIEW.md and
docs/v0_9/p0a3_completion_arithmetic_and_checker.md. Original reports describe
the earlier candidate and remain unchanged historical evidence. The completion
report describes new restricted-domain additions and outstanding blockers.
Neither report is independent QC approval.

New functionality: exact-rational outward square-root/pose bounds; rational-length
QO integration and attained-roll witnesses; independent numerical recomputation;
frame-entry bounds; prospective G0-only whole-circle QH architecture and resumable
cell checkpoints. General algebraic QO, G1/G2 numeric paths and full-domain
qualification remain incomplete. No full-circle numerical run occurred. No
scientific parameters or final viewing tier were selected.

Original ZIP is preserved in lineage/original_P0A3_implementation_candidate.zip:
480345 bytes; SHA-256 079c74ce69b9b94e26ccb346aadc4d1351922921774f7120e9db79e9f320835a.
Original independent QC report, JSON and combined ZIP are included. Attempts
01–04, failures and corrections remain unchanged. Attempt 05 passed 19 fresh
DEV checks; attempt 06 passed 21 after static metadata hardening. The original
42-test suite was not rerun. Commands, snapshots, outputs and diffs are retained.

Reproducibility command used for attempts 05–06, from the package root:

```sh
PYTHONPATH=src:. PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 LC_ALL=C.UTF-8 /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B tests/dev_v0_9/test_completion_microcontracts.py
```

A 60-second engineering subprocess guard was used. This is documentation, not
authorization for registered execution. No installer, dependency change or
repository modification occurred. Both layers use Python/Fraction; no numerical
kernel is imported from production into reference. Independent QC remains needed.

Full original-to-revised text diffs and file-level hash ledger are in diffs/.
Self-referential packaging metadata is excluded from its own diff and instead
inventoried/checksummed. Binary lineage archives are preserved whole with hashes.
Root inventory gives payload hashes/lengths; SHA256SUMS also hashes inventory
and excludes itself. Outer ZIP digest is supplied separately.

Source classes remain SOURCE_ATTESTED, SOURCE_CONSTRAINED_INTERPRETATION,
INDEPENDENT_DIAGNOSTIC, NULL_CONTROL, UNRESOLVED. New code is INDEPENDENT_DIAGNOSTIC.
Missing crop, two image exclusions, incomplete historic DEV, nonidentical P0A1
recovery, GPG-agent caveats, A09 metadata-only status and missing historical
three functions/carrier/optics remain unchanged.

NO_HEBREW_TARGET_ANALYSIS_PERFORMED; NO_P0A0_REGISTERED_PILOT_REPLAY;
NO_REGISTERED_NUMERICAL_CERTIFICATION_EXECUTED; NO_CANDIDATE_NULL_EXECUTION;
NO_AGENT_COMMIT_OR_PUSH; EXISTING_FROZEN_REPOSITORY_FILES_UNCHANGED within the
documented pinned-source/archive scope; QO_QH_CONDITIONAL_NOT_HEBREW_SCORES;
A_B_EXACT_DIRECTION_FAMILIES_NOT_FINAL_EXPERIMENTAL_TIERS;
QO_A_QO_B_QH_A_QH_B_GLOBAL_CERTIFICATION_DEFERRED;
HISTORICAL_FIRST_HAND_SHADOW_MODEL_NOT_ESTABLISHED;
P0A3_NOT_INDEPENDENTLY_APPROVED_OR_FROZEN.

Independent QC must review this revised partial candidate before any human-signed
implementation freeze. P0A4 additionally requires a separately signed protocol,
frozen cases/oracles/error/resource rules and explicit one-run authority. No
target-access gate is opened.
