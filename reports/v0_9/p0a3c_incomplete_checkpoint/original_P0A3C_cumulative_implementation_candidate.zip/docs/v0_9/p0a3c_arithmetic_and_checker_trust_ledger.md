# Arithmetic derivations and checker trust

[UNRESOLVED] These are reviewable derivations and candidate implementations,
not machine-checked proofs or independently approved numerical certificates.
O/H/CAP/F statuses are in the requirements matrix. Assertion tags distinguish
frozen facts, mathematical arguments, implementations and DEV observations.

## A1 — interval operations

[MATH DERIVATION] Endpoints are exact Python Fraction rationals. Addition and
subtraction use endpoint monotonicity; multiplication takes all four products;
division inverts an interval only when zero is excluded. Squaring uses zero as
the lower endpoint if the interval straddles zero. There is no binary64 rounding.
To enclose √x on denominator 2^b, production computes
k=floor(√floor(x*2^(2b))) using integer isqrt. The lower endpoint is k/2^b and
the upper is (k+1)/2^b unless the exact squared lower equals x. Exact rational
comparisons prove lower²<=x<=upper². The reference searches the same integer
lattice by bisection, with no isqrt call or shared interval class.

[UNRESOLVED] Common-mode trust includes CPython integer/Fraction semantics,
standard-library parsing, and the correctness of these mathematical arguments.
Two Python implementations are not an independently trusted arithmetic runtime.
There is no formally verified backend, general algebraic sign oracle or finite
bit-growth theorem. Component containment tests do not establish all operations.

## A2 — projection, sets and moments

[MATH DERIVATION] The integer/radical frame identities are stated in the contracts.
Production constructs them in p0a3c_geometry.observation; reference obtains the
same mathematics through separately retained literal_directions.exact_lift_witness.
The latter checks norm, orthogonality and determinant using exact integers.
Common positive denominators make coincidence equality a rational numerator
test. QH mean and variance are exact rational in this representation. Normalized
coordinates are a_j/√(D_j V); rho²=max Σa_j²/D_j / V, also exact rational.

[IMPLEMENTED_UNVERIFIED] Every A/B vector reaches this same algebraic path;
there is no G0-only dispatcher. Separate DEV checks exercised corner and 2:1
frames numerically and all 50 stratum triples structurally. This is not uniform
numerical certification of every input/frame/branch combination.

## A3 — independent QO integration

[MATH DERIVATION] On a segment of normalized duration h with endpoints x,z,
its mean contribution is h(x+z)/2. Around a common centroid, its variance is
h*(|(x+z)/2|²+|z-x|²/12), a sum of nonnegative terms. For two affine functions
with endpoints x,z and y,w on the same interval, their product integral is
h*(2xy+xw+zy+2zw)/6. Production uses these formulas and interval-affine
interpolation at every segment-pair intersection. Intersection endpoints are
lo=max(starts), hi=max(lo,min(ends)); an empty exact intersection has width zero.
Interval dependence may enlarge width and products but does not remove any
actual integral. Thus no unproved algebraic knot ordering is silently selected.

[MATH DERIVATION] Reference instead builds global-u slopes/intercepts, integrates
the polynomial primitives m*n*u³/3+(m*c+n*b)*u²/2+b*c*u, and computes its own
centroid, centered variance, normalization and correlations. Reversal uses
(m,b)->(-m,b+m), with u->1-u endpoints. Production reverses vertices and knots.
Reflection changes y signs in both derivations. The independent routes share
the same frozen estimand and finite segment-overlap decomposition, not code.

[MATH DERIVATION] Cauchy–Schwarz bounds r=√(α²+β²)<=1 for independently unit-RMS
paths. Intersecting an enclosure with [0,1] and QO² with [0,2] uses that theorem;
it is not a floating tolerance clamp. Empty intersection is a contradiction
requiring STOP. Nonnegative variance/distance square intersections likewise use
their exact geometric definitions. They must not hide a genuine inconsistency.

[UNRESOLVED] No generic exact-zero correlation predicate exists. The exact
expression witness requires r>0 or a proved exact tie. Near-zero or exact ties
can remain unresolved indefinitely at fixed supplied precision. The reference
is especially dependent near large translations/small extents; a failure to
establish positive RMS or contain its interval is fail-closed, not disproof of
the mathematical objective. No precision is automatically increased from scores.

## A4 — independent QH distances and lower bounds

[MATH DERIVATION] Production explicitly rotates normalized coordinate intervals
and computes sums of squared differences. Reference uses exact normalized norm
squares minus twice the normalized dot product. For centered numerators (x,y)
and target (z,w), with source denominator squares D0,D1 and variances Va,Vb,
the dot is x(cz+sw)/√(D0 Va Vb)+y(-sz+cw)/√(D1 Va Vb).
Reflection first replaces y by -y. Reference separately constructs both directed
nearest-distance extrema and their symmetric maximum. Rational c²+s²=1 proves
the feasible real-angle witness. Its radius is independently reconstructed.

[MATH DERIVATION] The circle coverage and Lipschitz lower-bound arguments are
in the contracts, with independent enumeration and recomputation in the checker.
The checker verifies that production intervals contain its independently
computed bounds, rather than trusting claimed hashes, point caches or labels.
Containment is sufficient conditional on the independent interval derivation;
it need not prove identical endpoints. Overlap without containment is
InconclusiveVerification. Disjoint genuine enclosures are an
IndependentContradiction and a mandatory STOP/quarantine condition. The forged
DEV record deliberately produces such a rejection; it is labeled negative
evidence and is not a contradiction on genuine numerical evidence.

## A5 — import graph and trust roots

[IMPLEMENTED_UNVERIFIED] Production path: p0a3c_engine -> p0a3c_scores ->
p0a3c_geometry -> p0a3c_interval; directions imports original contracts.
Reference path: p0a3c_checker -> p0a3c_oracle -> literal_directions. The reference
numerical dependency graph contains no production imports. p0a3c_resume imports
both sides as orchestration; it is not claimed to be an independent reference
kernel. AST source/import inventory and exact bundle hashes accompany this ZIP.
No new third-party numerical dependency is installed or used by the new kernels.

[IMPLEMENTED_UNVERIFIED] External expected request/production/reference digests
are required at checker entry. The checker recomputes raw input hashes, checks
live .py bundle hashes, all task ordering/partition data, each completed witness
and interval, aggregation and epsilon status. It does not cryptographically
attest data origin, the Python interpreter, dependencies, OS, concurrent writers
or future actual controls. Source hashes bind files, not loaded-code integrity
against hostile runtime mutation. `live_pins` must not be confused with trust.

[UNRESOLVED] Malformed deep JSON, arbitrary failure strings, adversarial resource
use and every exact degeneracy have not been independently qualified. Failure
records are structurally accepted as sticky incomplete states; the checker does
not prove that the asserted failure reason was inevitable. A post-advance
inconclusive check raises; the API does not automatically persist the newly
computed but unverified state. These are B05/B06 blockers, not hidden successes.

## Source-claim classes

[FROZEN RESULT] Retain SOURCE_ATTESTED, SOURCE_CONSTRAINED_INTERPRETATION,
INDEPENDENT_DIAGNOSTIC, NULL_CONTROL and UNRESOLVED as
distinct P0A1 provenance classes. All new code/DEV mathematics is
INDEPENDENT_DIAGNOSTIC. No source attestation is inferred from a numerical fit.
