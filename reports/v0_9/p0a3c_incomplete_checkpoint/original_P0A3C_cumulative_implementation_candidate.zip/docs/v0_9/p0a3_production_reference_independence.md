# I5 — Production/reference independence

Draft candidate; provenance class **INDEPENDENT_DIAGNOSTIC**. No target,
historical-shadow, scientific certification or independent-QC approval.

Source categories remain SOURCE_ATTESTED, SOURCE_CONSTRAINED_INTERPRETATION,
INDEPENDENT_DIAGNOSTIC, NULL_CONTROL and UNRESOLVED. Only INDEPENDENT_DIAGNOSTIC
applies to this new implementation; algorithmic independence is not historical
source authentication.

## Dependency graph and genuinely different algorithms

| Production | Separate reference/checker | Shared boundary / distinction |
|---|---|---|
| qo.parameterize/correlations: binary64 segment lengths, local endpoint product integration on merged breakpoints | reference/v0_9/qo_rational.py: Fraction lengths (rational-square only), global-u polynomial antiderivatives over every intersecting segment pair | Mathematical contract shared; no code, normalization, breakpoint merge, tie or cached output imported from production. Exact squared residual represented as a rational/symbolic radical. |
| qh.normalize/pair_extrema: distinct binary64 set, centered floats, streamed Euclidean nearest distances | reference/v0_9/qh_exact.py: explicit rational duplicate membership, exact means/variances, full pair matrix in a common quadratic extension; extrema by exact surd sign comparisons | Separate algorithms and arithmetic; only fresh integer/rational input meaning shared. Rotation reference accepts exact rational unit (cos,sin), not arbitrary floating theta. |
| directions.py: sign products/permutations and integer pattern validation | literal_directions.py: manually listed A0/C/E/T witnesses in exact canonical order | Independent fixed membership tables, independent JSON digest. No generator reuse. |
| frame_lift: registered normalized Gram construction then numerical cross product | literal_directions.exact_lift_witness: integer numerator/radical expression and exact dot/norm/determinant identities | Same mathematical theorem, different arithmetic realization. This does not bound rounding in production. |
| projection.project: binary64 matrix/point products | projection_exact.project: Fraction numerator over symbolic radical for each coordinate | No production projection import; exact expressions do not provide a floating enclosure. |
| certificates.py: immutable prospective request/schema guards | certificate_checker.py: independent keys/pins, literal manifest, every branch, rational seam partition, proposed bound/gap consistency | Structural independence established by imports; **numerical enclosure and feasible-witness checker NOT_IMPLEMENTED**. No structural success can confer certification. |
| serialization.py: exact key checks, strict dataclass reconstruction and finite JSON | DEV hand-written invalid payloads and deterministic roundtrip | No claim of independent formal serialization proof. |

Import DAG (all relative names are within their own namespace):

- production qo/qh → contracts, exceptions; projection → directions, contracts,
  exceptions; directions → contracts, exceptions; serialization → contracts,
  exceptions; certificates → contracts, exceptions. Standard library only.
- reference qo_rational → fractions, math.isqrt; qh_exact → fractions.
- reference projection_exact → reference literal_directions; reference
  certificate_checker → reference literal_directions. Neither imports production.
- DEV tests import both layers to compare independent outputs; tests are not oracles.

No production call into a reference, no reference call into a production
numerical kernel, no lazy eval/import of P0A0, no files/network access in score
kernels. The static DEV import check is supporting engineering evidence; human
source review remains required. Reusing the registered mathematics and input
schema is intentional, not a claim of independent discovery.

## Limits that must not be hidden

Production and reference use the same Python 3.12.14 interpreter/standard
library. They have separate source modules/algorithms, **not separate operating
systems, interpreters or formally isolated dependency stacks**. No package was
installed and no existing environment changed. SymPy is absent. Fraction
arithmetic is exact for its rational domain; it is not an arbitrary real or
algebraic backend.

- General irrational segment lengths in QO exact integration are explicitly
  rejected as UNRESOLVED_PROOF. Rational-length polylines have exact algebraic
  residual expressions; this is a narrower implemented oracle, not all O1–O5.
- General-angle transcendental QH enclosures are not implemented. Rational unit
  rotations have an independent exact surd reference; no full-circle numeric
  certificate results from it.
- Directed/outward interval arithmetic, witness recomputation enclosures,
  whole-domain numerical proof validation, SEP/COV/ROUND and continuous-camera
  Lδ certificates are NOT_ESTABLISHED/DEFERRED.
- The certificate checker checks structural assertions and provenance equality
  only. Hash equality is not truth of an arithmetic proof. Even a complete
  record returns UNRESOLVED_PROOF.
- GLOBAL_CERTIFIED and BOUNDED_APPROXIMATION exist in the status vocabulary but
  construction/deserialization/promotion of a claimed scored result with either
  is forbidden in P0A3. There is no hidden success Boolean or override token.

Thus source separation is implemented, but **full-domain independent oracle
coverage is NOT_ESTABLISHED**. P0A3_REFERENCE_INDEPENDENCE_NOT_ESTABLISHED applies
to the missing general numerical proof route, not an allegation of shared
production kernels in the implemented exact subdomains. P0A3_IMPLEMENTATION_INCOMPLETE
is retained for the missing arithmetic/proof backends. These cannot be repaired
by relabeling the bounded DEV checks as certification.
