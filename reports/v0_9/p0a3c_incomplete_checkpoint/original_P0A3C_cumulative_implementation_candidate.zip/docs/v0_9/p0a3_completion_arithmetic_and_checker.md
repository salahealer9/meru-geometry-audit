# Focused continuation: arithmetic, domains and independent verification

**Candidate implementation only; INDEPENDENT_DIAGNOSTIC.** This supplements,
not rewrites, the signed protocol and original API documents. The original
binary64 APIs retain their original uncertified semantics. New APIs are separate
explicit lanes, not silent upgrades of their results. No P0A3 readiness, P0A4
certificate, primary score or final experimental setting is assigned.

Source classes remain SOURCE_ATTESTED, SOURCE_CONSTRAINED_INTERPRETATION,
INDEPENDENT_DIAGNOSTIC, NULL_CONTROL, UNRESOLVED. No code authenticates historical
three functions, deformation, carrier, optics, target rights/order or shadows.

## Exposed domains and API contracts

| New API | Domain and output | Unsupported / still deferred |
|---|---|---|
| exact_bounds.sqrt_bounds(x,bits) | Nonnegative exact rational x, explicit integer bits; rational outward endpoints | No float conversion. bits 1..4096 is an implementation resource cap, not a selected scientific precision |
| qo_exact_candidate.evaluate(a,b,bits,allow_reversal,allow_reflection) | Each ordered coordinate sequence explicitly denotes one open piecewise-linear path; rational coordinates and rational Euclidean segment lengths. All permitted branch raw correlations, exact tie list, algebraic attained-roll witness, RMS and objective enclosures | No inferred order/closure/strokes; caller must supply this mathematical interpretation. General irrational lengths, arbitrary target observations, all-camera QO driver absent |
| exact_bounds.qh_enclosure(a,b,cosine,sine,mirror,bits) | Nonempty positive-extent rational finite planar supports; exact duplicates removed; rational unit (cos,sin); both directed extrema enclosed | Not an arbitrary floating-angle API; no hidden conversion from approximate radians; no scientific global status |
| exact_bounds.frame_enclosures(triple,bits) | Nonzero exact integer triple; canonical exact proper lift entries enclosed rationally | Frame-entry enclosure is not a continuous-camera regularity, SEP or COV result; arbitrary huge input complexity not bounded |
| qh_circle_candidate.request/start/advance | Supplied rational 3D vertices and rational planar support; A or B G0; explicit group, permission, bits, partition level, epsilon and source/config/resource pins | G1/G2 rejected, never silently replaced by G0; no historical shadow or candidate generator; complete engine not executed here |
| numerical_checker.check_qo/check_pose/check_frame/check_checkpoint | Independently recomputed exact input-domain quantities, bounds, witnesses, manifest, observation and cell coverage | Same interpreter/stdlib; full algebraic/G1/G2 oracle missing; independent human review not performed by this checker |
| checkpoint_io.save | Atomic UTF-8 canonical checkpoint replacement at a caller-authorized path; file and parent-directory fsync | Local filesystem semantics only; no universal crash/remote filesystem guarantee; caller must not name a frozen repository path |

Exact input encodings are integer, Fraction or rational string, never bool/float.
Public serialized rationals use canonical numerator/positive-denominator strings.
Inputs are not interpreted as target glyphs, fonts, ink masks, surfaces or graphs.
The caller's declaration of generic provenance is not a forensic origin proof.
All old production/reference modules and the original 42-test file remain
byte-identical; new functionality is in new source files only.

## Mathematical proof arguments for independent review

These are static derivations supporting candidate code; DEV success does not
prove implementation correctness. Exact hypotheses are part of every argument.

### A1 — Outward square roots without floating arithmetic

For x=p/q≥0 and M=2^bits, compute k=isqrt(floor(p M²/q)). Then
k²≤p M²/q<(k+1)², hence k/M≤sqrt(x)<(k+1)/M. If (k/M)²=x exactly, both endpoints
are k/M. Every comparison and operation uses Python arbitrary-precision integers
or Fraction. No reliance on hardware rounding mode, Decimal precision or an
unproved transcendental library. Endpoint width is at most 1/M, not a relative
accuracy guarantee. Very small positive radicands may have lower endpoint zero;
they are never asserted equal to zero unless exact equality was established.

### A2 — QO exact rational-length integrals and roll witness

If every segment length is rational, normalized arclength breakpoints are
rational. Removing only consecutive repeated vertices retains the parameterized
path, including retracing. On each common interval, affine coordinates are
determined by endpoints. The integral of product with endpoint values a,b and
c,d over width h equals h(2ac+ad+bc+2bd)/6. Centroids and centered second moments
are rational. Production uses merged breakpoints and this endpoint identity;
reference uses global-u polynomial antiderivatives over all intersecting segment
pairs, independently computes means/variances and exact extrema.

Write unnormalized correlations A,B and positive variances Va,Vb. The exact
normalized correlation-square ratio r=(A²+B²)/(Va Vb) lies in [0,1] by
Cauchy–Schwarz. Every traversal/reflection branch is enumerated; minimizing QO
equals maximizing rational r, so all exact tied branches are decidable here.
The chosen branch's minimizing rotation is
(cos theta,sin theta)=(A,B)/sqrt(A²+B²), or (1,0) when A=B=0, with whole-roll tie
explicit. This algebraic unit pair is an attained rotation, not an approximate
atan2 witness. No approximate angle must be certified to define it.

The objective is sqrt(2−2sqrt(r)). Enclose its inner root by A1, transform the
interval monotonically, intersect squared-score lower bound with the PROVED
nonnegative range, and enclose the outer root. This is a mathematical interval
intersection, not clipping a floating residual to a perfect match. A positive
upper bound survives unresolved near-zero uncertainty. r=1 yields exact zero.
Independent checks compare proposed endpoints against exact radical expressions
using rational sign/square tests and recompute all branches and the witness.
RMS bounds and consecutive-omission records are also recomputed. General
irrational segment lengths are explicitly refused, not approximated as rational.

### A3 — QH independent pair-distance bounds

For centered rational coordinates x,y, variances Va,Vb>0 and exact rational
rotation Q, each normalized squared distance is a+b sqrt(D), D=Va Vb,
a=|Qx|²/Va+|y|²/Vb and b=−2(Qx·y)/D. Production encloses sqrt(D) by A1, applies
the sign-aware rational affine map, intersects with proved squared-distance
nonnegativity and encloses the outer square root. Min and max are coordinatewise
monotone, so separate lower/upper endpoint minima and maxima enclose both
directed Hausdorff extrema and their symmetric maximum.

The reference does not reuse production roots, pair loops or normalization.
Existing qh_exact reconstructs distinct rational sets, exact means and variances,
the full pair matrix in a common quadratic extension, and extrema via exact
sign comparisons. A proposed root enclosure [l,u] is checked by proving
l≥0, a+b sqrt(D)−l²≥0, and u²−a−b sqrt(D)≥0. Exact sign tests square only after
separating sign cases. Thus supplied endpoints are verified against independently
recomputed geometry, not trusted because their hashes match. Arbitrary floating
angles remain unsupported, but rational unit pairs supply exact feasible
witnesses and a dense circle parameterization for the prospective engine.

### A4 — Exact frames and G0 projection

For integer v, s=v·v, j=argmin |v_j| with xyz tie order, d=s−v_j²>0, the lift has
integer numerators (s e_j−v_j v, v×e_j, v), denominator squares (sd,d,s).
The inherited exact identities establish row norms, orthogonality and positive
determinant. Production encloses n/sqrt(D) as (n/D)sqrt(D) by A1; reference uses
the independently implemented integer identities and exact radical endpoint
comparisons. This concerns the exact desired frame, not error certification of
the old binary64 frame routine. For G0 all denominators equal one, so projected
coordinates are exact rational signed coordinate selections; production and
reference derive them separately. General G1/G2 frame enclosures are implemented
but propagation into coincidence-sensitive normalized supports and full QO/QH
certificates is not. No rounding proof for that unsupported full domain is claimed.

### A5 — Complete circle charts and cell lower bounds

Use four closed charts theta=k*pi/2+2 atan(t), t∈[0,1], k=0,1,2,3. They cover
the circle exactly with shared boundary endpoints and disjoint interiors. The
rational point ((1−t²)/(1+t²),2t/(1+t²)), rotated by k quarter turns, is exact.
Uniform dyadic parameter cells [i/2^level,(i+1)/2^level] cover each chart. Their
midpoint is rational; since dtheta/dt=2/(1+t²)≤2, every cell point is within
angular distance at most hi−lo of its midpoint. This bound is in radians and
does not approximate pi. It is not a new objective or a changed circle domain.

For fixed normalized projected support, rho=max|x| has an independently checked
upper bound. Frozen Lipschitz theorem gives cell lower
max(0,center_lower−rho_upper*(hi−lo)). A center upper bound is a feasible witness
upper bound. Every G0 direction, explicit mirror branch, quadrant and cell is
enumerated canonically. Only after every numeric cell passes independent checks
may prospective L=min cell lower, U=min witness upper and U−L≤caller epsilon be
reported as checked bookkeeping. The API still reports
GLOBAL_CERTIFICATION_DEFERRED and NOT_GRANTED, never GLOBAL_CERTIFIED or
BOUNDED_APPROXIMATION in P0A3. No complete numeric evaluation was performed in
this continuation. Epsilon/level/bits are required caller inputs, not chosen
experimental parameters. G0 support is an explicit implementation restriction,
not a final viewing-tier choice.

### A6 — Checkpoint completeness and pin semantics

A checkpoint includes the exact request, request hash, ordered completed records,
full unvisited cell suffix, explicit failure, stop reason and noncertified status.
The external expected request is mandatory on resume/check: trusting the request
inside a file alone is insufficient. It contains source/reference/config/resource
pins and exact manifest; the caller/reviewer must establish those pins against
frozen code. DEV pins are explicitly synthetic schema probes, not code identities.
Production resume regenerates the plan and recomputes every completed cell,
rejecting modified witnesses or missing/reordered cells. Independent checker
reconstructs literal directions, projects source inputs independently, recomputes
pose bounds and rho, checks all branch/cell identities and aggregates only a
complete valid cover. No invalid view can be dropped to improve a minimum.

Completed-prefix replay can be expensive. Wall deadline is cooperative BETWEEN
new cells, starts after resume validation, and cannot preempt a Fraction operation.
The deterministic max_cells budget is the primary resumable work control. Atomic
save provides caller-directed persistence; the caller must save returned state.
An external hard kill inside a cell retains only the last saved checkpoint;
that cell remains pending, never silently completed. Failure states are sticky
and require review, not automatic retries. OS/process supervision and bounded
bit-growth/whole-call runtime proofs remain engineering blockers. No actual
timeout, crash or full completed-circle run was exercised here.

## Independence DAG and trust boundary

| Production | Independent route | Shared trust, not shared kernel |
|---|---|---|
| exact_bounds Fraction/isqrt enclosures and streamed extrema | qh_exact Fraction/surd pair matrix + numerical_checker endpoint sign predicates | Python/Fraction, mathematical definition and input encodings only |
| qo_exact_candidate endpoint integrals + merged breakpoints | qo_rational global-u antiderivatives + all segment intersections | Exact rational mathematics, no normalization/integration helper import |
| directions generated patterns + exact_bounds frame expressions | literal_directions manually listed triples + integer identity witnesses | Signed set/frame definitions; no production generator call |
| qh_circle_candidate source projection, chart loop, cells and checkpoint | numerical_checker independent axis observation, complex quarter-turn formula, literal complete plan, recomputed geometry | Request schema and pinned inputs; no search/production import |

Reference numerical_checker imports only fractions/json/hashlib and its reference
siblings. Production imports no reference. Both run in the same Python 3.12.14
standard library; there is no separate interpreter or formally verified Fraction
backend. No external package installed. Existing binary64 APIs remain separate.
Checkers are candidate code requiring independent source QC, not self-authorizing
proof authorities. Restricted-domain independent numeric coverage is improved;
full-domain P0A3_REFERENCE_INDEPENDENCE_NOT_ESTABLISHED remains.
