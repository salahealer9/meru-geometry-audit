# Future P0A4 design only — NOT AUTHORIZED / NOT RUN

[DEFERRED] Current P0A3C_IMPLEMENTATION_INCOMPLETE does not open P0A4. Resolve
mandatory algebraic degeneracy, checker and resource obligations under appropriate
authority first. A separately signed restricted-domain proposal would be a new
scope, never an automatic downgrade of the current acceptance domain.

[DEFERRED] After independent engineering QC and a separate human GPG-signed
code-only freeze, a new P0A4 preregistration must bind the exact implementation,
reference, interpreter/dependencies, schema and code bundle hashes. It must fix
external expected request hashes; independent generic fixtures/oracles; rational
input sizes; all admitted A/B camera, reflection/traversal and circle branches;
error budgets, precision/gap targets and stopping/resources selected independently
of observed results. No final values or fixture coordinates are selected here.

| Proposed requirement | Future independently chosen evidence |
|---|---|
| General algebraic QO | Separate exact-symbolic or validated interval oracle; normalized moments, α/β, objective, attained witness, exact/near ties |
| Finite-set QH | Exact coincidences, near coincidences, positive/small/collapsed extent; independently proved both directed extrema |
| Circle and finite cameras | Full certified cover and every discrete branch; seam/wrap checks; minL/minU; missing-branch negatives |
| Checker independence | Different algorithm/runtime where feasible; external pins; forged input, witness, bound, partition and status rejection |
| Resource/restart | Signed whole-call limits; kill/timeout/memory failure policy; verified last durable state; no dropped invalid views |
| Uniform eligible domain claims | Proved conditions/separation bounds or honest unresolved classification; tests alone cannot establish universality |
| Scientific boundary | Generic target-free mathematical observations only; historical/target/control gates remain separate |

[DEFERRED] The future registration must specify exactly one authorized execution,
full commands/environment/log retention, failures and mandatory STOP conditions,
then independent QC. No P0A0 case, coordinate/oracle/evaluator import or replay;
P0A3/P0A3C DEV must not be counted as registered certification results. No actual
candidate/null distributions, Hebrew metric choice, G1/G2 hierarchy, rights or
source-image processing is supplied by this design.
