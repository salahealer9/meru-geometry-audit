# P0A3C candidate contracts — incomplete engineering implementation

[UNRESOLVED] Disposition: P0A3C_IMPLEMENTATION_INCOMPLETE and
P0A3C_INDEPENDENT_CHECKER_UNQUALIFIED. This document describes additional code,
not independent approval, implementation freeze or numerical certification.
No existing production entry point is silently replaced. New symbols have the
p0a3c_ prefix; the original candidate remains intact in source and archived bytes.

## Authority and declared domain

[FROZEN RESULT] Protocol commit 01270ec3bff3c9a6352c5dadc90d5d9f12da0c0d,
blob 1a54a5c0626d329e1c7389ca389a907139b8413f, parent
8adbc226b1ef7234a9bedab02ca515a6c11e5c4f; signer
D4EC014EEFCC90E619D2AA59A91239ABCF512130. C0 evidence is in the accompanying
provenance directory. Its historical draft banner is preserved, not edited.

[IMPLEMENTED_UNVERIFIED] QO accepts one ordered open rational 3-D vertex sequence
and one independently supplied ordered open rational 2-D sequence. QH accepts
finite rational 3-D/2-D observations and makes a distinct support separately in
each view. A request's score explicitly determines these semantics. The arrays
are declared mathematical inputs, not inferred historical representations.
No stroke-order selection, closure, permutation, crop, cyclic shift, scale fit,
mask, optical model, continuous silhouette, glyph or target intake is implemented.
Numbers are integers or Fraction-compatible rational strings; bool and binary64
are rejected. The request wire format uses JSON integer/string coordinates.
Caller caps on count and input bit length bound resource admission. There is no
claim to decide every eligible rational case at a fixed precision.

[IMPLEMENTED_UNVERIFIED] Products QO_A/QO_B/QH_A/QH_B all have implemented paths
through exact algebraic frames and the finite task manifest. **None is declared
code-complete on the mandatory eligible domain.** QO zero-correlation decisions
and general checker/resource completion remain unresolved. A representable
interval is not a complete-domain solver guarantee.

## API and deterministic request

[IMPLEMENTED_UNVERIFIED] `p0a3c_engine.validate/tasks/start/evaluate_task` and
`p0a3c_resume.advance/save/load` are the new APIs. `p0a3c_checker.check` is the
separate reference verifier. Do not use the low-level `advance_verified` receipt
as a trust signature: it is an accidental-stale-state guard, and is trivially
reproducible by a caller. The public resume wrapper performs independent checks
before and after advancement. No CLI scientific runner is enabled by this ZIP.

| Request field | Exact meaning |
|---|---|
| schema | p0a3c-request-1; exact key set required |
| score, family, tier | QO or QH; A or B; 0/1/2; no primary choice |
| convention | SO2 signed views; O2 antipodal axes requires explicit reflection |
| reflection, reversal | explicit booleans; QH reversal forbidden |
| source, target | rational coordinate arrays, dimensions 3 and 2 |
| bits, checker_bits | fixed supplied precisions, 2 <= bits <= checker_bits <= 4096 |
| level | fixed QH dyadic chart level 0..16; no adaptive tuning |
| epsilon | positive exact rational; scientific value remains unselected |
| limits | positive max_vertices/max_input_bits/max_cells/max_steps |
| authority | pinned P0A3C commit above |
| information_barrier | GENERIC_TARGET_FREE_ONLY; declaration, not forensic proof |

[IMPLEMENTED_UNVERIFIED] Canonical JSON is sorted ASCII keys, compact separators,
finite integer/string values. Source/target arrays and full request have SHA-256
identities. External pins bind that request and live source/reference .py bundle
hashes. `live_pins` is a hash utility, not a trust-establishment ceremony. Future
independent QC/human freeze must supply expected hashes outside the certificate.
DEV captures its own temporary pins explicitly; these are not signed production
pins. All results retain GLOBAL_CERTIFICATION_DEFERRED.

## Exact camera and normalization semantics

[MATH DERIVATION] For integer viewing vector v, set s=v·v; choose j of smallest
|v_j|, breaking ties x,y,z; d=s-v_j². The first two frame rows are
u/√(s d), w/√d, with u=s e_j-v_j v and w=v×e_j. Their exact dot products vanish,
squared norms are s d and d, and det(u,w,v)=s d. For all admitted family vectors
d>0. This gives a proper frame and leaves each projected point as two rational
numerators divided by common positive square roots. Equal projected points are
exactly equal numerator pairs. No floating comparison or tolerance merge occurs.

[IMPLEMENTED_UNVERIFIED] QH sorts distinct numerator pairs, computes their exact
rational centroid and variance Σ((x_j-μ_j)²/D_j)/N, and normalizes with interval
roots of D_j*variance. Zero variance is NOT_EVALUABLE. Positive variance whose
root enclosure fails to exclude zero is unresolved at the supplied precision.
The radius is enclosed from the exact rational max norm² / variance. Both
directed all-pairs Hausdorff extrema are enclosed by monotone interval min/max.

[IMPLEMENTED_UNVERIFIED] QO removes only consecutive exactly equal projected
numerators and records their original indices. Nonconsecutive returns/retracing
remain. Segment length radicands are the exact rational sums Δx_j²/D_j, directly
reconstructible from the retained numerators and denominator squares. Durations
are length/total length; knots are prefix length/total length. Independent planar
arclength centroids and RMS radii are enclosed before analytic roll elimination.
Near-zero extents are not assigned an arbitrary positive cutoff or zero score.

## Branches, witnesses and tie records

[IMPLEMENTED_UNVERIFIED] Camera order is the frozen stratum order with sorted
signed triples. A counts 6/14/26; B counts 6/18/42. Each selected reflection and
QO reversal branch is enumerated explicitly. O2 selects the first-nonzero-positive
antipodal representative and includes both reflection branches. Signed SO2 views
remain the default mathematical contract, not an experimental selection.

[MATH DERIVATION] QO α=∫a·b, β=∫(a_x b_y-a_y b_x); optimizing proper planar roll
gives r=√(α²+β²), QO²=2-2r. For r>0 the attained rotation has (cos,sin)=(α/r,β/r).
The witness descriptor denotes these exact expressions on the pinned inputs;
its interval components are enclosures, **not arbitrary selectable coordinates**.
If exact zero is established, every rotation attains the score and (1,0) is used.
If intervals contain zero without resolving the equality, the witness remains
UNRESOLVED_ZERO_CORRELATION, and no complete candidate status is issued.

[IMPLEMENTED_UNVERIFIED] The current backend detects a whole-roll tie only when
both correlation enclosures are singleton zero. It lacks a general algebraic
zero/equality predicate or separation bound. Overlapping branch intervals are
possible minimizers, never declared equal. Singleton exact ties are separately
listed; `overlap_is_equality` is always false. A single possible minimizer does
not bypass witness checks. Lower precision can leave denominators unresolved.

## QH circle cells and finite pooling

[MATH DERIVATION] Chart q=0,1,2,3 maps t∈[0,1] to angle qπ/2+2atan(t).
The exact unit pair before the quarter turn is ((1-t²)/(1+t²),2t/(1+t²)).
The charts cover the circle, including overlapping endpoints and wraparound.
Level l divides each chart into closed dyadic cells [i/2^l,(i+1)/2^l]. Their
interiors are disjoint; shared boundaries intentionally occur twice and are not
counted as extra viewing directions. Each cell's midpoint supplies a feasible
real rotation. Since |d(2atan t)/dt|<=2, any point is at circular distance at most
the cell's t-width from its midpoint. No numerical atan evaluation is required.

[MATH DERIVATION] For a fixed normalized support, moving the source by angle δ
moves each point by at most rho_A*|δ|. Finite nearest distances, directed extrema
and their symmetric maximum preserve this Lipschitz bound. Thus
L_cell=max(0, f(mid).lo-rho_A.hi*width) and U_cell=f(mid).hi are valid enclosing
bounds, conditional on the interval arithmetic and exact observation identities.
Over a complete finite manifest, L=min L_cell and U=min U_cell. Finite pooling
does not imply a spherical cover, continuous-camera error or historical optics.

[IMPLEMENTED_UNVERIFIED] Every direction, reflection and cell is in the expected
manifest. The checker independently rebuilds it from literal direction tables.
Only a complete, failure-free, witness-resolved result with U-L<=supplied epsilon
can bear ENGINEERING_CERTIFICATE_CANDIDATE_UNVALIDATED. Otherwise it is pending,
failed, unresolved or gap-incomplete. No complete numeric camera manifest was
executed in this phase; only structural enumeration and five generic components
per DEV attempt were evaluated.

## Explicit resource and product limits

[UNRESOLVED] Fixed precision cannot resolve all small positive extents or exact
correlation degeneracies. The independent global-polynomial QO reference can
be too wide to fit inside production bounds; that is inconclusive, not success.
Arbitrary integer growth, runtime, allocation, preemption and hard-kill recovery
are not bounded by the production implementation. Input/task/step/read caps are
implemented; the DEV subprocess adds a 1-GiB/60-second cap only for its own run.
QO integration is O(n*m) segment-pair overlap enclosure, not the previously
discussed O(n+m) merged exact-knot implementation. No efficiency claim follows.

[DEFERRED] Smooth-curve sampling, continuous support covers, SEP/COV/sphere-wide
Lδ, historical source rights/optics/targets, actual control laws and measured
fairness remain separate obligations. All mathematical finite arrays here are
INDEPENDENT_DIAGNOSTIC, not historical reconstructions.
