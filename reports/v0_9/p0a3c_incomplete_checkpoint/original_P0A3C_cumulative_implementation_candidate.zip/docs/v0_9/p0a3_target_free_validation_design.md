# I6 — Future P0A4 catalogue design ONLY

**NOT REGISTERED, NOT EXECUTED, NO OUTCOMES ASSIGNED.** This is a proposed
requirement catalogue under P3 §8 and P2 O1–O5/H1–H5/CAP1–CAP5/F1–F2.
All content is INDEPENDENT_DIAGNOSTIC, not a target or historical model.
These IDs are proposal IDs, not registered case IDs. No P0A0 coordinates,
fixtures, oracles or evaluator may be imported or replayed.

Source classes remain SOURCE_ATTESTED, SOURCE_CONSTRAINED_INTERPRETATION,
INDEPENDENT_DIAGNOSTIC, NULL_CONTROL and UNRESOLVED. Proposed cases cannot
authenticate historical geometry, optics or target observations.

| Proposed ID | New target-free requirement | Independent oracle and failure criterion | Current gap |
|---|---|---|---|
| VF01 | Curved/polyline density and arclength correspondence | Independent exact segment integrals and a separately proved smooth approximation class; stop outside signed enclosure | General algebraic-length and sampling bounds missing |
| VF02 | Same finite support with independently supplied different labels | Independently specified combinatorial metadata; assert score cannot recover labels | No target graph extraction implemented or authorized |
| VF03 | Width/resolution-sensitive gap | Separately frozen analytic planar coverage model; retain resolution blindness | Raster implementation outside P0A3; cannot silently add an optical model |
| VF04 | Small component preservation | Exact finite support/component metadata separately supplied; no deletion or weighting adjustment | Continuous covers/component weighting unselected |
| VF05 | Endpoint/junction observable ambiguity | Independent explicit graph incidence, not inferred nearest-distance topology | Graph comparator outside scope |
| VF06 | Local notch and normalization sensitivity | Independent exact shape discrepancy and signed observation policy | Threshold/weights unselected; no calibration here |
| VF07 | Open reversal, mirror and genuinely closed phase distinction | Independent exact traversal/group oracles; reject unauthorized branch/phase | Closed/multi-stroke extensions deferred |
| VF08 | Zero, tiny, subnormal and dynamic-range extent | Exact scaled mathematics plus rigorous arithmetic enclosure; unsupported domains remain unevaluable | Stable tiny-scale/outward backend absent |
| VF09 | New analytic multi-basin local-versus-global objective | Independently derived stationary/global solution; local flag never accepted as global | No benchmark or scientific optimizer run now |
| VF10 | Duplicate frames, signed directions, antipodes and roll | Independent exact group/frame identities; complete branch manifest | No continuous-sphere inference from finite counts |
| VF11 | Coincident projections, normalization degeneracy and all-camera invalidity | Exact input/domain proof and full invalid-view ledger | Future full-camera driver/policy absent; never omit views |
| VF12 | Exact ties and unresolved near ties | Exact algebraic equality or interval separation; retain ambiguous minimizer classes | General equality/interval backend incomplete |
| VF13 | Circle seam, wrap, omitted or overlapping cells | Independent rational coverage plus proven analytic bounds | Structural checker only; no geometric enclosures |
| VF14 | Fabricated witness, false interval and mismatched provenance | Independent recomputation of witness feasibility, bound propagation and signed pins | Missing trusted arithmetic/proof engine |
| VF15 | Floating cancellation at a perfect or near-perfect fit | Exact reference plus outward enclosure, no clamp | Production intentionally returns unresolved/noncertified |
| VF16 | Precision-dependent output and arithmetic drift | Independently justified bit/error budget and containment checks | No precision sweep authorized by P0A3 |
| VF17 | Timeout, interrupted branch and resource exhaustion | Deterministic pre-signed resource limit and preserved partial certificate/log | No scientific runtime bound selected |
| VF18 | Candidate/control policy instrumentation | Pure configuration equality and manifest coverage before objects; later explicit model domains | N0–N3 laws and actual parity undefined |
| VF19 | SEP/COV/ROUND for each exact family | Independent complete pair types, spherical Voronoi/interval coverage proof and frame conversion error | No numerical covering/separation calculation now |
| VF20 | Full-camera Lδ approximation hypothesis | Uniform objective regularity, nondegenerate common domain and certified δ | NOT_ESTABLISHED; finite-camera work does not supply L |

Before implementation or execution of these proposed cases: independent QC of
P0A3; resolve critical incomplete arithmetic/reference coverage or explicitly
narrow a signed validation domain; human code-only GPG-signed freeze; then new
P0A4 preregistration fixing case data/IDs, exact oracle versions, arithmetic,
errors, allowed domains, output schemas, resource/stop rules and attempt policy.
Freeze fixture/harness bytes before **one** authorized run. Preserve every
failure, blind spot, omission, timeout and bound. Independent review and a
human decision follow. A discrepancy stops certification and requires a new
signed amendment, not hidden retries or tuning.

No epsilon, accuracy target, seed, sample size, effect, significance threshold,
P0A4 outcome or final experimental view tier is assigned here. Existing DEV
inputs and passing logs are **not** adopted as a future registered catalogue.
If rights, source, observables or optics are missing, narrow or defer the
scientific question; do not manufacture facts. Metadata-only rights/extraction,
22/27 conventions, independent second-chart uncertainty, candidate/null laws
and confirmatory statistics remain separate gates before first target pixels.
