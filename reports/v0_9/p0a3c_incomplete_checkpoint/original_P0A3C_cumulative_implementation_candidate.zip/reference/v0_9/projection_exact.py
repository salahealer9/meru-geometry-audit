"""Independent rational/radical orthographic expressions; no float renderer."""
from fractions import Fraction
from .literal_directions import exact_lift_witness

def project(points,triple):
    frame=exact_lift_witness(triple);result=[]
    for point in points:
        if len(point)!=3 or any(type(x) not in (int,str,Fraction) for x in point):
            raise ValueError("exact rational 3D coordinates required")
        p=tuple(Fraction(x) for x in point)
        result.append(tuple({"numerator":sum(Fraction(a)*b for a,b in zip(row,p)),
                             "denominator_square":den}
                            for row,den in zip(frame["row_integer_numerators"][:2],
                                               frame["row_denominator_square"][:2])))
    return {"coordinates":tuple(result),"arithmetic":"EXACT_RATIONAL_OVER_SQUARE_ROOT",
            "physical_shadow":False,"floating_rounding_certificate":"NOT_ESTABLISHED"}
