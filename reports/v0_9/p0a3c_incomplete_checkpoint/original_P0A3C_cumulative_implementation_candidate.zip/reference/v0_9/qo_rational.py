"""Independent exact rational segment-polynomial reference.

Supports rational coordinates with rational segment lengths. Irrational lengths
are explicitly UNRESOLVED_PROOF; no rounding fallback. No production imports.
"""
from fractions import Fraction as F
from math import isqrt

class ReferenceUnavailable(ValueError):
    status="UNRESOLVED_PROOF"

def rat(x):
    if type(x) not in (str,int,F):raise ValueError("Reference inputs must be exact rational encodings.")
    return F(x)

def rational_sqrt(x):
    if x<0:raise ValueError("negative squared length")
    a,b=isqrt(x.numerator),isqrt(x.denominator)
    if a*a!=x.numerator or b*b!=x.denominator:
        raise ReferenceUnavailable("IRRATIONAL_SEGMENT_LENGTH_BACKEND_NOT_IMPLEMENTED")
    return F(a,b)

def primitive_product(m,b,n,c,lo,hi):
    # Global-u polynomial antiderivative, independent of production endpoint rule.
    return m*n*(hi**3-lo**3)/3+(m*c+n*b)*(hi**2-lo**2)/2+b*c*(hi-lo)

def build(points):
    pp=[]
    for p in points:
        if len(p)!=2:raise ValueError("dimension")
        q=tuple(rat(x) for x in p)
        if not pp or q!=pp[-1]:pp.append(q)
    if len(pp)<2:raise ValueError("zero/empty path")
    lengths=[rational_sqrt(sum((b-a)**2 for a,b in zip(p,q))) for p,q in zip(pp,pp[1:])]
    total=sum(lengths,F(0));t=F(0);segments=[]
    for p,q,length in zip(pp,pp[1:],lengths):
        end=t+length/total
        coeff=tuple(((q[j]-p[j])/(end-t),p[j]-(q[j]-p[j])*t/(end-t)) for j in range(2))
        segments.append((t,end,coeff));t=end
    mu=tuple(sum(m*(hi*hi-lo*lo)/2+b*(hi-lo) for lo,hi,co in segments for m,b in [co[j]]) for j in range(2))
    centered=[(lo,hi,tuple((m,b-mu[j]) for j,(m,b) in enumerate(co))) for lo,hi,co in segments]
    variance=sum(primitive_product(m,b,m,b,lo,hi) for lo,hi,co in centered for m,b in co)
    if variance<=0:raise ValueError("zero extent")
    return centered,mu,variance

def evaluate(a,b,*,allow_reversal=False,allow_reflection=False):
    if type(allow_reversal) is not bool or type(allow_reflection) is not bool:raise ValueError("flags")
    aa,ma,va=build(a);bb,mb,vb=build(b);results=[]
    for mirror in ([False,True] if allow_reflection else [False]):
        for reverse in ([False,True] if allow_reversal else [False]):
            xx=[]
            for lo,hi,co in aa:
                cc=tuple((m if not reverse else -m, c if not reverse else c+m) for m,c in co)
                if mirror:cc=(cc[0],tuple(-x for x in cc[1]))
                xx.append((1-hi if reverse else lo,1-lo if reverse else hi,cc))
            alpha=F(0);beta=F(0)
            # Deliberately intersect every segment pair, not a shared union-merger.
            for l1,h1,x in xx:
                for l2,h2,y in bb:
                    lo,hi=max(l1,l2),min(h1,h2)
                    if lo>=hi:continue
                    alpha+=sum(primitive_product(*x[j],*y[j],lo,hi) for j in range(2))
                    beta+=primitive_product(-x[1][0],-x[1][1],*y[0],lo,hi)
                    beta+=primitive_product(*x[0],*y[1],lo,hi)
            ratio=(alpha*alpha+beta*beta)/(va*vb)
            if not 0<=ratio<=1:raise ValueError("exact Cauchy-Schwarz violation")
            results.append((ratio,mirror,reverse,alpha,beta))
    best=max(results,key=lambda x:x[0])
    ratio,mirror,reverse,alpha,beta=best
    try:squared=2-2*rational_sqrt(ratio)
    except ReferenceUnavailable:squared=None
    return {"reference_domain":"RATIONAL_COORDINATES_RATIONAL_SEGMENT_LENGTHS",
            "arithmetic":"EXACT_FRACTION_AND_SYMBOLIC_RADICAL",
            "centroids":(ma,mb),"variance":(va,vb),
            "raw_alpha":alpha,"raw_beta":beta,"correlation_squared":ratio,
            "normalized_alpha_expression":f"({alpha})/sqrt({va*vb})",
            "normalized_beta_expression":f"({beta})/sqrt({va*vb})",
            "squared_score_rational":squared,
            "squared_score_expression":f"2-2*sqrt({ratio})",
            "angle_expression":"0" if alpha==beta==0 else f"atan2({beta},{alpha}) modulo 2*pi",
            "whole_roll_tie":alpha==beta==0,"mirror":mirror,"reversed":reverse,
            "exact_tied_branch_count":sum(r[0]==ratio for r in results),
            "production_numerical_certificate":"NOT_ESTABLISHED"}
