"""Independent numerical verifier. No production imports, including enumeration.
External trusted pins are required and compared with live source and raw request.
"""
import hashlib
import json
from pathlib import Path
from fractions import Fraction as F
from .literal_directions import expected
from . import p0a3c_oracle as ref

class RejectedCertificate(ValueError):pass
class InconclusiveVerification(RejectedCertificate):pass
class IndependentContradiction(RejectedCertificate):pass
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)
def sha(x):return hashlib.sha256(canonical(x).encode()).hexdigest()
def code_identity(root,subdir):
    root=Path(root)
    entries=[(p.relative_to(root).as_posix(),hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted((root/subdir).rglob('*.py'))]
    return sha(entries)
def live_pins(request):
    """Utility for an external freeze process; calling this is NOT establishing trust."""
    root=Path(__file__).resolve().parents[2]
    return {'request_sha256':sha(request),'production_sha256':code_identity(root,'src'),'reference_sha256':code_identity(root,'reference')}
def interval(w):
    if type(w) is not list or len(w)!=2 or any(type(x) is not str for x in w):raise RejectedCertificate('INTERVAL_ENCODING')
    a,b=map(F,w)
    if a>b:raise RejectedCertificate('INVERTED_INTERVAL')
    return a,b
def contains(w,independent):
    a,b=interval(w);c,d=independent
    if b<c or d<a:raise IndependentContradiction('DISJOINT_INDEPENDENT_ENCLOSURES: STOP/quarantine for actual evidence')
    if not a<=c<=d<=b:raise InconclusiveVerification('REFERENCE_NOT_CONTAINED; no adaptive precision change')
def validate_request(r):
    keys={'schema','score','family','tier','convention','reflection','reversal','source','target','bits','checker_bits','level','epsilon','limits','authority','information_barrier'}
    if set(r)!=keys or r['schema']!='p0a3c-request-1' or r['score'] not in ('QO','QH'):raise RejectedCertificate('REQUEST')
    if r['authority']!='01270ec3bff3c9a6352c5dadc90d5d9f12da0c0d' or r['information_barrier']!='GENERIC_TARGET_FREE_ONLY':raise RejectedCertificate('AUTHORITY')
    if any(type(r[k]) is not bool for k in ('reflection','reversal')) or (r['score']=='QH' and r['reversal']) or (r['convention']=='O2' and not r['reflection']):raise RejectedCertificate('BRANCH')
    if any(type(r[k]) is not int for k in ('bits','checker_bits','level')) or not 2<=r['bits']<=r['checker_bits']<=4096 or not 0<=r['level']<=16:raise RejectedCertificate('PRECISION')
    if ref.q(r['epsilon'])<=0:raise RejectedCertificate('EPSILON')
    lim=r['limits']
    if set(lim)!={'max_vertices','max_input_bits','max_cells','max_steps'} or any(type(v) is not int or v<=0 for v in lim.values()):raise RejectedCertificate('RESOURCES')
    for name,dim in (('source',3),('target',2)):
        if type(r[name]) is not list or not 2<=len(r[name])<=lim['max_vertices']:raise RejectedCertificate('INPUT_COUNT')
        for p in r[name]:
            if type(p) is not list or len(p)!=dim:raise RejectedCertificate('INPUT_DIMENSION')
            for x in p:
                z=ref.q(x)
                if max(abs(z.numerator).bit_length(),z.denominator.bit_length())>lim['max_input_bits']:raise RejectedCertificate('INPUT_BITS')

def manifest(r):
    validate_request(r);out=[]
    for d in expected(r['family'],r['tier'],r['convention']):
        for m in range(1+int(r['reflection'])):
            if r['score']=='QO':
                for v in range(1+int(r['reversal'])):
                    out.append({'id':d['id']+'|m'+str(m)+'|r'+str(v),'triple':d['triple'],'mirror':bool(m),'reverse':bool(v)})
            else:
                for q in range(4):
                    for i in range(1<<r['level']):
                        out.append({'id':d['id']+'|m'+str(m)+'|q'+str(q)+'|l'+str(r['level'])+'|i'+str(i),'triple':d['triple'],'mirror':bool(m),'chart':q,'cell':i})
    if len(out)>r['limits']['max_cells']:raise RejectedCertificate('CELL_LIMIT')
    return out

def qh_observations(actual,oracle):
    for a,b,rms in zip(actual,oracle['exact_observations'],oracle['rms']):
        raw,den,n,mu,var=b
        enc=lambda x:f'{x.numerator}/{x.denominator}'
        exact={'numerators':[[enc(v) for v in p] for p in raw],'denominator_squares':list(den),'distinct_count':n,'duplicate_count':len(raw)-n,'mean_numerators':[enc(v) for v in mu],'variance':enc(var)}
        if set(a)!=set(exact)|{'rms'} or any(a[k]!=v for k,v in exact.items()):raise RejectedCertificate('QH_OBSERVATION')
        contains(a['rms'],rms)

def qo_observations(actual,oracle):
    if len(actual)!=2:raise RejectedCertificate('OBSERVATION_COUNT')
    for a,b in zip(actual,oracle):
        enc=lambda x:f'{x.numerator}/{x.denominator}'
        exact={'numerators':[[enc(v) for v in p] for p in b['raw']],'denominator_squares':list(b['den']),'omitted_consecutive_indices':b['omitted']}
        if set(a)!=set(exact)|{'lengths','total_length','centroid','variance','rms'} or any(a[k]!=v for k,v in exact.items()):raise RejectedCertificate('QO_OBSERVATION')
        if len(a['lengths'])!=len(b['lengths']) or len(a['centroid'])!=2:raise RejectedCertificate('OBSERVATION_SHAPE')
        for p,v in zip(a['lengths'],b['lengths']):contains(p,v)
        for p,v in zip(a['centroid'],b['centroid']):contains(p,v)
        for p,v in (('total_length','length'),('variance','variance'),('rms','rms')):contains(a[p],b[v])

def check_record(r,record):
    if set(record)!={'task','bounds','value'}:raise RejectedCertificate('RECORD_SCHEMA')
    t,v=record['task'],record['value']
    if t not in manifest(r) or v['score']!=r['score'] or v['bits']!=r['bits']:raise RejectedCertificate('RECORD_IDENTITY')
    if r['score']=='QO':
        if set(v)!={'score','objective','squared_objective','alpha','beta','correlation_norm','observations','witness','mirror','reverse','bits','status','certification'}:raise RejectedCertificate('QO_KEYS')
        if v['mirror']!=t['mirror'] or v['reverse']!=t['reverse'] or v['certification']!='GLOBAL_CERTIFICATION_DEFERRED':raise RejectedCertificate('QO_BRANCH')
        o=ref.qo(r['source'],r['target'],t['triple'],t['mirror'],t['reverse'],r['checker_bits'])
        for key in ('objective','squared_objective','alpha','beta','correlation_norm'):contains(v[key],o[key])
        qo_observations(v['observations'],o['observations'])
        w=v['witness'];kind,c,s=o['witness']
        if set(w)!={'type','cosine','sine'} or w['type']!=kind:raise InconclusiveVerification('QO_WITNESS_CLASS')
        if kind=='UNRESOLVED_ZERO_CORRELATION':
            if w['cosine'] is not None or w['sine'] is not None or v['status']!='UNRESOLVED_PROOF':raise RejectedCertificate('UNRESOLVED_WITNESS')
        else:
            contains(w['cosine'],c);contains(w['sine'],s)
            if v['status']!='GLOBAL_CERTIFICATION_DEFERRED':raise RejectedCertificate('QO_STATUS')
        if record['bounds']!=v['objective']:raise RejectedCertificate('QO_BOUNDS')
    else:
        if set(v)!={'score','objective','directed_ab','directed_ba','rho','observations','witness','bits','status','cell'} or v['status']!='GLOBAL_CERTIFICATION_DEFERRED':raise RejectedCertificate('QH_KEYS_STATUS')
        n=1<<r['level'];lo=F(t['cell'],n);hi=F(t['cell']+1,n);mid=(lo+hi)/2
        c=(1-mid*mid)/(1+mid*mid);s=2*mid/(1+mid*mid)
        for _ in range(t['chart']):c,s=-s,c
        if v['witness']!={'cosine':str(c),'sine':str(s),'mirror':t['mirror']}:raise RejectedCertificate('QH_ATTAINED_WITNESS')
        if v['cell']!={'t_interval':[str(lo),str(hi)],'midpoint':str(mid),'angle_radius_upper':str(hi-lo),'chart':t['chart']}:raise RejectedCertificate('CELL_GEOMETRY')
        if len(v['observations'])!=2:raise RejectedCertificate('OBSERVATION_COUNT')
        o=ref.qh(r['source'],r['target'],t['triple'],c,s,t['mirror'],r['checker_bits'])
        for key in ('objective','directed_ab','directed_ba','rho'):contains(v[key],o[key])
        qh_observations(v['observations'],o)
        bounds=(max(F(0),o['objective'][0]-o['rho'][1]*(hi-lo)),o['objective'][1])
        contains(record['bounds'],bounds)
    return 'CHECKER_RECOMPUTED_DEV_OR_UNREGISTERED'

def check(state,trusted):
    if set(state)!={'schema','request','request_sha256','input_sha256','completed','failures','pending','summary'} or state['schema']!='p0a3c-checkpoint-1':raise RejectedCertificate('STATE_SCHEMA')
    r=state['request'];all_tasks=manifest(r)
    if trusted!=live_pins(r):raise RejectedCertificate('EXTERNAL_REQUEST_OR_LIVE_CODE_PIN_MISMATCH')
    if state['request_sha256']!=sha(r) or state['input_sha256']!={k:sha(r[k]) for k in ('source','target')}:raise RejectedCertificate('INPUT_DIGEST')
    done=state['completed'];failed=state['failures'];pending=state['pending']
    if type(done) is not list or type(failed) is not list or type(pending) is not list or len(failed)>1:raise RejectedCertificate('PARTITION_TYPE')
    actual=[x['task'] for x in done]+[x['task'] for x in failed]+pending
    if actual!=all_tasks:raise RejectedCertificate('CANONICAL_COMPLETE_PARTITION')
    for f in failed:
        if set(f)!={'task','error_type','error','status'} or f['status']!='INCOMPLETE_STICKY_FAILURE':raise RejectedCertificate('FAILURE_RECORD')
    for x in done:check_record(r,x)
    upper=min((F(x['bounds'][1]) for x in done),default=None)
    if pending or failed:
        expected_summary={'status':'INCOMPLETE_STICKY_FAILURE' if failed else 'INCOMPLETE_PENDING','last_feasible_upper':None if upper is None else str(upper),'certification':'GLOBAL_CERTIFICATION_DEFERRED'}
    else:
        lower=min(F(x['bounds'][0]) for x in done);gap=upper-lower
        unresolved=any(x['value']['status']=='UNRESOLVED_PROOF' for x in done)
        status='UNRESOLVED_PROOF' if unresolved else ('ENGINEERING_CERTIFICATE_CANDIDATE_UNVALIDATED' if gap<=F(r['epsilon']) else 'INCOMPLETE_GAP')
        expected_summary={'status':status,'bounds':[str(lower),str(upper)],'gap':str(gap),'possible_minimizers':[x['task']['id'] for x in done if F(x['bounds'][0])<=upper],'proved_point_ties':[x['task']['id'] for x in done if F(x['bounds'][0])==F(x['bounds'][1])==upper],'overlap_is_equality':False,'certification':'GLOBAL_CERTIFICATION_DEFERRED'}
    if state['summary']!=expected_summary:raise RejectedCertificate('POOL_OR_STATUS')
    return {'receipt':sha(state),'status':expected_summary['status'],'certification':'GLOBAL_CERTIFICATION_DEFERRED','checker_qualification':'P0A3C_INDEPENDENT_CHECKER_UNQUALIFIED'}
