"""Independent structural circle/branch audit, NOT a numerical proof checker.

No production import. Complete records still return UNRESOLVED_PROOF because
arithmetic enclosures and witness identity have no implemented trusted backend.
"""
from fractions import Fraction as F
import re
from .literal_directions import check_manifest

def fraction(s):
    if not isinstance(s,str):raise ValueError("rational string required")
    q=F(s)
    if s!=f"{q.numerator}/{q.denominator}":raise ValueError("noncanonical rational")
    return q

def keys(d,names):
    if not isinstance(d,dict) or set(d)!=set(names):raise ValueError("unknown/missing keys")

def check(record,manifest,trusted_pins):
    keys(record,("score","family","tier","manifest_sha256","input_sha256","production_sha256",
                 "reference_sha256","configuration_sha256","branch_ids","cells","L","U","epsilon",
                 "uncertainty","schema_version","arithmetic_backend","status"))
    check_manifest(manifest);mp=manifest["payload"]
    if record["schema_version"]!="p0a3-candidate-1" or record["score"]!="QH" or record["status"]!="UNRESOLVED_PROOF" or record["arithmetic_backend"]!="NOT_IMPLEMENTED":
        raise ValueError("unavailable proof claim")
    if record["family"]!=mp["family"] or type(record["tier"]) is not int or record["tier"]!=mp["tier"] or record["manifest_sha256"]!=manifest["sha256"]:
        raise ValueError("direction identity")
    expected=[d["id"]+"|mirror="+str(m) for d in mp["directions"]
              for m in ([0,1] if mp["convention"]=="O2" else [0])]
    if list(record["branch_ids"])!=expected:raise ValueError("missing/reordered/extra branch")
    keys(trusted_pins,("input_sha256","production_sha256","reference_sha256","configuration_sha256"))
    for k,v in trusted_pins.items():
        if record[k]!=v:raise ValueError("pinned provenance disagreement")
    for value in [*record["input_sha256"],record["production_sha256"],record["reference_sha256"],record["configuration_sha256"]]:
        if not isinstance(value,str) or not re.fullmatch("[0-9a-f]{64}",value):raise ValueError("hash encoding")
    if len(record["input_sha256"])!=2:raise ValueError("input hashes")
    parts={b:[] for b in expected};lowers=[];uppers=[];seen=set()
    if not isinstance(record["cells"],(list,tuple)) or not record["cells"]:raise ValueError("missing cells")
    for cell in record["cells"]:
        keys(cell,("branch_id","cell_id","start_turn","end_turn","center_turn","center_lower",
                   "center_upper","cell_lower","witness_upper","witness_sha256","arithmetic_proof_sha256"))
        branch=cell["branch_id"];identity=(branch,cell["cell_id"])
        if branch not in parts or identity in seen or not isinstance(cell["cell_id"],str) or not cell["cell_id"]:
            raise ValueError("cell identity")
        seen.add(identity)
        for k in ("witness_sha256","arithmetic_proof_sha256"):
            if not isinstance(cell[k],str) or not re.fullmatch("[0-9a-f]{64}",cell[k]):raise ValueError("proof hash")
        a,b,c=map(fraction,(cell["start_turn"],cell["end_turn"],cell["center_turn"]))
        if not (0<=a<1 and 0<=b<=1 and 0<=c<1) or a==b:raise ValueError("circle endpoints")
        width=b-a if b>a else 1+b-a
        if (c-a)%1>width:raise ValueError("center not in cell")
        if b>a:parts[branch].append((a,b))
        else:parts[branch].extend(((a,F(1)),(F(0),b)))
        l,h,cl,u=map(fraction,(cell["center_lower"],cell["center_upper"],cell["cell_lower"],cell["witness_upper"]))
        if not 0<=cl<=l<=h<=u:raise ValueError("bound order")
        lowers.append(cl);uppers.append(u)
    for branch,intervals in parts.items():
        cursor=F(0)
        for a,b in sorted(intervals):
            if a!=cursor or b<=a:raise ValueError("circle gap/overlap or missing cell: "+branch)
            cursor=b
        if cursor!=1:raise ValueError("incomplete circle: "+branch)
    l,u,e=map(fraction,(record["L"],record["U"],record["epsilon"]))
    if not 0<=l<=u or e<0 or l!=min(lowers) or u!=min(uppers) or u-l>e:
        raise ValueError("global envelope/gap inconsistency")
    unc=record["uncertainty"]
    names={"observation","sampling","projection","normalization","arithmetic","optimization"}
    if not isinstance(unc,(list,tuple)) or any(not isinstance(x,(list,tuple)) or len(x)!=2 for x in unc):
        raise ValueError("uncertainty structure")
    if len(unc)!=6 or {k for k,v in unc}!=names:raise ValueError("missing uncertainty")
    for k,v in unc:
        if v!="NOT_ESTABLISHED" and fraction(v)<0:raise ValueError("negative uncertainty")
    return {"structural_status":"DEV_CHECKED_ONLY","status":"UNRESOLVED_PROOF",
            "full_circle_partition":"EXACT_RATIONAL_STRUCTURAL_MATCH",
            "branches":len(expected),"cells":len(seen),
            "numerical_enclosures":"NOT_CHECKED_BACKEND_NOT_IMPLEMENTED",
            "witness_geometry":"NOT_CHECKED_BACKEND_NOT_IMPLEMENTED",
            "no_certification_promotion":True}
