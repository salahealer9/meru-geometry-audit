"""Exact all-pairs reference for rational inputs and rational unit rotations.

Distances squared lie in a common quadratic extension; comparisons use signs
and rational squares, not production distances or floating sqrt.
"""
from fractions import Fraction as F

def rat(x):
    if type(x) not in (int,str,F):raise ValueError("exact rational input required")
    return F(x)

def centered(points):
    pp=[]
    for p in points:
        if len(p)!=2:raise ValueError("dimension")
        row=tuple(rat(v) for v in p)
        if row not in pp:pp.append(row)  # independent explicit duplicate membership
    if len(pp)<2:raise ValueError("zero/empty support")
    n=F(len(pp));mu=tuple(sum(p[j] for p in pp)/n for j in (0,1))
    zz=[tuple(p[j]-mu[j] for j in (0,1)) for p in pp]
    variance=sum(sum(v*v for v in p) for p in zz)/n
    if variance<=0:raise ValueError("zero extent")
    return zz,mu,variance

def sign_surd(a,b,D):
    """Exact sign of a+b sqrt(D), D>0 rational."""
    if D<=0:raise ValueError("positive radicand required")
    if b==0:return (a>0)-(a<0)
    if a==0:return (b>0)-(b<0)
    if a>0 and b>0:return 1
    if a<0 and b<0:return -1
    cmp=(a*a>b*b*D)-(a*a<b*b*D)
    return cmp if a>0 else -cmp

def compare(x,y,D):return sign_surd(x[0]-y[0],x[1]-y[1],D)

def extreme(items,D,want_max):
    winner=items[0]
    for x in items[1:]:
        c=compare(x,winner,D)
        if (c>0 if want_max else c<0):winner=x
    return winner

def evaluate(a,b,*,cosine="1",sine="0",mirror=False):
    c,s=rat(cosine),rat(sine)
    if c*c+s*s!=1 or type(mirror) is not bool:raise ValueError("exact unit planar action required")
    x,mx,vx=centered(a);y,my,vy=centered(b)
    xx=[]
    for p,q in x:
        if mirror:q=-q
        xx.append((c*p-s*q,s*p+c*q))
    D=vx*vy
    matrix=[]
    for p in xx:
        row=[]
        for q in y:
            const=sum(z*z for z in p)/vx+sum(z*z for z in q)/vy
            coeff=-2*sum(p[j]*q[j] for j in (0,1))/D
            if sign_surd(const,coeff,D)<0:raise ValueError("negative exact squared distance")
            row.append((const,coeff))
        matrix.append(row)
    da=extreme([extreme(row,D,False) for row in matrix],D,True)
    db=extreme([extreme([row[j] for row in matrix],D,False) for j in range(len(y))],D,True)
    h=extreme([da,db],D,True)
    return {"arithmetic":"EXACT_QUADRATIC_SURD","radicand":D,"centroids":(mx,my),"variance":(vx,vy),
            "directed_ab_squared":da,"directed_ba_squared":db,"hausdorff_squared":h,
            "meaning":"pair (a,b) denotes a+b*sqrt(radicand)",
            "scope":"FIXED_RATIONAL_UNIT_ROTATION_ONLY","global_roll":"DEFERRED",
            "production_float_enclosure":"NOT_ESTABLISHED"}
