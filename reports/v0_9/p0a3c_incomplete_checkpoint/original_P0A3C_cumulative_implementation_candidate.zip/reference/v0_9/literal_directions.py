"""Independent literal integer witnesses, not production generation."""
import hashlib
import json

TABLES={
 "A0":((-1,0,0),(0,-1,0),(0,0,-1),(0,0,1),(0,1,0),(1,0,0)),
 "C":((-1,-1,-1),(-1,-1,1),(-1,1,-1),(-1,1,1),(1,-1,-1),(1,-1,1),(1,1,-1),(1,1,1)),
 "E":((-1,-1,0),(-1,0,-1),(-1,0,1),(-1,1,0),(0,-1,-1),(0,-1,1),(0,1,-1),(0,1,1),(1,-1,0),(1,0,-1),(1,0,1),(1,1,0)),
 "T":((-2,-1,0),(-2,0,-1),(-2,0,1),(-2,1,0),(-1,-2,0),(-1,0,-2),(-1,0,2),(-1,2,0),
       (0,-2,-1),(0,-2,1),(0,-1,-2),(0,-1,2),(0,1,-2),(0,1,2),(0,2,-1),(0,2,1),
       (1,-2,0),(1,0,-2),(1,0,2),(1,2,0),(2,-1,0),(2,0,-1),(2,0,1),(2,1,0))
}

def expected(family,tier,convention="SO2"):
    if family not in ("A","B") or type(tier) is not int or tier not in (0,1,2) or convention not in ("SO2","O2"):
        raise ValueError("invalid reference domain")
    layers=("A0","C","E") if family=="A" else ("A0","E","T")
    out=[]
    for s in layers[:tier+1]:
        for v in TABLES[s]:
            if convention=="O2" and next(x for x in v if x)<0:continue
            out.append({"id":s+":"+",".join(map(str,v)),"stratum":s,"triple":list(v),
                        "norm_squared":sum(x*x for x in v),
                        "antipode_id":s+":"+",".join(str(-x) for x in v)})
    return out

def check_manifest(record):
    if set(record)!={"payload","sha256"}:raise ValueError("manifest keys")
    p=record["payload"]
    if set(p)!={"schema_version","family","tier","convention","final_experimental_tier","covering_certificate","directions"}:
        raise ValueError("payload keys")
    if p["schema_version"]!="p0a3-directions-1" or p["final_experimental_tier"] is not False or p["covering_certificate"]!="NOT_ESTABLISHED":
        raise ValueError("unauthorized scope")
    raw=json.dumps(p,sort_keys=True,separators=(",",":"),ensure_ascii=True,allow_nan=False).encode()
    if hashlib.sha256(raw).hexdigest()!=record["sha256"]:raise ValueError("manifest digest")
    if p["directions"]!=expected(p["family"],p["tier"],p["convention"]):
        raise ValueError("literal reference disagreement")
    return {"membership":"EXACT_LITERAL_MATCH","covering":"NOT_ESTABLISHED","numerical_certification":"DEFERRED"}

def exact_lift_witness(triple):
    """Alternate integer/radical expression, with exact orthogonality identities."""
    v=tuple(triple)
    if len(v)!=3 or any(type(x) is not int for x in v) or not any(v):raise ValueError("triple")
    s=sum(x*x for x in v);j=min(range(3),key=lambda k:abs(v[k]));d=s-v[j]**2
    e=tuple(int(k==j) for k in range(3))
    u=tuple(s*e[k]-v[j]*v[k] for k in range(3))
    w=(v[1]*e[2]-v[2]*e[1],v[2]*e[0]-v[0]*e[2],v[0]*e[1]-v[1]*e[0])
    nums=(u,w,v);den2=(s*d,d,s)
    if any(sum(x*x for x in row)!=den for row,den in zip(nums,den2)):
        raise ValueError("exact norm identity")
    if any(sum(nums[i][k]*nums[jj][k] for k in range(3))!=0 for i,jj in ((0,1),(0,2),(1,2))):
        raise ValueError("exact orthogonality identity")
    determinant=u[0]*(w[1]*v[2]-w[2]*v[1])-u[1]*(w[0]*v[2]-w[2]*v[0])+u[2]*(w[0]*v[1]-w[1]*v[0])
    if determinant!=s*d:raise ValueError("properness identity")
    return {"row_integer_numerators":nums,"row_denominator_square":den2,
            "basis_index":j,"exact_properness_identity":True,
            "floating_rounding_certificate":"NOT_ESTABLISHED"}
