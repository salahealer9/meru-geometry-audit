"""Independent exact recomputation/checks; never imports production code.

No scientific certification/phase approval is issued. Restricted domains explicit.
"""
from fractions import Fraction as F
import json,hashlib
from . import qh_exact,qo_rational,literal_directions

def require(condition,message):
    if not condition:raise ValueError(message)

def canon(x):
    require(type(x) in (str,int,F),'exact encoding; no bool/float')
    q=F(x);return f'{q.numerator}/{q.denominator}'

def point_rows(data,dim):
    rows=[]
    for row in data:
        require(len(row)==dim,'dimension');rows.append([canon(x) for x in row])
    return rows

def digest(data):return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def bounds(x):
    require(isinstance(x,list) and len(x)==2,'bounds shape')
    require(all(type(y) is str and canon(y)==y for y in x),'noncanonical bound')
    lo,hi=map(F,x);require(lo<=hi,'inverted bound');return lo,hi

def sign(a,b,d):return qh_exact.sign_surd(a,b,d) if d else (a>0)-(a<0)

def root_contains(interval,surd,d):
    lo,hi=bounds(interval);require(lo>=0,'negative objective endpoint')
    a,b=surd
    require(sign(a-lo*lo,b,d)>=0 and sign(hi*hi-a,-b,d)>=0,'REFUTED_ENCLOSURE')

def check_pose(a,b,record,*,cosine,sine,mirror):
    keys={'objective','rho','normalizers','centroids','cosine','sine','mirror','arithmetic','bits','status','scope'}
    require(set(record)==keys,'pose keys')
    require(record['arithmetic']=='EXACT_FRACTION_DYADIC_OUTWARD' and record['status']=='GLOBAL_CERTIFICATION_DEFERRED' and record['scope']=='FIXED_RATIONAL_UNIT_POSE','pose scope')
    require(type(record['bits']) is int and 1<=record['bits']<=4096,'precision')
    require(type(record['mirror']) is bool and record['mirror']==mirror and record['cosine']==canon(cosine) and record['sine']==canon(sine),'wrong witness rotation')
    exact=qh_exact.evaluate(a,b,cosine=canon(cosine),sine=canon(sine),mirror=mirror)
    root_contains(record['objective'],exact['hausdorff_squared'],exact['radicand'])
    require(record['centroids']==point_rows(exact['centroids'],2),'centroid mismatch')
    require(len(record['normalizers'])==2,'normalizer count')
    for box,v in zip(record['normalizers'],exact['variance']):root_contains(box,(v,F(0)),F(1))
    x,_,v=qh_exact.centered(a);r2=max(sum(q*q for q in p) for p in x)/v
    root_contains(record['rho'],(r2,F(0)),F(1))
    return {'numeric_enclosure_checked':True,'phase_status':'GLOBAL_CERTIFICATION_DEFERRED'}

def check_qo(a,b,r):
    require(set(r)=={'schema','input_sha256','bits','allow_reversal','allow_reflection','branches','exact_tied_branches','objective','squared_objective','witness','normalizers','centroids','omitted_consecutive_indices','status','domain'},'qo keys')
    require(type(r['bits']) is int and 1<=r['bits']<=4096,'qo precision')
    require(isinstance(r['normalizers'],list) and len(r['normalizers'])==2,'qo normalizer count')
    require(r['schema']=='p0a3-qo-rational-2' and r['status']=='GLOBAL_CERTIFICATION_DEFERRED','qo scope')
    require(r['domain']=='RATIONAL_COORDINATES_RATIONAL_SEGMENT_LENGTHS_OPEN_ORDERED_SINGLE_PATH','qo domain')
    require(r['input_sha256']==[digest(point_rows(x,2)) for x in (a,b)],'input hash')
    require(type(r['allow_reflection']) is bool and type(r['allow_reversal']) is bool,'branch flags')
    expected=[]
    for mirror in ([False,True] if r['allow_reflection'] else [False]):
        for reverse in ([False,True] if r['allow_reversal'] else [False]):
            aa=list(a)[::-1] if reverse else list(a)
            aa=[(F(x),-F(y) if mirror else F(y)) for x,y in aa]
            e=qo_rational.evaluate(aa,b)
            expected.append({'mirror':mirror,'reversed':reverse,'alpha_raw':canon(e['raw_alpha']),'beta_raw':canon(e['raw_beta']),'ratio':canon(e['correlation_squared'])})
    require(r['branches']==expected,'QO branch recomputation mismatch')
    best=max(F(e['ratio']) for e in expected);ties=[i for i,e in enumerate(expected) if F(e['ratio'])==best]
    require(r['exact_tied_branches']==ties,'tie omission')
    lo,hi=bounds(r['squared_objective'])
    require(lo>=0 and sign(2-lo,-F(2),best)>=0 and sign(hi-2,F(2),best)>=0,'REFUTED_QO_SQUARED_ENCLOSURE')
    root_contains(r['objective'],(F(2),-F(2)),best)
    chosen=expected[ties[0]];al,be=F(chosen['alpha_raw']),F(chosen['beta_raw']);n=al*al+be*be
    w={'cos_numerator':canon(al if n else 1),'sin_numerator':canon(be if n else 0),'denominator_squared':canon(n if n else 1),'whole_roll_tie':n==0}
    require(r['witness']==w,'wrong attained roll witness')
    _,ma,va=qo_rational.build(a);_,mb,vb=qo_rational.build(b)
    require(r['centroids']==point_rows((ma,mb),2),'qo centroids')
    for box,v in zip(r['normalizers'],(va,vb)):root_contains(box,(v,F(0)),F(1))
    omitted=[]
    for data in (a,b):
        rows=point_rows(data,2);omitted.append([i for i in range(1,len(rows)) if rows[i]==rows[i-1]])
    require(r['omitted_consecutive_indices']==omitted,'omission ledger')
    return {'numeric_enclosure_checked':True,'attained_roll_symbolic_witness_checked':True,'phase_status':'GLOBAL_CERTIFICATION_DEFERRED'}

def check_frame(record):
    require(set(record)=={'rows','triple','bits','basis_index','arithmetic','status'},'frame keys')
    require(record['status']=='GLOBAL_CERTIFICATION_DEFERRED' and record['arithmetic']=='EXACT_FRACTION_DYADIC_OUTWARD','frame scope')
    require(type(record['bits']) is int and 1<=record['bits']<=4096,'frame precision')
    exact=literal_directions.exact_lift_witness(record['triple'])
    require(record['basis_index']==exact['basis_index'],'basis')
    require(len(record['rows'])==3 and all(len(row)==3 for row in record['rows']),'frame shape')
    for row,num,d in zip(record['rows'],exact['row_integer_numerators'],exact['row_denominator_square']):
        for box,n in zip(row,num):
            lo,hi=bounds(box)
            require(sign(-lo,F(n,d),F(d))>=0 and sign(hi,-F(n,d),F(d))>=0,'REFUTED_FRAME_ENCLOSURE')
    return {'exact_proper_frame_entries_enclosed':True,'continuous_capacity':'NOT_ESTABLISHED'}

def axis_observation(source,triple):
    witness=literal_directions.exact_lift_witness(triple)
    require(witness['row_denominator_square']==(1,1,1),'G0-only numeric checker')
    rows=witness['row_integer_numerators'][:2]
    return [[sum(F(a)*F(b) for a,b in zip(row,p)) for row in rows] for p in source]

def check_checkpoint(state,expected_request):
    require(set(state)=={'schema','request','request_sha256','completed','pending','failure','stop_reason','status'},'checkpoint keys')
    r=expected_request
    require(state['schema']=='p0a3-qh-checkpoint-2' and state['request']==r and state['request_sha256']==digest(r),'external request pin')
    require(set(r)=={'schema','source','target','manifest','bits','level','epsilon','pins','permission_id','input_class','observation'},'request keys')
    require(r['schema']=='p0a3-qh-circle-2' and r['input_class']=='INDEPENDENT_DIAGNOSTIC' and r['observation']=='FINITE_VERTEX_ORTHOGRAPHIC_NOT_SHADOW','request authority')
    literal_directions.check_manifest(r['manifest']);m=r['manifest']['payload']
    require(m['tier']==0,'G1/G2 unsupported in numeric checker')
    require(type(r['bits']) is int and 1<=r['bits']<=4096 and type(r['level']) is int and 0<=r['level']<=16,'resource parameters')
    require(F(r['epsilon'])>0 and canon(r['epsilon'])==r['epsilon'],'epsilon')
    require(point_rows(r['source'],3)==r['source'] and point_rows(r['target'],2)==r['target'],'canonical inputs')
    require(set(r['pins'])=={'production','reference','configuration','resource_policy'} and all(type(h) is str and len(h)==64 and all(c in '0123456789abcdef' for c in h) for h in r['pins'].values()),'trusted external pins')
    require(isinstance(r['permission_id'],str) and bool(r['permission_id']) and (m['convention']!='O2' or r['permission_id']!='primary-no-reversal'),'sensitivity permission')
    cells=[];count=2**r['level'];by_id={}
    for d in literal_directions.expected(m['family'],0,m['convention']):
        by_id[d['id']]=d
        for reflected in range(2 if m['convention']=='O2' else 1):
            for q in range(4):
                for k in range(count):
                    cells.append({'id':f"{d['id']}|{reflected}|{q}|{k}",'direction':d['id'],'mirror':bool(reflected),'quadrant':q,'lo':canon(F(k,count)),'hi':canon(F(k+1,count))})
    completed=state['completed'];require(isinstance(completed,list) and len(completed)<=len(cells),'completed count')
    require(state['pending']==cells[len(completed):],'missing/reordered unvisited cell')
    lowers=[];uppers=[]
    for cell,item in zip(cells,completed):
        require(set(item)=={'cell','pose','cell_lower','witness_upper','observation_sha256','request_sha256'} and item['cell']==cell,'cell identity')
        a=axis_observation(r['source'],by_id[cell['direction']]['triple'])
        require(item['observation_sha256']==digest(point_rows(a,2)) and item['request_sha256']==digest(r),'observation/input pin')
        t=(F(cell['lo'])+F(cell['hi']))/2
        # Independent complex multiplication, rather than production quadrant loop.
        c0,s0=(1-t*t)/(1+t*t),2*t/(1+t*t)
        u,v=((1,0),(0,1),(-1,0),(0,-1))[cell['quadrant']];c,s=u*c0-v*s0,u*s0+v*c0
        check_pose(a,r['target'],item['pose'],cosine=c,sine=s,mirror=cell['mirror'])
        require(item['pose']['bits']==r['bits'],'precision mismatch')
        pl,pu=bounds(item['pose']['objective']);_,rho=bounds(item['pose']['rho'])
        lower=F(item['cell_lower']);upper=F(item['witness_upper'])
        require(canon(lower)==item['cell_lower'] and canon(upper)==item['witness_upper'],'bound encoding')
        require(0<=lower<=max(F(0),pl-rho*(F(cell['hi'])-F(cell['lo']))) and upper>=pu,'REFUTED_CELL_BOUND_OR_WITNESS')
        lowers.append(lower);uppers.append(upper)
    require(state['status'] in ('UNRESOLVED_PROOF','LOCAL_ONLY','GLOBAL_CERTIFICATION_DEFERRED'),'forbidden promotion')
    complete=len(completed)==len(cells) and state['failure'] is None
    expected_status='GLOBAL_CERTIFICATION_DEFERRED' if complete else ('LOCAL_ONLY' if completed else 'UNRESOLVED_PROOF')
    require(state['status']==expected_status,'inconsistent control status')
    require(state['stop_reason'] in ('NOT_STARTED','CELL_BUDGET','TIMEOUT','UNEVALUABLE_BRANCH','ALL_CELLS_EVALUATED'),'unknown stop reason')
    if complete:require(state['stop_reason']=='ALL_CELLS_EVALUATED','completion reason')
    elif state['failure'] is not None:
        failure=state['failure']
        require(set(failure)=={'cell','status','code','message'} and failure['cell']==cells[len(completed)] and state['stop_reason']=='UNEVALUABLE_BRANCH','failure state')
    else:require(state['stop_reason'] in ('NOT_STARTED','CELL_BUDGET','TIMEOUT') and (state['stop_reason']!='NOT_STARTED' or not completed),'partial reason')
    L=min(lowers) if complete else F(0);U=min(uppers) if uppers else None
    return {'all_cells_numerically_checked':complete,'checked_cells':len(completed),'unvisited_cells':len(cells)-len(completed),
            'lower':canon(L),'upper':None if U is None else canon(U),'prospective_gap_met':complete and U-L<=F(r['epsilon']),
            'phase_status':'GLOBAL_CERTIFICATION_DEFERRED','approval':'NOT_GRANTED','domain':'RATIONAL_INPUT_G0_ONLY'}
