"""Independent reference/checker package. No production numerical imports."""
