"""Independent interval reference: integer bisection, global polynomial integrals,
norm-minus-dot QH. No production numerical imports. Candidate, not QC approval.
"""
from fractions import Fraction as F
from .literal_directions import exact_lift_witness

def q(x):
    if type(x) not in (int,str,F):raise ValueError('exact rational required')
    return F(x)
def one(x):return (q(x),q(x))
def plus(a,b):return (a[0]+b[0],a[1]+b[1])
def minus(a,b):return (a[0]-b[1],a[1]-b[0])
def times(a,b):
    v=[x*y for x in a for y in b];return (min(v),max(v))
def over(a,b):
    if b[0]<=0<=b[1]:raise ValueError('REFERENCE_DENOMINATOR_UNRESOLVED')
    return times(a,(1/b[1],1/b[0]))
def scale(a,k):return times(a,one(k))
def square(a):return (F(0) if a[0]<=0<=a[1] else min(x*x for x in a),max(x*x for x in a))
def total(xs):
    out=one(0)
    for x in xs:out=plus(out,x)
    return out
def mn(xs):return (min(x[0] for x in xs),min(x[1] for x in xs))
def mx(xs):return (max(x[0] for x in xs),max(x[1] for x in xs))
def clip(a,lo,hi):
    out=(max(a[0],F(lo)),min(a[1],F(hi)))
    if out[0]>out[1]:raise ValueError('REFERENCE_CONTRADICTION')
    return out
def root(a,bits):
    if a[0]<0:raise ValueError('negative unproved radicand')
    def endpoint(x,up):
        scale=2**bits;low=0;high=scale*(1+x.numerator//x.denominator)
        # Search integer lattice by exact comparisons, no isqrt shared with production.
        while low<high:
            mid=(low+high+1)//2
            if F(mid*mid,scale*scale)<=x:low=mid
            else:high=mid-1
        return F(low+int(up and F(low*low,scale*scale)!=x),scale)
    return endpoint(a[0],False),endpoint(a[1],True)

def observed(data,triple):
    dim=2 if triple is None else 3
    pp=[]
    for p in data:
        if len(p)!=dim:raise ValueError('dimension')
        pp.append(tuple(q(x) for x in p))
    if triple is None:return pp,(1,1)
    f=exact_lift_witness(triple);rows=f['row_integer_numerators'][:2]
    return [tuple(sum(F(row[k])*p[k] for k in range(3)) for row in rows) for p in pp],tuple(f['row_denominator_square'][:2])

def set_data(data,triple):
    raw,den=observed(data,triple);distinct=[]
    for p in raw:
        if p not in distinct:distinct.append(p)
    if not distinct:raise ValueError('REFERENCE_EMPTY')
    mu=tuple(sum(p[k] for p in distinct)/len(distinct) for k in range(2))
    centered=[tuple(p[k]-mu[k] for k in range(2)) for p in distinct]
    var=sum(sum(p[k]**2/den[k] for k in range(2)) for p in centered)/len(distinct)
    if var<=0:raise ValueError('REFERENCE_COLLAPSE')
    return raw,den,centered,mu,var

def qh(source,target,triple,c,s,mirror,bits):
    c,s=q(c),q(s)
    if c*c+s*s!=1 or type(mirror) is not bool:raise ValueError('pose')
    raw,den,a,mu,va=set_data(source,triple);rawb,db,b,mub,vb=set_data(target,None)
    matrix=[]
    for x,y in a:
        if mirror:y=-y
        row=[]
        for z,w in b:
            norm=(x*x/den[0]+y*y/den[1])/va+(z*z+w*w)/vb
            # Exact norms minus algebraically normalized dot products.
            cross=plus(over(one(x*(c*z+s*w)),root(one(den[0]*va*vb),bits)),
                       over(one(y*(-s*z+c*w)),root(one(den[1]*va*vb),bits)))
            d2=minus(one(norm),scale(cross,2));d2=(max(F(0),d2[0]),d2[1])
            row.append(root(d2,bits))
        matrix.append(row)
    ab=mx([mn(row) for row in matrix]);ba=mx([mn([row[k] for row in matrix]) for k in range(len(b))])
    rho2=max(sum(p[k]*p[k]/den[k] for k in range(2)) for p in a)/va
    return {'objective':mx([ab,ba]),'directed_ab':ab,'directed_ba':ba,'rho':root(one(rho2),bits),
            'rms':[root(one(va),bits),root(one(vb),bits)],'exact_observations':[(raw,den,len(a),mu,va),(rawb,db,len(b),mub,vb)]}

def polynomial_path(data,triple,bits):
    raw,den=observed(data,triple);nums=[];omitted=[]
    for i,p in enumerate(raw):
        if nums and p==nums[-1]:omitted.append(i)
        else:nums.append(p)
    if len(nums)<2:raise ValueError('REFERENCE_COLLAPSE')
    ll=[root(one(sum((b[k]-a[k])**2/den[k] for k in range(2))),bits) for a,b in zip(nums,nums[1:])]
    length=total(ll);dur=[over(x,length) for x in ll];starts=[one(0)]
    for k in range(1,len(ll)):starts.append(over(total(ll[:k]),length))
    ends=starts[1:]+[one(1)]
    xy=[tuple(over(one(p[k]),root(one(den[k]),bits)) for k in range(2)) for p in nums]
    seg=[]
    for i in range(len(ll)):
        coeff=[]
        for k in range(2):
            slope=over(minus(xy[i+1][k],xy[i][k]),dur[i]);intercept=minus(xy[i][k],times(slope,starts[i]));coeff.append((slope,intercept))
        seg.append((starts[i],ends[i],coeff))
    def integral_linear(m,b,lo,hi):return plus(scale(times(m,minus(square(hi),square(lo))),F(1,2)),times(b,minus(hi,lo)))
    mu=[total(integral_linear(*co[k],lo,hi) for lo,hi,co in seg) for k in range(2)]
    centered=[(lo,hi,[(m,minus(b,mu[k])) for k,(m,b) in enumerate(co)]) for lo,hi,co in seg]
    variance=total(integral_product(m,b,m,b,lo,hi) for lo,hi,co in centered for m,b in co)
    variance=(max(F(0),variance[0]),variance[1]);rms=root(variance,bits)
    if rms[0]<=0:raise ValueError('REFERENCE_EXTENT_UNRESOLVED')
    normalized=[(lo,hi,[(over(m,rms),over(b,rms)) for m,b in co]) for lo,hi,co in centered]
    return normalized,{'raw':raw,'den':den,'omitted':omitted,'lengths':ll,'length':length,'centroid':mu,'variance':variance,'rms':rms}

def integral_product(m,b,n,c,lo,hi):
    cube=lambda x:times(square(x),x)
    return total([scale(times(times(m,n),minus(cube(hi),cube(lo))),F(1,3)),
                  scale(times(plus(times(m,c),times(n,b)),minus(square(hi),square(lo))),F(1,2)),
                  times(times(b,c),minus(hi,lo))])

def qo(source,target,triple,mirror,reverse,bits):
    aa,ma=polynomial_path(source,triple,bits);bb,mb=polynomial_path(target,None,bits);xx=[]
    for lo,hi,co in aa:
        if reverse:lo,hi=minus(one(1),hi),minus(one(1),lo);co=[(scale(m,-1),plus(b,m)) for m,b in co]
        if mirror:co=[co[0],(scale(co[1][0],-1),scale(co[1][1],-1))]
        xx.append((lo,hi,co))
    alpha=one(0);beta=one(0)
    for l,h,a in xx:
        for ll,hh,b in bb:
            lo=mx([l,ll]);hi=mx([lo,mn([h,hh])])
            alpha=plus(alpha,total(integral_product(*a[k],*b[k],lo,hi) for k in range(2)))
            beta=plus(beta,minus(integral_product(*a[0],*b[1],lo,hi),integral_product(*a[1],*b[0],lo,hi)))
    radius=clip(root(plus(square(alpha),square(beta)),bits),0,1)
    q2=clip(minus(one(2),scale(radius,2)),0,2);score=root(q2,bits)
    if alpha==beta==one(0):w=('WHOLE_ROLL_TIE',one(1),one(0))
    elif radius[0]>0:w=('ALGEBRAIC_OPTIMAL_UNIT_FROM_EXACT_CORRELATIONS',over(alpha,radius),over(beta,radius))
    else:w=('UNRESOLVED_ZERO_CORRELATION',None,None)
    return {'objective':score,'squared_objective':q2,'alpha':alpha,'beta':beta,'correlation_norm':radius,'observations':[ma,mb],'witness':w}
