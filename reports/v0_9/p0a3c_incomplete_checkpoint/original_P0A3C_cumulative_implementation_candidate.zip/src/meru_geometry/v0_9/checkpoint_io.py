"""Optional caller-directed durable checkpoint write, outside scientific kernels.

Caller owns path permissions/authorization; never auto-selects repository paths.
"""
import os,tempfile
from pathlib import Path
from .qh_circle_candidate import dumps

def save(state,destination):
    path=Path(destination)
    if path.is_symlink():raise ValueError('Refuse symlink checkpoint destination')
    data=dumps(state).encode('utf-8')
    fd,tmp=tempfile.mkstemp(prefix='.p0a3_checkpoint_',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
        directory=os.open(path.parent,os.O_RDONLY)
        try:os.fsync(directory)
        finally:os.close(directory)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    return len(data)
