"""Independent of reference: exact endpoint integration on rational-length paths.

INDEPENDENT_DIAGNOSTIC; exposed rigorous subdomain, no general algebraic claim.
"""
from fractions import Fraction as F
from .exact_bounds import points,encode,encoded_points,digest,exact_sqrt,sqrt_bounds,interval
from .exceptions import NotEvaluable,EngineeringError,UnresolvedProof

def path(data):
    pp=[];omitted=[]
    for i,p in enumerate(points(data,2)):
        if pp and p==pp[-1]:omitted.append(i)
        else:pp.append(p)
    if len(pp)<2:raise NotEvaluable('ZERO_PATH','Empty or zero length.')
    lengths=[exact_sqrt(sum((a-b)**2 for a,b in zip(p,q))) for p,q in zip(pp,pp[1:])]
    total=sum(lengths);ts=[F(0)]
    for l in lengths:ts.append(ts[-1]+l/total)
    mu=tuple(sum((ts[i+1]-ts[i])*(pp[i][j]+pp[i+1][j])/2 for i in range(len(lengths))) for j in range(2))
    zz=[tuple(p[j]-mu[j] for j in range(2)) for p in pp]
    var=sum((ts[i+1]-ts[i])*sum(zz[i][j]**2+zz[i][j]*zz[i+1][j]+zz[i+1][j]**2 for j in range(2))/3 for i in range(len(lengths)))
    if var<=0:raise NotEvaluable('ZERO_RMS','No positive exact extent.')
    return ts,zz,mu,var,omitted

def at(ts,pp,t):
    for i in range(len(ts)-1):
        if ts[i]<=t<=ts[i+1]:
            f=(t-ts[i])/(ts[i+1]-ts[i]);return tuple(a+(b-a)*f for a,b in zip(pp[i],pp[i+1]))
    raise EngineeringError('BREAKPOINT','Outside path domain.')

def product(a,b,c,d,width):return width*(2*a*c+a*d+b*c+2*b*d)/6

def evaluate(a,b,*,bits,allow_reversal,allow_reflection):
    if type(allow_reversal) is not bool or type(allow_reflection) is not bool:raise EngineeringError('FLAGS','Explicit Boolean options.')
    ta,pa,ma,va,oa=path(a);tb,pb,mb,vb,ob=path(b);branches=[]
    for mirror in ([False,True] if allow_reflection else [False]):
        for reverse in ([False,True] if allow_reversal else [False]):
            tt=[1-t for t in ta[::-1]] if reverse else ta
            pp=pa[::-1] if reverse else pa
            pp=[(x,-y if mirror else y) for x,y in pp]
            knots=sorted(set(tt+tb));alpha=F(0);beta=F(0)
            for lo,hi in zip(knots,knots[1:]):
                x,z=at(tt,pp,lo),at(tt,pp,hi);y,w=at(tb,pb,lo),at(tb,pb,hi);h=hi-lo
                alpha+=sum(product(x[j],z[j],y[j],w[j],h) for j in (0,1))
                beta+=product(x[0],z[0],y[1],w[1],h)-product(x[1],z[1],y[0],w[0],h)
            r=(alpha*alpha+beta*beta)/(va*vb)
            if not 0<=r<=1:raise UnresolvedProof('CAUCHY: Exact correlation contradicts Cauchy bound.')
            branches.append({'mirror':mirror,'reversed':reverse,'alpha_raw':encode(alpha),'beta_raw':encode(beta),'ratio':encode(r)})
    best=max(F(x['ratio']) for x in branches);ties=[i for i,x in enumerate(branches) if F(x['ratio'])==best]
    low,high=sqrt_bounds(best,bits)
    # Intersect with [0,1] using the exact proved correlation ratio, not float clipping.
    q2=(max(F(0),2-2*high),2-2*low)
    q=(sqrt_bounds(q2[0],bits)[0],sqrt_bounds(q2[1],bits)[1])
    chosen=branches[ties[0]];aa,bb=F(chosen['alpha_raw']),F(chosen['beta_raw']);norm=aa*aa+bb*bb
    witness={'cos_numerator':encode(aa if norm else F(1)),'sin_numerator':encode(bb if norm else F(0)),'denominator_squared':encode(norm if norm else F(1)),'whole_roll_tie':norm==0}
    return {'schema':'p0a3-qo-rational-2','input_sha256':[digest(encoded_points(points(x,2))) for x in (a,b)],'bits':bits,'allow_reversal':allow_reversal,'allow_reflection':allow_reflection,'branches':branches,'exact_tied_branches':ties,'objective':interval(q),'squared_objective':interval(q2),'witness':witness,'normalizers':[interval(sqrt_bounds(v,bits)) for v in (va,vb)],'centroids':encoded_points((ma,mb)),'omitted_consecutive_indices':[oa,ob],'status':'GLOBAL_CERTIFICATION_DEFERRED','domain':'RATIONAL_COORDINATES_RATIONAL_SEGMENT_LENGTHS_OPEN_ORDERED_SINGLE_PATH'}
