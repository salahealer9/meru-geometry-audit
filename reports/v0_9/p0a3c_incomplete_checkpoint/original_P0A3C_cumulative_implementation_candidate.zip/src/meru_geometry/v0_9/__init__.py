"""P0A3 draft engineering namespace; not installed, frozen or certified."""
SCHEMA_VERSION = "p0a3-candidate-1"
PROVENANCE_CLASS = "INDEPENDENT_DIAGNOSTIC"
