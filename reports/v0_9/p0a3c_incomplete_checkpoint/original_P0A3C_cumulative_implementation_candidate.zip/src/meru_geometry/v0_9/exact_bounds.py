"""INDEPENDENT_DIAGNOSTIC: rational/dyadic outward enclosures, no floats.

Precision is caller supplied. This backend is candidate code, not P0A3 approval.
"""
from fractions import Fraction as F
from math import isqrt
import hashlib,json
from .exceptions import EngineeringError,NotEvaluable,UnresolvedProof

def rational(x):
    if type(x) not in (int,str,F):raise EngineeringError('EXACT_ENCODING','Only integers or exact rational strings/Fraction; no float/bool.')
    try:return F(x)
    except (ValueError,ZeroDivisionError) as e:raise EngineeringError('EXACT_ENCODING',str(e)) from e

def encode(x):
    x=F(x);return f'{x.numerator}/{x.denominator}'

def points(data,dim):
    if not isinstance(data,(list,tuple)):raise EngineeringError('POINTS','Explicit sequence required.')
    out=[]
    for p in data:
        if not isinstance(p,(list,tuple)) or len(p)!=dim:raise EngineeringError('DIMENSION','Wrong coordinate shape.')
        out.append(tuple(rational(x) for x in p))
    return tuple(out)

def encoded_points(data):return [[encode(x) for x in p] for p in data]

def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def sqrt_bounds(x,bits):
    x=rational(x)
    if type(bits) is not int or not 1<=bits<=4096:raise EngineeringError('PRECISION','bits must be 1..4096; engineering resource cap, not accuracy selection.')
    if x<0:raise UnresolvedProof('RADICAND: Negative exact radicand.')
    scale=1<<bits
    k=isqrt((x.numerator*scale*scale)//x.denominator)
    lo=F(k,scale)
    return lo,lo if lo*lo==x else F(k+1,scale)

def exact_sqrt(x):
    x=rational(x)
    if x<0:raise NotEvaluable('RADICAND','Negative exact square.')
    a,b=isqrt(x.numerator),isqrt(x.denominator)
    if a*a!=x.numerator or b*b!=x.denominator:
        raise UnresolvedProof('ALGEBRAIC_DOMAIN: Rational segment lengths required; no rounding fallback.')
    return F(a,b)

def interval(x):return [encode(x[0]),encode(x[1])]

def normalized_support(data):
    p=sorted(set(points(data,2)))
    if not p:raise NotEvaluable('EMPTY','Empty support.')
    mu=tuple(sum(x[j] for x in p)/len(p) for j in range(2))
    z=[tuple(x[j]-mu[j] for j in range(2)) for x in p]
    v=sum(sum(t*t for t in x) for x in z)/len(z)
    if v==0:raise NotEvaluable('ZERO_EXTENT','Zero RMS.')
    return z,mu,v

def pose(c,s):
    c,s=rational(c),rational(s)
    if c*c+s*s!=1:raise EngineeringError('ROTATION','Exact rational unit pair required.')
    return c,s

def qh_enclosure(a,b,*,cosine,sine,mirror,bits):
    if type(mirror) is not bool:raise EngineeringError('MIRROR','Boolean required.')
    c,s=pose(cosine,sine);x,mx,vx=normalized_support(a);y,my,vy=normalized_support(b)
    xx=[(c*p-s*(-q if mirror else q),s*p+c*(-q if mirror else q)) for p,q in x]
    D=vx*vy;root=sqrt_bounds(D,bits);matrix=[]
    for p in xx:
        row=[]
        for q in y:
            base=sum(t*t for t in p)/vx+sum(t*t for t in q)/vy
            coeff=-2*sum(p[j]*q[j] for j in range(2))/D
            vals=[base+coeff*r for r in root]
            # Intersect with a proved nonnegative squared Euclidean distance.
            lo,hi=max(F(0),min(vals)),max(vals)
            if hi<0:raise UnresolvedProof('ENCLOSURE: Inconsistent exact distance enclosure.')
            row.append((sqrt_bounds(lo,bits)[0],sqrt_bounds(hi,bits)[1]))
        matrix.append(row)
    directed=[]
    for rows in (matrix,list(zip(*matrix))):
        directed.append((max(min(v[0] for v in row) for row in rows),max(min(v[1] for v in row) for row in rows)))
    h=(max(v[0] for v in directed),max(v[1] for v in directed))
    rho2=max(sum(t*t for t in p) for p in x)/vx
    return {'objective':interval(h),'rho':interval(sqrt_bounds(rho2,bits)),
            'normalizers':[interval(sqrt_bounds(v,bits)) for v in (vx,vy)],
            'centroids':encoded_points((mx,my)),'cosine':encode(c),'sine':encode(s),'mirror':mirror,
            'arithmetic':'EXACT_FRACTION_DYADIC_OUTWARD','bits':bits,
            'status':'GLOBAL_CERTIFICATION_DEFERRED','scope':'FIXED_RATIONAL_UNIT_POSE'}

def rational_pose(quadrant,t):
    if type(quadrant) is not int or quadrant not in range(4):raise EngineeringError('CHART','Bad quadrant.')
    t=rational(t)
    if not 0<=t<=1:raise EngineeringError('CHART','Chart parameter outside [0,1].')
    c,s=(1-t*t)/(1+t*t),2*t/(1+t*t)
    for _ in range(quadrant):c,s=-s,c
    return c,s

def axis_project(data,triple):
    v=tuple(triple)
    if len(v)!=3 or any(type(x) is not int for x in v) or sum(x*x for x in v)!=1:
        raise UnresolvedProof('CAMERA_DOMAIN: Rigorous numeric camera engine currently supports G0 axes only.')
    j=min(range(3),key=lambda k:abs(v[k]));u=tuple(int(k==j) for k in range(3))
    w=(v[1]*u[2]-v[2]*u[1],v[2]*u[0]-v[0]*u[2],v[0]*u[1]-v[1]*u[0])
    return tuple(tuple(sum(row[k]*p[k] for k in range(3)) for row in (u,w)) for p in points(data,3))

def frame_enclosures(triple,*,bits):
    v=tuple(triple)
    if len(v)!=3 or any(type(x) is not int for x in v) or not any(v):raise EngineeringError('TRIPLE','Nonzero integer triple.')
    s=sum(x*x for x in v);j=min(range(3),key=lambda k:abs(v[k]));d=s-v[j]*v[j]
    e=tuple(int(k==j) for k in range(3));u=tuple(s*e[k]-v[j]*v[k] for k in range(3))
    w=(v[1]*e[2]-v[2]*e[1],v[2]*e[0]-v[0]*e[2],v[0]*e[1]-v[1]*e[0])
    rows=[]
    for row,den in zip((u,w,v),(s*d,d,s)):
        # n/sqrt(d) = (n/d)*sqrt(d): no inverse-zero interval at low precision.
        lo,hi=sqrt_bounds(den,bits);rr=[]
        for n in row:
            vals=(F(n,den)*lo,F(n,den)*hi);rr.append(interval((min(vals),max(vals))))
        rows.append(rr)
    return {'rows':rows,'triple':list(v),'bits':bits,'basis_index':j,'arithmetic':'EXACT_FRACTION_DYADIC_OUTWARD','status':'GLOBAL_CERTIFICATION_DEFERRED'}
