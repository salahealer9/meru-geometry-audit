"""Exact rational-numerator algebraic camera observations for every A/B tier."""
from fractions import Fraction as F
from .p0a3c_interval import I,rat,enc
from .exceptions import EngineeringError,NotEvaluable

def points(data,dim):
    if not isinstance(data,(tuple,list)):raise EngineeringError('POINTS','Explicit finite sequence.')
    out=[]
    for p in data:
        if not isinstance(p,(tuple,list)) or len(p)!=dim:raise EngineeringError('DIMENSION','Wrong dimension.')
        out.append(tuple(rat(x) for x in p))
    return tuple(out)

def observation(data,triple=None):
    if triple is None:return points(data,2),(1,1)
    v=tuple(triple)
    if len(v)!=3 or any(type(x) is not int for x in v) or not any(v):raise EngineeringError('CAMERA','Nonzero integer triple.')
    s=sum(x*x for x in v);j=min(range(3),key=lambda k:abs(v[k]));d=s-v[j]*v[j]
    u=tuple(s*int(k==j)-v[j]*v[k] for k in range(3));e=tuple(int(k==j) for k in range(3))
    w=(v[1]*e[2]-v[2]*e[1],v[2]*e[0]-v[0]*e[2],v[0]*e[1]-v[1]*e[0])
    return tuple(tuple(sum(row[k]*p[k] for k in range(3)) for row in (u,w)) for p in points(data,3)),(s*d,d)

def coordinate_boxes(nums,den,bits):return [tuple(I(x)/I(d).root(bits) for x,d in zip(p,den)) for p in nums]

def support(data,triple,bits):
    raw,den=observation(data,triple);pp=sorted(set(raw))
    if not pp:raise NotEvaluable('EMPTY','No finite points.')
    mu=tuple(sum(p[j] for p in pp)/len(pp) for j in range(2))
    zz=[tuple(p[j]-mu[j] for j in range(2)) for p in pp]
    variance=sum(sum(p[j]*p[j]/den[j] for j in range(2)) for p in zz)/len(pp)
    if variance==0:raise NotEvaluable('COLLAPSED_VIEW','Exact zero projected RMS; view retained as failure.')
    normalized=[tuple(I(p[j])/I(den[j]*variance).root(bits) for j in range(2)) for p in zz]
    rho2=max(sum(p[j]*p[j]/den[j] for j in range(2)) for p in zz)/variance
    return normalized,{'numerators':[[enc(v) for v in p] for p in raw],'denominator_squares':list(den),'distinct_count':len(pp),'duplicate_count':len(raw)-len(pp),'mean_numerators':[enc(x) for x in mu],'variance':enc(variance),'rms':I(variance).root(bits).wire()},I(rho2).root(bits)

def path(data,triple,bits):
    raw,den=observation(data,triple);pp=[];omitted=[]
    for k,p in enumerate(raw):
        if pp and p==pp[-1]:omitted.append(k)
        else:pp.append(p)
    if len(pp)<2:raise NotEvaluable('COLLAPSED_PATH','Empty or constant projected path.')
    lengths=[I(sum((b[j]-a[j])**2/den[j] for j in range(2))).root(bits) for a,b in zip(pp,pp[1:])]
    total=sum(lengths,I(0));dur=[l/total for l in lengths];t=[I(0)]
    for l in lengths[:-1]:t.append((sum(lengths[:len(t)],I(0)))/total)
    t.append(I(1));xy=coordinate_boxes(pp,den,bits)
    mu=[sum((xy[k][j]+xy[k+1][j])*dur[k]/2 for k in range(len(dur))) for j in range(2)]
    zz=[tuple(p[j]-mu[j] for j in range(2)) for p in xy]
    # Integral as midpoint square + endpoint-difference square/12: nonnegative summands.
    variance=sum(dur[k]*sum(((zz[k][j]+zz[k+1][j])/2).square()+(zz[k+1][j]-zz[k][j]).square()/12 for j in range(2)) for k in range(len(dur)))
    rms=variance.root(bits)
    if rms.lo<=0:raise EngineeringError('EXTENT_UNRESOLVED','Positive extent not separated at requested precision.','UNRESOLVED_PROOF')
    norm=[tuple(x/rms for x in p) for p in zz]
    meta={'numerators':[[enc(x) for x in p] for p in raw],'denominator_squares':list(den),'omitted_consecutive_indices':omitted,'lengths':[l.wire() for l in lengths],'total_length':total.wire(),'centroid':[x.wire() for x in mu],'variance':variance.wire(),'rms':rms.wire()}
    return t,dur,norm,meta
