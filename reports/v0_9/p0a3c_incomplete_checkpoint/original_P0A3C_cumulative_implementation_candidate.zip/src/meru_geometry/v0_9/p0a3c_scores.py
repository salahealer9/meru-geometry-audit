"""General algebraic-camera interval score components; never registered certificates."""
from .p0a3c_interval import I,rat,minimum,maximum
from .p0a3c_geometry import path,support
from .exceptions import EngineeringError

def qh(source,target,triple,*,cosine,sine,mirror,bits):
    c,s=rat(cosine),rat(sine)
    if c*c+s*s!=1 or type(mirror) is not bool:raise EngineeringError('POSE','Exact rational unit witness and Boolean mirror.')
    a,ma,rho=support(source,triple,bits);b,mb,_=support(target,None,bits)
    x=[(c*p-s*(-q if mirror else q),s*p+c*(-q if mirror else q)) for p,q in a]
    matrix=[[(sum((p[j]-q[j]).square() for j in range(2))).root(bits) for q in b] for p in x]
    ab=maximum([minimum(row) for row in matrix]);ba=maximum([minimum(list(col)) for col in zip(*matrix)])
    result=maximum([ab,ba])
    return {'score':'QH','objective':result.wire(),'directed_ab':ab.wire(),'directed_ba':ba.wire(),'rho':rho.wire(),'observations':[ma,mb],
            'witness':{'cosine':str(c),'sine':str(s),'mirror':mirror},'bits':bits,'status':'GLOBAL_CERTIFICATION_DEFERRED'}

def qo(source,target,triple,*,mirror,reverse,bits):
    if type(mirror) is not bool or type(reverse) is not bool:raise EngineeringError('BRANCH','Explicit Boolean options.')
    ta,da,a,ma=path(source,triple,bits);tb,db,b,mb=path(target,None,bits)
    if reverse:ta=[1-t for t in ta[::-1]];da=da[::-1];a=a[::-1]
    if mirror:a=[(x,-y) for x,y in a]
    alpha=I(0);beta=I(0)
    def at(pp,tt,dd,k,u):return tuple(pp[k][j]+(pp[k+1][j]-pp[k][j])*(u-tt[k])/dd[k] for j in range(2))
    def prod(x,z,y,w,h):return h*(2*x*y+x*w+z*y+2*z*w)/6
    for i in range(len(da)):
        for j in range(len(db)):
            lo=maximum([ta[i],tb[j]]);hi=maximum([lo,minimum([ta[i+1],tb[j+1]])])
            width=hi-lo;h=I(max(0,width.lo),max(0,width.hi))
            x,z=at(a,ta,da,i,lo),at(a,ta,da,i,hi);y,w=at(b,tb,db,j,lo),at(b,tb,db,j,hi)
            alpha+=sum(prod(x[k],z[k],y[k],w[k],h) for k in range(2))
            beta+=prod(x[0],z[0],y[1],w[1],h)-prod(x[1],z[1],y[0],w[0],h)
    r=(alpha.square()+beta.square()).root(bits).intersect(0,1)
    q2=(2-2*r).intersect(0,2);score=q2.root(bits)
    if alpha.lo==alpha.hi==beta.lo==beta.hi==0:
        witness={'type':'WHOLE_ROLL_TIE','cosine':['1/1','1/1'],'sine':['0/1','0/1']};state='GLOBAL_CERTIFICATION_DEFERRED'
    elif r.lo>0:
        witness={'type':'ALGEBRAIC_OPTIMAL_UNIT_FROM_EXACT_CORRELATIONS','cosine':(alpha/r).wire(),'sine':(beta/r).wire()};state='GLOBAL_CERTIFICATION_DEFERRED'
    else:witness={'type':'UNRESOLVED_ZERO_CORRELATION','cosine':None,'sine':None};state='UNRESOLVED_PROOF'
    return {'score':'QO','objective':score.wire(),'squared_objective':q2.wire(),'alpha':alpha.wire(),'beta':beta.wire(),'correlation_norm':r.wire(),
            'observations':[ma,mb],'witness':witness,'mirror':mirror,'reverse':reverse,'bits':bits,'status':state,'certification':'GLOBAL_CERTIFICATION_DEFERRED'}
