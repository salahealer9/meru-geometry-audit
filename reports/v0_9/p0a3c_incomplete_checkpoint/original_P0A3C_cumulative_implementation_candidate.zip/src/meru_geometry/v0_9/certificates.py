"""Prospective proof requests only. Rigorous numeric certification is unavailable."""
from dataclasses import dataclass, asdict
from fractions import Fraction
from .contracts import VERSION, hash_field, text_field
from .exceptions import EngineeringError, UnresolvedProof

def rational(s):
    if not isinstance(s,str):
        raise EngineeringError("RATIONAL_ENCODING","Use canonical rational strings, never float bounds.")
    try:q=Fraction(s)
    except (ValueError,ZeroDivisionError) as e:
        raise EngineeringError("RATIONAL_ENCODING","Invalid rational.") from e
    canonical=str(q.numerator)+"/"+str(q.denominator)
    if s!=canonical:raise EngineeringError("RATIONAL_ENCODING","Canonical numerator/denominator required.")
    return q

@dataclass(frozen=True)
class CellProposal:
    branch_id: str
    cell_id: str
    start_turn: str
    end_turn: str
    center_turn: str
    center_lower: str
    center_upper: str
    cell_lower: str
    witness_upper: str
    witness_sha256: str
    arithmetic_proof_sha256: str

    def __post_init__(self):
        text_field(self.branch_id);text_field(self.cell_id)
        s,e,c=map(rational,(self.start_turn,self.end_turn,self.center_turn))
        if not (0<=s<1 and 0<=e<=1 and 0<=c<1) or s==e:
            raise EngineeringError("CELL_DOMAIN","Invalid oriented circle cell.")
        span=e-s if e>s else 1+e-s
        if (c-s)%1>span:
            raise EngineeringError("CELL_CENTER","Center outside cell.")
        lo,hi,cl,wu=map(rational,(self.center_lower,self.center_upper,self.cell_lower,self.witness_upper))
        if not 0<=cl<=lo<=hi<=wu:
            raise EngineeringError("BOUND_ORDER","Invalid proposed bound ordering.")
        hash_field(self.witness_sha256);hash_field(self.arithmetic_proof_sha256)

@dataclass(frozen=True)
class ProofProposal:
    score: str
    family: str
    tier: int
    manifest_sha256: str
    input_sha256: tuple
    production_sha256: str
    reference_sha256: str
    configuration_sha256: str
    branch_ids: tuple
    cells: tuple
    L: str
    U: str
    epsilon: str
    uncertainty: tuple
    schema_version: str = VERSION
    arithmetic_backend: str = "NOT_IMPLEMENTED"
    status: str = "UNRESOLVED_PROOF"

    def __post_init__(self):
        if self.schema_version!=VERSION or self.score!="QH" or self.family not in ("A","B") or type(self.tier) is not int or self.tier not in (0,1,2):
            raise EngineeringError("PROOF_SCHEMA","Only prospective QH finite-camera cell proof schema.")
        if self.status!="UNRESOLVED_PROOF" or self.arithmetic_backend!="NOT_IMPLEMENTED":
            raise EngineeringError("PROOF_PROMOTION","No numeric proof backend is implemented.")
        for h in (self.manifest_sha256,self.production_sha256,self.reference_sha256,self.configuration_sha256):
            hash_field(h)
        if len(self.input_sha256)!=2:raise EngineeringError("INPUT_HASHES","Two inputs required.")
        object.__setattr__(self,"input_sha256",tuple(hash_field(h) for h in self.input_sha256))
        if not self.branch_ids or len(set(self.branch_ids))!=len(self.branch_ids):
            raise EngineeringError("BRANCHES","Unique nonempty branch manifest required.")
        for b in self.branch_ids:text_field(b)
        object.__setattr__(self,"branch_ids",tuple(self.branch_ids))
        if not self.cells or not all(isinstance(c,CellProposal) for c in self.cells):
            raise EngineeringError("CELLS","Cell proposal records required.")
        object.__setattr__(self,"cells",tuple(self.cells))
        if set(c.branch_id for c in self.cells)!=set(self.branch_ids):
            raise EngineeringError("MISSING_BRANCH","Every branch requires cells.")
        if len({(c.branch_id,c.cell_id) for c in self.cells})!=len(self.cells):
            raise EngineeringError("DUPLICATE_CELL","Duplicate cell ID.")
        l,u,eps=map(rational,(self.L,self.U,self.epsilon))
        if not 0<=l<=u or eps<0:raise EngineeringError("GAP","Invalid proposed envelope.")
        expected={"observation","sampling","projection","normalization","arithmetic","optimization"}
        if len(self.uncertainty)!=len(expected) or {k for k,v in self.uncertainty}!=expected:
            raise EngineeringError("UNCERTAINTY","All separate error categories required.")
        for k,v in self.uncertainty:
            if v!="NOT_ESTABLISHED" and rational(v)<0:
                raise EngineeringError("UNCERTAINTY","Negative uncertainty.")
        object.__setattr__(self,"uncertainty",tuple(tuple(x) for x in self.uncertainty))

    def to_dict(self):
        return asdict(self)

def promote_to_certified(*args,**kwargs):
    raise UnresolvedProof("Directed/outward arithmetic, witness validation and independent registered QC are unavailable. No certification promotion exists.")
