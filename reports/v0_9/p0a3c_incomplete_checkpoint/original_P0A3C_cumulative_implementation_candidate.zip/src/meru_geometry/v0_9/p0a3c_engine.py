"""Finite-camera candidate orchestration. Never authorizes registered execution.
All work is explicit and caller bounded; no automatic precision/epsilon tuning.
"""
import copy
import hashlib
import json
from fractions import Fraction as F
from .directions import directions
from .p0a3c_interval import I,rat
from .p0a3c_scores import qo,qh

SCHEMA='p0a3c-request-1'
DEFERRED='GLOBAL_CERTIFICATION_DEFERRED'

def dumps(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)
def digest(x):return hashlib.sha256(dumps(x).encode()).hexdigest()
def validate(r):
    keys={'schema','score','family','tier','convention','reflection','reversal','source','target','bits','checker_bits','level','epsilon','limits','authority','information_barrier'}
    if set(r)!=keys or r['schema']!=SCHEMA:raise ValueError('REQUEST_SCHEMA')
    if r['score'] not in ('QO','QH') or r['convention'] not in ('SO2','O2'):raise ValueError('SCORE_CONVENTION')
    if any(type(r[k]) is not bool for k in ('reflection','reversal')):raise ValueError('BRANCH_BOOLEAN')
    if r['convention']=='O2' and not r['reflection']:raise ValueError('AXIS_REQUIRES_REFLECTION')
    if r['score']=='QH' and r['reversal']:raise ValueError('QH_HAS_NO_TRAVERSAL')
    if r['authority']!='01270ec3bff3c9a6352c5dadc90d5d9f12da0c0d' or r['information_barrier']!='GENERIC_TARGET_FREE_ONLY':raise ValueError('AUTHORITY_BARRIER')
    if any(type(r[k]) is not int for k in ('bits','checker_bits','level')) or not 2<=r['bits']<=r['checker_bits']<=4096 or not 0<=r['level']<=16:raise ValueError('PRECISION_LEVEL')
    if rat(r['epsilon'])<=0:raise ValueError('EPSILON')
    lim=r['limits']
    if set(lim)!={'max_vertices','max_input_bits','max_cells','max_steps'} or any(type(v) is not int or v<=0 for v in lim.values()):raise ValueError('LIMITS')
    for name,dim in (('source',3),('target',2)):
        data=r[name]
        if not isinstance(data,list) or not 2<=len(data)<=lim['max_vertices']:raise ValueError('INPUT_COUNT')
        for p in data:
            if not isinstance(p,list) or len(p)!=dim:raise ValueError('INPUT_DIMENSION')
            for x in p:
                z=rat(x)
                if max(abs(z.numerator).bit_length(),z.denominator.bit_length())>lim['max_input_bits']:raise ValueError('INPUT_BITS')
    ds=directions(r['family'],r['tier'],r['convention'])
    count=len(ds)*(2 if r['reflection'] else 1)*(2 if r['score']=='QO' and r['reversal'] else 1)*(4*2**r['level'] if r['score']=='QH' else 1)
    if count>lim['max_cells']:raise ValueError('CELL_RESOURCE_LIMIT')
    return r

def tasks(r):
    validate(r);out=[]
    for d in directions(r['family'],r['tier'],r['convention']):
        for mirror in ((False,True) if r['reflection'] else (False,)):
            if r['score']=='QO':
                for reverse in ((False,True) if r['reversal'] else (False,)):
                    out.append({'id':f'{d.direction_id}|m{int(mirror)}|r{int(reverse)}','triple':list(d.triple),'mirror':mirror,'reverse':reverse})
            else:
                for chart in range(4):
                    for cell in range(2**r['level']):
                        out.append({'id':f'{d.direction_id}|m{int(mirror)}|q{chart}|l{r["level"]}|i{cell}','triple':list(d.triple),'mirror':mirror,'chart':chart,'cell':cell})
    return out

def pose(chart,t):
    c=(1-t*t)/(1+t*t);s=2*t/(1+t*t)
    return ((c,s),(-s,c),(-c,-s),(s,-c))[chart]

def evaluate_task(r,task):
    if task not in tasks(r):raise ValueError('UNREGISTERED_TASK')
    if r['score']=='QO':
        value=qo(r['source'],r['target'],task['triple'],mirror=task['mirror'],reverse=task['reverse'],bits=r['bits'])
        bounds=value['objective']
    else:
        n=2**r['level'];lo=F(task['cell'],n);hi=F(task['cell']+1,n);mid=(lo+hi)/2;c,s=pose(task['chart'],mid)
        value=qh(r['source'],r['target'],task['triple'],cosine=c,sine=s,mirror=task['mirror'],bits=r['bits'])
        f=I(*value['objective']);rho=I(*value['rho'])
        bounds=I(max(F(0),f.lo-rho.hi*(hi-lo)),f.hi).wire()
        value['cell']={'t_interval':[str(lo),str(hi)],'midpoint':str(mid),'angle_radius_upper':str(hi-lo),'chart':task['chart']}
    return {'task':copy.deepcopy(task),'bounds':bounds,'value':value}

def summary(r,completed,failures,pending):
    witness=min((F(x['bounds'][1]) for x in completed),default=None)
    if failures:return {'status':'INCOMPLETE_STICKY_FAILURE','last_feasible_upper':None if witness is None else str(witness),'certification':DEFERRED}
    if pending:return {'status':'INCOMPLETE_PENDING','last_feasible_upper':None if witness is None else str(witness),'certification':DEFERRED}
    lo=min(F(x['bounds'][0]) for x in completed);hi=min(F(x['bounds'][1]) for x in completed)
    unresolved=any(x['value']['status']=='UNRESOLVED_PROOF' for x in completed)
    status='UNRESOLVED_PROOF' if unresolved else ('ENGINEERING_CERTIFICATE_CANDIDATE_UNVALIDATED' if hi-lo<=rat(r['epsilon']) else 'INCOMPLETE_GAP')
    possible=[x['task']['id'] for x in completed if F(x['bounds'][0])<=hi]
    exact_ties=[x['task']['id'] for x in completed if F(x['bounds'][0])==F(x['bounds'][1])==hi]
    return {'status':status,'bounds':[str(lo),str(hi)],'gap':str(hi-lo),'possible_minimizers':possible,'proved_point_ties':exact_ties,'overlap_is_equality':False,'certification':DEFERRED}

def start(r):
    ts=tasks(r)
    return {'schema':'p0a3c-checkpoint-1','request':copy.deepcopy(r),'request_sha256':digest(r),'input_sha256':{k:digest(r[k]) for k in ('source','target')},'completed':[],'failures':[],'pending':ts,'summary':summary(r,[],[],ts)}

def advance_verified(state,verified_receipt,steps):
    """Internal orchestration entry: public resume layer supplies independent receipt.
    A receipt is a guard against accidental stale use, NOT a security signature.
    """
    if verified_receipt!=digest(state):raise ValueError('STALE_VERIFICATION_RECEIPT')
    r=state['request'];validate(r)
    if type(steps) is not int or not 0<=steps<=r['limits']['max_steps']:raise ValueError('STEP_LIMIT')
    out=copy.deepcopy(state)
    if out['failures']:return out
    for _ in range(min(steps,len(out['pending']))):
        task=out['pending'][0]
        try:record=evaluate_task(r,task)
        except Exception as e:
            if 'CONTRADICTION' in str(e):raise
            out['failures'].append({'task':task,'error_type':type(e).__name__,'error':str(e),'status':'INCOMPLETE_STICKY_FAILURE'})
            out['pending'].pop(0);break
        out['completed'].append(record);out['pending'].pop(0)
    out['summary']=summary(r,out['completed'],out['failures'],out['pending'])
    return out
