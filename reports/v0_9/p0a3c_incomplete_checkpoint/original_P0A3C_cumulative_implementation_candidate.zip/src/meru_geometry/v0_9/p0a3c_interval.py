"""Candidate exact-rational outward interval backend. No binary64 arithmetic.
INDEPENDENT_DIAGNOSTIC; GLOBAL_CERTIFICATION_DEFERRED.
"""
from dataclasses import dataclass
from fractions import Fraction as F
from math import isqrt
from .exceptions import EngineeringError,UnresolvedProof

def rat(x):
    if type(x) not in (int,str,F):raise EngineeringError('RATIONAL','Exact rational input required, no bool/float.')
    try:return F(x)
    except (ValueError,ZeroDivisionError) as e:raise EngineeringError('RATIONAL',str(e)) from e
def enc(x):x=F(x);return f'{x.numerator}/{x.denominator}'

@dataclass(frozen=True)
class I:
    lo:F
    hi:F|None=None
    def __post_init__(self):
        a=rat(self.lo);b=a if self.hi is None else rat(self.hi)
        if a>b:raise EngineeringError('INTERVAL','Inverted endpoints.')
        object.__setattr__(self,'lo',a);object.__setattr__(self,'hi',b)
    def __add__(self,b):b=as_i(b);return I(self.lo+b.lo,self.hi+b.hi)
    __radd__=__add__
    def __neg__(self):return I(-self.hi,-self.lo)
    def __sub__(self,b):return self+-as_i(b)
    def __rsub__(self,b):return as_i(b)+-self
    def __mul__(self,b):
        b=as_i(b);v=[a*c for a in (self.lo,self.hi) for c in (b.lo,b.hi)];return I(min(v),max(v))
    __rmul__=__mul__
    def __truediv__(self,b):
        b=as_i(b)
        if b.lo<=0<=b.hi:raise UnresolvedProof('DENOMINATOR_NOT_SEPARATED_FROM_ZERO')
        return self*I(1/b.hi,1/b.lo)
    def square(self):
        return I(0 if self.lo<=0<=self.hi else min(self.lo*self.lo,self.hi*self.hi),max(self.lo*self.lo,self.hi*self.hi))
    def intersect(self,lo,hi):
        a,b=max(self.lo,F(lo)),min(self.hi,F(hi))
        if a>b:raise EngineeringError('ENCLOSURE_CONTRADICTION','Empty intersection with proved range. STOP.')
        return I(a,b)
    def root(self,bits):
        if self.lo<0:raise UnresolvedProof('UNPROVED_NONNEGATIVE_ROOT')
        return I(root_end(self.lo,bits,False),root_end(self.hi,bits,True))
    def wire(self):return [enc(self.lo),enc(self.hi)]

def as_i(x):return x if isinstance(x,I) else I(x)
def root_end(x,bits,upper):
    if type(bits) is not int or not 2<=bits<=4096:raise EngineeringError('PRECISION','Caller bits 2..4096, engineering cap.')
    s=1<<bits;k=isqrt((x.numerator*s*s)//x.denominator)
    return F(k+int(upper and F(k*k,s*s)!=x),s)
def minimum(values):return I(min(v.lo for v in values),min(v.hi for v in values))
def maximum(values):return I(max(v.lo for v in values),max(v.hi for v in values))
