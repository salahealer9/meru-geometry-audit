"""Strict versioned record serialization; no dynamic imports, NaN or Infinity."""
from dataclasses import asdict, fields, replace
import json
from .contracts import (Geometry, Options, Normalization, Result, EvaluationContext,
                        VERSION, digest, export_budget)
from .exceptions import EngineeringError

TYPES = {"geometry": Geometry, "result": Result}

def exact_keys(d, expected):
    if not isinstance(d, dict) or set(d) != set(expected):
        raise EngineeringError("SCHEMA_KEYS", "Unknown or missing keys.")

def dumps(record):
    kind = next((k for k,c in TYPES.items() if isinstance(record,c)), None)
    if kind is None:
        raise EngineeringError("RECORD_TYPE", "Only Geometry/Result records supported.")
    return json.dumps({"schema_version": VERSION, "record_type": kind, "payload": asdict(record)},
                      sort_keys=True, separators=(",", ":"), allow_nan=False, ensure_ascii=True)+"\n"

def _pairs(items):
    out = {}
    for k,v in items:
        if k in out:
            raise EngineeringError("DUPLICATE_KEY", "Duplicate JSON key.")
        out[k]=v
    return out

def _nonfinite(s):
    raise EngineeringError("NONFINITE_JSON", "Non-standard JSON number prohibited.")

def loads(text):
    try:
        d=json.loads(text, object_pairs_hook=_pairs, parse_constant=_nonfinite)
        exact_keys(d, ("schema_version","record_type","payload"))
        if d["schema_version"] != VERSION or d["record_type"] not in TYPES:
            raise EngineeringError("VERSION", "Unknown schema or record type.")
        cls=TYPES[d["record_type"]];p=d["payload"]
        exact_keys(p, [f.name for f in fields(cls)])
        if cls is Result:
            exact_keys(p["options"], [f.name for f in fields(Options)])
            p["options"]=Options(**p["options"])
            if not isinstance(p["normalizations"],list):
                raise EngineeringError("NORMALIZATIONS", "Expected JSON array.")
            ns=[]
            for n in p["normalizations"]:
                exact_keys(n,[f.name for f in fields(Normalization)])
                ns.append(Normalization(**n))
            p["normalizations"]=tuple(ns)
            if p["context"] is not None:
                exact_keys(p["context"],[f.name for f in fields(EvaluationContext)])
                p["context"]=EvaluationContext(**p["context"])
        return cls(**p)
    except EngineeringError:
        raise
    except (ValueError, TypeError, KeyError, OverflowError) as e:
        raise EngineeringError("JSON_SCHEMA", str(e)) from e

def error_json(exc):
    if not isinstance(exc, EngineeringError):
        raise TypeError("Only explicit engineering failures may be serialized.")
    return json.dumps({"schema_version":VERSION,"status":exc.status,
                       "error_code":exc.code,"message":str(exc)},
                      sort_keys=True,allow_nan=False)+"\n"

def bind_result(result,*,manifest,direction_id,budget,production_sha256,
                reference_sha256,configuration_sha256):
    """Bind explicit metadata, not certify the camera-to-input transformation."""
    from .directions import manifest as expected_manifest
    if not isinstance(result,Result):raise EngineeringError("RESULT_TYPE","Result record required.")
    try:
        p=manifest["payload"]
        expected=expected_manifest(p["family"],p["tier"],p["convention"])
        if manifest!=expected or p["convention"]!=result.options.group:
            raise EngineeringError("MANIFEST_BINDING","Manifest/convention mismatch.")
        if direction_id not in {d["id"] for d in p["directions"]}:
            raise EngineeringError("CAMERA_BINDING","Unknown exact camera.")
        expected_budget=export_budget(result.score,p["family"],p["tier"],result.options,
                         resource_policy_id=budget["resource_policy_id"],
                         accuracy_policy_id=budget["accuracy_policy_id"])
        if budget!=expected_budget:raise EngineeringError("BUDGET_BINDING","Budget/score/nuisance mismatch.")
        ctx=EvaluationContext(p["family"],p["tier"],direction_id,manifest["sha256"],digest(budget),
                              production_sha256,reference_sha256,configuration_sha256)
        return replace(result,context=ctx)
    except (KeyError,TypeError) as e:
        raise EngineeringError("CONTEXT_SCHEMA","Malformed binding record.") from e
