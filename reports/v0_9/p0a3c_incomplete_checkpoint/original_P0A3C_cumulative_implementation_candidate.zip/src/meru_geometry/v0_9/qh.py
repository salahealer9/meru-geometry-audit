"""QH fixed-pose finite-support engineering evaluator; no global roll search."""
from dataclasses import dataclass
import math
import sys
from .contracts import (Options, Normalization, Result, number,
                        require_geometry, failed)
from .exceptions import EngineeringError, NotEvaluable

@dataclass(frozen=True)
class Support:
    points: tuple
    normalization: Normalization

def normalize(g):
    require_geometry(g,"R2-U")
    if g.ordered is not False or g.closed is not None or g.stroke_count is not None:
        raise NotEvaluable("SUPPORT_SEMANTICS","Unordered support has no closure/stroke metadata.")
    pts=tuple(sorted(set(g.coordinates)))  # exact equality of represented binary64 points
    if len(pts)<2:
        raise NotEvaluable("EMPTY_OR_ZERO_EXTENT","Nonempty positive-extent support required.")
    anchor=pts[0];rel=tuple(tuple(p[j]-anchor[j] for j in range(2)) for p in pts)
    if not all(math.isfinite(x) for p in rel for x in p):
        raise NotEvaluable("ARITHMETIC_RANGE","Centering overflow.")
    mu=tuple(math.fsum(p[j] for p in rel)/len(pts) for j in range(2))
    centered=tuple(tuple(p[j]-mu[j] for j in range(2)) for p in rel)
    r2=math.fsum(x*x for p in centered for x in p)/len(pts)
    if not math.isfinite(r2) or r2<sys.float_info.min:
        raise NotEvaluable("RMS_RANGE","Zero, subnormal, underflowed or overflowed squared extent; no certified tiny-scale backend.")
    r=math.sqrt(r2);out=tuple(tuple(x/r for x in p) for p in centered)
    if not all(math.isfinite(x) for p in out for x in p):
        raise NotEvaluable("NORMALIZATION_RANGE","Nonfinite normalized support.")
    mean=tuple(anchor[j]+mu[j] for j in range(2))
    return Support(out,Normalization("UNIFORM_DISTINCT_POINTS",mean,r,
                   ("EXACT_DUPLICATES_REMOVED:"+str(len(g.coordinates)-len(pts)),
                    "NO_TOLERANCE_MERGE_NO_GRAPH_INFERENCE")))

def pair_extrema(a,b):
    """Nonempty finite coordinates, fixed pose. Return directed maxima separately."""
    if not a or not b:
        raise NotEvaluable("EMPTY_SUPPORT","Empty observations are unscored.")
    da=max(min(math.hypot(x[0]-y[0],x[1]-y[1]) for y in b) for x in a)
    db=max(min(math.hypot(x[0]-y[0],x[1]-y[1]) for x in a) for y in b)
    if not math.isfinite(da) or not math.isfinite(db):
        raise NotEvaluable("DISTANCE_RANGE","Unrepresentable distance.")
    return da,db

def evaluate_at_angle(a,b,angle,options=Options(),*,mirror=False):
    require_geometry(a,"R2-U");require_geometry(b,"R2-U")
    if not isinstance(options,Options) or options.allow_reversal:
        raise EngineeringError("QH_OPTIONS","Support has no traversal/reversal.")
    if type(mirror) is not bool or (mirror and options.group!="O2"):
        raise EngineeringError("MIRROR_PERMISSION","Mirror requires explicit O2.")
    theta=number(angle)%(2*math.pi)
    try:
        x,y=normalize(a),normalize(b);c,s=math.cos(theta),math.sin(theta)
        xx=tuple((p[0],-p[1] if mirror else p[1]) for p in x.points)
        rot=tuple((c*p[0]-s*p[1],s*p[0]+c*p[1]) for p in xx)
        da,db=pair_extrema(rot,y.points);value=max(da,db)
        return Result("QH","LOCAL_ONLY",value,value*value,(a.fingerprint,b.fingerprint),
                      options,(x.normalization,y.normalization),
                      (("angle",theta),("mirror",mirror),("directed_ab",da),("directed_ba",db)),
                      ("FIXED_POSE_ONLY_NO_ROLL_MINIMUM","BINARY64_NO_OUTWARD_ENCLOSURE",
                       "NOT_A_CERTIFIED_FEASIBLE_UPPER_BOUND","FINITE_SUPPORT_NOT_TOPOLOGY"))
    except EngineeringError as exc:
        return failed("QH",a,b,options,exc)
    except (OverflowError,ZeroDivisionError) as exc:
        return failed("QH",a,b,options,NotEvaluable("ARITHMETIC_RANGE",str(exc)))
