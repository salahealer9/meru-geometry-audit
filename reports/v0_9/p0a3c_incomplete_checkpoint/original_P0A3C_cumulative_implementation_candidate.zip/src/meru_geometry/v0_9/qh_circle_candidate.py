"""Prospective G0-only full-circle engine. No phase certification promotion.

Circle charts: quadrant k, theta=k*pi/2+2*atan(t), 0<=t<=1.
Caller supplies all precision/partition/error/resource settings; no scientific defaults.
"""
import json,time
from fractions import Fraction as F
from .exact_bounds import (points,encoded_points,rational,encode,digest,axis_project,
                           rational_pose,qh_enclosure)
from .directions import manifest
from .exceptions import EngineeringError

def request(source,target,*,family,tier,group,bits,level,epsilon,pins,permission_id):
    if tier!=0 or type(tier) is not int:raise EngineeringError('UNSUPPORTED_CAMERA_DOMAIN','New rigorous engine supports both families G0 only; G1/G2 deferred.')
    if type(bits) is not int or not 1<=bits<=4096 or type(level) is not int or not 0<=level<=16:
        raise EngineeringError('RESOURCE_DOMAIN','bits 1..4096 and level 0..16 are engineering caps, not final parameters.')
    eps=rational(epsilon)
    if eps<=0:raise EngineeringError('EPSILON','Caller must supply positive prospective epsilon.')
    if not isinstance(permission_id,str) or not permission_id or (group=='O2' and permission_id=='primary-no-reversal'):
        raise EngineeringError('PERMISSION','Explicit sensitivity permission required.')
    names={'production','reference','configuration','resource_policy'}
    if not isinstance(pins,dict) or set(pins)!=names or any(not isinstance(h,str) or len(h)!=64 or any(c not in '0123456789abcdef' for c in h) for h in pins.values()):
        raise EngineeringError('PINS','Exact SHA-256 pins required; caller must independently trust them.')
    return {'schema':'p0a3-qh-circle-2','source':encoded_points(points(source,3)),'target':encoded_points(points(target,2)),
            'manifest':manifest(family,tier,group),'bits':bits,'level':level,'epsilon':encode(eps),'pins':dict(pins),
            'permission_id':permission_id,'input_class':'INDEPENDENT_DIAGNOSTIC','observation':'FINITE_VERTEX_ORTHOGRAPHIC_NOT_SHADOW'}

def validate_request(r):
    keys={'schema','source','target','manifest','bits','level','epsilon','pins','permission_id','input_class','observation'}
    if not isinstance(r,dict) or set(r)!=keys:raise EngineeringError('REQUEST_SCHEMA','Unknown/missing fields.')
    try:
        m=r['manifest']['payload']
        canonical=request(r['source'],r['target'],family=m['family'],tier=m['tier'],group=m['convention'],bits=r['bits'],level=r['level'],epsilon=r['epsilon'],pins=r['pins'],permission_id=r['permission_id'])
    except (KeyError,TypeError) as e:raise EngineeringError('REQUEST_SCHEMA',str(e)) from e
    if canonical!=r:raise EngineeringError('REQUEST_CANONICAL','Request must be canonical and exact.')

def plan(r):
    validate_request(r);out=[];n=1<<r['level']
    for d in r['manifest']['payload']['directions']:
        for mirror in ([False,True] if r['manifest']['payload']['convention']=='O2' else [False]):
            for quadrant in range(4):
                for i in range(n):
                    out.append({'id':f"{d['id']}|{int(mirror)}|{quadrant}|{i}",'direction':d['id'],'mirror':mirror,'quadrant':quadrant,'lo':encode(F(i,n)),'hi':encode(F(i+1,n))})
    return out

def cell_value(r,cell):
    d=next(x for x in r['manifest']['payload']['directions'] if x['id']==cell['direction'])
    a=axis_project(r['source'],d['triple']);lo,hi=F(cell['lo']),F(cell['hi'])
    c,s=rational_pose(cell['quadrant'],(lo+hi)/2)
    v=qh_enclosure(a,r['target'],cosine=c,sine=s,mirror=cell['mirror'],bits=r['bits'])
    lower=max(F(0),F(v['objective'][0])-F(v['rho'][1])*(hi-lo))
    return {'cell':cell,'pose':v,'cell_lower':encode(lower),'witness_upper':v['objective'][1],
            'observation_sha256':digest(encoded_points(a)),'request_sha256':digest(r)}

def start(r):
    cells=plan(r)
    return {'schema':'p0a3-qh-checkpoint-2','request':r,'request_sha256':digest(r),'completed':[],
            'pending':cells,'failure':None,'stop_reason':'NOT_STARTED','status':'UNRESOLVED_PROOF'}

def validate_checkpoint(state,expected_request):
    keys={'schema','request','request_sha256','completed','pending','failure','stop_reason','status'}
    if not isinstance(state,dict) or set(state)!=keys or state['schema']!='p0a3-qh-checkpoint-2':raise EngineeringError('CHECKPOINT_SCHEMA','Unknown checkpoint.')
    validate_request(expected_request)
    if state['request']!=expected_request or state['request_sha256']!=digest(expected_request):raise EngineeringError('CHECKPOINT_PINS','Externally expected request mismatch.')
    allcells=plan(expected_request);done=state['completed']
    if not isinstance(done,list) or len(done)>len(allcells) or state['pending']!=allcells[len(done):]:raise EngineeringError('CHECKPOINT_COVERAGE','Missing/reordered pending cells.')
    for expected,actual in zip(allcells,done):
        if actual!=cell_value(expected_request,expected):raise EngineeringError('CHECKPOINT_WITNESS','Stored witness/bounds changed; replay under exact production semantics rejected.')
    if state['status'] not in ('LOCAL_ONLY','UNRESOLVED_PROOF','GLOBAL_CERTIFICATION_DEFERRED'):raise EngineeringError('PROMOTION','No certified status in P0A3.')

def advance(state,expected_request,*,max_cells,wall_seconds=None):
    validate_checkpoint(state,expected_request)
    if type(max_cells) is not int or max_cells<0:raise EngineeringError('BUDGET','Nonnegative deterministic cell budget required.')
    if wall_seconds is not None and (type(wall_seconds) not in (int,float) or not 0<wall_seconds<float('inf')):raise EngineeringError('TIMEOUT','Finite positive engineering wall budget required.')
    s=json.loads(json.dumps(state,allow_nan=False));deadline=None if wall_seconds is None else time.monotonic()+wall_seconds
    if s['failure'] is not None:raise EngineeringError('FAILED_CHECKPOINT','Failure requires review, not silent resume.')
    reason='CELL_BUDGET'
    for _ in range(max_cells):
        if not s['pending']:break
        if deadline is not None and time.monotonic()>=deadline:reason='TIMEOUT';break
        cell=s['pending'][0]
        try:v=cell_value(expected_request,cell)
        except EngineeringError as e:
            s['failure']={'cell':cell,'status':e.status,'code':e.code,'message':str(e)};reason='UNEVALUABLE_BRANCH';break
        s['completed'].append(v);s['pending'].pop(0)
    if not s['pending'] and s['failure'] is None:reason='ALL_CELLS_EVALUATED'
    s['stop_reason']=reason
    s['status']='GLOBAL_CERTIFICATION_DEFERRED' if reason=='ALL_CELLS_EVALUATED' else ('LOCAL_ONLY' if s['completed'] else 'UNRESOLVED_PROOF')
    return s

def dumps(state):return json.dumps(state,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n'

def loads(text,expected_request):
    def pairs(xs):
        d={}
        for k,v in xs:
            if k in d:raise EngineeringError('DUPLICATE_KEY','Duplicate JSON key.')
            d[k]=v
        return d
    def bad(x):raise EngineeringError('NONFINITE_JSON','Nonfinite JSON prohibited.')
    try:s=json.loads(text,object_pairs_hook=pairs,parse_constant=bad)
    except (ValueError,TypeError) as e:raise EngineeringError('JSON',str(e)) from e
    validate_checkpoint(s,expected_request);return s
