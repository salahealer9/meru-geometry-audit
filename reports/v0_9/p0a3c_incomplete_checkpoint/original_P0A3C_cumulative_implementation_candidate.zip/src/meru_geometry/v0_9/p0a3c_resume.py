"""Public checked checkpoint orchestration; reference imports no production code.
Single writer only. No wall-clock, OS kill, disk-loss or memory-limit guarantee.
"""
import hashlib
import json
import os
import tempfile
from pathlib import Path
from .p0a3c_engine import dumps,advance_verified
from reference.v0_9.p0a3c_checker import check

def advance(state,trusted,steps):
    checked=check(state,trusted)
    result=advance_verified(state,checked['receipt'],steps)
    check(result,trusted)
    return result

def save(path,state,trusted,inject=None):
    check(state,trusted);path=Path(path)
    data=dumps(state).encode();envelope=dumps({'payload':state,'sha256':hashlib.sha256(data).hexdigest()}).encode()
    fd,name=tempfile.mkstemp(prefix=path.name+'.tmp-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(envelope);f.flush();os.fsync(f.fileno())
        if inject:inject('BEFORE_REPLACE')
        os.replace(name,path)
        if inject:inject('AFTER_REPLACE')
        directory=os.open(path.parent,os.O_RDONLY)
        try:os.fsync(directory)
        finally:os.close(directory)
    finally:
        if os.path.exists(name):os.unlink(name)

def load(path,trusted,max_bytes):
    if type(max_bytes) is not int or max_bytes<=0:raise ValueError('EXPLICIT_READ_SIZE_CAP')
    def pairs(items):
        out={}
        for k,v in items:
            if k in out:raise ValueError('DUPLICATE_JSON_KEY')
            out[k]=v
        return out
    with open(path,'rb') as f:data=f.read(max_bytes+1)
    if len(data)>max_bytes:raise ValueError('CHECKPOINT_SIZE_CAP')
    def reject(x):raise ValueError('NONFINITE_OR_FLOAT_JSON')
    blob=json.loads(data,object_pairs_hook=pairs,parse_float=reject,parse_constant=reject)
    if set(blob)!={'payload','sha256'} or hashlib.sha256(dumps(blob['payload']).encode()).hexdigest()!=blob['sha256']:raise ValueError('CHECKPOINT_DIGEST')
    check(blob['payload'],trusted)
    return blob['payload']
