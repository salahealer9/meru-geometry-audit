"""Orthographic point observation only; never a physical-shadow operator."""
from dataclasses import dataclass
import math
from .contracts import Geometry, require_geometry, require_open
from .exceptions import NotEvaluable, EngineeringError
from .directions import Direction, frame_lift

@dataclass(frozen=True)
class ProjectionObservation:
    geometry: Geometry
    direction_id: str
    source_fingerprint: str
    events: tuple
    arithmetic: str = "BINARY64_UNCERTIFIED"
    operator: str = "ORTHOGRAPHIC_CENTRELINE_NOT_PHYSICAL_SHADOW"

def project(source,direction,*,support=False):
    require_geometry(source,"R3-C")
    if type(support) is not bool or not isinstance(direction,Direction):
        raise EngineeringError("PROJECTION_OPTIONS","Explicit direction and Boolean support flag required.")
    if not support:require_open(source)
    frame=frame_lift(direction)
    try:
        pts=tuple(tuple(math.fsum(row[j]*p[j] for j in range(3)) for row in frame.rows[:2])
                  for p in source.coordinates)
    except (OverflowError,ValueError) as exc:
        raise NotEvaluable("PROJECTION_RANGE","Unrepresentable projected sum.") from exc
    if not all(math.isfinite(x) for p in pts for x in p):
        raise NotEvaluable("PROJECTION_RANGE","Nonfinite projected coordinate.")
    events=tuple("PROJECTED_CONSECUTIVE_COLLAPSE:"+str(i) for i,(a,b) in enumerate(zip(pts,pts[1:])) if a==b)
    if support:
        events+=("FINITE_VERTICES_ONLY_NO_CONTINUOUS_COVER",
                 "EXACT_FLOAT_COINCIDENCES:"+str(len(pts)-len(set(pts))))
    geom=Geometry("R2-U" if support else "R2-O",pts,source.input_id+"@"+direction.direction_id,
                  source.units,source.fingerprint,False if support else True,
                  None if support else False,None if support else 1)
    return ProjectionObservation(geom,direction.direction_id,source.fingerprint,events)
