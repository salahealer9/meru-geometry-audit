"""Explicit unscored failures. No exception is converted into a zero score."""
class EngineeringError(ValueError):
    def __init__(self, code, message, status="INVALID_INPUT"):
        super().__init__(message)
        self.code, self.status = code, status

class NotEvaluable(EngineeringError):
    def __init__(self, code, message):
        super().__init__(code, message, "NOT_EVALUABLE")

class UnresolvedProof(EngineeringError):
    def __init__(self, message):
        super().__init__("PROOF_UNAVAILABLE", message, "UNRESOLVED_PROOF")
