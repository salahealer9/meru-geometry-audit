"""Exact symbolic membership; floating frame lifts remain uncertified."""
from dataclasses import dataclass
from itertools import product, permutations
import math
from .contracts import digest
from .exceptions import EngineeringError

LAYERS={"A":("A0","C","E"),"B":("A0","E","T")}

@dataclass(frozen=True)
class Direction:
    family: str
    tier: int
    stratum: str
    triple: tuple
    convention: str = "SO2"

    def __post_init__(self):
        if self.family not in LAYERS or type(self.tier) is not int or self.tier not in (0,1,2):
            raise EngineeringError("DIRECTION_FAMILY","Unknown family or tier.")
        if self.stratum not in LAYERS[self.family][:self.tier+1] or self.convention not in ("SO2","O2"):
            raise EngineeringError("DIRECTION_STRATUM","Invalid stratum/convention.")
        v=tuple(self.triple)
        if len(v)!=3 or any(type(x) is not int for x in v):
            raise EngineeringError("DIRECTION_TRIPLE","Exact integer triple required.")
        expected={"A0":[0,0,1],"C":[1,1,1],"E":[0,1,1],"T":[0,1,2]}[self.stratum]
        if sorted(abs(x) for x in v)!=expected:
            raise EngineeringError("DIRECTION_PATTERN","Invalid exact magnitude pattern.")
        if self.convention=="O2" and next(x for x in v if x)!=abs(next(x for x in v if x)):
            raise EngineeringError("AXIS_REPRESENTATIVE","First nonzero coordinate must be positive.")
        object.__setattr__(self,"triple",v)

    @property
    def direction_id(self):
        return self.stratum+":"+",".join(str(x) for x in self.triple)

    @property
    def norm_squared(self):return sum(x*x for x in self.triple)

    @property
    def antipode_id(self):return self.stratum+":"+",".join(str(-x) for x in self.triple)

def _stratum(name):
    if name=="A0":
        return sorted({tuple(s if j==i else 0 for j in range(3)) for i in range(3) for s in (-1,1)})
    if name=="C":return sorted(product((-1,1),repeat=3))
    if name=="E":return sorted({p for a,b in product((-1,1),repeat=2) for p in permutations((a,b,0))})
    if name=="T":return sorted({p for a,b in product((-1,1),repeat=2) for p in permutations((2*a,b,0))})
    raise EngineeringError("STRATUM","Unknown stratum.")

def directions(family,tier,convention="SO2"):
    if family not in LAYERS or type(tier) is not int or tier not in (0,1,2) or convention not in ("SO2","O2"):
        raise EngineeringError("FAMILY","Invalid exact design request.")
    return tuple(Direction(family,tier,s,v,convention)
                 for s in LAYERS[family][:tier+1] for v in _stratum(s)
                 if convention=="SO2" or next(x for x in v if x)>0)

def manifest(family,tier,convention="SO2"):
    ds=directions(family,tier,convention)
    payload={"schema_version":"p0a3-directions-1","family":family,"tier":tier,
             "convention":convention,"final_experimental_tier":False,
             "covering_certificate":"NOT_ESTABLISHED",
             "directions":[{"id":d.direction_id,"stratum":d.stratum,"triple":list(d.triple),
                            "norm_squared":d.norm_squared,"antipode_id":d.antipode_id} for d in ds]}
    return {"payload":payload,"sha256":digest(payload)}

@dataclass(frozen=True)
class Frame:
    rows: tuple
    basis_index: int
    seam_tie_indices: tuple
    direction_id: str
    arithmetic: str = "BINARY64_UNCERTIFIED"

def frame_lift(d):
    if not isinstance(d,Direction):raise EngineeringError("DIRECTION","Direction record required.")
    j=min(range(3),key=lambda k:abs(d.triple[k]))  # exact tie order x,y,z
    n=tuple(x/math.sqrt(d.norm_squared) for x in d.triple)
    den=math.sqrt(1-n[j]*n[j])
    u=tuple(((1.0 if k==j else 0.0)-n[j]*n[k])/den for k in range(3))
    v=(n[1]*u[2]-n[2]*u[1],n[2]*u[0]-n[0]*u[2],n[0]*u[1]-n[1]*u[0])
    ties=tuple(k for k in range(3) if abs(d.triple[k])==abs(d.triple[j]))
    return Frame((u,v,n),j,ties,d.direction_id)
