"""Immutable mathematical records. Binary64 is engineering arithmetic only."""
from dataclasses import dataclass, asdict
import hashlib
import json
import math
import re
from .exceptions import EngineeringError, NotEvaluable

VERSION = "p0a3-candidate-1"
DEFERRED = "GLOBAL_CERTIFICATION_DEFERRED"
STATUSES = frozenset(("INVALID_INPUT", "NOT_EVALUABLE", "LOCAL_ONLY",
                     "BOUNDED_APPROXIMATION", "GLOBAL_CERTIFIED", DEFERRED,
                     "UNRESOLVED_PROOF"))

def number(x):
    if type(x) not in (int, float):
        raise EngineeringError("NUMBER_TYPE", "Expected finite int/float, not bool or text.")
    try:
        y = float(x)
    except (OverflowError, ValueError) as e:
        raise EngineeringError("NUMBER_RANGE", "Not representable in binary64.") from e
    if not math.isfinite(y) or (type(x) is int and int(y) != x):
        raise EngineeringError("NUMBER_RANGE", "Nonfinite or inexact integer conversion.")
    return 0.0 if y == 0 else y

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False, ensure_ascii=True).encode()).hexdigest()

def hash_field(s):
    if not isinstance(s, str) or re.fullmatch(r"[0-9a-f]{64}", s) is None:
        raise EngineeringError("HASH", "Expected lowercase SHA-256.")
    return s

def text_field(s):
    if not isinstance(s, str) or not s or not s.isascii():
        raise EngineeringError("TEXT", "Required nonempty ASCII metadata.")
    return s

@dataclass(frozen=True)
class Geometry:
    representation: str
    coordinates: tuple
    input_id: str
    units: str
    source_sha256: str
    ordered: bool | None
    closed: bool | None
    stroke_count: int | None
    purpose: str = "GENERIC_MATHEMATICAL_INPUT"
    provenance_class: str = "INDEPENDENT_DIAGNOSTIC"
    schema_version: str = VERSION

    def __post_init__(self):
        if self.representation not in ("R3-C", "R2-O", "R2-U"):
            raise NotEvaluable("REPRESENTATION", "No target, raster, graph or physical-shadow API.")
        if self.schema_version != VERSION or self.purpose != "GENERIC_MATHEMATICAL_INPUT" or self.provenance_class != "INDEPENDENT_DIAGNOSTIC":
            raise EngineeringError("SCOPE", "Unsupported version or observation authority.")
        text_field(self.input_id); text_field(self.units); hash_field(self.source_sha256)
        if self.ordered is not None and type(self.ordered) is not bool:
            raise EngineeringError("ORDER", "ordered must be bool or null.")
        if self.closed is not None and type(self.closed) is not bool:
            raise EngineeringError("CLOSURE", "closed must be bool or null.")
        if self.stroke_count is not None and (type(self.stroke_count) is not int or self.stroke_count < 1):
            raise EngineeringError("STROKES", "stroke_count must be positive int or null.")
        dim = 3 if self.representation == "R3-C" else 2
        if not isinstance(self.coordinates, (tuple, list)):
            raise EngineeringError("COORDINATES", "Coordinates must be an explicit finite sequence.")
        pts = []
        for p in self.coordinates:
            if not isinstance(p, (tuple, list)) or len(p) != dim:
                raise EngineeringError("DIMENSION", "Coordinate dimension mismatch.")
            pts.append(tuple(number(x) for x in p))
        object.__setattr__(self, "coordinates", tuple(pts))

    @property
    def fingerprint(self):
        return digest(asdict(self))

@dataclass(frozen=True)
class Options:
    group: str = "SO2"
    allow_reversal: bool = False
    permission_id: str = "primary-no-reversal"

    def __post_init__(self):
        if self.group not in ("SO2", "O2") or type(self.allow_reversal) is not bool:
            raise EngineeringError("OPTIONS", "Explicit SO2/O2 and Boolean reversal required.")
        text_field(self.permission_id)
        if (self.group == "O2" or self.allow_reversal) and self.permission_id == "primary-no-reversal":
            raise EngineeringError("PERMISSION", "Sensitivity requires an explicit permission ID.")

@dataclass(frozen=True)
class Normalization:
    measure: str
    centroid: tuple
    rms: float
    events: tuple = ()
    arithmetic: str = "BINARY64_UNCERTIFIED"

    def __post_init__(self):
        if self.measure not in ("PLANAR_ARCLENGTH_DU", "UNIFORM_DISTINCT_POINTS"):
            raise EngineeringError("MEASURE", "Unknown normalizer.")
        if len(self.centroid) != 2:
            raise EngineeringError("CENTROID", "Centroid must have dimension two.")
        object.__setattr__(self, "centroid", tuple(number(x) for x in self.centroid))
        r = number(self.rms)
        if r <= 0:
            raise NotEvaluable("EXTENT", "Positive radius required.")
        object.__setattr__(self, "rms", r)
        if self.arithmetic != "BINARY64_UNCERTIFIED":
            raise EngineeringError("ARITHMETIC", "No certified arithmetic backend exists.")
        if not all(isinstance(x, str) for x in self.events):
            raise EngineeringError("EVENT", "Events must be strings.")
        object.__setattr__(self, "events", tuple(self.events))

@dataclass(frozen=True)
class EvaluationContext:
    family: str
    tier: int
    direction_id: str
    manifest_sha256: str
    budget_sha256: str
    production_sha256: str
    reference_sha256: str
    configuration_sha256: str
    binding_scope: str = "DECLARED_METADATA_NOT_GEOMETRY_PROOF"

    def __post_init__(self):
        if self.family not in ("A","B") or type(self.tier) is not int or self.tier not in (0,1,2):
            raise EngineeringError("CONTEXT_FAMILY","Invalid family/tier context.")
        text_field(self.direction_id)
        for h in (self.manifest_sha256,self.budget_sha256,self.production_sha256,
                  self.reference_sha256,self.configuration_sha256):hash_field(h)
        if self.binding_scope!="DECLARED_METADATA_NOT_GEOMETRY_PROOF":
            raise EngineeringError("CONTEXT_SCOPE","Provenance binding is not a geometry certificate.")

@dataclass(frozen=True)
class Result:
    score: str
    status: str
    value: float | None
    squared_estimate: float | None
    input_hashes: tuple
    options: Options
    normalizations: tuple = ()
    witness: tuple = ()
    diagnostics: tuple = ()
    error_code: str | None = None
    certification: str = DEFERRED
    schema_version: str = VERSION
    context: EvaluationContext | None = None

    def __post_init__(self):
        if self.schema_version != VERSION or self.score not in ("QO", "QH"):
            raise EngineeringError("RESULT_SCHEMA", "Unknown result schema/score.")
        if self.status not in STATUSES:
            raise EngineeringError("STATUS", "Unknown status.")
        # Stronger than a Boolean guard: no public promotion path exists in P0A3.
        if self.status in ("GLOBAL_CERTIFIED", "BOUNDED_APPROXIMATION") or self.certification != DEFERRED:
            raise EngineeringError("CERTIFICATION_FORBIDDEN", "No validated proof backend in P0A3.")
        if not isinstance(self.options, Options) or len(self.input_hashes) != 2:
            raise EngineeringError("RESULT_FIELDS", "Options and two input digests required.")
        object.__setattr__(self, "input_hashes", tuple(hash_field(h) for h in self.input_hashes))
        for name in ("value", "squared_estimate"):
            v = getattr(self, name)
            if v is not None:
                object.__setattr__(self, name, number(v))
        if self.value is not None and self.value < 0:
            raise EngineeringError("SCORE_SIGN", "Score must be nonnegative.")
        if self.status in ("LOCAL_ONLY",DEFERRED) and self.value is None:
            raise EngineeringError("SCORE_MISSING","Scored engineering status requires a value.")
        if self.status in ("INVALID_INPUT", "NOT_EVALUABLE", "UNRESOLVED_PROOF") and self.value is not None:
            raise EngineeringError("UNSCORED", "Failure cannot contain an ordinary score.")
        if self.status in ("INVALID_INPUT", "NOT_EVALUABLE") and not self.error_code:
            raise EngineeringError("ERROR_CODE", "Failure requires a code.")
        if self.error_code is not None:text_field(self.error_code)
        if self.context is not None and not isinstance(self.context,EvaluationContext):
            raise EngineeringError("RESULT_CONTEXT","Expected immutable context record or null.")
        if not all(isinstance(n, Normalization) for n in self.normalizations):
            raise EngineeringError("NORMALIZATIONS", "Expected normalization records.")
        object.__setattr__(self, "normalizations", tuple(self.normalizations))
        keys = []
        pairs = []
        for k, v in self.witness:
            text_field(k)
            if k in keys or type(v) not in (str, bool, int, float):
                raise EngineeringError("WITNESS", "Unique scalar witness fields required.")
            keys.append(k); pairs.append((k, number(v) if type(v) in (int, float) else v))
        object.__setattr__(self, "witness", tuple(pairs))
        if not all(isinstance(s, str) for s in self.diagnostics):
            raise EngineeringError("DIAGNOSTIC", "Diagnostics must be text.")
        object.__setattr__(self, "diagnostics", tuple(self.diagnostics))

def require_geometry(g, representation):
    if not isinstance(g, Geometry) or g.representation != representation:
        raise EngineeringError("REPRESENTATION", "Wrong mathematical input type.")

def require_open(g):
    if g.ordered is not True or g.closed is not False or g.stroke_count != 1:
        raise NotEvaluable("OPEN_ORDERED_SINGLE_PATH", "One explicitly open ordered path required.")

def failed(score, a, b, options, exc):
    return Result(score, exc.status, None, None, (a.fingerprint, b.fingerprint),
                  options, diagnostics=(str(exc),), error_code=exc.code)

def export_budget(score, family, tier, options, *, resource_policy_id, accuracy_policy_id):
    if score not in ("QO", "QH") or family not in ("A", "B") or type(tier) is not int or tier not in (0,1,2):
        raise EngineeringError("BUDGET", "Unknown score/family/tier.")
    if not isinstance(options, Options) or (score == "QH" and options.allow_reversal):
        raise EngineeringError("BUDGET_OPTIONS", "Invalid nuisance domain.")
    text_field(resource_policy_id); text_field(accuracy_policy_id)
    d = {"schema_version": VERSION, "score": score, "family": family, "tier": tier,
         "options": asdict(options), "translation": "INDEPENDENT_CENTROID",
         "scale": "INDEPENDENT_POSITIVE_RMS_NO_RESIDUAL_FIT", "roll_domain": "FULL_S1",
         "crop": False, "mask": False, "stroke_assignment": False, "closed_shift": False,
         "resource_policy_id": resource_policy_id, "accuracy_policy_id": accuracy_policy_id,
         "failure_policy": "NO_SILENT_VIEW_OR_OBJECT_OMISSION",
         "actual_candidate_null_parity": "NOT_ESTABLISHED", "certification": DEFERRED}
    return d
