"""QO: engineering realization of continuous open-polyline arclength integrals."""
import math
import sys
from bisect import bisect_right
from dataclasses import dataclass
from .contracts import (Geometry, Options, Normalization, Result, DEFERRED,
                        require_geometry, require_open, failed)
from .exceptions import EngineeringError, NotEvaluable

@dataclass(frozen=True)
class Parameterized:
    nodes: tuple
    points: tuple
    normalization: Normalization

def parameterize(g):
    require_geometry(g, "R2-O"); require_open(g)
    if len(g.coordinates) < 2:
        raise NotEvaluable("EMPTY_OR_POINT", "At least two path vertices required.")
    pts=[g.coordinates[0]]; events=[]
    for i,p in enumerate(g.coordinates[1:],1):
        if p == pts[-1]:
            events.append("OMITTED_EXACT_CONSECUTIVE_ZERO_SEGMENT:"+str(i-1))
        else:
            pts.append(p)
    if len(pts)<2:
        raise NotEvaluable("ZERO_LENGTH", "All vertices coincide.")
    origin=pts[0]
    rel=[tuple(p[j]-origin[j] for j in range(2)) for p in pts]
    if not all(math.isfinite(x) for p in rel for x in p):
        raise NotEvaluable("ARITHMETIC_RANGE", "Translation overflow.")
    lens=[math.hypot(b[0]-a[0],b[1]-a[1]) for a,b in zip(rel,rel[1:])]
    total=math.fsum(lens)
    if not math.isfinite(total) or total<=0 or any(x<=0 for x in lens):
        raise NotEvaluable("LENGTH_RANGE", "Length not representable positively.")
    nodes=[0.0]+[math.fsum(lens[:i])/total for i in range(1,len(lens))]+[1.0]
    if any(b<=a for a,b in zip(nodes,nodes[1:])):
        raise NotEvaluable("BREAKPOINT_COLLAPSE", "Positive segment lost at binary64 precision.")
    weights=[b-a for a,b in zip(nodes,nodes[1:])]
    mean=tuple(math.fsum(w*(a[j]+b[j])/2 for w,a,b in zip(weights,rel,rel[1:])) for j in range(2))
    centered=[tuple(p[j]-mean[j] for j in range(2)) for p in rel]
    r2=math.fsum(w*math.fsum(a[j]*a[j]+a[j]*b[j]+b[j]*b[j] for j in range(2))/3
                  for w,a,b in zip(weights,centered,centered[1:]))
    if not math.isfinite(r2) or r2<sys.float_info.min:
        raise NotEvaluable("RMS_RANGE", "Zero, subnormal, underflowed or overflowed squared extent; no certified tiny-scale backend.")
    r=math.sqrt(r2);normalized=tuple(tuple(x/r for x in p) for p in centered)
    if not all(math.isfinite(x) for p in normalized for x in p):
        raise NotEvaluable("NORMALIZATION_RANGE", "Nonfinite normalized coordinate.")
    mu=tuple(origin[j]+mean[j] for j in range(2))
    if not all(math.isfinite(x) for x in mu):
        raise NotEvaluable("CENTROID_RANGE", "Centroid overflow.")
    return Parameterized(tuple(nodes),normalized,
                         Normalization("PLANAR_ARCLENGTH_DU",mu,r,tuple(events)))

def _at(path,u):
    if u==1.0:return path.points[-1]
    i=max(0,bisect_right(path.nodes,u)-1)
    a,b=path.nodes[i:i+2];t=(u-a)/(b-a)
    return tuple((1-t)*x+t*y for x,y in zip(path.points[i],path.points[i+1]))

def correlations(a,b):
    nodes=sorted(set(a.nodes+b.nodes)); terms_a=[]; terms_b=[]
    def dot(x,y):return x[0]*y[0]+x[1]*y[1]
    def turn(x):return (-x[1],x[0])
    for lo,hi in zip(nodes,nodes[1:]):
        x0,x1,y0,y1=_at(a,lo),_at(a,hi),_at(b,lo),_at(b,hi)
        def integral(z0,z1):
            return (hi-lo)*(2*dot(z0,y0)+dot(z0,y1)+dot(z1,y0)+2*dot(z1,y1))/6
        terms_a.append(integral(x0,x1));terms_b.append(integral(turn(x0),turn(x1)))
    return math.fsum(terms_a),math.fsum(terms_b)

def evaluate(a,b,options=Options()):
    require_geometry(a,"R2-O");require_geometry(b,"R2-O")
    if not isinstance(options,Options):raise EngineeringError("OPTIONS","Options record required.")
    try:
        x,y=parameterize(a),parameterize(b)
        branches=[]
        for mirror in ((False,True) if options.group=="O2" else (False,)):
            for reverse in ((False,True) if options.allow_reversal else (False,)):
                pts=tuple((p[0],-p[1] if mirror else p[1]) for p in x.points)
                nodes=x.nodes
                if reverse:
                    pts=pts[::-1];nodes=tuple(1-u for u in nodes[::-1])
                    if any(v<=u for u,v in zip(nodes,nodes[1:])):
                        raise NotEvaluable("REVERSE_BREAKPOINT_COLLAPSE","Reversal lost a positive segment.")
                aa,bb=correlations(Parameterized(nodes,pts,x.normalization),y)
                c=math.hypot(aa,bb);squared=2-2*c
                if not all(math.isfinite(v) for v in (aa,bb,c,squared)):
                    raise NotEvaluable("ARITHMETIC_RANGE","Nonfinite correlation.")
                theta=0.0 if aa==bb==0 else math.atan2(bb,aa)%(2*math.pi)
                branches.append((squared,mirror,reverse,theta,aa,bb))
        best=min(branches,key=lambda r:r[0])  # stable order: determinant then traversal
        sq,mirror,reverse,theta,aa,bb=best
        tied=sum(row[0]==sq for row in branches)
        notes=["BINARY64_ONLY_NO_OUTWARD_ENCLOSURE","POSITIVE_RADICAND_SIGN_NOT_CERTIFIED",
               "ALL_BRANCHES_EVALUATED:"+str(len(branches)),
               "FLOAT_EQUAL_BRANCHES_NOT_PROVED_TIES:"+str(tied),
               "RADICANDS:"+repr(tuple(row[0] for row in branches))]
        if aa==bb==0:notes.append("COMPUTED_ALL_ROLL_TIE_CANONICAL_ZERO_NOT_EXACT_PROOF")
        # Never silently clamp cancellation or a negative expression into zero.
        value=math.sqrt(sq) if sq>0 else None
        if value is None:notes.append("RADICAND_NONPOSITIVE_SIGN_OR_CANCELLATION_UNRESOLVED")
        return Result("QO",DEFERRED if value is not None else "UNRESOLVED_PROOF",
                      value,sq,(a.fingerprint,b.fingerprint),options,
                      (x.normalization,y.normalization),
                      (("angle",theta),("mirror",mirror),("reversed",reverse),
                       ("alpha",aa),("beta",bb)),tuple(notes),
                      None if value is not None else "RADICAND_UNRESOLVED")
    except EngineeringError as exc:
        return failed("QO",a,b,options,exc)
    except (OverflowError,ZeroDivisionError) as exc:
        return failed("QO",a,b,options,NotEvaluable("ARITHMETIC_RANGE",str(exc)))
