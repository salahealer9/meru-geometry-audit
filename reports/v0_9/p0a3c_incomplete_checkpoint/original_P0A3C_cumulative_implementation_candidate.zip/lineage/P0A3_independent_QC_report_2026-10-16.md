# P0A3 — Independent QC of implementation-candidate archive

**Review date:** 2026-10-16  
**Scope:** read-only review of the isolated, submitted implementation-candidate ZIP; bounded repeat of the already supplied 42 generic DEV software tests only. No Meru/Hebrew target access, P0A0 S00–S12 replay, registered scientific evaluation, candidate/null run, Git commit or push.

## Decision: integrity PASS; engineering readiness NOT QUALIFIED

The archive is authentic to its supplied digest and internally coherent. Its source and reference layers are meaningful, separated in the inspected code, and the final DEV run is reproducible. **However, the implementation remains incomplete against the signed P0A3 §11 readiness condition. Do not assign `P0A3_TARGET_BLIND_IMPLEMENTATION_READY_FOR_REGISTERED_CERTIFICATION` and do not proceed directly to P0A4 execution.** This is not a provenance failure or accusation of unauthorized work. It is an accurately disclosed *partial engineering outcome*.

**Qualified dispositions:** `P0A3_IMPLEMENTATION_INCOMPLETE`, `P0A3_REFERENCE_INDEPENDENCE_NOT_ESTABLISHED` (full-domain numeric coverage), `P0A3_NUMERICAL_CERTIFICATION_DEFERRED`, `P0A3_OBSERVATION_MODEL_UNRESOLVED`, `P0A3_EFFECTIVE_CAPACITY_LEVELS_UNSELECTED`, and `P0A3_CONTROL_FAIRNESS_UNVERIFIED` coexist. The reported 42 DEV passes do not change these statuses.

## 1. Integrity and provenance

| Independent check | Observed result |
|---|---|
| Original ZIP SHA-256 | `079c74ce69b9b94e26ccb346aadc4d1351922921774f7120e9db79e9f320835a` |
| Original ZIP size | 480,345 bytes |
| ZIP entries/integrity | 73 entries, CRC PASS; no traversal, absolute paths or symlinks found |
| SHA256SUMS | 72/72 verified |
| PACKAGE_INVENTORY.json | 71/71 payload records, hashes and sizes verified |
| Production/reference/DEV source hashes | 17/17 independently verified |
| Attempt 4 pre-run snapshots | 17/17 identical to delivered source bytes |
| Historical DEV logs | Four attempt snapshots, stdout/stderr SHA-256 and exit codes verified |
| P0A3 signed commit | `2425db592e80d5f688adc0facdea9e1042c05cdb` |
| Protocol blob | `38106180f7b2855992b70c925d64169dee0213ca` |
| Direct parent | `07b64003940072e00fb2ce969ebc3866a9a3dc4d` |
| GitHub signature and feature branch | Valid; remote HEAD matches signed P0A3 preregistration |
| Signed P0A0–P0A2 ancestry | Seven earlier consecutive signed commits and parents verified through GitHub, together with current P0A3 |
| Pinned source Git blobs | 20/20 matched independently against frozen remote sources |

The submitted original includes both the authoritative P0A3 protocol text and P0A2 decision/QC text. Historical DRAFT and PRE-QC labels in the copies remain archival and are not to be rewritten. Source-hash verification includes read-only P0A0 JSONL; no pilot execution or modification was performed. The agent's nonzero isolated GPG import warning, prior P0A1 recovery limitations, absent crop, two deselected image-dependent tests and incomplete historic DEV log all remain properly disclosed. Local live repository status, absence of actions outside submitted evidence and original image bytes cannot be verified from this package.

## 2. Bounded independent DEV check

| Attempt | Original recorded result | QC conclusion |
|---|---|---|
| 01 | 38/38 pass | Source and logs preserved |
| 02 | 41 run, 38 pass, two failed assertions and one error | Failures and pre-repair code retained; return code 1 correctly logged |
| 03 | 41/41 pass | Corrections and changes retained |
| 04 | 42/42 pass | Delivered code exactly matches pre-run state |

A **separate independent bounded DEV rerun** of the submitted `tests/dev_v0_9/test_microcontracts.py` used only the included fresh generic microfixtures, within the original engineering categories and outside the Meru Git repository. Result: **42 tests passed; exit 0**. The log is included with the QC record. This check does *not* establish floating-point error enclosures, general exactness, full-circle global optimization, camera coverage, matching significance or physical shadow semantics. It is not a newly registered scientific test.

All 16 inspected Python modules/tests parsed successfully. Static inspection found no imports from reference numerical oracles into the production code, or production numerical kernels into reference modules; no P0A0 evaluator import, external Hebrew images or proxy-font logic in the numerical kernels. `requirements_to_code_and_proof.csv` (25 rows) and `independent_oracle_matrix.csv` (7 rows) are populated. Source separation is meaningful for the rational/surd domains explicitly supported; it does not establish general oracle independence.

## 3. Mathematical/software contracts reviewed

**QO:** one independently ordered, open polyline on each side; arclength-parametrized planar centering and positive RMS normalization; piecewise quadratic moment/correlation integration; analytic formula for roll and explicit reflection/reversal options. Nonconsecutive returns are retained and consecutive zero-length segments are logged/omitted. `qo_rational.py` uses an algorithmically separate global-antiderivative reference for the **rational segment-length subdomain**. Production uses binary64 arithmetic. There is **no directed/outward bound on the integrals, normalizations, cancelling squared residual or angle witness**, and general irrational length/equality support is absent. Exact or near-zero score can be `UNRESOLVED_PROOF` rather than silently clamped to zero; this is a limitation, not a spurious scientific failure.

**QH:** finite sets with exact represented duplicates removed, separately centered by uniform distinct-point empirical measure; two directed nearest-neighbour extrema and their symmetric maximum at a **given** planar rotation. The independent rational-unit-rotation checker uses exact quadratic-surd pair comparisons and does not import the production nearest-neighbour code. **No global roll-search implementation** or independently validated outward interval computation is supplied. The fixed-angle `LOCAL_ONLY` value is uncertified and cannot be treated as a global or rigorous feasible upper bound.

**Directions:** A and B retain exact integer-triple membership and 6/14/26 and 6/18/42 signed counts; canonical nested strata and O(2) half-count convention; computed proper-frame lift is marked binary64-uncertified. The literal reference pattern tables and exact integer/radical witnesses are genuinely separate routes. Numerical SEP/COV/ROUND certificates, a selected final G1/G2 hierarchy, and a continuous-camera Lδ bound remain unavailable. Point projection is a mathematical centreline observation, not a historical hand-shadow model.

**Certificates/serialization:** versioned, finite-only JSON; explicit statuses and missing-observable failures; witness, manifest and budget context pins. The independent cell checker tests structural coverage, branch identity and claimed envelope consistency, but **explicitly does not verify numerical lower bounds, witness geometry or arithmetic** and always ends in `UNRESOLVED_PROOF`. Public score/serializer classes prohibit `GLOBAL_CERTIFIED` or `BOUNDED_APPROXIMATION` promotion. A structural manifest hash authenticates identity, not truth. The binding API checks declared direction IDs and budget but *does not independently prove* a planar observation came from that camera.

These are proper scoped engineering observations, not claims that every possible input branch or numeric edge has been tested. The implementer itself disclosed the computational and proof limitations.

## 4. Eight outstanding blockers; actions before a positive readiness claim

| Blocker | Requirement to complete or explicitly narrow |
|---|---|
| **B01 — QO arithmetic** | Implement/review independently bounded general permitted path-length, normalization, integral, correlation and attained-roll witnesses; preserve nonattainment/roundoff uncertainty. |
| **B02 — QH fixed-pose arithmetic** | Add rigorously directed pair distances, arbitrary rotation/witness enclosures and reference recomputation; no conventional floating `float` endpoints masquerading as outward intervals. |
| **B03 — QH global angle certificate** | Implement full circular partition, mathematically justified Lipschitz lower bounds and feasible upper witnesses, numerical checker and all-camera aggregation with no omitted invalid view. |
| **B04 — direction numerical proof** | Supply needed frame/projection rounding and direction membership/separation/coverage certificate architecture, with SEP/COV/ROUND and continuous-view issues either proved in scope or clearly deferred without a false claim. |
| **B05 — reference/checker coverage** | Demonstrate independent numerical checks on the full declared production domain; preserve restricted rational-only routines as restricted oracles. |
| **B06 — interruption control** | Implement auditable partial-result/timeout persistence for any future iterative QH solver or explicitly freeze it as nonexecutable/deferred. |
| **B07 — observation and rights** | Remain unresolved pending independent rights/annotation/historical model gates. Do not repair via proxy glyphs. |
| **B08 — control fairness and score/tier choices** | Keep actual source-constrained candidates/N0–N3 generators, budgets, primary statistic and final hierarchy unresolved until independently preregistered. |

B07 and B08 are **legitimate longer-term scientific blockers** and do not need Hebrew exposure to complete a target-free numerical implementation. B01–B03/B05–B06 are the practical software/certification-interface blockers; B04 must be carefully separated into exact finite-family representation versus future optional continuous sphere statements. A subsequent P0A3 completion attempt must not redefine registered QO/QH mathematics or silently change the frozen limitations.

## 5. Recommendation: preserve and complete, not certify

**Recommendation:** Retain the original immutable 480,345-byte ZIP and this independent QC as a traceable partial engineering checkpoint. Prefer an additive **target-blind P0A3 completion pass**, still under the signed implementation-only authority and within its permitted bounded generic DEV testing, before seeking a positive P0A3 readiness freeze. Require an updated ZIP preserving the original source/archive identity, the four DEV histories, additional source diffs/tests, all failures and fully explicit outstanding proof statuses. Then perform a fresh independent QC.

If implementation completion is impossible within the protocol, it is legitimate to **human-sign an incomplete-outcome preservation freeze** instead, explicitly retaining `P0A3_IMPLEMENTATION_INCOMPLETE`; this would record progress/negative engineering outcome, **not** release P0A4, approve a solver, fix experimental score/tier choices or open target images. Under no circumstance should this partial package be frozen *as* `P0A3_TARGET_BLIND_IMPLEMENTATION_READY_FOR_REGISTERED_CERTIFICATION`.

A subsequent P0A4 protocol must be separately signed after an independently reviewed implementation freeze and must enumerate registered cases/oracles/accuracy/stopping and explicit authorized target-free execution. It cannot borrow the current 42 DEV checks as certification. Later target source/rights, observation-model and matched-control gates remain closed.

**QC conclusion:** `P0A3_ARCHIVE_INTEGRITY_PASS`; `P0A3_DEV_REPRODUCIBILITY_PASS`; **`P0A3_IMPLEMENTATION_READINESS_NOT_QUALIFIED`**. No current mandatory provenance, information-barrier or unauthorized-execution STOP trigger was observed within the inspected evidence.
