# Checkpoint and resource evidence

[IMPLEMENTED_UNVERIFIED] Schema p0a3c-checkpoint-1 contains the complete request,
request/input hashes, canonical completed/failure/pending partition and summary.
The exact manifest is independently reconstructed. Completed records contain
task identity, interval bounds, normalized observation metadata and witnesses.
At most one sticky failure terminates progress; a failure cannot become a valid
view or zero score. Missing/reordered/duplicated tasks fail partition equality.

[IMPLEMENTED_UNVERIFIED] Save first independently checks the state, writes a
same-directory temporary file, flushes and fsyncs it, atomically replaces the
destination, then fsyncs the containing directory. Loading limits bytes, rejects
duplicate keys/nonfinite/floating JSON, checks the envelope digest and external
request/live-source pins, and independently recomputes every completed record.
Incomplete numerical cells are never installed as completed cell records.
The system assumes a single writer; no lock or hostile filesystem guarantee.

[DEV_CHECKED_ONLY] Tests 18–21 use one generic completed QH cell, incomplete
states and controlled faults BEFORE_REPLACE/AFTER_REPLACE. The former retains
the old checkpoint, the latter exposes the complete new checkpoint in the same
running OS. Truncated JSON and duplicate keys are rejected. Stale verification
receipts and changed externally expected identity are rejected. No true hard kill,
power loss, process memory exhaustion or filesystem durability test was executed.

[UNRESOLVED] A crash between cells can use the last durable checkpoint; work
since that save is not guaranteed retained. Save is caller-controlled, not an
automatic per-cell durable transaction. Failure messages are not independently
proved causal explanations. No enforced whole-operation timeout, dynamic integer
bit-growth or production memory cap exists. The parser read-size cap does not
bound arbitrary deep nesting. A raised post-advance checker error does not
automatically persist that unverified new result. These gaps keep B06 PARTIAL.

[DEV_CHECKED_ONLY] Each test subprocess was bounded by 60 seconds and 1 GiB
RLIMIT_AS, four vertices, 64-bit rational inputs, 4096 structural manifest cells,
one advancement step and 1-MiB checkpoint reads. These are DEV limits only.
Production/checker precisions were fixed at 24/96 bits, chart level 1, epsilon
1/100. There was no adaptive refinement, parameter search or full coverage run.
