# Prospective P0A3C DEV envelope — before attempt 07

[IMPLEMENTED_UNVERIFIED] These checks concern engineering microcontracts only.
No scientific objective, P0A0 fixture, registered P0A4 case, historical shape,
letter, glyph, font, target image, candidate or null is used.

Fixed fresh rational source: (4,-7,2), (9,1,6), (13,8,-3).
Fixed independent abstract 2-D input: (-5,2), (3,9), (11,-4).
These arbitrary coordinate lists have no source/shape/letter interpretation.
At most four points in duplicate/collapse variants. Rational input numerator and
denominator caps 64 bits; explicit scalar near duplicate 1/1048576. No random data.

Predeclared 22 unittest methods:
1 root-square rational containment; 2 signed interval arithmetic;
3 float rejection; 4 exact projected duplicate handling; 5 near duplicate retained;
6 collapsed support failure; 7 full 12 A/B/tier/convention structural manifests;
8 exact proper-frame identities on the 50 literal stratum triples (no projection);
9 canonical full task manifests (no numeric evaluation); 10 circle seam identities;
11 QO corner-camera generic component; 12 QO 2:1-camera mirror/reversal component;
13 QH corner-camera one cell; 14 QH 2:1-camera one cell;
15 deliberate forged objective rejection; 16 external pin mismatch rejection;
17 missing/reordered pending work rejection; 18 one-cell checked resume;
19 atomic before/after-replace fault injection; 20 truncated/duplicate-key JSON rejection;
21 sticky failure partition; 22 resource/input-contract rejection.

[MATH DERIVATION] Root bounds must satisfy lo² <= x <= hi².
Integer camera rows have squared norms (s*d,d,s), zero cross dot products and
determinant s*d. Quarter-chart endpoints coincide exactly around the full circle.
Exact duplicates are equal rational numerator pairs, never a proximity test.
All other numerical tests check interval containment/recomputation, not known
scientific performance or minima. Forged-evidence tests deliberately change a
copy; a contradiction on genuine evidence triggers STOP, not an ordinary repair.

Production precision fixed 24 bits, independent reference fixed 96 bits; no
automatic refinement. Chart level fixed 1, DEV epsilon 1/100. These are solely
software-test constants, not final scientific settings. Maximum 4096 manifest
tasks, at most one checkpoint advancement step. Only five numeric production
task evaluations in the suite (two QO, three QH); independent recomputation of
those same records at most 40 times. No all-camera/all-cell evaluation.

New attempts start at 07. Each subprocess has a 60-second wall timeout and a
1-GiB address-space limit where resource.RLIMIT_AS is available. Timeout is an
incomplete failed DEV attempt, not permission to raise limits. No timed benchmark.
No real process kill or power-loss test; inject exceptions at BEFORE_REPLACE and
AFTER_REPLACE. Single writer, local temporary directory. Checkpoint read cap 1 MiB.
No production integer-growth bound or arbitrary crash guarantee is inferred.

Execution: isolated venv Python with -B, PYTHONPATH=src:., PYTHONHASHSEED=0,
LC_ALL=C.UTF-8; tests/dev_v0_9/test_p0a3c_microcontracts.py. The logger records
the exact absolute executable, command, source snapshot, output and exit code.
Attempts 01–06 remain unchanged. Reruns only for preserved ordinary code/test
bugs, within this same envelope; no score-dependent retuning.
