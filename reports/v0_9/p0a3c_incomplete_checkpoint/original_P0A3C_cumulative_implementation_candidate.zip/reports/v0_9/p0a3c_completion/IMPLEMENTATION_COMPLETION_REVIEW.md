# P0A3C implementation-candidate review — independent QC requested

[UNRESOLVED] **P0A3C_IMPLEMENTATION_INCOMPLETE**.
**P0A3C_INDEPENDENT_CHECKER_UNQUALIFIED** remains applicable. No readiness,
approval, implementation freeze or global numerical certification is assigned.
The signed historical P0A3 incomplete checkpoint and its NOT_QUALIFIED independent
QC conclusion remain true and unchanged.

## C0–C9 evidence and disposition

| Stage | Disposition | Evidence and limits |
|---|---|---|
| C0 | PASS, integrity scope | Complete protocol directly retrieved/read; exact commit/blob/parent; ten commit signatures and signed v0.8 tag; baseline archives and six attempts verified |
| C1 | PARTIAL | Explicit rational-input/all-algebraic-frame API; all four products routed; fixed-precision unresolved cases remain |
| C2 | PARTIAL | General interval QO moments/correlations and algebraic witness expression; independent global-u reference; general exact-zero predicate missing |
| C3 | PARTIAL | Algebraic frame propagation, exact QH distinctness/variance, outward distances and feasible unit witnesses; uniform domain qualification absent |
| C4 | PARTIAL | Full circle/camera/branch task architecture, Lipschitz lower bounds and minL/minU; whole-domain run deliberately NOT_RUN; resource/completion guarantees unresolved |
| C5 | PARTIAL | Both exact A/B families, all tiers, SO2/O2 branches and exact lifts; finite precision may leave eligible observations unresolved; no SEP/COV/Lδ claim |
| C6 | PARTIAL | Independent numerical reference, live/external pins, coverage/pooling/witness checks and forged-evidence rejection; shared Fraction/CPython trust and inconclusive cases remain |
| C7 | PARTIAL | Canonical partitions, sticky failures, atomic/fsync I/O and checked resume; controlled interruption only; hard resource/crash guarantees absent |
| C8 | PASS, bounded audit scope with disclosed retention omission | Prospective 22-case scope; attempts 07 and 08 retained; config template and future P0A4 design only |
| C9 | PACKAGED, engineering-only | Cumulative source/reference/tests, unchanged baseline/QC, provenance, proof matrices, diffs, inventory and checksums; independent acceptance pending |

[FROZEN RESULT] P0A3C commit 01270ec3bff3c9a6352c5dadc90d5d9f12da0c0d,
protocol blob 1a54a5c0626d329e1c7389ca389a907139b8413f, direct parent
8adbc226b1ef7234a9bedab02ca515a6c11e5c4f. Exact primary/signing fingerprint
D4EC014EEFCC90E619D2AA59A91239ABCF512130 verified locally with GPG for all
ten protocol/freeze commits and the v0.8 tag. GitHub validity alone was not used
as the signature proof. Commit object hashes and additive tree transitions were
reconstructed. Intermediate pre-P0A0 ancestry to v0.8 uses the recorded GitHub
compare merge-base evidence, not a new full local-history signature walk.

[FROZEN RESULT] At retrieval, branch tip equaled the pinned P0A3C commit. A
bounded workspace listing found no meru-geometry-audit checkout; no fresh local
HEAD/upstream/clean-worktree claim is made. Existing prior working artifacts were
not replaced. All new writes were within p0a3c_work. No git write/commit/push,
clone/reset/switch/update or existing-repository modification was performed.

[FROZEN RESULT] GPG public-key import returned 2 due to gpg-agent startup, with
the public key actually imported; all subsequent signature verifications returned
0 and exact VALIDSIG fingerprint. Unknown ownertrust is disclosed; trust is the
user-specified fingerprint, not an asserted Web-of-Trust identity. Original
warnings, signature payloads, commands and raw retrieval records are retained.

## Improvements and accepted domain

[IMPLEMENTED_UNVERIFIED] Five additive production modules and two separate
reference/checker modules now implement rational endpoint intervals; exact
rational-numerator/radical camera projection; independent QO arclength moments;
QH finite-support normalization and all-pairs bounds; complete finite A/B and
circle manifests; external-pinned independent checking; and checked checkpoint
orchestration. Earlier source is byte-preserved. The new path does not import the
old registered evaluator or silently upgrade the original binary64 APIs.

[MATH DERIVATION] Candidate QO bounds use exact rational interval propagation
through nonrational segment lengths and independent arclength normalization.
QH empirical variance and collision decisions are exact in rational numerator
coordinates. The four chart coverage proof and rho*angular-radius lower bound
provide a finite-camera certification architecture. These claims are conditional
on review of the arithmetic/code and do not constitute numerical certification.

[UNRESOLVED] QO_A, QO_B, QH_A and QH_B are **not declared code-complete** on the
full minimum eligible domain. Core score paths exist for all exact A/B frames,
but fixed precision can fail to separate a positive denominator; general exact
QO zero correlations/ties cannot always supply an attained witness; independent
QO intervals can be inconclusive; and complete resource/restart guarantees are
absent. No final scientific tier, primary Hebrew score, epsilon or precision is
selected by the illustrative DEV settings. Finite cameras are not authenticated
historical viewing-capacity families.

## DEV chronology and independent evidence

| Attempt | Historical/fresh | Result | Interpretation |
|---|---|---|---|
| 01 | preserved bytes | 38 tests passed | original DEV only |
| 02 | preserved bytes | 41 tests; 2 failures, 1 error | original failures/corrections retained |
| 03 | preserved bytes | 41 passed | original DEV only |
| 04 | preserved bytes | 42 passed | original independently NOT_QUALIFIED candidate |
| 05 | preserved bytes | 19 passed | focused continuation DEV only |
| 06 | preserved bytes | 21 passed | focused continuation DEV only |
| 07 | fresh P0A3C | 22 passed, exit 0 | predetermined generic component checks |
| 08 | fresh P0A3C | 22 passed, exit 0 | same scope; numeric evidence export added |

[DEV_CHECKED_ONLY] Attempt 07 preserved complete logs and source but did not
export its in-memory numeric records. The disclosed audit-retention correction
added only DEV output logging; attempt 08 separately retained all five production
records and request/checkpoint evidence. Do not relabel attempt 08 as attempt 07
or describe the omission as a numerical failure. No new actual numerical failure
or independent genuine-enclosure contradiction occurred. Deliberately forged
objective rejection is preserved as a negative test, not actual certification.

[CHECKER_RECOMPUTED_DEV] Two QO component records (corner, 2:1 camera with
mirror/reversal), two QH cell records (corner/2:1), and one axis QH checkpoint
cell were independently recomputed in each attempt. Reference arithmetic uses
integer bisection, global-polynomial QO antiderivatives and norm-minus-dot QH,
without production numerical imports. Exact memberships and all 50 integer lift
identities were checked structurally. No full numerical camera/circle run was
performed. Tests are not parameter/performance evidence or global certificates.

[DEV_CHECKED_ONLY] Isolated stdlib-only Python 3.12.14 environment; no third-party
packages in that venv. Exact compiler/platform/base-environment inventory is
retained. Commands, source snapshots, patches, timestamps, exit codes, stdout,
stderr and evidence hashes are in dev_history and the cumulative append-only log.
Each fresh attempt used 60 seconds/1 GiB guards and fixed 24/96-bit arithmetic.
No automatic retry, epsilon tuning or precision search occurred.

## Remaining blockers and non-promotion

[UNRESOLVED] B01–B06 are PARTIAL; B07–B08 remain UNRESOLVED scientific gates.
No obligation is discharged merely because code exists. The CSV acceptance and
O1–O5/H1–H5/CAP1–CAP5/F1–F2 traceability matrices identify precise symbols,
derivations, DEV evidence and residual requirements. CAP numbering changed in
the P0A3C handoff: CAP3 means precision propagation, CAP4 groups SEP/COV. The old
CAP3=SEP/CAP4=COV records remain unchanged, with explicit crosswalk in the new
matrix. Continuous-camera CAP5 is deferred, not inferred from discrete counts.

[DEFERRED] P0A3C_GLOBAL_NUMERICAL_CERTIFICATION_DEFERRED;
P0A3C_CONTINUOUS_CAMERA_COVERAGE_DEFERRED;
P0A3C_HISTORICAL_OBSERVATION_UNRESOLVED;
P0A3C_CONTROL_FAIRNESS_UNVERIFIED. Independent QC and a separate human-signed
code-only freeze must precede any separately registered P0A4 execution. This
incomplete package is returned for review/preservation, not automatic advancement.

## Inherited scientific limitations — unchanged

[FROZEN RESULT] P0A0 5 PASS / 8 EXPECTED_BLIND_SPOT / 0 FAIL / 0 NOT_EVALUABLE;
S11 local 0.4 versus analytic global 0. These results were read/hash-checked only.
Historical 1281 passed/two image-test exclusions are not fresh results. Missing
`aog_p07_spherical_projection.png` remains missing. The 35-dot incomplete log
does not become 59 completed tests. P0A1's lost 60,950-byte draft and recovered
54,360-byte package remain a disclosed nonidentical recovery. Prior GPG caveats
remain in their evidence. A09 is metadata-only, not an inspected JPEG or actual
image-byte hash. No exhaustive off-workspace/off-environment absence claim.

[UNRESOLVED] Missing historical deformation, three function sets, carrier,
optics/hand-shadow law, independent chart identity, 22 versus 27 corpus decisions,
rights/extraction, uncertainty, detectable effects and multiplicity remain later
gates. Five source classes remain SOURCE_ATTESTED,
SOURCE_CONSTRAINED_INTERPRETATION, INDEPENDENT_DIAGNOSTIC, NULL_CONTROL, UNRESOLVED.
No new source intake or historical reconstruction was performed.

[DEV_CHECKED_ONLY] Within the recorded actions: no Hebrew/letter/glyph/font-proxy
access or scoring, no P0A0 replay, no P0A4 execution, no candidate/null run,
optimizer benchmark, simulation or projection sweep; no existing repository
modification, commit or push. Only authorized target-blind DEV component checks
were executed. Independent QC must assess the evidence; this is not final QC.
