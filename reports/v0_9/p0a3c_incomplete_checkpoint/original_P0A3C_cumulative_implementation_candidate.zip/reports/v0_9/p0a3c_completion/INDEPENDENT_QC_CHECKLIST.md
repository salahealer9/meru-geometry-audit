# Independent QC checklist — no approval prefilled

- Reverify P0A3C exact commit/blob/parent/fingerprint, raw signed payloads and
  frozen lineage. Review GPG-agent/ownertrust and bounded-workspace caveats.
- Verify the 1,315,235-byte original candidate, both QC layers, nested original,
  historical attempts 01–06 and all current baseline-file preservation hashes.
- Verify CRC, safe ZIP paths, complete inventory/hash manifest and all diffs.
- Review A1–A5 derivations, exact frame/collision/variance identities, outward
  interval operations, QO arclength/integration/witness semantics and unresolved
  exact ties. Do not infer proof from test counts.
- Review every task/camera/optional branch and complete circle chart coverage;
  check independent L/U, feasible witnesses, min pooling and epsilon semantics.
- Review reference import DAG/common-mode Fraction/CPython trust and external
  input/live-code pin checking. A local hash utility is not a signed trust root.
- Review returned PARTIAL/inconclusive/failure states, partition integrity,
  checkpoint durability assumptions, missing hard resource guarantees and absent
  automatic persistence of unverified post-advance records.
- Audit prospective DEV scope, attempts 07/08 and retention correction. Distinguish
  deliberate forged-certificate negatives from actual evidence contradictions.
- Preserve B07/B08 and all inherited source/crop/result limitations. No historical
  authentication, final tiers/score, target access or controls are authorized.
- Retain P0A3C_IMPLEMENTATION_INCOMPLETE and checker-unqualified state unless a
  separately justified independent review discharges every mandatory obligation.
  No agent result freezes the package or authorizes P0A4.
