# Arithmetic and degeneracy obligations

| ID | Evidence class | Current handling | Remaining obligation |
|---|---|---|---|
| A1 | MATH DERIVATION; DEV_CHECKED_ONLY | Exact rational outward operations; integer-root enclosure | Independent backend proof/common-mode assessment; bit-growth bounds |
| A2 | MATH DERIVATION; DEV_CHECKED_ONLY | Rational numerator/radical frame; exact coincidence and variance | Uniform eligible input/precision contract |
| A3 | CHECKER_RECOMPUTED_DEV | Two independent QO integration paths on two nonrational frames | Exact zero-correlation decision, all degeneracies, witness completeness |
| A4 | CHECKER_RECOMPUTED_DEV | Coordinate-difference vs norm-minus-dot QH bounds | General checker/domain numerical qualification |
| A5 | IMPLEMENTED_UNVERIFIED | Complete circle/camera manifests, midpoint feasible witness and Lipschitz cell L | Independent whole-domain certification deferred; no run here |
| ZERO | IMPLEMENTED_UNVERIFIED | Exact projected duplicates/collapse; zero denominators refused | Classify every near-degenerate algebraic comparison without false ties |
| TIE | UNRESOLVED | Singleton zero/tie only; interval overlaps retained as ambiguity | General exact equality/separation backend |
| CLIP | MATH DERIVATION | Intersect only with proved nonnegative/Cauchy range | Independent review; empty intersection must STOP |
| REF | UNRESOLVED | Wider reference interval causes inconclusive verification | Guaranteed reference enclosure sharpness/termination absent |
| COST | UNRESOLVED | Finite caller input/cell/step caps; fixed precision | Integer growth/memory/time limits and recoverable cancellation incomplete |

[IMPLEMENTED_UNVERIFIED] Inputs and every normalization are reconstructed from
original rational coordinates; no binary64 frame is used in the added score
path. Interval arithmetic propagates dependency conservatively. Greater width is
not an excuse to tune the precision/epsilon from results. A new externally pinned
request is required for any setting change under a future authorized protocol.

[UNRESOLVED] All four finite products remain incomplete on the full mandatory
domain. Continuous silhouettes/curves, spherical COV, SEP and uniform Lδ remain
deferred separately; their absence must never be reported as a finite-camera
capacity measurement. B07/B08 scientific gates remain unresolved.
