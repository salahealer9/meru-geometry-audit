# Independent QC checklist — uncompleted

For a reviewer independent of the implementer. No boxes are preapproved. New
code is INDEPENDENT_DIAGNOSTIC. Preserve source classes SOURCE_ATTESTED,
SOURCE_CONSTRAINED_INTERPRETATION, INDEPENDENT_DIAGNOSTIC, NULL_CONTROL, UNRESOLVED.

- [ ] Recompute outer ZIP SHA-256, safe-path/member inventory, every byte length
  and SHA256SUMS entry, including empty stdout files and historical failures.
- [ ] Independently retrieve full signed P0A3 protocol and confirm commit, blob,
  parent, signer, branch-at-retrieval record and full frozen P0A0–P0A2 lineage.
- [ ] Review local GPG verification, nonzero key-import diagnostic, reconstructed
  Git objects, additive tree transitions and v0.8 ancestry evidence scope.
- [ ] Confirm original P0A0 result/archive hashes and all preserved limitations;
  no replay, historical reclassification, crop replacement or overwritten draft.
- [ ] Check code is isolated and additive; no existing repository modification,
  no commit/push, no fabricated local clean-HEAD or upstream claim.
- [ ] Inspect every production/reference module; verify different normalization,
  integration, nearest-distance, direction and tie algorithms where claimed.
- [ ] Confirm same interpreter/stdlib limitation and restricted exact domains;
  no production numerical import in independent references or cached reuse.
- [ ] Check QO measure, order, zero-segment/retracing, normalization, alpha/beta,
  branch, roll and no-clamping semantics against frozen mathematics.
- [ ] Check QH distinct-set weights, both directed extrema, no topology inference,
  explicit mirror policy and no unsupported whole-circle numeric claim.
- [ ] Check exact A/B strata, append order, antipodes, O2 representative rule,
  proper frame convention and seams; distinguish membership from SEP/COV/ROUND.
- [ ] Review immutable record invariants, versioned schema, strict finite JSON,
  explicit error propagation, context/budget binding and its geometry-proof gap.
- [ ] Verify GLOBAL_CERTIFIED/BOUNDED_APPROXIMATION cannot be created through
  supported API; structural proof checker cannot certify numeric assertions.
- [ ] Trace every O/H/CAP/F obligation and all four products to gaps/acceptance
  conditions; do not close obligations from passing DEV tests alone.
- [ ] Inspect all four DEV attempts and pre-run sources; verify failures/repairs,
  fixed initial debug allowance and no S00–S12 fixture/oracle reuse.
- [ ] Confirm no fonts/glyphs, images, target-derived arrays, new archival intake,
  optimizers, scientific sweeps, candidate-null or registered execution occurred.
- [ ] Review future VF01–VF20 catalogue as unexecuted design; no generated cases,
  seeds, scientific thresholds, performance claims or retrospective outcomes.
- [ ] Preserve missing crop, two image exclusions, incomplete 35-dot DEV record,
  P0A1 nonidentical recovery, A09 metadata-only and missing historical functions.
- [ ] Confirm actual candidate/N0–N3 laws, common error/resource goals and target
  rights/observables remain unresolved; fixed 22 bases are not replicates.
- [ ] Assess B01–B08 blockers; request bounded authorized corrections as needed.
  Do not assign positive readiness to an incomplete candidate.
- [ ] Record an independently authored QC decision. Any later implementation
  freeze must be separately human GPG-signed; no agent self-signature.
- [ ] Keep P0A4 numerical execution and all target gates closed pending their
  separate signed prerequisites and explicit authorization.

Reviewer identity: NOT_ASSIGNED. QC outcome: PENDING. Human implementation
freeze: ABSENT. P0A3_TARGET_BLIND_IMPLEMENTATION_READY_FOR_REGISTERED_CERTIFICATION:
NOT_ASSIGNED.
