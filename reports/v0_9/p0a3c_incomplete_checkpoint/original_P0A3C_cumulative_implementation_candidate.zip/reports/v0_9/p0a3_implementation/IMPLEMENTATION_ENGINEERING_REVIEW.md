# P0A3 engineering review — submitted for independent QC

**Decision proposed: retain partial implementation; do not approve readiness.**
New work is INDEPENDENT_DIAGNOSTIC. This is the implementer's report, not an
independent QC decision. I0–I8 were addressed in registered order, with I6
engineering corrections to earlier draft modules retained before final packaging.
Source, DEV snapshots, failures, repairs and remaining proof obligations are
delivered without modifying any frozen scientific files.

## Authority and preservation

The complete 214-line P0A3 protocol was retrieved directly from GitHub and read
before implementation. Commit `2425db592e80d5f688adc0facdea9e1042c05cdb`, protocol
blob `38106180f7b2855992b70c925d64169dee0213ca`, parent
`07b64003940072e00fb2ce969ebc3866a9a3dc4d` and signer
`D4EC014EEFCC90E619D2AA59A91239ABCF512130` matched the Work handoff. P0A0, P0A1
and P0A2 protocol/implementation/result/decision commits were verified by direct
GitHub Git data retrieval, reconstructed commit/tree hashes, exact parents,
GitHub verification metadata and local detached GPG verification. Eight commit
signatures and the v0.8 annotated tag verified locally. Public-key import exited
2 because of the environment's gpg-agent issue; this did not prevent subsequent
successful exact-fingerprint signature verification. The complete diagnostic is
retained, not relabeled a successful import.

All seven adjacent frozen transitions were additive, with no removed or changed
inherited blobs; P0A3 added only its protocol, P0A2 decision added 21 files. The
v0.8 tag object/target and remote ancestry comparison to pre-P0A0 are recorded;
this is not a newly performed local walk of every historical commit. Remote
branch tip matched P0A3 at retrieval. No existing checkout was found in a bounded
workspace listing. Consequently there is no fresh local HEAD/status/upstream or
git-diff claim. No clone, reset, fetch, checkout, commit, push or repository write
was used. Final input/archive byte preservation is recorded separately.

The signed P0A2 closeout's positive methodology-design status is acknowledged:
P0A2_TARGET_BLIND_NUMERICAL_DESIGN_READY_FOR_IMPLEMENTATION_PLANNING. It does not
remove P0A2_OBSERVATION_MODEL_UNRESOLVED, P0A2_SCORE_SELECTION_DEFERRED,
P0A2_CAPACITY_CERTIFICATION_DEFERRED, P0A2_SOLVER_CERTIFICATION_DEFERRED,
P0A2_CONTROL_FAIRNESS_NOT_SPECIFIED or P0A2_SOURCE_CONSTRAINT_UNRESOLVED. Historical
DRAFT/PRE-QC titles remain unchanged; later human-signed decisions control.

## Stage evidence and limits

| Stage | Delivered work | Evidence status and unresolved boundary |
|---|---|---|
| I0 | Complete signed lineage, 20 pinned text sources, original-result and three archive hashes, environment and barrier records | Verified identity within stated scope; no target image inspection |
| I1 | Separate contracts/exceptions/projection/score/direction/certificate/serialization modules, API document and versioned structural JSON schema | IMPLEMENTED_UNVERIFIED; DEV_CHECKED_ONLY for exercised contracts; schema not an arithmetic proof |
| I2 | QO open-path arclength normalization, integral correlations and permitted analytic roll branches; separate rational-length integral reference | DEV_CHECKED_ONLY; general algebraic/outward arithmetic and global camera certificate missing |
| I3 | QH uniform distinct support, both directed extrema at a supplied angle, exact rational-rotation surd reference; prospective cell/proof records | DEV_CHECKED_ONLY; no roll optimizer, numerical interval checker or global solver |
| I4 | Exact A 6/14/26 and B 6/18/42 signed-direction generators, O2 representatives, literal checkers, frame convention and 12 manifests | DEV_CHECKED_ONLY; inherited symbolic set theorem retained; SEP/COV/ROUND and physical interpretation NOT_ESTABLISHED |
| I5 | Source-separated algorithms, import DAG, exact projection/lift witnesses and structural certificate checks | Restricted-domain independent routes implemented; full-domain INDEPENDENT_ORACLE_NOT_ESTABLISHED |
| I6 | Four bounded deterministic DEV attempts; all source snapshots/logs/diffs; future VF01–VF20 catalogue without numerical execution | Final 42 PASS; historical attempt-2 failures retained; no registered certification outcome |
| I7 | Requirement/proof matrix, status/error/blocker ledger, common exportable budget metadata and source/control restrictions | Actual control parity NOT_ESTABLISHED; no selected score/tier/epsilon/law |
| I8 | Complete partial candidate ZIP, provenance, environment, inventory, hashes and uncompleted independent-QC checklist | Submitted only; not approved or frozen |

Component contracts deliberately distinguish a supplied observation from its
camera metadata. `bind_result` checks exact manifest/budget/options and pins; it
does not prove the planar input was produced by the named camera. There is no
all-camera score runner that could silently drop collapsed views. No physical
3D candidate is fitted or compared with a 2D proxy. No scientific constants were
selected from DEV outputs. The subnormal-energy guard is a machine-format domain
restriction using `sys.float_info.min`, not a scientific extent threshold.

QO's implemented prefix summation has O(n²+m²) work, with additional breakpoint
sorting/search costs; the frozen P0A2 O(n+m) field-operation route is a design
envelope, not claimed achieved here. QH fixed-angle production and reference use
O(nm) pair work; the independent reference stores an O(nm) matrix. No timings
are interpreted as benchmarks. No finite precision/refinement complexity or
global numerical efficiency is established.

## DEV execution record

| Attempt | Tests | Outcome | Source transition |
|---|---:|---|---|
| 1 | 38 | PASS, exit 0 | Original declared generic DEV categories |
| 2 | 41 | 38 pass; 2 failures; 1 error; exit 1 | Added explicit context, projection-overflow and scored-value contract negatives before repairs |
| 3 | 41 | PASS, exit 0 | Repaired those three defects, with full diff and pre-run snapshot |
| 4 | 42 | PASS, exit 0 | Static review added machine-subnormal guard and its DEV case before running; no pre-fix observation claimed |

The 162 total test-method executions are repeat engineering checks across four
documented source states, not 162 distinct cases, registered trials or scientific
replicates. Pre-run snapshots contain the complete source/test state; subsequent
patches disclose changes. Empty stdout files are intentional and retained;
unittest writes to stderr. Exact executable, command, environment, timeout,
exit code and SHA-256 of every output are recorded. No further numerical tests
were run for packaging. The final candidate source/test bytes are checked
against attempt 4's pre-run snapshot.

The initial numeric comparison allowance, 256 ulps of max(1,abs(reference)),
was fixed before execution and never tuned. It is solely a debugging assertion
allowance; neither an enclosure nor an experimental epsilon. Tiny/subnormal
normalization cases return explicit unevaluable outcomes, not zero matches.

## Complete blocker register

| ID | Missing capability / proof | Required disposition |
|---|---|---|
| B01 | General algebraic QO path lengths, exact equality and rigorous normalization/correlation enclosures | Independent arithmetic implementation/review; retain UNRESOLVED_PROOF for unsupported reference inputs |
| B02 | Outward QH arbitrary-angle pair distances and feasible witness recomputation | Add independently reviewed interval or exact backend under appropriate authority; ordinary float endpoints are not bounds |
| B03 | Complete numeric cell-bound/Lipschitz/witness checker and all-camera branch aggregation | Structural checker remains noncertifying; require every branch plus uncertainty and geometric identity |
| B04 | Frame/projection rounding proof, SEP/COV, uniform camera Lδ | Separate signed proof/certification scope; no numerical sweep here |
| B05 | Full-domain independent oracle and dependency isolation | Existing source separation is narrow; shared interpreter/stdlib and absent general backend disclosed |
| B06 | Timeout/interruption persistence controller for a future iterative solver | No iterative solver here; future controller must retain visited/unvisited branches and partial witnesses without promotion |
| B07 | Observable historical geometry/order/optics, rights and target uncertainty | Separate source/target gates; cannot be resolved by code or DEV checks |
| B08 | Candidate/N0–N3 laws and fair accuracy/resource/failure policies; primary score and final levels | Human preregistered future decisions; exportable metadata does not establish parity |

These engineering incompletenesses are permitted partial-delivery outcomes under
P0A3 §11; they are not provenance/barrier failures. No mandatory provenance or
information-barrier failure was detected within the checked scope. No readiness
status is assigned. Proposed coexistently limited decisions:

- P0A3_IMPLEMENTATION_INCOMPLETE
- P0A3_REFERENCE_INDEPENDENCE_NOT_ESTABLISHED (full-domain coverage)
- P0A3_NUMERICAL_CERTIFICATION_DEFERRED
- P0A3_OBSERVATION_MODEL_UNRESOLVED
- P0A3_EFFECTIVE_CAPACITY_LEVELS_UNSELECTED
- P0A3_CONTROL_FAIRNESS_UNVERIFIED

## Inherited facts and limitations preserved

The original P0A0 JSONL remains SHA-256
`4b4b27b0d5d9a95ffe864e2d2c83433be0ddd544b6122ebbea294857326817d6`:
5 PASS, 8 EXPECTED_BLIND_SPOT, 0 FAIL, 0 NOT_EVALUABLE over S00–S12. This was
read/hash/parsed only, never replayed. S11's local 0.4 versus analytic global 0
remains an EXPECTED_BLIND_SPOT. Frozen historical 1,281 passed tests and two
image-test exclusions are not new P0A3 test outcomes. The inherited missing
`aog_p07_spherical_projection.png` crop remains unavailable. The interrupted
35-dot DEV log remains incomplete, not a 59-test completion. Historical
GPG-agent setup/import caveats remain visible.

P0A1's lost 60,950-byte draft was replaced by a disclosed 54,360-byte recovered
package, not a byte-identical recovery; the recovered and original archived
package identities remain distinct. Three inherited ZIPs were verified as
whole bytes, not extracted to obtain fixture data. A09 is metadata-only here;
no actual JPEG hash or image inspection is claimed. There is no exhaustive
off-environment target-data search claim. v0.8's missing final deformation,
three function sets, carrier and hand-shadow/optical law remain unresolved.

The five source classes SOURCE_ATTESTED, SOURCE_CONSTRAINED_INTERPRETATION,
INDEPENDENT_DIAGNOSTIC, NULL_CONTROL, UNRESOLVED remain distinct. A/B and L1
projections are independent mathematical candidates, not uniquely authenticated
historical Tenen choices. QO/QH are conditional objectives, not selected Hebrew
scores. The fixed 22-base corpus is not independent replication; 22-vs-27,
rights, extraction, secondary charts, detectable effects, multiplicity and
confirmatory inference are later signed gates.

## Mandatory declarations and next gate

NO_HEBREW_TARGET_ANALYSIS_PERFORMED; NO_P0A0_REGISTERED_PILOT_REPLAY;
NO_REGISTERED_NUMERICAL_CERTIFICATION_EXECUTED; NO_CANDIDATE_NULL_EXECUTION;
NO_AGENT_COMMIT_OR_PUSH; EXISTING_FROZEN_REPOSITORY_FILES_UNCHANGED within the
explicit provenance/preservation scope above; QO_QH_CONDITIONAL_NOT_HEBREW_SCORES;
A_B_EXACT_DIRECTION_FAMILIES_NOT_FINAL_EXPERIMENTAL_TIERS;
QO_A_QO_B_QH_A_QH_B_GLOBAL_CERTIFICATION_DEFERRED;
HISTORICAL_FIRST_HAND_SHADOW_MODEL_NOT_ESTABLISHED;
P0A3_NOT_INDEPENDENTLY_APPROVED_OR_FROZEN.

An independent reviewer must assess this partial artifact and blockers. Only
after necessary authorized corrections and independent QC may the human create
a separately GPG-signed implementation-only freeze. A separately signed P0A4
protocol and explicit one-run authority must precede any registered numerical
certification. Neither event automatically permits Hebrew-target work.
