# Revised candidate independent QC checklist

All boxes unapproved. INDEPENDENT_DIAGNOSTIC. Source classes remain
SOURCE_ATTESTED, SOURCE_CONSTRAINED_INTERPRETATION, INDEPENDENT_DIAGNOSTIC,
NULL_CONTROL and UNRESOLVED.

- [ ] Verify original ZIP/QC bytes, revised inventory/checksums/CRC, original
  histories unchanged and cumulative command-log prefix preserved.
- [ ] Inspect fresh signed protocol/lineage and all 20 pinned source checks.
- [ ] Inspect complete source/document/report diffs and metadata exclusions.
- [ ] Review arithmetic proof A1–A6, restricted domains and exact QO witness.
- [ ] Review genuinely separate reference normalization/integration/pair extrema.
- [ ] Verify numeric checker recomputes observations, objectives, rho and bounds,
  rather than trusting supplied hashes or cached production output.
- [ ] Review exact frame enclosures, G0 projection and deferred G1/G2 paths.
- [ ] Review full circle charts, endpoint seams, every-cell/branch enumeration,
  lower/upper aggregation and external trusted source/config/resource pins.
- [ ] Review interruption, suffix preservation, resume recomputation, atomic save
  and cooperative deadline limitations; no unperformed crash/timeout claim.
- [ ] Inspect attempts 01–06, failures/corrections, fixed predeclared DEV scope
  and final source snapshot. No full-circle numeric certification was executed.
- [ ] Confirm inherited crop/image exclusions/DEV/recovery/GPG/source caveats.
- [ ] Preserve B07–B08 scientific unknowns, all restricted-domain blockers and
  no Hebrew-target, registered pilot, candidate/null or benchmark execution.
- [ ] Issue fresh independent QC; do not assign readiness from DEV passes.
  Human-signed implementation freeze and separate P0A4 authority remain absent.
