# Certification, failures and proof ledger

INDEPENDENT_DIAGNOSTIC; implementer report, not independent approval. The source
classes SOURCE_ATTESTED, SOURCE_CONSTRAINED_INTERPRETATION, INDEPENDENT_DIAGNOSTIC,
NULL_CONTROL and UNRESOLVED retain their separate meanings. No historical
physical-shadow, target or candidate/control claim is established by these APIs.

## Status contract

| Status | Current behavior and retained evidence |
|---|---|
| INVALID_INPUT | Explicit EngineeringError before valid geometry exists, or unscored Result when valid input records are available; finite JSON error fields. Wrong dimensions/nonfinite/bool/inexact integer/illegal metadata rejected. |
| NOT_EVALUABLE | Empty, zero-extent, underflow/subnormal energy, overflow, missing ordered/open/single-path status or unsupported observation; no ordinary value. Projection may raise structured exception before scoring. |
| LOCAL_ONLY | QH at one supplied angle; finite engineering value/witness only, not certified feasible upper bound. Result requires value. |
| GLOBAL_CERTIFICATION_DEFERRED | QO positive computed residual engineering candidate; analytic formula does not certify binary64 output. Result requires value. All four full products remain deferred separately. |
| UNRESOLVED_PROOF | QO nonpositive computed squared residual is retained diagnostically without ordinary value; exact-reference unsupported domain and all structurally accepted proof proposals remain unresolved. |
| BOUNDED_APPROXIMATION | Vocabulary reserved; Result creation/deserialization rejects it. No rigorous backend capable of establishing U−L≤epsilon exists. |
| GLOBAL_CERTIFIED | Vocabulary reserved; Result creation/deserialization and promotion reject it, regardless of success Boolean or metadata. |

Score values and squared diagnostic estimates are different fields. An invalid
or unevaluable result never substitutes zero, NaN or infinity for a score.
Normalization arithmetic is always BINARY64_UNCERTIFIED in production. Bounds in
prospective proof proposals are asserted rationals for structural review only.
No ordinary float is relabeled directed/outward arithmetic. Exact equality of
reference rational/surd quantities is distinct from equality of rounded floats.

## Observed DEV failures and repairs (all logs retained)

| ID | Attempt / test | Observed defect | Correction and verification |
|---|---|---|---|
| DEV-F01 | 2 / test_39 | Result lacked explicit context fields for family/camera/manifest/budget/code/reference/config binding; assertion failed | Added immutable EvaluationContext, strict roundtrip and bind_result validation. Attempt 3/4 pass. Scope remains declared metadata, not geometry proof. |
| DEV-F02 | 2 / test_40 | Projection's math.fsum raised unstructured OverflowError | Catch arithmetic range failure and raise NOT_EVALUABLE / PROJECTION_RANGE. Attempt 3/4 pass. No claim of stable large-coordinate arithmetic. |
| DEV-F03 | 2 / test_41 | LOCAL_ONLY Result accepted missing value; expected rejection absent | Scored engineering statuses require a value; failure states prohibit ordinary values. Attempt 3/4 pass. |
| STATIC-F04 | Before attempt 4 / test_42 | Static review found subnormal second-moment range not explicitly excluded; no pre-fix run/outcome claimed | QO/QH reject r² below sys.float_info.min, including subnormal positive energy. Guard derives from binary64 format, not tuned observations; attempt 4 passes. |

Attempt 1: 38 PASS. Attempt 2: 41 run, 2 failures + 1 error. Attempt 3: 41 PASS.
Attempt 4: 42 PASS. The original failed tests, exact source snapshots, patches,
stdout/stderr and command records remain in dev_history/. No failed assertion
was removed, tolerance widened or frozen fixture altered. The test_39 name
indicates required schema fields; context may remain null for a standalone
planar component calculation. A downstream whole-product record must bind it
explicitly and still requires an independently verified observation relation.

## Non-executed or unimplemented failure paths

| Event | Required interpretation / current limit |
|---|---|
| QO unknown error near computed q²=0 | No clipping. Nonpositive estimate unresolved; positive estimate still has no enclosure, even if apparently far from zero. |
| Tiny but positive input | Machine-domain rejection is not a theorem that the mathematical geometry is degenerate. Future validated rescaling/precision remains absent. |
| QH point coincidence | Exact input-domain duplicate policy only; changed empirical weights can change the normalizer. No tolerance merge/convergence claim. |
| Closed/multistroke/unordered path | QO refuses it; no concatenation, cyclic shift, warping, assignment, crop or hidden reflection. |
| Empty/collapsed camera | Block any whole-domain claim; no all-camera aggregator is implemented, so no silent omission path is offered. |
| Incomplete circle/branch list, gap or overlap | Independent structural checker rejects; accepted complete lists still unresolved numerically. |
| Wrong pins/bounds/manifest | Explicit structural failure, no numeric certificate. A hash is identity, not proof truth. |
| Unverified cell lower bound or witness feasibility | Always UNRESOLVED_PROOF; numeric verification backend absent. |
| Solver timeout/interruption | No solver executed or timeout event observed. Future controller must preserve partial logs, visited/unvisited branches, witness and bounds; no global result unless complete proof already survives. DEV harness timeout guard is not such a solver controller. |
| Nonattained raw positive-scale infimum | Residual free-scale fitting is outside QO/QH; no zero-scale surrogate or attained-minimum claim. |
| Missing target observables or physical optics | NOT_EVALUABLE for that observation claim; mathematical point projection cannot repair source evidence. |
| Provenance mismatch or target contamination | Mandatory STOP and preserve/quarantine diagnostics; no such event detected in this task's checked scope. |

## Proof evidence classification

PROVED_SYMBOLICALLY applies only to the inherited mathematical identities under
their exact hypotheses: QO degree-two integral/trigonometric reduction, QH fixed
normalized-set Lipschitz inequality, A/B membership definitions and proper frame
construction. It does not apply to this production implementation's rounded
outputs. Exact restricted references are code implementing derivations, still
subject to independent review; DEV success is DEV_CHECKED_ONLY.

The requirements CSV maps every O1–O5, H1–H5, CAP1–CAP5 and F1–F2 to code,
independent route, exercised checks and a precise outstanding acceptance
obligation. O2/O3 arithmetic and witness error, H2/H3 interval/global completeness,
CAP2 ROUND, CAP3 SEP, CAP4 COV, CAP5 uniform Ldelta, and actual F1/F2 observational
and fairness gates remain NOT_ESTABLISHED or DEFERRED. Separate observation,
sampling, mesh/raster/optics, floating and optimization uncertainties must not be
summed unless they are compatible dimensionless bounds on a common domain.

QO_A, QO_B, QH_A, QH_B: GLOBAL_CERTIFICATION_DEFERRED. Counts and exact membership
are not effective-capacity measurements. No final G1/G2 level, scientific epsilon,
primary score, historical viewing model, candidate or N0–N3 law was selected.
P0A3_IMPLEMENTATION_INCOMPLETE and full-domain
P0A3_REFERENCE_INDEPENDENCE_NOT_ESTABLISHED remain proposed limited outcomes.
