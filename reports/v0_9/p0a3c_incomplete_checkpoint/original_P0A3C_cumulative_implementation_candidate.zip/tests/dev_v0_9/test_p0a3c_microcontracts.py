"""22 prospective generic DEV microcontracts; not registered certification."""
import copy
import json
import os
import tempfile
import unittest
from pathlib import Path
from fractions import Fraction as F
from meru_geometry.v0_9.p0a3c_interval import I
from meru_geometry.v0_9.p0a3c_geometry import support
from meru_geometry.v0_9 import p0a3c_engine as eng
from meru_geometry.v0_9 import p0a3c_resume as io
from meru_geometry.v0_9.directions import manifest
from reference.v0_9.literal_directions import TABLES,check_manifest,exact_lift_witness
from reference.v0_9 import p0a3c_checker as chk

SOURCE=[[4,-7,2],[9,1,6],[13,8,-3]]
TARGET=[[-5,2],[3,9],[11,-4]]
def request(score='QH',family='A'):
    return {'schema':'p0a3c-request-1','score':score,'family':family,'tier':2,'convention':'SO2','reflection':True,'reversal':score=='QO','source':copy.deepcopy(SOURCE),'target':copy.deepcopy(TARGET),'bits':24,'checker_bits':96,'level':1,'epsilon':'1/100','limits':{'max_vertices':4,'max_input_bits':64,'max_cells':4096,'max_steps':1},'authority':'01270ec3bff3c9a6352c5dadc90d5d9f12da0c0d','information_barrier':'GENERIC_TARGET_FREE_ONLY'}

class Microcontracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.records={}
        for score,family,triple,mirror,reverse,chart,cell in [('QO','A',[1,1,1],False,False,None,None),('QO','B',[0,1,2],True,True,None,None),('QH','A',[1,1,1],False,None,0,1),('QH','B',[0,1,2],True,None,3,0)]:
            r=request(score,family)
            t=next(x for x in eng.tasks(r) if x['triple']==triple and x['mirror']==mirror and (x.get('reverse')==reverse if score=='QO' else x['chart']==chart and x['cell']==cell))
            cls.records[(score,family)]=(r,eng.evaluate_task(r,t))
        cls.r=request();cls.pins=chk.live_pins(cls.r)  # DEV trust anchor explicitly captured outside certificate.
        cls.initial=eng.start(cls.r)
        cls.one=io.advance(cls.initial,cls.pins,1)
        if os.environ.get('P0A3C_DEV_EVIDENCE'):
            Path(os.environ['P0A3C_DEV_EVIDENCE']).write_text(json.dumps({'scope':'BOUNDED_DEV_ONLY_NOT_CERTIFICATION','records':[{'request':r,'record':c} for r,c in cls.records.values()],'external_dev_pins':cls.pins,'initial_checkpoint':cls.initial,'one_cell_checkpoint':cls.one},sort_keys=True,indent=2)+'\n')

    def test_01_root(self):
        for x in (F(0),F(2),F(7,13),F(49,9)):
            z=I(x).root(24);self.assertLessEqual(z.lo*z.lo,x);self.assertGreaterEqual(z.hi*z.hi,x)
    def test_02_interval(self):
        self.assertEqual((I(-2,3)*I(-4,1)).wire(),['-12/1','8/1']);self.assertEqual(I(-2,3).square().wire(),['0/1','9/1'])
    def test_03_float(self):
        with self.assertRaises(ValueError):I(0.5)
    def test_04_duplicate(self):
        _,m,_=support(SOURCE+[SOURCE[0]],(1,1,1),24);self.assertEqual(m['distinct_count'],3);self.assertEqual(m['duplicate_count'],1)
    def test_05_near_duplicate(self):
        _,m,_=support(TARGET+[[-5,'2097153/1048576']],None,24);self.assertEqual(m['distinct_count'],4)
    def test_06_collapse(self):
        with self.assertRaisesRegex(ValueError,'zero projected RMS'):support([[1,1,1],[2,2,2]],(1,1,1),24)
    def test_07_manifests(self):
        for family,counts in [('A',[6,14,26]),('B',[6,18,42])]:
            for tier in range(3):
                for mode in ('SO2','O2'):
                    m=manifest(family,tier,mode);check_manifest(m);self.assertEqual(len(m['payload']['directions']),counts[tier]//(2 if mode=='O2' else 1))
    def test_08_frames(self):
        for table in TABLES.values():
            for t in table:self.assertTrue(exact_lift_witness(t)['exact_properness_identity'])
    def test_09_tasks(self):
        for score in ('QO','QH'):
            for family in ('A','B'):
                r=request(score,family);self.assertEqual(eng.tasks(r),chk.manifest(r))
    def test_10_seams(self):
        for q in range(4):self.assertEqual(eng.pose(q,F(1)),eng.pose((q+1)%4,F(0)))
    def check_component(self,key):
        r,c=self.records[key];self.assertEqual(chk.check_record(r,c),'CHECKER_RECOMPUTED_DEV_OR_UNREGISTERED')
    def test_11_qo_corner(self):self.check_component(('QO','A'))
    def test_12_qo_twotoone(self):self.check_component(('QO','B'))
    def test_13_qh_corner(self):self.check_component(('QH','A'))
    def test_14_qh_twotoone(self):self.check_component(('QH','B'))
    def test_15_forged_objective(self):
        r,c=self.records[('QH','A')];fake=copy.deepcopy(c);fake['value']['objective']=['999/1','1000/1']
        with self.assertRaises(chk.IndependentContradiction):chk.check_record(r,fake)
    def test_16_external_pin(self):
        fake=dict(self.pins);fake['request_sha256']='0'*64
        with self.assertRaises(chk.RejectedCertificate):chk.check(self.initial,fake)
    def test_17_partition(self):
        for mode in ('missing','reorder'):
            fake=copy.deepcopy(self.initial)
            if mode=='missing':fake['pending'].pop()
            else:fake['pending'][0],fake['pending'][1]=fake['pending'][1],fake['pending'][0]
            with self.assertRaises(chk.RejectedCertificate):chk.check(fake,self.pins)
    def test_18_resume(self):
        self.assertEqual(len(self.one['completed']),1);self.assertEqual(chk.check(self.one,self.pins)['status'],'INCOMPLETE_PENDING')
        with self.assertRaises(ValueError):eng.advance_verified(self.one,'stale',1)
    def test_19_atomic_faults(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'checkpoint.json';io.save(p,self.initial,self.pins)
            def before(stage):
                if stage=='BEFORE_REPLACE':raise RuntimeError('DEV_FAULT_BEFORE_REPLACE')
            with self.assertRaises(RuntimeError):io.save(p,self.one,self.pins,before)
            self.assertEqual(io.load(p,self.pins,1048576),self.initial)
            def after(stage):
                if stage=='AFTER_REPLACE':raise RuntimeError('DEV_FAULT_AFTER_REPLACE')
            with self.assertRaises(RuntimeError):io.save(p,self.one,self.pins,after)
            self.assertEqual(io.load(p,self.pins,1048576),self.one)
    def test_20_bad_json(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'bad.json'
            for raw in ('{"payload":','{"x":1,"x":2}'):
                p.write_text(raw)
                with self.assertRaises(ValueError):io.load(p,self.pins,1048576)
    def test_21_sticky(self):
        s=copy.deepcopy(self.initial);task=s['pending'].pop(0)
        s['failures']=[{'task':task,'error_type':'DEV_INJECTED','error':'Controlled interruption; no numerical claim','status':'INCOMPLETE_STICKY_FAILURE'}]
        s['summary']=eng.summary(self.r,[],s['failures'],s['pending'])
        self.assertEqual(io.advance(s,self.pins,1),s)
    def test_22_limits(self):
        for change in ('vertices','float','level','bits'):
            r=request()
            if change=='vertices':r['source']=SOURCE*2
            if change=='float':r['source'][0][0]=0.25
            if change=='level':r['level']=17
            if change=='bits':r['bits']=4097
            with self.assertRaises(ValueError):eng.start(r)

if __name__=='__main__':unittest.main(verbosity=2)
