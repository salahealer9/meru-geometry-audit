# Continuation DEV declaration — before attempt 05

INDEPENDENT_DIAGNOSTIC; no registered numerical certification. Original attempts
01–04 and the original 42-test file are unchanged and will NOT be rerun here.
Only test_completion_microcontracts.py is run. Its fresh handwritten integers
are not copied from original DEV or P0A0 fixtures and have no glyph/source intent.

Declared checks: exact rational square-root endpoint inequalities (three scalars,
one fixed 12-bit debugging setting); invalid exact encodings; a simple fresh
right-angle polyline integral; exact duplicates/retracing; explicit unsupported
irrational length; exact identity/tie witness; restricted QO independent bounds;
one rational fixed-pose QH and reflected variant; deliberate forged enclosure
rejection; exact frame entry enclosures on two supplied generic triples;
G0 checkpoint full structural enumeration with zero cells evaluated; exactly
one-cell advance and zero-cell resume/serialization; pending-cell omission and
pin/witness corruption rejection; caller-directed atomic checkpoint roundtrip
in a temporary directory; independent import AST inspection.

No full camera/circle numerical run, gap-based qualification, optimization,
precision sweep, sphere sweep or timing benchmark. A unit caller supplies 12
bits, partition level 0, and a prospective epsilon of 1/7 solely to inspect
serialization/partial-state controls; no complete gap is computed or passed.
No experimental parameter is selected. Exact assertions only; no float margin.
Every command/output/source snapshot and any failure is retained as attempt 05+.
Any unexpected independently refuted produced enclosure triggers STOP; negative
tests corrupt a known record deliberately and are labeled rejection probes.

Before attempt 06: static review found missing strict QO record-key/normalizer-
count checks, frame metadata checks and checkpoint control-status consistency
checks in the new independent checker. Added explicit guards plus tests 20–21
before running. No produced numerical enclosure was refuted, and no pre-fix
failure is claimed. These are metadata/schema hardening inside the declared
categories; no change to arithmetic, fixture geometry or settings.
