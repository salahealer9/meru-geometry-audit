"""Fresh bounded continuation checks; no full numerical certification run."""
import ast,copy,json,tempfile,unittest
from pathlib import Path
from fractions import Fraction as F
from meru_geometry.v0_9 import exact_bounds as e,qo_exact_candidate as qo,qh_circle_candidate as circle,checkpoint_io
from meru_geometry.v0_9.exceptions import EngineeringError,UnresolvedProof,NotEvaluable
from reference.v0_9 import numerical_checker as ref

A=((2,3),(7,3),(7,15));B=((-11,4),(-11,9),(1,9))
SOURCE=((2,5,11),(5,9,13),(8,15,20))
PINS={k:format(i,'064x') for i,k in enumerate(('production','reference','configuration','resource_policy'),1)}
def request():return circle.request(SOURCE,B,family='A',tier=0,group='SO2',bits=12,level=0,epsilon='1/7',pins=PINS,permission_id='primary-no-reversal')

class Completion(unittest.TestCase):
    def test_01_outward_sqrt_integer_inequalities(self):
        for x in (F(2),F(9,16),F(1,10**20)):
            lo,hi=e.sqrt_bounds(x,12);self.assertLessEqual(lo*lo,x);self.assertGreaterEqual(hi*hi,x);self.assertLessEqual(hi-lo,F(1,4096))
    def test_02_exact_encoding_refuses_float_bool(self):
        for x in (0.5,True,'nan'):
            with self.assertRaises(EngineeringError):e.rational(x)
    def test_03_qo_independent_new_broken_line(self):
        r=qo.evaluate(A,B,bits=12,allow_reversal=True,allow_reflection=True)
        self.assertTrue(ref.check_qo(A,B,r)['numeric_enclosure_checked']);self.assertEqual(len(r['branches']),4)
    def test_04_qo_identity_not_float_clamping(self):
        r=qo.evaluate(A,A,bits=12,allow_reversal=False,allow_reflection=False)
        self.assertEqual(r['objective'],['0/1','0/1']);self.assertTrue(ref.check_qo(A,A,r)['attained_roll_symbolic_witness_checked'])
    def test_05_qo_duplicate_retrace_preserved(self):
        a=(A[0],A[0],A[1],A[0]);r=qo.evaluate(a,B,bits=12,allow_reversal=False,allow_reflection=False)
        self.assertEqual(r['omitted_consecutive_indices'][0],[1]);ref.check_qo(a,B,r)
    def test_06_qo_irrational_backend_explicit(self):
        with self.assertRaises(UnresolvedProof):qo.evaluate(((0,0),(2,3)),B,bits=12,allow_reversal=False,allow_reflection=False)
    def test_07_qh_rational_rotation_independent(self):
        r=e.qh_enclosure(A,B,cosine='5/13',sine='12/13',mirror=False,bits=12)
        self.assertTrue(ref.check_pose(A,B,r,cosine='5/13',sine='12/13',mirror=False)['numeric_enclosure_checked'])
    def test_08_qh_explicit_mirror_and_duplicate(self):
        a=A+(A[1],);r=e.qh_enclosure(a,B,cosine='-3/5',sine='4/5',mirror=True,bits=12)
        ref.check_pose(a,B,r,cosine='-3/5',sine='4/5',mirror=True)
    def test_09_forged_objective_rejection_probe(self):
        r=e.qh_enclosure(A,B,cosine=1,sine=0,mirror=False,bits=12);r['objective']=['99/1','100/1']
        with self.assertRaises(ValueError):ref.check_pose(A,B,r,cosine=1,sine=0,mirror=False)
    def test_10_zero_extent_and_invalid_rotation(self):
        with self.assertRaises(NotEvaluable):e.qh_enclosure(((6,9),),B,cosine=1,sine=0,mirror=False,bits=12)
        with self.assertRaises(EngineeringError):e.qh_enclosure(A,B,cosine=1,sine=1,mirror=False,bits=12)
    def test_11_frame_exact_entry_enclosures(self):
        for v in ((0,-1,2),(1,1,1)):self.assertTrue(ref.check_frame(e.frame_enclosures(v,bits=12))['exact_proper_frame_entries_enclosed'])
    def test_12_checkpoint_plan_no_numerical_run(self):
        r=request();s=circle.start(r);self.assertEqual(len(s['pending']),24)
        result=ref.check_checkpoint(s,r);self.assertFalse(result['prospective_gap_met']);self.assertEqual(result['checked_cells'],0)
    def test_13_one_cell_then_zero_cell_resume(self):
        r=request();s=circle.advance(circle.start(r),r,max_cells=1)
        self.assertEqual(len(s['completed']),1);self.assertEqual(len(s['pending']),23)
        check=ref.check_checkpoint(s,r);self.assertFalse(check['all_cells_numerically_checked']);self.assertFalse(check['prospective_gap_met'])
        t=circle.loads(circle.dumps(s),r);t=circle.advance(t,r,max_cells=0)
        self.assertEqual(t['completed'],s['completed']);self.assertEqual(t['pending'],s['pending'])
    def test_14_pending_omission_rejected(self):
        r=request();s=circle.start(r);s['pending'].pop()
        with self.assertRaises(ValueError):ref.check_checkpoint(s,r)
        with self.assertRaises(EngineeringError):circle.loads(circle.dumps(s),r)
    def test_15_external_pin_mismatch_rejected(self):
        r=request();s=circle.start(r);other=copy.deepcopy(r);other['pins']['reference']='f'*64
        with self.assertRaises(ValueError):ref.check_checkpoint(s,other)
    def test_16_unavailable_tier_no_fallback(self):
        with self.assertRaises(EngineeringError):circle.request(SOURCE,B,family='B',tier=1,group='SO2',bits=12,level=0,epsilon='1/7',pins=PINS,permission_id='primary-no-reversal')
    def test_17_atomic_checkpoint_bytes(self):
        r=request();s=circle.start(r)
        with tempfile.TemporaryDirectory(prefix='p0a3_dev_checkpoint_') as d:
            p=Path(d)/'checkpoint.json';checkpoint_io.save(s,p)
            self.assertEqual(p.read_text(),circle.dumps(s));self.assertEqual(circle.loads(p.read_text(),r),s)
    def test_18_reference_no_production_import(self):
        tree=ast.parse(Path('reference/v0_9/numerical_checker.py').read_text())
        for n in ast.walk(tree):
            if isinstance(n,ast.ImportFrom):self.assertNotIn('meru_geometry',n.module or '')
    def test_19_nonfinite_and_duplicate_checkpoint_json(self):
        r=request()
        for raw in ('{"a":1,"a":2}','{"a":NaN}'):
            with self.assertRaises(EngineeringError):circle.loads(raw,r)
    def test_20_qo_metadata_omission_and_extra_rejected(self):
        r=qo.evaluate(A,B,bits=12,allow_reversal=False,allow_reflection=False)
        bad=copy.deepcopy(r);bad['normalizers']=[]
        with self.assertRaises(ValueError):ref.check_qo(A,B,bad)
        bad=copy.deepcopy(r);bad['success']=True
        with self.assertRaises(ValueError):ref.check_qo(A,B,bad)
    def test_21_partial_state_cannot_claim_completion(self):
        r=request();s=circle.start(r);s['status']='GLOBAL_CERTIFICATION_DEFERRED';s['stop_reason']='ALL_CELLS_EVALUATED'
        with self.assertRaises(ValueError):ref.check_checkpoint(s,r)

if __name__=='__main__':unittest.main(verbosity=2)
