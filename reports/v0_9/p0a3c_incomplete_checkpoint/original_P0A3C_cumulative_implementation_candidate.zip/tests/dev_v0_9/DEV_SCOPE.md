# Pre-execution bounded DEV declaration

Declared before the first test invocation. This file and all source/tests will
be snapshotted before every attempt; commands, stdout/stderr, failures and
post-fix diffs remain in reports/v0_9/p0a3_implementation/dev_history/.

Only tests/dev_v0_9/test_microcontracts.py is authorized here, invoked by its
explicit filename with Python unittest. No broad discovery, pytest, inherited
tests, P0A0 import, optimizers, coverage/separation sweep, glyph proxy or object
versus target search. The fixtures are newly typed generic integer/rational
line segments, short broken lines and finite point sets, not copied coordinates
or oracles. No fixture is an intended letter or historical 3D candidate.

Categories, declared before execution:

1. Strict input/JSON schema, immutable copies, deterministic hashes and serialization.
2. Empty/nonfinite/bad dimension/unsupported observation and false-certification rejection.
3. Fresh line and broken-line du moments/correlations; comparison with independent
   rational antiderivatives; exact duplicate versus nonconsecutive return semantics.
4. Explicit reversal/reflection options; ordinary planar transforms; cancellation
   preserves an unresolved value instead of clamp-to-zero.
5. Fixed-angle finite-support directed extrema with independent exact quadratic
   surd references; no angle search or numerical benchmark.
6. Exact A/B pattern memberships, counts, strict nesting, antipodes and axis
   representatives. Emit exact manifests only, no covering/separation measures.
7. Canonical frame identities on three generic direction inputs; a single small
   centerline projection and its collapse events; independent symbolic reference.
8. Prospective certificate schemas and independent rejection of missing branches,
   cells, wrap gaps, inconsistent envelopes/provenance and forged certifications.
   Placeholder bounds are schema probes, never asserted geometric enclosures.
9. Static reference-import separation and unchanged exportable fairness policies.

For binary64 identity comparisons only, a predeclared DEV comparison allowance
of 256*ulp(max(1,abs(reference))) is used. It is a debugging assertion margin,
not a rigorously derived interval, scientific tolerance, future solver epsilon,
target threshold or parameter calibrated to outputs. It will not be increased
in response to a failure. Exact Fraction and integer checks use exact equality.
No wall-clock performance acceptance criterion, timing benchmark or random seed.

Tests may be corrected/expanded only inside these categories with original
attempt snapshots and diff retained. Scientific probes and arbitrary irrational
QO algebraic-backend qualification go to the future P0A4 catalogue, not a DEV
workaround.

Before attempt 02, static review identified three concrete interface risks
within categories 1/2/7: missing explicit result camera/config/budget binding,
unstructured projection overflow, and acceptance of a scored status with no
value. Tests 39–41 are declared to expose these before correction. No new
scientific category or tolerance is introduced.

Before attempt 04, final static review narrowed the unsupported tiny-scale
domain to include subnormal squared RMS (below sys.float_info.min). This is a
binary64 representability guard, not a scientific score epsilon; no numeric
output was used to tune it. Test 42 covers that specific remaining risk under
the already declared tiny-extent/invalid-input category. The comparison
allowance remains unchanged.
