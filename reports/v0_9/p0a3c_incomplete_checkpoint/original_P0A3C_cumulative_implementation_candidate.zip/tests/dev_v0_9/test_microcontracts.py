"""Fresh bounded DEV microexamples only; no registered fixture imports."""
import unittest
import math
import json
import hashlib
import dataclasses
from fractions import Fraction as F
from pathlib import Path
import ast
from meru_geometry.v0_9 import contracts, serialization, qo, qh, directions, projection, certificates
from meru_geometry.v0_9.exceptions import EngineeringError, UnresolvedProof
from reference.v0_9 import qo_rational, qh_exact, literal_directions, certificate_checker, projection_exact

ROOT=Path(__file__).resolve().parents[2]
HASH=hashlib.sha256(b"fresh generic DEV schema placeholder, not a proof").hexdigest()
A=((13,-8),(19,-8),(19,0))
B=((-6,17),(-6,29),(-1,29))

def geometry(points,kind="R2-O",**kw):
    default=dict(input_id="fresh-dev",units="abstract-unit",source_sha256=HASH,
                 ordered=kind!="R2-U",closed=None if kind=="R2-U" else False,
                 stroke_count=None if kind=="R2-U" else 1)
    default.update(kw)
    return contracts.Geometry(kind,points,**default)

def proposal(*,wrapped=False):
    mf=directions.manifest("A",0)
    branches=tuple(d["id"]+"|mirror=0" for d in mf["payload"]["directions"])
    cells=[]
    for b in branches:
        ranges=[("3/4","1/4","0/1"),("1/4","3/4","1/2")] if wrapped else [("0/1","1/1","1/2")]
        for i,(start,end,center) in enumerate(ranges):
            cells.append(certificates.CellProposal(b,str(i),start,end,center,
                          "0/1","1/1","0/1","1/1",HASH,HASH))
    p=certificates.ProofProposal("QH","A",0,mf["sha256"],(HASH,HASH),HASH,HASH,HASH,
        branches,tuple(cells),"0/1","1/1","1/1",
        tuple((x,"NOT_ESTABLISHED") for x in ("observation","sampling","projection","normalization","arithmetic","optimization")))
    d=json.loads(json.dumps(p.to_dict()))
    pins={k:d[k] for k in ("input_sha256","production_sha256","reference_sha256","configuration_sha256")}
    return d,mf,pins

class MicroDEV(unittest.TestCase):
    def near(self,a,b):
        self.assertLessEqual(abs(a-b),256*math.ulp(max(1.0,abs(b))))

    def test_01_geometry_copy_and_fingerprint(self):
        p=[[13,-8],[19,-8]];g=geometry(p);p[0][0]=0
        self.assertEqual(g.coordinates[0],(13.,-8.))
        self.assertEqual(g.fingerprint,geometry(((13,-8),(19,-8))).fingerprint)
        with self.assertRaises(dataclasses.FrozenInstanceError):g.units="changed"

    def test_02_nonfinite_bool_inexact_integer_rejected(self):
        for bad in (float("nan"),float("inf"),True,2**53+1):
            with self.assertRaises(EngineeringError):geometry(((bad,0),(1,1)))

    def test_03_bad_dimension_and_observation_rejected(self):
        with self.assertRaises(EngineeringError):geometry(((1,2,3),(4,5,6)))
        with self.assertRaises(EngineeringError):geometry(((1,2),(3,4)),kind="R2-H")

    def test_04_json_roundtrip(self):
        g=geometry(A);s=serialization.dumps(g)
        self.assertEqual(serialization.dumps(serialization.loads(s)),s)

    def test_05_json_extra_duplicate_and_nonfinite_rejected(self):
        d=json.loads(serialization.dumps(geometry(A)));d["payload"]["hidden_mask"]=True
        with self.assertRaises(EngineeringError):serialization.loads(json.dumps(d))
        with self.assertRaises(EngineeringError):serialization.loads('{"x":1,"x":2}')
        with self.assertRaises(EngineeringError):serialization.loads('{"x":NaN}')

    def test_06_certification_flags_unrepresentable(self):
        for status in ("GLOBAL_CERTIFIED","BOUNDED_APPROXIMATION"):
            with self.assertRaises(EngineeringError):
                contracts.Result("QO",status,0.,0.,(HASH,HASH),contracts.Options())
        with self.assertRaises(UnresolvedProof):certificates.promote_to_certified(success=True)

    def test_07_options_need_explicit_sensitivity(self):
        with self.assertRaises(EngineeringError):contracts.Options(group="O2")
        with self.assertRaises(EngineeringError):contracts.Options(allow_reversal=True)
        self.assertEqual(contracts.Options("O2",False,"dev-explicit-mirror").group,"O2")

    def test_08_qo_fresh_line_integral(self):
        g=geometry(((13,-8),(19,-8)))
        p=qo.parameterize(g);self.assertEqual(p.normalization.centroid,(16.,-8.))
        self.near(p.normalization.rms,math.sqrt(3.))
        ref=qo_rational.evaluate(((13,-8),(19,-8)),((13,-8),(19,-8)))
        self.assertEqual(ref["variance"],(F(3),F(3)))
        self.assertEqual(ref["squared_score_rational"],0)

    def test_09_qo_duplicate_and_return_semantics(self):
        p=qo.parameterize(geometry(((13,-8),(13,-8),(19,-8),(13,-8))))
        self.assertEqual(len(p.points),3);self.assertEqual(len(p.normalization.events),1)
        self.assertEqual(p.points[0],p.points[-1])

    def test_10_qo_empty_zero_closed_missing_order_multistroke(self):
        for g in (geometry(()),geometry(((13,-8),(13,-8))),geometry(A,closed=True),
                  geometry(A,ordered=None),geometry(A,stroke_count=2)):
            r=qo.evaluate(g,geometry(B));self.assertEqual(r.status,"NOT_EVALUABLE")
            self.assertIsNone(r.value)

    def test_11_qo_broken_line_independent_correlations(self):
        x,y=qo.parameterize(geometry(A)),qo.parameterize(geometry(B))
        aa,bb=qo.correlations(x,y);r=qo_rational.evaluate(A,B)
        den=math.sqrt(float(r["variance"][0]*r["variance"][1]))
        self.near(aa,float(r["raw_alpha"])/den);self.near(bb,float(r["raw_beta"])/den)
        out=qo.evaluate(geometry(A),geometry(B))
        self.assertEqual(out.certification,contracts.DEFERRED)
        self.near(out.value,math.sqrt(2-2*math.sqrt(float(r["correlation_squared"]))))

    def test_12_qo_transform_and_result_serialization(self):
        target=tuple((31-y,7+x) for x,y in A)
        r=qo.evaluate(geometry(A),geometry(target))
        self.assertIn(r.status,(contracts.DEFERRED,"UNRESOLVED_PROOF"))
        self.near(r.squared_estimate,0.)
        s=serialization.dumps(r);self.assertEqual(serialization.dumps(serialization.loads(s)),s)

    def test_13_qo_reversal_permission(self):
        opt=contracts.Options(allow_reversal=True,permission_id="dev-reversal")
        ref=qo_rational.evaluate(A,tuple(reversed(A)),allow_reversal=True)
        self.assertTrue(ref["reversed"]);self.assertEqual(ref["squared_score_rational"],0)
        out=qo.evaluate(geometry(A),geometry(tuple(reversed(A))),opt)
        self.assertTrue(dict(out.witness)["reversed"])
        self.assertEqual(qo.evaluate(geometry(A),geometry(tuple(reversed(A)))).options.allow_reversal,False)

    def test_14_qo_reflection_separate(self):
        target=tuple((x,-y) for x,y in A)
        opt=contracts.Options("O2",False,"dev-mirror")
        r=qo.evaluate(geometry(A),geometry(target),opt)
        self.assertTrue(dict(r.witness)["mirror"])
        self.assertEqual(qo_rational.evaluate(A,target,allow_reflection=True)["squared_score_rational"],0)

    def test_15_qo_reference_declines_irrational_length(self):
        with self.assertRaises(qo_rational.ReferenceUnavailable):
            qo_rational.evaluate(((2,7),(3,8)),((2,7),(4,7)))

    def test_16_qo_never_clamps_nonpositive_radicand(self):
        r=qo.evaluate(geometry(((13,-8),(19,-8))),geometry(((13,-8),(19,-8))))
        if r.squared_estimate<=0:
            self.assertIsNone(r.value);self.assertEqual(r.status,"UNRESOLVED_PROOF")
        else:
            self.assertEqual(r.status,contracts.DEFERRED)
        self.assertIn("BINARY64_ONLY_NO_OUTWARD_ENCLOSURE",r.diagnostics)

    def test_17_qh_exact_duplicate_no_near_merge(self):
        x=qh.normalize(geometry(((2,5),(2,5),(2+2**-20,5),(7,9)),"R2-U"))
        self.assertEqual(len(x.points),3)
        self.assertIn("EXACT_DUPLICATES_REMOVED:1",x.normalization.events)

    def test_18_qh_empty_and_point(self):
        for pts in ((),((2,5),),((2,5),(2,5))):
            r=qh.evaluate_at_angle(geometry(pts,"R2-U"),geometry(B,"R2-U"),0)
            self.assertEqual(r.status,"NOT_EVALUABLE");self.assertIsNone(r.value)

    def test_19_qh_scalar_directed_pair_extrema(self):
        a=((2.,5.),(7.,5.));b=((3.,5.),(5.,5.),(7.,5.))
        da,db=qh.pair_extrema(a,b)
        self.assertEqual(da,1.);self.assertEqual(db,2.)

    def test_20_qh_independent_normalized_surd_reference(self):
        r=qh.evaluate_at_angle(geometry(A,"R2-U"),geometry(B,"R2-U"),0)
        ref=qh_exact.evaluate(A,B);a,b=ref["hausdorff_squared"]
        expected=math.sqrt(float(a)+float(b)*math.sqrt(float(ref["radicand"])))
        self.near(r.value,expected);self.assertEqual(r.status,"LOCAL_ONLY")
        self.assertEqual(r.certification,contracts.DEFERRED)

    def test_21_qh_rational_unit_rotation(self):
        target=tuple((-y,x) for x,y in A)
        r=qh_exact.evaluate(A,target,cosine="0",sine="1")
        a,b=r["hausdorff_squared"]
        self.assertEqual(qh_exact.sign_surd(a,b,r["radicand"]),0)
        with self.assertRaises(ValueError):qh_exact.evaluate(A,B,cosine="1",sine="1")

    def test_22_qh_forbids_hidden_mirror_and_reversal(self):
        a,b=geometry(A,"R2-U"),geometry(B,"R2-U")
        with self.assertRaises(EngineeringError):qh.evaluate_at_angle(a,b,0,mirror=True)
        with self.assertRaises(EngineeringError):qh.evaluate_at_angle(a,b,0,contracts.Options(allow_reversal=True,permission_id="dev"))

    def test_23_qh_surd_comparisons(self):
        self.assertEqual(qh_exact.sign_surd(F(2),F(-1),F(4)),0)
        self.assertEqual(qh_exact.sign_surd(F(-1),F(1),F(2)),1)
        self.assertEqual(qh_exact.sign_surd(F(1),F(-1),F(2)),-1)

    def test_24_direction_exact_manifests_and_counts(self):
        out=ROOT/"reports/v0_9/p0a3_implementation/direction_manifests"
        out.mkdir(exist_ok=True,parents=True)
        for family,counts in (("A",(6,14,26)),("B",(6,18,42))):
            for tier,count in enumerate(counts):
                for group in ("SO2","O2"):
                    mf=directions.manifest(family,tier,group)
                    self.assertEqual(len(mf["payload"]["directions"]),count if group=="SO2" else count//2)
                    self.assertEqual(literal_directions.check_manifest(mf)["membership"],"EXACT_LITERAL_MATCH")
                    (out/f"{family}_G{tier}_{group}.json").write_text(json.dumps(mf,indent=2)+"\n")

    def test_25_direction_nesting_and_shared_g0(self):
        def triples(f,t):return [d.triple for d in directions.directions(f,t)]
        self.assertEqual(triples("A",0),triples("B",0))
        for f in ("A","B"):
            a,b,c=triples(f,0),triples(f,1),triples(f,2)
            self.assertEqual(b[:len(a)],a);self.assertEqual(c[:len(b)],b)
            self.assertTrue(set(a)<set(b)<set(c))

    def test_26_antipodes_and_axis_representatives(self):
        ds=directions.directions("B",2);vs={d.triple for d in ds}
        self.assertTrue(all(tuple(-x for x in v) in vs for v in vs))
        self.assertTrue(all(next(x for x in d.triple if x)>0 for d in directions.directions("B",2,"O2")))
        with self.assertRaises(EngineeringError):directions.Direction("A",0,"C",(1,1,1))

    def test_27_three_frame_identities_and_reference(self):
        for d in (directions.Direction("A",0,"A0",(0,0,1)),
                  directions.Direction("A",1,"C",(-1,1,1)),
                  directions.Direction("B",2,"T",(2,-1,0))):
            frame=directions.frame_lift(d);ref=literal_directions.exact_lift_witness(d.triple)
            for i,row in enumerate(frame.rows):
                for k,value in enumerate(row):
                    self.near(value,ref["row_integer_numerators"][i][k]/math.sqrt(ref["row_denominator_square"][i]))
            self.assertTrue(ref["exact_properness_identity"])

    def test_28_frame_antipode_and_seam(self):
        d=directions.Direction("A",1,"C",(1,1,1))
        a=directions.frame_lift(d);b=directions.frame_lift(directions.Direction("A",1,"C",(-1,-1,-1)))
        self.assertEqual(a.basis_index,0);self.assertEqual(a.seam_tie_indices,(0,1,2))
        self.assertEqual(a.rows[0],b.rows[0])
        self.assertEqual(a.rows[1],tuple(-x for x in b.rows[1]))

    def test_29_projection_and_collapse_events(self):
        pts=((2,-5,7),(4,-2,7),(4,-2,11))
        d=directions.Direction("A",0,"A0",(0,0,1))
        r=projection.project(geometry(pts,"R3-C"),d)
        self.assertEqual(r.geometry.coordinates,((2.,-5.),(4.,-2.),(4.,-2.)))
        self.assertIn("PROJECTED_CONSECUTIVE_COLLAPSE:1",r.events)
        exact=projection_exact.project(pts,d.triple)
        self.assertEqual(exact["coordinates"][0][0]["numerator"],2)
        self.assertFalse(exact["physical_shadow"])

    def test_30_certificate_complete_is_still_unresolved(self):
        d,m,p=proposal();r=certificate_checker.check(d,m,p)
        self.assertEqual(r["status"],"UNRESOLVED_PROOF");self.assertTrue(r["no_certification_promotion"])

    def test_31_certificate_wrap_structure(self):
        d,m,p=proposal(wrapped=True);r=certificate_checker.check(d,m,p)
        self.assertEqual(r["full_circle_partition"],"EXACT_RATIONAL_STRUCTURAL_MATCH")

    def test_32_certificate_missing_cell_rejected(self):
        d,m,p=proposal();d["cells"].pop()
        with self.assertRaises(ValueError):certificate_checker.check(d,m,p)

    def test_33_certificate_gap_and_overlap_rejected(self):
        for start in ("1/4","3/4"):
            d,m,p=proposal(wrapped=True);d["cells"][1]["start_turn"]=start
            if start=="1/4":d["cells"][1]["end_turn"]="1/2"
            with self.assertRaises(ValueError):certificate_checker.check(d,m,p)

    def test_34_certificate_provenance_and_bounds_rejected(self):
        d,m,p=proposal();d["configuration_sha256"]="0"*64
        with self.assertRaises(ValueError):certificate_checker.check(d,m,p)
        d,m,p=proposal();d["epsilon"]="0/1"
        with self.assertRaises(ValueError):certificate_checker.check(d,m,p)
        d,m,p=proposal();d["cells"][0]["center_lower"]="2/1"
        with self.assertRaises(ValueError):certificate_checker.check(d,m,p)

    def test_35_certificate_no_claim_from_json(self):
        d,m,p=proposal();d["status"]="GLOBAL_CERTIFIED"
        with self.assertRaises(ValueError):certificate_checker.check(d,m,p)
        with self.assertRaises(EngineeringError):
            certificates.CellProposal("b","c","0/1","1/1","1/2","0/1","1/1","0/1","1/1",HASH,"not-a-hash")

    def test_36_reference_no_production_imports(self):
        for path in (ROOT/"reference/v0_9").glob("*.py"):
            tree=ast.parse(path.read_text())
            for node in ast.walk(tree):
                if isinstance(node,ast.Import):self.assertFalse(any(a.name.startswith("meru_geometry") for a in node.names))
                if isinstance(node,ast.ImportFrom):self.assertFalse((node.module or "").startswith("meru_geometry"))

    def test_37_exportable_identical_parity_policy(self):
        kw=dict(resource_policy_id="UNSELECTED",accuracy_policy_id="UNSELECTED")
        a=contracts.export_budget("QO","A",1,contracts.Options(),**kw)
        b=contracts.export_budget("QO","A",1,contracts.Options(),**kw)
        self.assertEqual(a,b);self.assertEqual(a["actual_candidate_null_parity"],"NOT_ESTABLISHED")
        self.assertFalse(a["crop"]);self.assertEqual(a["certification"],contracts.DEFERRED)

    def test_38_tiny_underflow_not_zero_match(self):
        g=geometry(((0,0),(2**-600,0)))
        r=qo.evaluate(g,geometry(A))
        self.assertEqual(r.status,"NOT_EVALUABLE");self.assertIsNone(r.value)

    def test_39_score_record_requires_context_fields(self):
        self.assertIn("context",{f.name for f in dataclasses.fields(contracts.Result)})
        r=qh.evaluate_at_angle(geometry(A,"R2-U"),geometry(B,"R2-U"),0)
        mf=directions.manifest("A",0)
        budget=contracts.export_budget("QH","A",0,contracts.Options(),
                                      resource_policy_id="DEV_SCHEMA_ONLY",accuracy_policy_id="UNSELECTED")
        bound=serialization.bind_result(r,manifest=mf,direction_id=mf["payload"]["directions"][0]["id"],
                         budget=budget,production_sha256=HASH,reference_sha256=HASH,configuration_sha256=HASH)
        self.assertEqual(bound.context.family,"A")
        self.assertEqual(bound.context.budget_sha256,contracts.digest(budget))
        self.assertEqual(serialization.dumps(serialization.loads(serialization.dumps(bound))),serialization.dumps(bound))
        with self.assertRaises(EngineeringError):
            serialization.bind_result(r,manifest=mf,direction_id="absent",budget=budget,
                         production_sha256=HASH,reference_sha256=HASH,configuration_sha256=HASH)

    def test_40_projection_overflow_is_structured(self):
        g=geometry(((1.7e308,-1.7e308,-1.7e308),),"R3-C")
        with self.assertRaises(EngineeringError):
            projection.project(g,directions.Direction("A",1,"C",(1,1,1)))

    def test_41_scored_status_cannot_have_missing_value(self):
        with self.assertRaises(EngineeringError):
            contracts.Result("QH","LOCAL_ONLY",None,None,(HASH,HASH),contracts.Options())

    def test_42_subnormal_energy_is_explicitly_unsupported(self):
        # Representation-domain guard, not a fitted scientific epsilon.
        pts=((0,0),(2**-530,0))
        for score in ("QO","QH"):
            with self.subTest(score=score):
                if score=="QO":r=qo.evaluate(geometry(pts),geometry(A))
                else:r=qh.evaluate_at_angle(geometry(pts,"R2-U"),geometry(A,"R2-U"),0)
                self.assertEqual(r.status,"NOT_EVALUABLE");self.assertIsNone(r.value)

if __name__=="__main__":
    unittest.main(verbosity=2)
